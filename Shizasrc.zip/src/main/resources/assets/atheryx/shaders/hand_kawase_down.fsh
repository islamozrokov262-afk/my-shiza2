#version 150

// Kawase downsampling pass.
//   uP0 = (uOffset.x, uOffset.y, uHalfPixel.x, uHalfPixel.y)

layout(std140) uniform Uniforms {
    mat4 uProj;
    vec4 uP0;
    vec4 uP1;
    vec4 uP2;
    vec4 uP3;
    vec4 uP4;
    vec4 uP5;
    vec4 uP6;
    vec4 uP7;
    vec4 uP8;
    vec4 uP9;
    vec4 uP10;
    vec4 uP11;
};

in vec2 vUV;
out vec4 fragColor;

uniform sampler2D Sampler0;

void main() {
    vec2 uv = vUV;
    vec2 halfPixel = uP0.zw * uP0.xy;

    vec4 sum = texture(Sampler0, uv) * 4.0;
    sum += texture(Sampler0, uv - halfPixel);
    sum += texture(Sampler0, uv + halfPixel);
    sum += texture(Sampler0, uv + vec2(halfPixel.x, -halfPixel.y));
    sum += texture(Sampler0, uv - vec2(halfPixel.x, -halfPixel.y));

    fragColor = sum / 8.0;
}