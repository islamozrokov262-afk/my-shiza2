#version 150

layout(std140) uniform Uniforms {
    mat4 uProj;
    vec4 uP0;
    vec4 uP1;
    vec4 uP2;
    vec4 uP3;
    vec4 uP4;
    vec4 uP5;
    vec4 uP6;
    vec4 uP7;
    vec4 uP8;
    vec4 uP9;
    vec4 uP10;
    vec4 uP11;
};

out vec2 vUV;

void main() {
    vec2 positions[3] = vec2[](
        vec2(-1.0, -1.0),
        vec2( 3.0, -1.0),
        vec2(-1.0,  3.0)
    );

    vec2 pos = positions[gl_VertexID];
    vUV = pos * 0.5 + 0.5;
    gl_Position = vec4(pos, 0.0, 1.0);
}