#version 150

// Kawase upsampling pass.
//   uP0 = (uOffset.x, uOffset.y, uHalfPixel.x, uHalfPixel.y)
//   uP5 = color (rgb)

layout(std140) uniform Uniforms {
    mat4 uProj;
    vec4 uP0;
    vec4 uP1;
    vec4 uP2;
    vec4 uP3;
    vec4 uP4;
    vec4 uP5;
    vec4 uP6;
    vec4 uP7;
    vec4 uP8;
    vec4 uP9;
    vec4 uP10;
    vec4 uP11;
};

in vec2 vUV;
out vec4 fragColor;

uniform sampler2D Sampler0;

void main() {
    vec2 uv = vUV;
    vec2 halfPixel = uP0.zw * uP0.xy;

    vec4 sum = texture(Sampler0, uv + vec2(-halfPixel.x * 2.0, 0.0));
    sum += texture(Sampler0, uv + vec2(-halfPixel.x, halfPixel.y)) * 2.0;
    sum += texture(Sampler0, uv + vec2(0.0, halfPixel.y * 2.0));
    sum += texture(Sampler0, uv + vec2(halfPixel.x, halfPixel.y)) * 2.0;
    sum += texture(Sampler0, uv + vec2(halfPixel.x * 2.0, 0.0));
    sum += texture(Sampler0, uv + vec2(halfPixel.x, -halfPixel.y)) * 2.0;
    sum += texture(Sampler0, uv + vec2(0.0, -halfPixel.y * 2.0));
    sum += texture(Sampler0, uv + vec2(-halfPixel.x, -halfPixel.y)) * 2.0;

    vec4 result = sum / 12.0;
    fragColor = vec4(result.rgb * uP5.rgb, result.a);
}