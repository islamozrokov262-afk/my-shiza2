#version 150

// Маска руки = разница цвета кадра ДО и ПОСЛЕ рендера рук.
//   Sampler0 — сцена до рук
//   Sampler1 — сцена после рук

layout(std140) uniform Uniforms {
    mat4 uProj;
    vec4 uP0;
    vec4 uP1;
    vec4 uP2;
    vec4 uP3;
    vec4 uP4;
    vec4 uP5;
    vec4 uP6;
    vec4 uP7;
    vec4 uP8;
    vec4 uP9;
    vec4 uP10;
    vec4 uP11;
};

in vec2 vUV;
out vec4 fragColor;

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

void main() {
    vec4 before = texture(Sampler0, vUV);
    vec4 after = texture(Sampler1, vUV);

    vec3 colorDiff = abs(after.rgb - before.rgb);
    float maxColorDiff = max(max(colorDiff.r, colorDiff.g), colorDiff.b);
    float isHand = maxColorDiff > 0.01 ? 1.0 : 0.0;

    float topDistance = 1.0 - vUV.y;
    isHand *= smoothstep(0.012, 0.075, topDistance);

    fragColor = vec4(isHand, isHand, isHand, isHand);
}