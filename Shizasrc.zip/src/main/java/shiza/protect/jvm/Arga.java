package shiza.protect.jvm;

import java.io.IOException;
import java.io.InputStream;

public final class Arga {
   public static final String CLASS_NAME = "shiza.protect.jvm.Arga";
   public static final int A = 65;
   public static final int R = 82;
   public static final int G = 71;
   public static final byte[] ARGA = new byte[]{65, 82, 71, 65};
   private static final byte[] f_1_eaa3 = new byte[]{-54, -2, -70, -66};
   private static final String f_2_5662 = "shiza.jvm.arga";
   private static final String f_3_1692 = "41.52.47.41";

   private Arga() {
   }

   public static String token() {
      long h = -3750763034362895579L;

      for(int i = 0; i < 4; ++i) {
         long var3 = h ^ (long)ARGA[i];
         h = var3 * 1099511628211L;
      }

      return String.format("%016x", h);
   }

   public static boolean jvmArga() {
      return "41.52.47.41".equals(System.getProperty("shiza.jvm.arga"));
   }

   public static native boolean nativeAlive();

   public static native int[] nativeSalt();

   public static native Class<?> defineClassNative(ClassLoader var0, String var1, byte[] var2);

   public static int[] saltInts() {
      try {
         int[] s = nativeSalt();
         return s == null ? new int[0] : s;
      } catch (Throwable var1) {
         return new int[0];
      }
   }

   public static Class<?> defineClassSafely(ClassLoader loader, String name, byte[] bytes) {
      try {
         return defineClassNative(loader, name, bytes);
      } catch (Throwable var4) {
         return null;
      }
   }

   public static boolean selfStamped() {
      byte[] bytes = readOwnClassBytes();
      return bytes != null && bytes.length >= 4 && hasMagicPrefix(bytes, ARGA) && !hasMagicPrefix(bytes, f_1_eaa3);
   }

   public static void assertProtected() {
      if (!jvmArga()) {
         throw new IllegalStateException("Shiza JVM required: shiza.jvm.arga missing.");
      } else if (!nativeAlive()) {
         throw new IllegalStateException("Shiza JVM wrapper DLL not alive.");
      } else if (!selfStamped()) {
         throw new IllegalStateException("Shiza jar is not ARGA-stamped.");
      }
   }

   private static byte[] readOwnClassBytes() {
      try (InputStream in = Arga.class.getResourceAsStream("/shiza/protect/jvm/Arga.class")) {
         if (in == null) {
            return null;
         } else {
            return in.readAllBytes();
         }
      } catch (IOException var5) {
         return null;
      }
   }

   private static boolean hasMagicPrefix(byte[] data, byte[] magic) {
      for(int i = 0; i < magic.length; ++i) {
         if (data[i] != magic[i]) {
            return false;
         }
      }

      return true;
   }
}
