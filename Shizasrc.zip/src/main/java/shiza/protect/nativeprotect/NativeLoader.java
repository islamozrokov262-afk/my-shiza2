package shiza.protect.nativeprotect;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Method;
import shiza.protect.NativeGuard;

public final class NativeLoader extends ClassLoader {
   private static final NativeLoader INSTANCE = new NativeLoader(NativeLoader.class.getClassLoader());

   private NativeLoader(ClassLoader parent) {
      super(parent);
   }

   public static NativeLoader getInstance() {
      return INSTANCE;
   }

   public Class<?> load(String className) throws ClassNotFoundException {
      synchronized(this.getClassLoadingLock(className)) {
         Class<?> loaded = this.findLoadedClass(className);
         if (loaded != null) {
            return loaded;
         } else {
            byte[] bytes = nativeBytes(className.replace('.', '/'));
            return bytes != null && bytes.length != 0 ? this.defineClass(className, bytes, 0, bytes.length) : super.loadClass(className);
         }
      }
   }

   public Object invokePayload(String className) {
      try {
         Class<?> cls = this.load(className);
         Method method = cls.getDeclaredMethod("payload");
         method.setAccessible(true);
         MethodHandle handle = MethodHandles.lookup().unreflect(method);
         return handle.invokeWithArguments();
      } catch (Throwable var5) {
         return null;
      }
   }

   public boolean isEmbeddedAvailable() {
      return NativeGuard.isNativeReady();
   }

   private static native byte[] nativeBytes(String var0);
}
