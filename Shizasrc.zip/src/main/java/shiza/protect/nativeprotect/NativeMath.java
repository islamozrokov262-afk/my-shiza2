package shiza.protect.nativeprotect;

import shiza.protect.NativeGuard;

public final class NativeMath {
   public static boolean ensureNative() {
      NativeGuard.init();
      return NativeGuard.isNativeReady();
   }

   public static native int add(int var0, int var1);

   public static native String greet(String var0);
}
