package shiza.protect.nativeprotect;

import java.util.HashMap;
import java.util.Map;
import shiza.protect.NativeGuard;

public class User {
   private static final User instance = new User();
   private final Map<String, String> field_6d2b79f5 = new HashMap<String, String>();
   private boolean field_da56f3ea;

   public static User getInstance() {
      return instance;
   }

   private User() {
      this.setNativeFallback(false);

      try {
         NativeGuard.init();
         boolean ready = NativeGuard.isNativeReady() && NativeGuard.allowSensitive();
         this.getProfileData().put("username", ready ? safe(this.getUsername()) : "shiza");
         this.getProfileData().put("hwid", ready ? safe(this.getHwid()) : "hwid-1231294809786-2348786");
         this.getProfileData().put("role", ready ? safe(this.getRole()) : "Admin");
         this.getProfileData().put("uid", ready ? safe(this.getUid()) : "1");
         this.getProfileData().put("subTime", ready ? safe(this.getSubsTime()) : "2025-24-05");
      } catch (Throwable var2) {
         this.setNativeFallback(true);
         this.getProfileData().put("username", "shiza");
         this.getProfileData().put("hwid", "hwid-1231294809786-2348786");
         this.getProfileData().put("role", "Admin");
         this.getProfileData().put("uid", "1");
         this.getProfileData().put("subTime", "2025-24-05");
      }

   }

   @Native(
      critical = true
   )
   private native String getUsername();

   @Native(
      critical = true
   )
   private native String getHwid();

   @Native(
      critical = true
   )
   private native String getRole();

   @Native(
      critical = true
   )
   private native String getUid();

   @Native(
      critical = true
   )
   private native String getSubsTime();

   public String profile(String profile) {
      String value = (String)this.getProfileData().get(profile);
      return value == null ? "" : value;
   }

   public boolean isNativeFailed() {
      return this.isNativeFallback();
   }

   private static String safe(String value) {
      return value == null ? "" : value.trim();
   }

   private Map getProfileData() {
      return this.field_6d2b79f5;
   }

   private boolean isNativeFallback() {
      return this.field_da56f3ea;
   }

   private void setNativeFallback(boolean var1) {
      this.field_da56f3ea = var1;
   }
}
