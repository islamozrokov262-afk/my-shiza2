package shiza.protect;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Locale;

public final class Protector {
   private Protector() {
   }

   public static boolean debugDetected() {
      return hasJdwpDebugArguments() || hasNativeAgentArguments() || hasDiagnosticOrJavaAgentArguments() || hasDebugOrAgentEnvironmentOptions();
   }

   public static boolean dumpDetected() {
      return isCurrentJvmListedByAttachApi() || hasHeapDumpArguments();
   }

   public static boolean analyze() {
      return debugDetected() || dumpDetected();
   }

   private static String launcherTokenPropertyName() {
      return "shiza.launcher.token";
   }

   private static String launcherTokenSecret() {
      return "ShizaLauncherKey_0x7A91F3";
   }

   private static String computeExpectedLauncherToken() {
      String secret = launcherTokenSecret();
      long h = -3750763034362895579L;

      for(int i = 0; i < secret.length(); ++i) {
         long var4 = h ^ (long)secret.charAt(i);
         h = var4 * 1099511628211L;
      }

      return String.format("%016x", h);
   }

   public static boolean launcherValid() {
      String provided = System.getProperty(launcherTokenPropertyName());
      return provided == null ? false : provided.trim().equalsIgnoreCase(computeExpectedLauncherToken());
   }

   private static boolean hasJdwpDebugArguments() {
      for(String arg : getJvmInputArguments()) {
         String a = arg.toLowerCase(Locale.ROOT);
         if (a.contains("jdwp") || a.contains("dt_socket") || a.contains("-xdebug") || a.contains("-xrunjdwp")) {
            return true;
         }
      }

      return false;
   }

   private static boolean hasNativeAgentArguments() {
      for(String arg : getJvmInputArguments()) {
         String a = arg.toLowerCase(Locale.ROOT);
         if (a.contains("agentlib:") || a.contains("agentpath:")) {
            return true;
         }
      }

      return false;
   }

   private static boolean hasDiagnosticOrJavaAgentArguments() {
      for(String arg : getJvmInputArguments()) {
         String a = arg.toLowerCase(Locale.ROOT);
         if (a.equals("-debug") || a.contains("-xx:+startflightrecording") || a.contains("-javaagent:")) {
            return true;
         }
      }

      return false;
   }

   private static boolean hasDebugOrAgentEnvironmentOptions() {
      String[] vars = new String[]{"JAVA_TOOL_OPTIONS", "JDK_JAVA_OPTIONS", "_JAVA_OPTIONS", "JAVA_AGENTS"};

      for(String v : vars) {
         String val = System.getenv(v);
         if (val != null) {
            String lower = val.toLowerCase(Locale.ROOT);
            if (lower.contains("agentlib:") || lower.contains("agentpath:") || lower.contains("javaagent:") || lower.contains("jdwp")) {
               return true;
            }
         }
      }

      return false;
   }

   private static boolean isCurrentJvmListedByAttachApi() {
      try {
         Class<?> vm = Class.forName("com.sun.tools.attach.VirtualMachine");
         Method list = vm.getMethod("list");
         Iterable<?> vms = (Iterable<?>)list.invoke((Object)null);
         Class<?> descClass = Class.forName("com.sun.tools.attach.VirtualMachineDescriptor");
         Method display = descClass.getMethod("displayName");
         Method id = descClass.getMethod("id");

         for(Object v : vms) {
            Object vId = id.invoke(v);
            String displayed = String.valueOf(display.invoke(v));
            if (String.valueOf(vId).equals(getCurrentProcessId()) && !displayed.equals("")) {
               return true;
            }
         }
      } catch (Throwable var12) {
      }

      return false;
   }

   private static boolean hasHeapDumpArguments() {
      for(String arg : getJvmInputArguments()) {
         String a = arg.toLowerCase(Locale.ROOT);
         if (a.contains("heapdump") || a.contains("hprof")) {
            return true;
         }
      }

      return false;
   }

   private static List<String> getJvmInputArguments() {
      try {
         RuntimeMXBean bean = ManagementFactory.getRuntimeMXBean();
         return bean.getInputArguments() == null ? List.of() : bean.getInputArguments();
      } catch (Throwable var1) {
         return List.<String>of();
      }
   }

   private static String getCurrentProcessId() {
      try {
         String name = ManagementFactory.getRuntimeMXBean().getName();
         int at = name.indexOf(64);
         return at < 0 ? name : name.substring(0, at);
      } catch (Throwable var2) {
         return "";
      }
   }
}
