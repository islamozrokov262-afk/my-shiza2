package shiza.protect;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.CodeSource;
import java.security.MessageDigest;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.CRC32;

public final class NativeGuard {
   public static final String PRIMARY_LIB = "shizaguard";
   public static final String FALLBACK_LIB = "obfcore";
   private static final String f_1_ed3b = "/META-INF/shizaguard/guard.fp";
   private static final String f_2_530c = "META-INF/shizaguard/guard.fp";
   private static final AtomicBoolean f_3_36f2 = new AtomicBoolean(false);
   private static volatile boolean f_4_a185;
   private static volatile String f_5_89bd = "";
   private static volatile boolean f_6_1cb;

   private NativeGuard() {
   }

   public static void init() {
      if (f_3_36f2.compareAndSet(false, true)) {
         if (!Protector.launcherValid()) {
            Runtime.getRuntime().halt(9);
         } else {
            try {
               f_5_89bd = computeJarFingerprint();
               f_4_a185 = tryLoadNativeLibrary("shizaguard") || tryLoadNativeLibrary("obfcore");
               if (f_4_a185) {
                  try {
                     nativePing();
                  } catch (UnsatisfiedLinkError var1) {
                  }
               }

               f_6_1cb = !passesIntegrityCheck() || Protector.analyze() || !Protector.launcherValid();
            } catch (Throwable var2) {
               f_4_a185 = false;
               f_6_1cb = true;
            }

         }
      }
   }

   public static boolean isNativeReady() {
      return f_4_a185;
   }

   public static boolean isTampered() {
      return f_6_1cb;
   }

   public static String jarFingerprint() {
      return f_5_89bd;
   }

   public static boolean enforced() {
      String fp = f_5_89bd;
      return !fp.isEmpty() && !fp.equals("dev") && !fp.equals("classpath") && !fp.equals("unknown") ? resourceExists("/META-INF/shizaguard/guard.fp") : false;
   }

   @Protect("gate")
   public static boolean allowSensitive() {
      if (f_6_1cb) {
         return false;
      } else {
         boolean expectsNative = resourceExists("/META-INF/shizaguard/native/win-x64/shizaguard.dll") || resourceExists("/META-INF/shizaguard/native/win-x64/obfcore.dll") || resourceExists("/META-INF/shizaguard/native/linux-x64/libshizaguard.so") || resourceExists("/META-INF/shizaguard/native/linux-x64/libobfcore.so");
         return !expectsNative || f_4_a185;
      }
   }

   private static boolean resourceExists(String path) {
      try {
         boolean var2;
         try (InputStream in = NativeGuard.class.getResourceAsStream(path)) {
            var2 = in != null;
         }

         return var2;
      } catch (Throwable var6) {
         return false;
      }
   }

   private static boolean passesIntegrityCheck() {
      return !enforced() ? true : verifyJarAgainstGuardManifest();
   }

   private static boolean verifyJarAgainstGuardManifest() {
      Map<String, String> expected = new LinkedHashMap<String, String>();

      long total;
      try {
         total = Long.parseUnsignedLong(readGuardManifest(expected), 16);
      } catch (Throwable var14) {
         return false;
      }

      Path jar = getCodeSourcePath();
      if (jar != null && Files.isRegularFile(jar)) {
         try {
            CRC32 totalCrc = new CRC32();

            try (JarFile jf = new JarFile(jar.toFile())) {
               Enumeration<JarEntry> entries = jf.entries();

               while(entries.hasMoreElements()) {
                  JarEntry entry = entries.nextElement();
                  if (!entry.isDirectory() && !"META-INF/shizaguard/guard.fp".equals(entry.getName())) {
                     byte[] bytes;
                     try (InputStream in = jf.getInputStream(entry)) {
                        bytes = in.readAllBytes();
                     }

                     totalCrc.update(bytes);
                     String wanted = expected.get(entry.getName());
                     if (wanted != null) {
                        CRC32 single = new CRC32();
                        single.update(bytes);
                        if (!wanted.equals(formatCrc32Hex(single.getValue()))) {
                           boolean var11 = false;
                           return var11;
                        }
                     }
                  }
               }
            }

            return totalCrc.getValue() == total;
         } catch (Throwable var17) {
            return false;
         }
      } else {
         return false;
      }
   }

   private static String readGuardManifest(Map<String, String> out) throws Exception {
      try (InputStream in = NativeGuard.class.getResourceAsStream("/META-INF/shizaguard/guard.fp")) {
         if (in == null) {
            throw new IllegalStateException("guard manifest missing");
         } else {
            String text = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            String total = null;

            for(String line : text.split("\\r?\\n")) {
               if (!line.isEmpty()) {
                  int eq = line.indexOf(61);
                  if (eq <= 0) {
                     throw new IllegalStateException("bad manifest line");
                  }

                  String key = line.substring(0, eq);
                  String value = line.substring(eq + 1).trim();
                  if (key.equals("total")) {
                     total = value;
                  } else {
                     out.put(key, value);
                  }
               }
            }

            if (total == null) {
               throw new IllegalStateException("manifest has no total");
            } else {
               return total;
            }
         }
      }
   }

   private static String formatCrc32Hex(long value) {
      return String.format("%08x", value);
   }

   private static Path getCodeSourcePath() {
      CodeSource cs = NativeGuard.class.getProtectionDomain().getCodeSource();
      if (cs != null && cs.getLocation() != null) {
         try {
            return Path.of(cs.getLocation().toURI());
         } catch (Throwable var2) {
            return null;
         }
      } else {
         return null;
      }
   }

   private static boolean tryLoadNativeLibrary(String libraryName) {
      try {
         String resourcePath = resolveNativeLibraryResourcePath(libraryName);
         if (resourcePath != null) {
            Path extracted = extractNativeLibraryResource(resourcePath);
            if (extracted != null) {
               System.load(extracted.toAbsolutePath().toString());
               return true;
            }
         }
      } catch (Throwable var4) {
      }

      try {
         System.loadLibrary(libraryName);
         return true;
      } catch (Throwable var3) {
         return false;
      }
   }

   private static Path extractNativeLibraryResource(String resourcePath) {
      try (InputStream in = NativeGuard.class.getResourceAsStream(resourcePath)) {
         if (in == null) {
            return null;
         } else {
            String suffix = resourcePath.endsWith(".dll") ? ".dll" : ".so";
            Path temp = Files.createTempFile("shiza-native-", suffix);
            Files.copy(in, temp, StandardCopyOption.REPLACE_EXISTING);
            temp.toFile().deleteOnExit();
            return temp;
         }
      } catch (Throwable var7) {
         return null;
      }
   }

   private static String resolveNativeLibraryResourcePath(String libraryName) {
      String os = normalizePlatformName(System.getProperty("os.name", ""));
      String arch = normalizePlatformName(System.getProperty("os.arch", ""));
      if (os.contains("win") && isX64Architecture(arch)) {
         return "/META-INF/shizaguard/native/win-x64/" + String.valueOf(libraryName) + ".dll";
      } else {
         return os.contains("linux") && isX64Architecture(arch) ? "/META-INF/shizaguard/native/linux-x64/lib" + String.valueOf(libraryName) + ".so" : null;
      }
   }

   private static boolean isX64Architecture(String arch) {
      return arch.contains("amd64") || arch.contains("x86_64");
   }

   private static String normalizePlatformName(String s) {
      return s.toLowerCase(Locale.ROOT);
   }

   private static String computeJarFingerprint() {
      try {
         CodeSource codeSource = NativeGuard.class.getProtectionDomain().getCodeSource();
         if (codeSource != null && codeSource.getLocation() != null) {
            Path path = Path.of(codeSource.getLocation().toURI());
            if (!Files.isRegularFile(path)) {
               return "classpath";
            } else {
               MessageDigest md = MessageDigest.getInstance("SHA-256");
               byte[] all = Files.readAllBytes(path);
               int n = all.length;
               int head = Math.min(n, 65536);
               int tail = Math.min(n, 65536);
               md.update(all, 0, head);
               if (n > head) {
                  md.update(all, n - tail, tail);
               }

               md.update(intToBigEndianBytes(n));
               byte[] dig = md.digest();
               StringBuilder sb = new StringBuilder(16);

               for(int i = 0; i < 8 && i < dig.length; ++i) {
                  sb.append(String.format("%02x", dig[i]));
               }

               return sb.toString();
            }
         } else {
            return "dev";
         }
      } catch (Throwable var10) {
         return "unknown";
      }
   }

   private static byte[] intToBigEndianBytes(int v) {
      return new byte[]{(byte)(v >>> 24), (byte)(v >>> 16), (byte)(v >>> 8), (byte)v};
   }

   private static native void nativePing();
}
