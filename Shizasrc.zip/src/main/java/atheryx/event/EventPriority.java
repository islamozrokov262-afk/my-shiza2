package atheryx.event;

public enum EventPriority {
   LOWEST(0),
   LOW(1),
   NORMAL(2),
   HIGH(3),
   HIGHEST(4),
   MONITOR(5);

   private final int field_6d2b79f5;

   private EventPriority(int level) {
      this.field_6d2b79f5 = level;
   }

   public int getLevel() {
      return this.getLevelInternal();
   }

   private int getLevelInternal() {
      return this.field_6d2b79f5;
   }

}
