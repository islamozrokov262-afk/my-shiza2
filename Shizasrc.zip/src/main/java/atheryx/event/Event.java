package atheryx.event;

import lombok.Generated;

public abstract class Event {
   private boolean cancelled;

   public Event() {
      this.writeCancelled(false);
      this.writeCancelled(false);
   }

   @Generated
   public boolean isCancelled() {
      return this.readCancelled();
   }

   @Generated
   public void setCancelled(boolean cancelled) {
      this.writeCancelled(cancelled);
   }

   private boolean readCancelled() {
      return this.cancelled;
   }

   private void writeCancelled(boolean var1) {
      this.cancelled = var1;
   }

}
