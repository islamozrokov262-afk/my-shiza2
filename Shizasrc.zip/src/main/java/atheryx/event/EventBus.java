package atheryx.event;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventBus {
   private static final Map<Class<? extends Event>, List<ListenerEntry>> listenersByType = new ConcurrentHashMap<Class<? extends Event>, List<ListenerEntry>>();
   private static final Set<Object> registeredOwners = Collections.<Object>newSetFromMap(new ConcurrentHashMap());

   public static void register(Object object) {
      if (!registeredOwners.contains(object)) {
         registeredOwners.add(object);

         for(Method method : object.getClass().getDeclaredMethods()) {
            if (method.isAnnotationPresent(EventHandler.class) && method.getParameterCount() == 1) {
               Class<?> parameterType = method.getParameterTypes()[0];
               if (Event.class.isAssignableFrom(parameterType)) {
                  Class<? extends Event> paramType = parameterType.asSubclass(Event.class);
                  EventHandler annotation = (EventHandler)method.getAnnotation(EventHandler.class);
                  EventPriority priority = annotation.priority();
                  method.setAccessible(true);
                  (listenersByType.computeIfAbsent(paramType, (k) -> {
                     return new CopyOnWriteArrayList();
                  })).add(new ListenerEntry(object, method, priority));
                  (listenersByType.get(paramType)).sort(Comparator.comparingInt((l) -> {
                     return l.priority.getLevel();
                  }));
               }
            }
         }

      }
   }

   public static void unregister(Object object) {
      if (registeredOwners.contains(object)) {
         registeredOwners.remove(object);

         for(List<ListenerEntry> listenerList : listenersByType.values()) {
            listenerList.removeIf((listener) -> {
               return listener.owner == object;
            });
         }

      }
   }

   public static <T extends Event> T post(T event) {
      List<ListenerEntry> eventListeners = listenersByType.get(event.getClass());
      if (eventListeners != null && !eventListeners.isEmpty()) {
         for(ListenerEntry listener : eventListeners) {
            if (!event.isCancelled() || listener.priority.getLevel() >= EventPriority.HIGH.getLevel()) {
               try {
                  listener.method.invoke(listener.owner, event);
               } catch (Exception e) {
                  e.printStackTrace();
               }
            }
         }

         return event;
      } else {
         return event;
      }
   }

   public static boolean isRegistered(Object object) {
      return registeredOwners.contains(object);
   }

   public static void clear() {
      listenersByType.clear();
      registeredOwners.clear();
   }

   public static int getListenerCount(Class<? extends Event> eventClass) {
      List<ListenerEntry> list = listenersByType.get(eventClass);
      return list == null ? 0 : list.size();
   }


   private static class ListenerEntry {
      final Object owner;
      final Method method;
      final EventPriority priority;

      ListenerEntry(Object owner, Method method, EventPriority priority) {
         this.owner = owner;
         this.method = method;
         this.priority = priority;
      }

      private Object getOwnerInternal() {
         return this.owner;
      }

      private Method getMethodInternal() {
         return this.method;
      }

      private EventPriority getPriorityInternal() {
         return this.priority;
      }

   }
}
