package atheryx.event;

import atheryx.event.impl.KeyEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.gui.ClickGui;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.setting.impl.KeybindSetting;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public class EventManager {
   class_310 mc;
   public static ClickGui clickGui = new ClickGui();
   private final Map<Function, Boolean> field_da56f3ea;

   public EventManager() {
      this.setClientInternal(class_310.method_1551());
      this.field_da56f3ea = new HashMap<Function, Boolean>();
   }

   public static void post(Object event) {
      for(Function function : FunctionManager.getFunctions()) {
         if (function != null && function.isEnabled()) {
            for(Method method : function.getClass().getDeclaredMethods()) {
               if (method.isAnnotationPresent(EventHandler.class)) {
                  Class<?>[] params = method.getParameterTypes();
                  if (params.length == 1 && params[0].isAssignableFrom(event.getClass())) {
                     try {
                        method.setAccessible(true);
                        method.invoke(function, event);
                     } catch (Exception var9) {
                     }
                  }
               }
            }
         }
      }

   }

   @EventHandler
   public void onKey(KeyEvent event) {
      int key = event.getInput().comp_4795();
      int action = event.getAction();
      if (key == 344 && action == 1) {
         if (this.getClientInternal().field_1755 == clickGui) {
            clickGui.close();
         } else {
            this.getClientInternal().method_1507(clickGui);
         }
      }

      if (this.getClientInternal().field_1755 == null && action == 1) {
         for(Function function : FunctionManager.getFunctions()) {
            if (function.getKeybind() == key && function.getKeybind() > 0) {
               function.toggle();
            }
         }
      }

   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.getClientInternal().field_1755 == null && this.getClientInternal().method_22683() != null) {
         long window = this.getClientInternal().method_22683().method_4490();

         for(Function function : FunctionManager.getFunctions()) {
            int keybind = function.getKeybind();
            if (!KeybindSetting.isMouseBinding(keybind)) {
               this.getListenerCacheInternal().remove(function);
            } else {
               boolean down = GLFW.glfwGetMouseButton(window, KeybindSetting.keyToMouseButton(keybind)) == 1;
               boolean wasDown = (Boolean)this.getListenerCacheInternal().getOrDefault(function, false);
               if (down && !wasDown) {
                  function.toggle();
               }

               this.getListenerCacheInternal().put(function, down);
            }
         }

      } else {
         this.getListenerCacheInternal().clear();
      }
   }

   private class_310 getClientInternal() {
      return this.mc;
   }

   private void setClientInternal(class_310 var1) {
      this.mc = var1;
   }

   private Map getListenerCacheInternal() {
      return this.field_da56f3ea;
   }

}
