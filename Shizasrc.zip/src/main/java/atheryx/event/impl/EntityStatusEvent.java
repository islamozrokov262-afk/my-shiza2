package atheryx.event.impl;

import atheryx.event.Event;
import lombok.Generated;
import net.minecraft.class_1297;
import net.minecraft.class_2663;

public class EntityStatusEvent extends Event {
   private final class_2663 field_6d2b79f5;
   private final class_1297 field_da56f3ea;

   public EntityStatusEvent(class_2663 packet, class_1297 entity) {
      this.field_6d2b79f5 = packet;
      this.field_da56f3ea = entity;
   }

   @Generated
   public class_2663 getStatusPacket() {
      return this.getStatusPacketInternal();
   }

   @Generated
   public class_1297 getEntity() {
      return this.getEntityInternal();
   }

   private class_2663 getStatusPacketInternal() {
      return this.field_6d2b79f5;
   }

   private class_1297 getEntityInternal() {
      return this.field_da56f3ea;
   }

}
