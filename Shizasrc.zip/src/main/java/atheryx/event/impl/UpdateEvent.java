package atheryx.event.impl;

import atheryx.event.Event;

public class UpdateEvent extends Event {
}
