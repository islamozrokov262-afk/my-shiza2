package atheryx.event.impl;

import atheryx.event.Event;
import lombok.Generated;
import net.minecraft.class_7439;

public class GameMessageEvent extends Event {
   private final class_7439 field_6d2b79f5;

   public GameMessageEvent(class_7439 packet) {
      this.field_6d2b79f5 = packet;
   }

   @Generated
   public class_7439 getMessage() {
      return this.getMessageInternal();
   }

   private class_7439 getMessageInternal() {
      return this.field_6d2b79f5;
   }

}
