package atheryx.event.impl;

import atheryx.event.Event;
import lombok.Generated;
import net.minecraft.class_11908;

public class KeyEvent extends Event {
   int action;
   class_11908 input;

   @Generated
   public int getAction() {
      return this.getActionInternal();
   }

   @Generated
   public class_11908 getInput() {
      return this.getInputInternal();
   }

   @Generated
   public KeyEvent(int action, class_11908 input) {
      this.setActionInternal(action);
      this.setInputInternal(input);
   }

   private int getActionInternal() {
      return this.action;
   }

   private void setActionInternal(int var1) {
      this.action = var1;
   }

   private class_11908 getInputInternal() {
      return this.input;
   }

   private void setInputInternal(class_11908 var1) {
      this.input = var1;
   }

}
