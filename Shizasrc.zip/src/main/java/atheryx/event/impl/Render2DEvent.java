package atheryx.event.impl;

import atheryx.event.Event;
import lombok.Generated;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public class Render2DEvent extends Event {
   private final class_9779 field_6d2b79f5;
   private final class_332 field_da56f3ea;

   public Render2DEvent(class_9779 tickCounter) {
      this(tickCounter, (class_332)null);
   }

   public Render2DEvent(class_9779 tickCounter, class_332 context) {
      this.field_6d2b79f5 = tickCounter;
      this.field_da56f3ea = context;
   }

   @Generated
   public class_9779 getTickCounter() {
      return this.getTickCounterInternal();
   }

   @Generated
   public class_332 getDrawContext() {
      return this.getDrawContextInternal();
   }

   private class_9779 getTickCounterInternal() {
      return this.field_6d2b79f5;
   }

   private class_332 getDrawContextInternal() {
      return this.field_da56f3ea;
   }

}
