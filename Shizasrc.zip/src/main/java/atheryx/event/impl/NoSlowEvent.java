package atheryx.event.impl;

import atheryx.event.Event;

public class NoSlowEvent extends Event {
}
