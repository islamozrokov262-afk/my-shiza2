package atheryx.event.impl;

import atheryx.event.Event;
import net.minecraft.class_2596;

public class PacketSendEvent extends Event {
   private final class_2596<?> field_6d2b79f5;
   private boolean field_da56f3ea;

   public PacketSendEvent(class_2596<?> packet) {
      this.field_6d2b79f5 = packet;
   }

   public class_2596<?> getPacket() {
      return this.getPacketInternal();
   }

   public void cancel() {
      this.setCancelledInternal(true);
   }

   public boolean isCancelled() {
      return this.getCancelledInternal();
   }

   private class_2596 getPacketInternal() {
      return this.field_6d2b79f5;
   }

   private boolean getCancelledInternal() {
      return this.field_da56f3ea;
   }

   private void setCancelledInternal(boolean var1) {
      this.field_da56f3ea = var1;
   }

}
