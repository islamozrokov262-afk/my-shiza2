package atheryx.event.impl;

import atheryx.event.Event;
import lombok.Generated;

public class InputEvent extends Event {
   private float field_6d2b79f5;
   private float field_da56f3ea;
   private boolean field_47826ddf;
   private boolean field_b4ade7d4;
   private boolean field_21d961c9;

   @Generated
   public float getForward() {
      return this.getForwardInternal();
   }

   @Generated
   public float getStrafe() {
      return this.getStrafeInternal();
   }

   @Generated
   public boolean isJumping() {
      return this.getJumpingInternal();
   }

   @Generated
   public boolean isSneaking() {
      return this.getSneakingInternal();
   }

   @Generated
   public boolean isSprinting() {
      return this.getSprintingInternal();
   }

   @Generated
   public void setForward(float forward) {
      this.setForwardInternal(forward);
   }

   @Generated
   public void setStrafe(float strafe) {
      this.setStrafeInternal(strafe);
   }

   @Generated
   public void setJumping(boolean jump) {
      this.setJumpingInternal(jump);
   }

   @Generated
   public void setSneaking(boolean sneak) {
      this.setSneakingInternal(sneak);
   }

   @Generated
   public void setSprinting(boolean sprint) {
      this.setSprintingInternal(sprint);
   }

   @Generated
   public InputEvent(float forward, float strafe, boolean jump, boolean sneak, boolean sprint) {
      this.setForwardInternal(forward);
      this.setStrafeInternal(strafe);
      this.setJumpingInternal(jump);
      this.setSneakingInternal(sneak);
      this.setSprintingInternal(sprint);
   }

   private float getForwardInternal() {
      return this.field_6d2b79f5;
   }

   private void setForwardInternal(float var1) {
      this.field_6d2b79f5 = var1;
   }

   private float getStrafeInternal() {
      return this.field_da56f3ea;
   }

   private void setStrafeInternal(float var1) {
      this.field_da56f3ea = var1;
   }

   private boolean getJumpingInternal() {
      return this.field_47826ddf;
   }

   private void setJumpingInternal(boolean var1) {
      this.field_47826ddf = var1;
   }

   private boolean getSneakingInternal() {
      return this.field_b4ade7d4;
   }

   private void setSneakingInternal(boolean var1) {
      this.field_b4ade7d4 = var1;
   }

   private boolean getSprintingInternal() {
      return this.field_21d961c9;
   }

   private void setSprintingInternal(boolean var1) {
      this.field_21d961c9 = var1;
   }

}
