package atheryx.event.impl;

import atheryx.event.Event;
import lombok.Generated;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

public class AttackEntityEvent extends Event {
   private final class_1657 field_6d2b79f5;
   private final class_1297 field_da56f3ea;

   public AttackEntityEvent(class_1657 player, class_1297 target) {
      this.field_6d2b79f5 = player;
      this.field_da56f3ea = target;
   }

   @Generated
   public class_1657 getPlayer() {
      return this.getPlayerInternal();
   }

   @Generated
   public class_1297 getTarget() {
      return this.getTargetInternal();
   }

   private class_1657 getPlayerInternal() {
      return this.field_6d2b79f5;
   }

   private class_1297 getTargetInternal() {
      return this.field_da56f3ea;
   }

}
