package atheryx.event.impl;

import atheryx.event.Event;

public class PostMotionEvent extends Event {
}
