package atheryx.event.impl;

import atheryx.event.Event;
import lombok.Generated;
import net.minecraft.class_2338;

public class BlockPlaceEvent extends Event {
   private final class_2338 field_6d2b79f5;

   public BlockPlaceEvent(class_2338 pos) {
      this.field_6d2b79f5 = pos;
   }

   @Generated
   public class_2338 getBlockPos() {
      return this.getBlockPosInternal();
   }

   private class_2338 getBlockPosInternal() {
      return this.field_6d2b79f5;
   }

}
