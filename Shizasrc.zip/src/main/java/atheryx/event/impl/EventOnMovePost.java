package atheryx.event.impl;

import atheryx.event.Event;
import lombok.Generated;
import net.minecraft.class_243;

public class EventOnMovePost extends Event {
   private final float field_6d2b79f5;
   private final class_243 field_da56f3ea;

   @Generated
   public float getYaw() {
      return this.getYawInternal();
   }

   @Generated
   public class_243 getMovement() {
      return this.getMovementInternal();
   }

   @Generated
   public EventOnMovePost(float speed, class_243 movementInput) {
      this.field_6d2b79f5 = speed;
      this.field_da56f3ea = movementInput;
   }

   private float getYawInternal() {
      return this.field_6d2b79f5;
   }

   private class_243 getMovementInternal() {
      return this.field_da56f3ea;
   }

}
