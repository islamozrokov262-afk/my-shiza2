package atheryx.command;

import atheryx.neuro.NeuroCommand;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

public final class CommandManager {
   private CommandManager() {
   }

   public static boolean execute(String input) {
      return FriendCommand.execute(input) || ConfigCommand.execute(input) || BotCommand.execute(input) || NeuroCommand.execute(input) || executeParseCommand(input);
   }

   public static List<String> getSuggestions(String input) {
      String commandLine = input.stripLeading().toLowerCase(Locale.ROOT);
      if (".".equals(commandLine)) {
         return Stream.of(".friend", ".cfg", ".bot", ".neuro", ".нейро").sorted().toList();
      } else {
         return commandLine.startsWith(".p") && ".parse".startsWith(commandLine) ? List.of(".parse") : Stream.of(FriendCommand.getSuggestions(input).stream(), ConfigCommand.getSuggestions(input).stream(), BotCommand.getSuggestions(input).stream(), NeuroCommand.getSuggestions(input).stream()).flatMap((stream) -> {
            return stream;
         }).sorted(Comparator.naturalOrder()).toList();
      }
   }

   private static boolean executeParseCommand(String input) {
      if (!".parse".equalsIgnoreCase(input.strip())) {
         return false;
      } else {
         ParseCommand.execute();
         return true;
      }
   }

   public static String getInlineSuggestion(String input) {
      List<String> suggestions = getSuggestions(input);
      if (suggestions.isEmpty()) {
         return null;
      } else {
         String suggestion = suggestions.getFirst();
         if (!".friend".equals(suggestion) && !".cfg".equals(suggestion) && !".bot".equals(suggestion) && !".neuro".equals(suggestion) && !".нейро".equals(suggestion)) {
            return suggestion.endsWith("<nick>") ? suggestion.substring(0, suggestion.length() - "<nick>".length()) : suggestion;
         } else {
            return String.valueOf(suggestion) + " ";
         }
      }
   }

}
