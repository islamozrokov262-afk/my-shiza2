package atheryx.command;

import atheryx.manager.ConfigManager;
import atheryx.neuro.NeuroCommand;
import atheryx.neuro.NeuroManager;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.Locale;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2172;

public final class MinarClientCommands {
   private MinarClientCommands() {
   }

   public static void init() {
      ClientCommandRegistrationCallback.EVENT.register((ClientCommandRegistrationCallback)(dispatcher, registryAccess) -> {
         dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal(".cfg").then(ClientCommandManager.literal("dir").executes((context) -> {
            handleOpenDirectory();
            return 1;
         }))).then(((LiteralArgumentBuilder)ClientCommandManager.literal("save").executes((context) -> {
            saveConfig((String)null);
            return 1;
         })).then(ClientCommandManager.argument("name", StringArgumentType.word()).executes((context) -> {
            saveConfig(StringArgumentType.getString(context, "name"));
            return 1;
         })))).then(((LiteralArgumentBuilder)ClientCommandManager.literal("load").executes((context) -> {
            loadConfig((String)null);
            return 1;
         })).then(ClientCommandManager.argument("name", StringArgumentType.word()).suggests((context, builder) -> {
            return class_2172.method_9265(ConfigManager.getConfigNames(), builder);
         }).executes((context) -> {
            loadConfig(StringArgumentType.getString(context, "name"));
            return 1;
         })))).then(ClientCommandManager.literal("reset").executes((context) -> {
            ConfigManager.reset();
            CommandFeedback.sendFeedback("Settings reset.", class_124.field_1060);
            return 1;
         })));
      });
      ClientCommandRegistrationCallback.EVENT.register((ClientCommandRegistrationCallback)(dispatcher, registryAccess) -> {
         dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal(".friend").then(ClientCommandManager.literal("add").then(ClientCommandManager.argument("nick", StringArgumentType.word()).executes((context) -> {
            return executeFriendAction("add", StringArgumentType.getString(context, "nick"));
         })))).then(ClientCommandManager.literal("remove").then(ClientCommandManager.argument("nick", StringArgumentType.word()).executes((context) -> {
            return executeFriendAction("remove", StringArgumentType.getString(context, "nick"));
         })))).then(ClientCommandManager.literal("clear").executes((context) -> {
            FriendCommand.execute(".friend clear");
            return 1;
         })));
      });
      ClientCommandRegistrationCallback.EVENT.register((ClientCommandRegistrationCallback)(dispatcher, registryAccess) -> {
         dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal(".bot").then(ClientCommandManager.literal("list").executes((context) -> {
            BotCommand.execute(".bot list");
            return 1;
         }))).then(ClientCommandManager.literal("return").executes((context) -> {
            BotCommand.execute(".bot return");
            return 1;
         }))).then(ClientCommandManager.literal("connect").then(ClientCommandManager.argument("name", StringArgumentType.word()).then(ClientCommandManager.argument("ip", StringArgumentType.string()).executes((context) -> {
            String var1 = StringArgumentType.getString(context, "name");
            BotCommand.execute(var1 + StringArgumentType.getString(context, "ip"));
            return 1;
         }))))).then(ClientCommandManager.literal("remove").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes((context) -> {
            BotCommand.execute(".bot remove " + String.valueOf(StringArgumentType.getString(context, "name")));
            return 1;
         })))).then(ClientCommandManager.literal("control").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes((context) -> {
            BotCommand.execute(".bot control " + String.valueOf(StringArgumentType.getString(context, "name")));
            return 1;
         })))).then(ClientCommandManager.literal("say").then(ClientCommandManager.argument("name", StringArgumentType.word()).then(ClientCommandManager.argument("message", StringArgumentType.greedyString()).executes((context) -> {
            String var1 = StringArgumentType.getString(context, "name");
            BotCommand.execute(var1 + StringArgumentType.getString(context, "message"));
            return 1;
         }))))).then(ClientCommandManager.literal("sayall").then(ClientCommandManager.argument("message", StringArgumentType.greedyString()).executes((context) -> {
            BotCommand.execute(".bot sayall " + String.valueOf(StringArgumentType.getString(context, "message")));
            return 1;
         }))));
      });
      ClientCommandRegistrationCallback.EVENT.register((ClientCommandRegistrationCallback)(dispatcher, registryAccess) -> {
         dispatcher.register((LiteralArgumentBuilder)ClientCommandManager.literal(".parse").executes((context) -> {
            ParseCommand.execute();
            return 1;
         }));
      });
      ClientCommandRegistrationCallback.EVENT.register((ClientCommandRegistrationCallback)(dispatcher, registryAccess) -> {
         dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal(".neuro").then(ClientCommandManager.literal("record").then(ClientCommandManager.argument("model", StringArgumentType.word()).executes((context) -> {
            NeuroCommand.execute(".neuro record " + String.valueOf(StringArgumentType.getString(context, "model")));
            return 1;
         })))).then(ClientCommandManager.literal("start").then(ClientCommandManager.argument("model", StringArgumentType.word()).suggests((context, builder) -> {
            return class_2172.method_9265(NeuroManager.listModels(), builder);
         }).executes((context) -> {
            NeuroCommand.execute(".neuro start " + String.valueOf(StringArgumentType.getString(context, "model")));
            return 1;
         }))));
      });
   }

   private static int executeFriendAction(String action, String name) {
      FriendCommand.execute(action + name);
      return 1;
   }

   private static void handleOpenDirectory() {
      if (ConfigManager.openConfigDirectory()) {
         CommandFeedback.sendFeedback("Config folder opened.", class_124.field_1060);
      } else {
         CommandFeedback.sendFeedback("Could not open config folder.", class_124.field_1061);
      }

   }

   private static void loadConfig(String name) {
      if (name != null && !ConfigManager.isValidConfigName(name)) {
         CommandFeedback.sendFeedback("Invalid config name. Use letters, numbers, _ or -.", class_124.field_1054);
      } else {
         if (ConfigManager.load(name)) {
            CommandFeedback.sendFeedback(String.valueOf(formatConfigName(name)) + " loaded.", class_124.field_1060);
         } else {
            CommandFeedback.sendFeedback(String.valueOf(formatConfigName(name)) + " was not found or could not be loaded.", class_124.field_1061);
         }

      }
   }

   private static void saveConfig(String name) {
      if (name != null && !ConfigManager.isValidConfigName(name)) {
         CommandFeedback.sendFeedback("Invalid config name. Use letters, numbers, _ or -.", class_124.field_1054);
      } else {
         if (ConfigManager.save(name)) {
            CommandFeedback.sendFeedback(String.valueOf(formatConfigName(name)) + " saved.", class_124.field_1060);
         } else {
            CommandFeedback.sendFeedback("Could not save " + String.valueOf(formatConfigName(name).toLowerCase(Locale.ROOT)) + ".", class_124.field_1061);
         }

      }
   }

   private static String formatConfigName(String name) {
      return name == null ? "Config" : "Config '" + String.valueOf(name) + "'";
   }

}
