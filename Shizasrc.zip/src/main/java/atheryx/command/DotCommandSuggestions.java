package atheryx.command;

import atheryx.manager.ConfigManager;
import atheryx.neuro.NeuroManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2172;

public final class DotCommandSuggestions {
   private static final CommandDispatcher<Object> obf_u0440 = new CommandDispatcher();

   private DotCommandSuggestions() {
   }

   public static CompletableFuture<Suggestions> getSuggestions(String input, int cursor) {
      CompletableFuture<Suggestions> neuroModelSuggestions = getNeuroModelSuggestions(input, cursor);
      return neuroModelSuggestions != null ? neuroModelSuggestions : obf_u0440.getCompletionSuggestions(obf_u0440.parse(input, new Object()), cursor);
   }

   private static CompletableFuture<Suggestions> getNeuroModelSuggestions(String input, int cursor) {
      int safeCursor = Math.max(0, Math.min(cursor, input.length()));
      String beforeCursor = input.substring(0, safeCursor);
      String lower = beforeCursor.toLowerCase(Locale.ROOT);
      CompletableFuture english = buildModelSuggestions(input, safeCursor, lower, ".neuro start");
      if (english != null) {
         return english;
      } else {
         CompletableFuture<Suggestions> russianStart = buildModelSuggestions(input, safeCursor, lower, ".нейро start");
         return russianStart != null ? russianStart : buildModelSuggestions(input, safeCursor, lower, ".нейро старт");
      }
   }

   private static CompletableFuture<Suggestions> buildModelSuggestions(String input, int cursor, String lower, String commandPrefix) {
      List<String> models = NeuroManager.listModels();
      if (models.isEmpty()) {
         return null;
      } else if (!lower.equals(commandPrefix)) {
         String modelPrefix = " " + String.valueOf(commandPrefix);
         if (lower.startsWith(modelPrefix)) {
            SuggestionsBuilder builder = new SuggestionsBuilder(input, modelPrefix.length());
            return class_2172.method_9265(models, builder);
         } else {
            return null;
         }
      } else {
         SuggestionsBuilder builder = new SuggestionsBuilder(input, cursor);

         for(String model : models) {
            builder.suggest(String.valueOf(model) + " ");
         }

         return builder.buildFuture();
      }
   }

   static {
      obf_u0440.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal(".cfg").then(LiteralArgumentBuilder.literal("dir"))).then(LiteralArgumentBuilder.literal("save").then(RequiredArgumentBuilder.argument("name", StringArgumentType.word())))).then(LiteralArgumentBuilder.literal("load").then(RequiredArgumentBuilder.argument("name", StringArgumentType.word()).suggests((context, builder) -> {
         return class_2172.method_9265(ConfigManager.getConfigNames(), builder);
      })))).then(LiteralArgumentBuilder.literal("reset")));
      obf_u0440.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal(".friend").then(LiteralArgumentBuilder.literal("add").then(RequiredArgumentBuilder.argument("nick", StringArgumentType.word())))).then(LiteralArgumentBuilder.literal("remove").then(RequiredArgumentBuilder.argument("nick", StringArgumentType.word())))).then(LiteralArgumentBuilder.literal("clear")));
      obf_u0440.register(LiteralArgumentBuilder.literal(".parse"));
      obf_u0440.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal(".neuro").then(LiteralArgumentBuilder.literal("record").then(RequiredArgumentBuilder.argument("model", StringArgumentType.word())))).then(LiteralArgumentBuilder.literal("start").then(RequiredArgumentBuilder.argument("model", StringArgumentType.word()).suggests((context, builder) -> {
         return class_2172.method_9265(NeuroManager.listModels(), builder);
      }))));
      obf_u0440.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal(".нейро").then(LiteralArgumentBuilder.literal("рекод").then(RequiredArgumentBuilder.argument("model", StringArgumentType.word())))).then(LiteralArgumentBuilder.literal("record").then(RequiredArgumentBuilder.argument("model", StringArgumentType.word())))).then(LiteralArgumentBuilder.literal("старт").then(RequiredArgumentBuilder.argument("model", StringArgumentType.word()).suggests((context, builder) -> {
         return class_2172.method_9265(NeuroManager.listModels(), builder);
      })))).then(LiteralArgumentBuilder.literal("start").then(RequiredArgumentBuilder.argument("model", StringArgumentType.word()).suggests((context, builder) -> {
         return class_2172.method_9265(NeuroManager.listModels(), builder);
      }))));
   }

}
