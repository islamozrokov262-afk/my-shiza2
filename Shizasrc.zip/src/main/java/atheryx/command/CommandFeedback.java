package atheryx.command;

import atheryx.gui.ThemeManager;
import java.awt.Color;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_5251;

public final class CommandFeedback {
   private static final String obf_u00e4 = "Shiza";

   private CommandFeedback() {
   }

   public static void sendFeedback(String message, class_124 color) {
      class_310 client = class_310.method_1551();
      if (client.field_1705 != null) {
         client.field_1705.method_1743().method_1812(class_2561.method_43470("[").method_27692(class_124.field_1063).method_10852(createBrandText()).method_10852(class_2561.method_43470("] ").method_27692(class_124.field_1063)).method_10852(class_2561.method_43470(message).method_27692(color)));
      }
   }

   private static class_5250 createBrandText() {
      class_5250 text = class_2561.method_43473();
      Color start = ThemeManager.getCurrentColor();
      Color end = Color.WHITE;

      for(int i = 0; i < "Shiza".length(); ++i) {
         float progress = "Shiza".length() == 1 ? 1.0F : (float)i / (float)("Shiza".length() - 1);
         int red = lerpChannel(start.getRed(), end.getRed(), progress);
         int green = lerpChannel(start.getGreen(), end.getGreen(), progress);
         int blue = lerpChannel(start.getBlue(), end.getBlue(), progress);
         text.method_10852(class_2561.method_43470(String.valueOf("Shiza".charAt(i))).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(red << 16 | green << 8 | blue))));
      }

      return text;
   }

   private static int lerpChannel(int from, int to, float progress) {
      return Math.round((float)from + (float)(to - from) * progress);
   }

}
