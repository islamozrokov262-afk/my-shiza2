package atheryx.command;

import atheryx.manager.FriendManager;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_124;

public final class FriendCommand {
   public static final String PREFIX = ".";
   public static final String COMMAND = "friend";

   private FriendCommand() {
   }

   public static boolean execute(String input) {
      String commandLine = input.trim();
      if (!matchesCommand(commandLine)) {
         return false;
      } else {
         String[] arguments = commandLine.split("\\s+");
         if (arguments.length == 1) {
            printUsage();
            return true;
         } else {
            String var3 = arguments[1].toLowerCase(Locale.ROOT);
            byte var4 = -1;
            switch (var3.hashCode()) {
               case -934610812:
                  if (var3.equals("remove")) {
                     var4 = 1;
                  }
                  break;
               case 96417:
                  if (var3.equals("add")) {
                     var4 = 0;
                  }
                  break;
               case 94746189:
                  if (var3.equals("clear")) {
                     var4 = 2;
                  }
            }

            switch (var4) {
               case 0 -> handleAdd(arguments);
               case 1 -> handleRemove(arguments);
               case 2 -> handleClear(arguments);
               default -> printUsage();
            }

            return true;
         }
      }
   }

   public static List<String> getSuggestions(String input) {
      String commandLine = input.stripLeading().toLowerCase(Locale.ROOT);
      if (!".".equals(commandLine) && (!commandLine.startsWith(".") || !".friend".startsWith(commandLine))) {
         if (!commandLine.startsWith(".friend ")) {
            return List.<String>of();
         } else {
            String attribute = commandLine.substring(".friend ".length());
            return attribute.contains(" ") ? List.of() : List.of(".friend add <nick>", ".friend remove <nick>", ".friend clear").stream().filter((suggestion) -> {
               return suggestion.substring(".friend ".length()).toLowerCase(Locale.ROOT).startsWith(attribute);
            }).toList();
         }
      } else {
         return List.of(".friend");
      }
   }

   private static boolean matchesCommand(String input) {
      String lowerInput = input.toLowerCase(Locale.ROOT);
      return lowerInput.equals(".friend") || lowerInput.startsWith(".friend ");
   }

   private static void handleAdd(String[] arguments) {
      if (arguments.length == 3 && isValidPlayerName(arguments[2])) {
         if (FriendManager.addFriend(arguments[2])) {
            sendFeedback(String.valueOf(arguments[2]) + " added to friends.", class_124.field_1060);
         } else {
            sendFeedback(String.valueOf(arguments[2]) + " is already in friends.", class_124.field_1054);
         }

      } else {
         sendFeedback("Usage: .friend add <nick>", class_124.field_1054);
      }
   }

   private static void handleRemove(String[] arguments) {
      if (arguments.length == 3 && isValidPlayerName(arguments[2])) {
         if (FriendManager.removeBot(arguments[2])) {
            sendFeedback(String.valueOf(arguments[2]) + " removed from friends.", class_124.field_1060);
         } else {
            sendFeedback(String.valueOf(arguments[2]) + " was not found in friends.", class_124.field_1054);
         }

      } else {
         sendFeedback("Usage: .friend remove <nick>", class_124.field_1054);
      }
   }

   private static void handleClear(String[] arguments) {
      if (arguments.length != 2) {
         sendFeedback("Usage: .friend clear", class_124.field_1054);
      } else {
         int cleared = FriendManager.clearFriends();
         sendFeedback("Friends list cleared (" + String.valueOf(cleared) + ").", class_124.field_1060);
      }
   }

   private static boolean isValidPlayerName(String name) {
      return name.matches("[A-Za-z0-9_]{1,16}");
   }

   private static void printUsage() {
      sendFeedback(".friend add <nick> - add friend", class_124.field_1080);
      sendFeedback(".friend remove <nick> - remove friend", class_124.field_1080);
      sendFeedback(".friend clear - clear friends list", class_124.field_1080);
   }

   private static void sendFeedback(String message, class_124 color) {
      CommandFeedback.sendFeedback(message, color);
   }

}
