package atheryx.command;

import atheryx.bot.BotSessionManager;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_124;

public final class BotCommand {
   public static final String COMMAND = "bot";

   private BotCommand() {
   }

   public static boolean execute(String input) {
      String commandLine = input.trim();
      if (!matchesCommand(commandLine)) {
         return false;
      } else {
         String[] arguments = commandLine.split("\\s+");
         if (arguments.length < 2) {
            printUsage();
            return true;
         } else {
            String var3 = arguments[1].toLowerCase(Locale.ROOT);
            byte var4 = -1;
            switch (var3.hashCode()) {
               case -934610812:
                  if (var3.equals("remove")) {
                     var4 = 1;
                  }
                  break;
               case -934396624:
                  if (var3.equals("return")) {
                     var4 = 2;
                  }
                  break;
               case -909332010:
                  if (var3.equals("sayall")) {
                     var4 = 5;
                  }
                  break;
               case 113643:
                  if (var3.equals("say")) {
                     var4 = 4;
                  }
                  break;
               case 3322014:
                  if (var3.equals("list")) {
                     var4 = 6;
                  }
                  break;
               case 951351530:
                  if (var3.equals("connect")) {
                     var4 = 0;
                  }
                  break;
               case 951543133:
                  if (var3.equals("control")) {
                     var4 = 3;
                  }
            }

            switch (var4) {
               case 0 -> handleConnect(arguments);
               case 1 -> handleRemove(arguments);
               case 2 -> handleReturn(arguments);
               case 3 -> handleControl(arguments);
               case 4 -> handleSay(arguments);
               case 5 -> handleSayAll(arguments);
               case 6 -> handleList(arguments);
               default -> printUsage();
            }

            return true;
         }
      }
   }

   public static List<String> getSuggestions(String input) {
      String commandLine = input.stripLeading().toLowerCase(Locale.ROOT);
      if (!".".equals(commandLine) && (!commandLine.startsWith(".") || !".bot".startsWith(commandLine))) {
         if (!commandLine.startsWith(".bot ")) {
            return List.<String>of();
         } else {
            String attribute = commandLine.substring(".bot ".length());
            if (attribute.contains(" ") && !attribute.toLowerCase(Locale.ROOT).startsWith("say ") && !attribute.toLowerCase(Locale.ROOT).startsWith("sayall ") && !attribute.toLowerCase(Locale.ROOT).startsWith("connect ")) {
               return List.<String>of();
            } else {
               return !attribute.contains(" ") ? List.of(".bot connect <name> <ip>", ".bot remove <name>", ".bot return", ".bot control <name>", ".bot say <name> <msg>", ".bot sayall <msg>", ".bot list").stream().filter((suggestion) -> {
                  return suggestion.substring(".bot ".length()).toLowerCase(Locale.ROOT).startsWith(attribute);
               }).toList() : List.of();
            }
         }
      } else {
         return List.of(".bot");
      }
   }

   private static void handleConnect(String[] arguments) {
      if (arguments.length != 4) {
         CommandFeedback.sendFeedback("Usage: .bot connect <name> <ip>", class_124.field_1054);
      } else {
         String name = arguments[2];
         String ip = arguments[3];
         BotSessionManager.connectBot(name, ip);
         CommandFeedback.sendFeedback(name + ip, class_124.field_1060);
      }
   }

   private static void handleRemove(String[] arguments) {
      if (arguments.length != 3) {
         CommandFeedback.sendFeedback("Usage: .bot remove <name>", class_124.field_1054);
      } else {
         String name = arguments[2];
         if (BotSessionManager.removeBot(name)) {
            CommandFeedback.sendFeedback("Bot disconnected and removed: " + String.valueOf(name), class_124.field_1060);
         } else {
            CommandFeedback.sendFeedback("Bot not found: " + String.valueOf(name), class_124.field_1061);
         }

      }
   }

   private static void handleControl(String[] arguments) {
      if (arguments.length != 3) {
         CommandFeedback.sendFeedback("Usage: .bot control <name>", class_124.field_1054);
      } else {
         String name = arguments[2];
         if (BotSessionManager.controlBot(name)) {
            CommandFeedback.sendFeedback("Switched to bot: " + String.valueOf(name), class_124.field_1060);
         } else {
            CommandFeedback.sendFeedback("Bot not found: " + String.valueOf(name), class_124.field_1061);
         }

      }
   }

   private static void handleSay(String[] arguments) {
      if (arguments.length < 4) {
         CommandFeedback.sendFeedback("Usage: .bot say <name> <message>", class_124.field_1054);
      } else {
         String name = arguments[2];
         StringBuilder message = new StringBuilder();

         for(int i = 3; i < arguments.length; ++i) {
            message.append(arguments[i]).append(" ");
         }

         if (BotSessionManager.sendMessageToBot(name, message.toString().trim())) {
            CommandFeedback.sendFeedback("Message from " + String.valueOf(name) + " sent.", class_124.field_1060);
         } else {
            CommandFeedback.sendFeedback("Bot not found: " + String.valueOf(name), class_124.field_1061);
         }

      }
   }

   private static void handleSayAll(String[] arguments) {
      if (arguments.length < 3) {
         CommandFeedback.sendFeedback("Usage: .bot sayall <message>", class_124.field_1054);
      } else {
         StringBuilder message = new StringBuilder();

         for(int i = 2; i < arguments.length; ++i) {
            message.append(arguments[i]).append(" ");
         }

         BotSessionManager.sendMessageToAll(message.toString().trim());
         CommandFeedback.sendFeedback("Message sent from all bots.", class_124.field_1060);
      }
   }

   private static void handleReturn(String[] arguments) {
      if (BotSessionManager.returnToPreviousSession()) {
         CommandFeedback.sendFeedback("Returned to previous session", class_124.field_1060);
      } else {
         CommandFeedback.sendFeedback("No saved session to return to", class_124.field_1061);
      }

   }

   private static void handleList(String[] arguments) {
      List<BotSessionManager.BotSession> connections = BotSessionManager.getConnections();
      if (connections.isEmpty()) {
         CommandFeedback.sendFeedback("Bot list is empty", class_124.field_1054);
      } else {
         CommandFeedback.sendFeedback("Connected bots:", class_124.field_1075);

         for(BotSessionManager.BotSession connection : connections) {
            CommandFeedback.sendFeedback(connection.name() + connection.address(), class_124.field_1075);
         }

      }
   }

   private static boolean matchesCommand(String input) {
      String lowerInput = input.toLowerCase(Locale.ROOT);
      return lowerInput.equals(".bot") || lowerInput.startsWith(".bot ");
   }

   private static void printUsage() {
      CommandFeedback.sendFeedback(".bot connect <name> <ip> - connect a bot", class_124.field_1080);
      CommandFeedback.sendFeedback(".bot control <name> - switch to bot", class_124.field_1080);
      CommandFeedback.sendFeedback(".bot say <name> <message> - send chat as bot", class_124.field_1080);
      CommandFeedback.sendFeedback(".bot sayall <message> - send chat as all bots", class_124.field_1080);
      CommandFeedback.sendFeedback(".bot remove <name> - disconnect bot", class_124.field_1080);
      CommandFeedback.sendFeedback(".bot return - return to previous session", class_124.field_1080);
      CommandFeedback.sendFeedback(".bot list - list connected bots", class_124.field_1080);
   }

}
