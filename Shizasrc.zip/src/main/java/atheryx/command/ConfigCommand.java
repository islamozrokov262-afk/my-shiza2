package atheryx.command;

import atheryx.manager.ConfigManager;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_124;

public final class ConfigCommand {
   public static final String COMMAND = "cfg";

   private ConfigCommand() {
   }

   public static boolean execute(String input) {
      String commandLine = input.trim();
      if (!matchesCommand(commandLine)) {
         return false;
      } else {
         String[] arguments = commandLine.split("\\s+");
         if (arguments.length >= 2 && arguments.length <= 3) {
            String var3 = arguments[1].toLowerCase(Locale.ROOT);
            byte var4 = -1;
            switch (var3.hashCode()) {
               case 99469:
                  if (var3.equals("dir")) {
                     var4 = 0;
                  }
                  break;
               case 3327206:
                  if (var3.equals("load")) {
                     var4 = 1;
                  }
                  break;
               case 3522941:
                  if (var3.equals("save")) {
                     var4 = 2;
                  }
                  break;
               case 108404047:
                  if (var3.equals("reset")) {
                     var4 = 3;
                  }
            }

            switch (var4) {
               case 0:
                  if (arguments.length != 2) {
                     printUsage();
                  } else {
                     handleOpenDirectory();
                  }
                  break;
               case 1:
                  handleLoad(arguments);
                  break;
               case 2:
                  handleSave(arguments);
                  break;
               case 3:
                  if (arguments.length != 2) {
                     printUsage();
                  } else {
                     reset();
                  }
                  break;
               default:
                  printUsage();
            }

            return true;
         } else {
            printUsage();
            return true;
         }
      }
   }

   public static List<String> getSuggestions(String input) {
      String commandLine = input.stripLeading().toLowerCase(Locale.ROOT);
      if (!".".equals(commandLine) && (!commandLine.startsWith(".") || !".cfg".startsWith(commandLine))) {
         if (!commandLine.startsWith(".cfg ")) {
            return List.<String>of();
         } else {
            String attribute = commandLine.substring(".cfg ".length());
            return attribute.contains(" ") ? List.of() : List.of(".cfg dir", ".cfg load", ".cfg save", ".cfg reset").stream().filter((suggestion) -> {
               return suggestion.substring(".cfg ".length()).toLowerCase(Locale.ROOT).startsWith(attribute);
            }).toList();
         }
      } else {
         return List.of(".cfg");
      }
   }

   private static boolean matchesCommand(String input) {
      String lowerInput = input.toLowerCase(Locale.ROOT);
      return lowerInput.equals(".cfg") || lowerInput.startsWith(".cfg ");
   }

   private static void handleOpenDirectory() {
      if (ConfigManager.openConfigDirectory()) {
         CommandFeedback.sendFeedback("Config folder opened.", class_124.field_1060);
      } else {
         CommandFeedback.sendFeedback("Could not open config folder.", class_124.field_1061);
      }

   }

   private static void handleLoad(String[] arguments) {
      if (arguments.length == 3 && !ConfigManager.isValidConfigName(arguments[2])) {
         CommandFeedback.sendFeedback("Invalid config name. Use letters, numbers, _ or -.", class_124.field_1054);
      } else {
         String name = arguments.length == 3 ? arguments[2] : null;
         if (ConfigManager.load(name)) {
            CommandFeedback.sendFeedback(String.valueOf(formatConfigName(name)) + " loaded.", class_124.field_1060);
         } else {
            CommandFeedback.sendFeedback(String.valueOf(formatConfigName(name)) + " was not found or could not be loaded.", class_124.field_1061);
         }

      }
   }

   private static void handleSave(String[] arguments) {
      if (arguments.length == 3 && !ConfigManager.isValidConfigName(arguments[2])) {
         CommandFeedback.sendFeedback("Invalid config name. Use letters, numbers, _ or -.", class_124.field_1054);
      } else {
         String name = arguments.length == 3 ? arguments[2] : null;
         if (ConfigManager.save(name)) {
            CommandFeedback.sendFeedback(String.valueOf(formatConfigName(name)) + " saved.", class_124.field_1060);
         } else {
            CommandFeedback.sendFeedback("Could not save " + String.valueOf(formatConfigName(name).toLowerCase(Locale.ROOT)) + ".", class_124.field_1061);
         }

      }
   }

   private static void reset() {
      ConfigManager.reset();
      CommandFeedback.sendFeedback("Settings reset.", class_124.field_1060);
   }

   private static void printUsage() {
      CommandFeedback.sendFeedback(".cfg dir - open config folder", class_124.field_1080);
      CommandFeedback.sendFeedback(".cfg load [name] - load config", class_124.field_1080);
      CommandFeedback.sendFeedback(".cfg save [name] - save config", class_124.field_1080);
      CommandFeedback.sendFeedback(".cfg reset - reset all settings", class_124.field_1080);
   }

   private static String formatConfigName(String name) {
      return name == null ? "Config" : "Config '" + String.valueOf(name) + "'";
   }

}
