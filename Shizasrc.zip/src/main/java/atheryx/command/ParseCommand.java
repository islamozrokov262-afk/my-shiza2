package atheryx.command;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_640;

public final class ParseCommand {
   private static final class_310 obf_u0431 = class_310.method_1551();

   private ParseCommand() {
   }

   public static void execute() {
      if (obf_u0431.field_1724 == null) {
         CommandFeedback.sendFeedback("Вы не подключены к серверу.", class_124.field_1061);
         return;
      }

      class_634 networkHandler = obf_u0431.method_1562();
      if (networkHandler == null) {
         CommandFeedback.sendFeedback("Список игроков недоступен.", class_124.field_1061);
         return;
      }

      File directory = new File(obf_u0431.field_1697, "files/parser");
      if (!directory.exists() && !directory.mkdirs()) {
         CommandFeedback.sendFeedback("Не удалось создать папку parser.", class_124.field_1061);
         return;
      }

      Collection<class_640> entries = networkHandler.method_45732();
      File file = new File(directory, createOutputFileName());

      try (FileWriter writer = new FileWriter(file, StandardCharsets.UTF_8)) {
         for (class_640 entry : entries) {
            class_268 team = entry.method_2955();
            class_2561 prefix = team == null ? class_2561.method_43473() : team.method_1144();
            class_2561 suffix = team == null ? class_2561.method_43473() : team.method_1136();
            writer.write(prefix.getString());
            writer.write(entry.method_2966().name());
            writer.write(suffix.getString());
            writer.write(System.lineSeparator());
         }

         CommandFeedback.sendFeedback("Сохранено игроков: " + entries.size() + " -> " + file.getName(), class_124.field_1060);
      } catch (Exception exception) {
         CommandFeedback.sendFeedback("Ошибка сохранения parse: " + exception.getMessage(), class_124.field_1061);
      }
   }

   private static String createOutputFileName() {
      String server = "local";
      if (obf_u0431.method_1558() != null && obf_u0431.method_1558().field_3761 != null) {
         server = obf_u0431.method_1558().field_3761;
      }

      server = server.replaceAll("[^A-Za-z0-9._-]", "_");
      String time = (new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss")).format(new Date());
      return server + time;
   }

}
