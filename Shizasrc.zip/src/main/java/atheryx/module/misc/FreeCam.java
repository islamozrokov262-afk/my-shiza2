package atheryx.module.misc;

import atheryx.event.EventHandler;
import atheryx.event.impl.InputEvent;
import atheryx.event.impl.PacketReceiveEvent;
import atheryx.event.impl.PacketSendEvent;
import atheryx.event.impl.Render2DEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.render.RenderUtil;
import atheryx.render.font.Msdf;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;
import java.util.Locale;
import net.minecraft.class_243;
import net.minecraft.class_2678;
import net.minecraft.class_2724;
import net.minecraft.class_2828;
import net.minecraft.class_3532;

@NewFunction(
   name = "FreeCam",
   desc = "Позволяет свободно летать камерой по миру",
   category = Category.MISC
)
public class FreeCam extends Function {
   private final NumberSetting skorostNumberSetting = new NumberSetting("Скорость", 2.0D, (double)0.5F, 5.0D, 0.1);
   private final BooleanSetting zamorozkaBooleanSetting = new BooleanSetting("Заморозка", false);
   private class_243 field_47826ddf;
   private class_243 field_b4ade7d4;
   private String field_21d961c9;
   private long field_8f04dbbe;

   public FreeCam() {
      this.setCurrentPosition(class_243.field_1353);
      this.setPreviousPosition(class_243.field_1353);
      this.setCoords("");
      this.addSettings(new Setting[]{this.getSpeedSetting(), this.getFreezeSetting()});
   }

   public static FreeCam resolveFreeCam() {
      return (FreeCam)FunctionManager.getFunction(FreeCam.class);
   }

   public void onEnable() {
      if (this.mc.field_1724 != null) {
         class_243 var10003 = this.mc.field_1724.method_5836(1.0F);
         this.setPreviousPosition(var10003);
         this.setCurrentPosition(var10003);
         this.setCoords(this.formatText(this.getCurrentPosition()));
         this.setLastActionTime(System.currentTimeMillis());
         this.mc.field_1730 = false;
      }
   }

   public void onDisable() {
      this.mc.field_1730 = true;
   }

   @EventHandler
   public void onPacketSend(PacketSendEvent event) {
      if (this.getFreezeSetting().isEnabled() && event.getPacket() instanceof class_2828) {
         event.cancel();
      }

   }

   @EventHandler
   public void onPacketReceive(PacketReceiveEvent event) {
      if (event.getPacket() instanceof class_2724 || event.getPacket() instanceof class_2678) {
         this.toggle();
      }

   }

   @EventHandler
   public void onInput(InputEvent event) {
      if (this.mc.field_1724 != null) {
         float forward = event.getForward();
         float strafe = event.getStrafe();
         double step = this.getSpeedSetting().getValue();
         this.setPreviousPosition(this.getCurrentPosition());
         class_243 horizontal = this.calculateDirectionVector(forward, strafe, this.mc.field_1724.method_36454()).method_1021(step);
         double y = event.isJumping() ? step : (event.isSneaking() ? -step : (double)0.0F);
         this.setCurrentPosition(this.getCurrentPosition().method_1031(horizontal.field_1352, y, horizontal.field_1350));
         event.setForward(0.0F);
         event.setStrafe(0.0F);
         event.setJumping(false);
         event.setSneaking(false);
      }
   }

   @EventHandler
   public void onRender2D(Render2DEvent event) {
      if (event.getDrawContext() != null && this.mc.field_1724 != null) {
         float tickDelta = event.getTickCounter().method_60637(true);
         class_243 cameraPos = new class_243(this.calculateAnimationFactor(tickDelta), this.calculateMovementSpeed(tickDelta), this.calculateTargetDistance(tickDelta));
         String coords = this.formatText(cameraPos);
         if (!coords.equals(this.getCoords())) {
            this.setCoords(coords);
            this.setLastActionTime(System.currentTimeMillis());
         }

         float progress = Math.clamp((float)(System.currentTimeMillis() - this.getLastActionTime()) / 260.0F, 0.0F, 1.0F);
         float bounce = (float)Math.sin((double)progress * 3.1415926535897931D) * 2.20000005F;
         float size = 8.5F + bounce;
         float centerX = (float)this.mc.method_22683().method_4486() / 2.0F;
         float y = (float)this.mc.method_22683().method_4502() / 2.0F + 13.0F;
         RenderUtil.drawAlignedText(event.getDrawContext(), Msdf.SF_BOLD, centerX + 1.0F, y + 1.0F, this.getCoords(), size, new Color(0, 0, 0, 140), "center");
         RenderUtil.drawAlignedText(event.getDrawContext(), Msdf.SF_BOLD, centerX, y, this.getCoords(), size, new Color(245, 247, 250), "center");
      }
   }

   public double calculateAnimationFactor(float tickDelta) {
      return class_3532.method_16436((double)tickDelta, this.getPreviousPosition().field_1352, this.getCurrentPosition().field_1352);
   }

   public double calculateMovementSpeed(float tickDelta) {
      return class_3532.method_16436((double)tickDelta, this.getPreviousPosition().field_1351, this.getCurrentPosition().field_1351);
   }

   public double calculateTargetDistance(float tickDelta) {
      return class_3532.method_16436((double)tickDelta, this.getPreviousPosition().field_1350, this.getCurrentPosition().field_1350);
   }

   public float calculateAnimationFactorForTarget(float tickDelta) {
      return this.mc.field_1724 == null ? 0.0F : class_3532.method_17821(tickDelta, this.mc.field_1724.field_5982, this.mc.field_1724.method_36454());
   }

   public float calculateMovementSpeedForTarget(float tickDelta) {
      return this.mc.field_1724 == null ? 0.0F : class_3532.method_16439(tickDelta, this.mc.field_1724.field_6004, this.mc.field_1724.method_36455());
   }

   private class_243 calculateDirectionVector(float forward, float strafe, float yaw) {
      if (forward == 0.0F && strafe == 0.0F) {
         return class_243.field_1353;
      } else {
         double angle = Math.toRadians((double)yaw);
         double sin = Math.sin(angle);
         double cos = Math.cos(angle);
         double x = (double)strafe * cos - (double)forward * sin;
         double z = (double)forward * cos + (double)strafe * sin;
         return (new class_243(x, (double)0.0F, z)).method_1029();
      }
   }

   private String formatText(class_243 value) {
      return String.format(Locale.ROOT, "X %.1f  Z %.1f  Y %.1f", value.field_1352, value.field_1350, value.field_1351);
   }

   private NumberSetting getSpeedSetting() {
      return this.skorostNumberSetting;
   }

   private BooleanSetting getFreezeSetting() {
      return this.zamorozkaBooleanSetting;
   }

   private class_243 getCurrentPosition() {
      return this.field_47826ddf;
   }

   private void setCurrentPosition(class_243 var1) {
      this.field_47826ddf = var1;
   }

   private class_243 getPreviousPosition() {
      return this.field_b4ade7d4;
   }

   private void setPreviousPosition(class_243 var1) {
      this.field_b4ade7d4 = var1;
   }

   private String getCoords() {
      return this.field_21d961c9;
   }

   private void setCoords(String var1) {
      this.field_21d961c9 = var1;
   }

   private long getLastActionTime() {
      return this.field_8f04dbbe;
   }

   private void setLastActionTime(long var1) {
      this.field_8f04dbbe = var1;
   }

}
