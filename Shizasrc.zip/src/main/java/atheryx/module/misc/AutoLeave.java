package atheryx.module.misc;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.manager.FriendManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import java.util.Locale;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_5250;
import net.minecraft.class_640;

@NewFunction(
   name = "AutoLeave",
   desc = "Автоматически выходит, когда рядом появляется игрок",
   category = Category.MISC
)
public class AutoLeave extends Function {
   private final ModeSetting tipVyhodaModeSetting = new ModeSetting("Тип выхода", new String[]{"Main Menu", "Hub"});
   private final BooleanSetting playersBooleanSetting = new BooleanSetting("Players", true);
   private final BooleanSetting staffBooleanSetting = new BooleanSetting("Staff", true);
   private final NumberSetting maksimalnayaDistantsiyaNumberSetting = new NumberSetting("Максимальная дистанция", 10.0D, 5.0D, 40.0D, (double)1.0F);

   public AutoLeave() {
      this.addSettings(new Setting[]{this.getExitTypeSetting(), this.getPlayersSetting(), this.getStaffSetting(), this.getMaximumDistanceSetting()});
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null && this.mc.method_1562() != null) {
         if (this.getPlayersSetting().isEnabled()) {
            for(class_1657 player : this.mc.field_1687.method_18456()) {
               if (player != this.mc.field_1724 && !FriendManager.isFriend(player.method_7334().name()) && (double)this.mc.field_1724.method_5739(player) <= this.getMaximumDistanceSetting().getValue()) {
                  class_5250 var10001 = player.method_5477().method_27661();
                  float var10002 = this.mc.field_1724.method_5739(player);
                  this.refreshTarget(var10001.method_27693(" - появился рядом " + String.valueOf(Math.round(var10002)) + "м"));
                  return;
               }
            }
         }

         if (this.getStaffSetting().isEnabled() && this.shouldProcess()) {
            this.refreshTarget(class_2561.method_43470("Стафф на сервере"));
         }

      }
   }

   private boolean shouldProcess() {
      for(class_640 entry : this.mc.method_1562().method_45732()) {
         class_268 team = entry.method_2955();
         String var5 = team == null ? "" : team.method_1144().getString() + team.method_1136().getString();
         String label = (var5 + entry.method_2966().name()).toLowerCase(Locale.ROOT);
         if (label.contains("staff") || label.contains("moder") || label.contains("helper") || label.contains("admin") || label.contains("модер") || label.contains("хелпер") || label.contains("админ")) {
            return true;
         }
      }

      return false;
   }

   private void refreshTarget(class_2561 reason) {
      if (this.mc.method_1562() != null) {
         if (this.getExitTypeSetting().isSelected("Hub")) {
            this.mc.method_1562().method_45730("hub");
         } else {
            this.mc.method_1562().method_48296().method_10747(class_2561.method_43470("[AutoLeave]\n").method_10852(reason));
         }

         this.toggle();
      }
   }

   private ModeSetting getExitTypeSetting() {
      return this.tipVyhodaModeSetting;
   }

   private BooleanSetting getPlayersSetting() {
      return this.playersBooleanSetting;
   }

   private BooleanSetting getStaffSetting() {
      return this.staffBooleanSetting;
   }

   private NumberSetting getMaximumDistanceSetting() {
      return this.maksimalnayaDistantsiyaNumberSetting;
   }

}
