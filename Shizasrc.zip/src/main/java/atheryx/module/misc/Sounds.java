package atheryx.module.misc;

import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.Locale;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineEvent;
import net.minecraft.class_1109;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;

@NewFunction(
   name = "Sounds",
   desc = "Plays a sound when a module is enabled or disabled",
   category = Category.MISC
)
public class Sounds extends Function {
   private final ModeSetting soundThemeSetting = new ModeSetting(
      "Звук", "Дефолт", "Плавный", "Целка", "Блоп", "Module 5", "Module 6", "Module 7"
   );
   private final NumberSetting volumeSetting = new NumberSetting("Громкость", 100.0, 0.0, 100.0, 1.0);

   public Sounds() {
      this.addSettings(this.soundThemeSetting, this.volumeSetting);
   }

   public static void playModuleToggleSound(boolean enabled) {
      Sounds sounds = FunctionManager.getFunction(Sounds.class);
      SoundTheme theme = sounds == null
         ? SoundTheme.DEFAULT
         : SoundTheme.byDisplayName(sounds.soundThemeSetting.getValue());
      float volume = sounds == null ? 1.0F : (float)(sounds.volumeSetting.getValue() / 100.0);
      if (volume <= 0.0F) {
         return;
      }

      if (theme == SoundTheme.DEFAULT) {
         playWav(enabled ? "assets/atheryx/sounds/on.wav" : "assets/atheryx/sounds/off.wav", volume);
      } else if (theme.usesWav()) {
         playWav(theme.wavPath(enabled), volume);
      } else {
         playMinecraftSound(theme.event(enabled), volume);
      }
   }

   private static void playMinecraftSound(class_2960 id, float volume) {
      class_310 client = class_310.method_1551();
      client.method_1483().method_4873(class_1109.method_4757(class_3414.method_47908(id), 1.0F, volume));
   }

   private static void playWav(String path, float volume) {
      Thread thread = new Thread(() -> loadAndPlayWav(path, volume), "Atheryx-Sound");
      thread.setDaemon(true);
      thread.start();
   }

   private static void loadAndPlayWav(String path, float volume) {
      try (InputStream resource = Sounds.class.getClassLoader().getResourceAsStream(path)) {
         if (resource == null) {
            return;
         }

         try (AudioInputStream audio = AudioSystem.getAudioInputStream(new BufferedInputStream(resource))) {
            Clip clip = AudioSystem.getClip();
            clip.addLineListener(event -> {
               if (event.getType() == LineEvent.Type.STOP) {
                  clip.close();
               }
            });
            clip.open(audio);
            applyVolume(clip, volume);
            clip.start();
         }
      } catch (Exception ignored) {
      }
   }

   private static void applyVolume(Clip clip, float volume) {
      if (!clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
         return;
      }

      FloatControl gain = (FloatControl)clip.getControl(FloatControl.Type.MASTER_GAIN);
      float decibels = (float)(20.0 * Math.log10(Math.clamp(volume, 1.0E-4F, 1.0F)));
      gain.setValue(Math.clamp(decibels, gain.getMinimum(), gain.getMaximum()));
   }

   private enum SoundTheme {
      DEFAULT("Дефолт", "default"),
      SMOOTH("Плавный", "smooth"),
      CELESTIAL("Целка", "celestial"),
      BLOP("Блоп", "blop"),
      MODULE_5("Module 5", "module5", 5),
      MODULE_6("Module 6", "module6", 6),
      MODULE_7("Module 7", "module7", 7);

      private final String displayName;
      private final String resourceName;
      private final int wavNumber;

      SoundTheme(String displayName, String resourceName) {
         this(displayName, resourceName, -1);
      }

      SoundTheme(String displayName, String resourceName, int wavNumber) {
         this.displayName = displayName;
         this.resourceName = resourceName;
         this.wavNumber = wavNumber;
      }

      private class_2960 event(boolean enabled) {
         return class_2960.method_60655("atheryx", this.resourceName + (enabled ? "_on" : "_off"));
      }

      private boolean usesWav() {
         return this.wavNumber > 0;
      }

      private String wavPath(boolean enabled) {
         return "assets/atheryx/sounds/module_" + (enabled ? "enable" : "disable") + "_" + this.wavNumber + ".wav";
      }

      private static SoundTheme byDisplayName(String value) {
         for (SoundTheme theme : values()) {
            if (theme.displayName.equalsIgnoreCase(value)
               || theme.resourceName.equals(value.toLowerCase(Locale.ROOT))) {
               return theme;
            }
         }
         return DEFAULT;
      }
   }
}
