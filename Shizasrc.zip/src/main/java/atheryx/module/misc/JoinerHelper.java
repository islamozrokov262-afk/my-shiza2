package atheryx.module.misc;

import atheryx.event.EventHandler;
import atheryx.event.impl.PacketReceiveEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import java.util.Locale;
import net.minecraft.class_1268;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2596;
import net.minecraft.class_2661;
import net.minecraft.class_2886;
import net.minecraft.class_437;
import net.minecraft.class_476;
import org.lwjgl.glfw.GLFW;

@NewFunction(
   name = "JoinerHelper",
   desc = "Помогает заходить на выбранный сервер",
   category = Category.MISC
)
public class JoinerHelper extends Function {
   private final ModeSetting serverModeSetting = new ModeSetting("Сервер", new String[]{"ReallyWorld", "SpookyTime Duels"});
   private final NumberSetting nomerGrifaNumberSetting = new NumberSetting("Номер грифа", (double)1.0F, (double)1.0F, 54.0D, (double)1.0F);
   private long field_47826ddf;

   public JoinerHelper() {
      this.addSettings(new Setting[]{this.getServerSetting(), this.getGriefServerNumberSetting()});
   }

   public void onEnable() {
      this.setLastActionTime(0L);
      this.restoreSelectedSlot();
   }

   public void onDisable() {
      this.setLastActionTime(0L);
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.mc.field_1724 != null) {
         if (GLFW.glfwGetKey(this.mc.method_22683().method_4490(), 260) == 1) {
            this.toggle();
         } else if (this.mc.field_1755 == null && this.mc.field_1724.field_6012 < 5) {
            this.restoreSelectedSlot();
         } else {
            class_437 var3 = this.mc.field_1755;
            if (var3 instanceof class_476) {
               class_476 container = (class_476)var3;

               for(int var5 = 0; var5 < ((class_1707)container.method_17577()).field_7761.size(); ++var5) {
                  String name = ((class_1735)((class_1707)container.method_17577()).field_7761.get(var5)).method_7677().method_7964().getString().toLowerCase(Locale.ROOT);
                  if (this.matchesItemName(name) && System.currentTimeMillis() - this.getLastActionTime() > 70L) {
                     this.mc.field_1761.method_2906(((class_1707)container.method_17577()).field_7763, var5, 0, class_1713.field_7790, this.mc.field_1724);
                     this.setLastActionTime(System.currentTimeMillis());
                     return;
                  }
               }

            }
         }
      }
   }

   @EventHandler
   public void onPacketReceive(PacketReceiveEvent event) {
      class_2596 var3 = event.getPacket();
      if (var3 instanceof class_2661 packet) {
         String message = packet.comp_2325().getString().toLowerCase(Locale.ROOT);
         if (message.contains("переполнен") || message.contains("подождите") || message.contains("уже подключены") || message.contains("server is full")) {
            this.restoreSelectedSlot();
         }
      }

   }

   private boolean matchesItemName(String itemName) {
      if (this.getServerSetting().isSelected("ReallyWorld")) {
         int number = (int)this.getGriefServerNumberSetting().getValue();
         return itemName.contains("гриферское выживание") || itemName.contains("гриф #" + String.valueOf(number)) || itemName.contains("grief #" + String.valueOf(number));
      } else {
         return itemName.contains("дуэли") || itemName.contains("duels") || itemName.contains("липкий поршень");
      }
   }

   private void restoreSelectedSlot() {
      if (this.mc.field_1724 != null && this.mc.field_1724.field_3944 != null) {
         this.mc.field_1724.field_3944.method_52787(new class_2886(class_1268.field_5808, this.mc.field_1724.method_31548().method_67532(), this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455()));
      }
   }

   private ModeSetting getServerSetting() {
      return this.serverModeSetting;
   }

   private NumberSetting getGriefServerNumberSetting() {
      return this.nomerGrifaNumberSetting;
   }

   private long getLastActionTime() {
      return this.field_47826ddf;
   }

   private void setLastActionTime(long var1) {
      this.field_47826ddf = var1;
   }

}
