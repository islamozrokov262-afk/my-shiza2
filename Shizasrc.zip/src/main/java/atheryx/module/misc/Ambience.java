package atheryx.module.misc;

import atheryx.event.EventHandler;
import atheryx.event.impl.Render2DEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.NumberSetting;
import net.minecraft.class_638;

@NewFunction(
   name = "Ambience",
   desc = "Изменяет локальное время мира",
   category = Category.RENDER
)
public class Ambience extends Function {
   private final NumberSetting timeNumberSetting = new NumberSetting("Time", 6000.0D, (double)0.0F, 24000.0D, 100.0D);
   private boolean field_da56f3ea;
   private long field_47826ddf;

   public Ambience() {
      this.addSettings(new Setting[]{this.getTimeSetting()});
      this.getTimeSetting().setChangeListener(() -> {
         if (this.isEnabled()) {
            this.advanceActionPhase();
         }

      });
   }

   public void onEnable() {
      this.refreshTarget();
      this.advanceActionPhase();
   }

   public void onDisable() {
      this.updateRotation();
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      this.advanceActionPhase();
   }

   @EventHandler
   public void onRender2D(Render2DEvent event) {
      this.advanceActionPhase();
   }

   private void refreshTarget() {
      class_638 world = this.mc.field_1687;
      if (world == null) {
         this.setActionPending(false);
      } else {
         this.setLastActionTime(world.method_8532());
         this.setActionPending(true);
      }
   }

   private void updateRotation() {
      class_638 world = this.mc.field_1687;
      if (world != null && this.isActionPending()) {
         world.method_29089(world.method_28104().method_188(), this.getLastActionTime(), true);
         this.setActionPending(false);
      }
   }

   private void advanceActionPhase() {
      class_638 world = this.mc.field_1687;
      if (world != null) {
         world.method_29089(world.method_28104().method_188(), (long)this.getTimeSetting().getValue(), false);
      }
   }

   private NumberSetting getTimeSetting() {
      return this.timeNumberSetting;
   }

   private boolean isActionPending() {
      return this.field_da56f3ea;
   }

   private void setActionPending(boolean var1) {
      this.field_da56f3ea = var1;
   }

   private long getLastActionTime() {
      return this.field_47826ddf;
   }

   private void setLastActionTime(long var1) {
      this.field_47826ddf = var1;
   }

}
