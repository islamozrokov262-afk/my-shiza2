package atheryx.module.misc;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.TextSetting;
import net.minecraft.class_418;
import net.minecraft.class_437;

@NewFunction(
   name = "AutoRespawn",
   desc = "Автоматически возрождается после смерти",
   category = Category.MISC
)
public class AutoRespawn extends Function {
   private final BooleanSetting ispolzovatKomanduBooleanSetting = new BooleanSetting("Использовать команду", false);
   private final TextSetting komandaTextSetting = new TextSetting("Команда", "home");
   private boolean field_47826ddf;

   public AutoRespawn() {
      this.setActionPending(false);
      this.addSettings(new Setting[]{this.getUseCommandSetting(), this.getCommandTextSetting()});
   }

   public void onEnable() {
      this.setActionPending(false);
      super.onEnable();
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.mc.field_1724 != null) {
         if (this.mc.field_1755 instanceof class_418) {
            if (!this.isActionPending()) {
               this.mc.field_1724.method_7331();
               this.mc.method_1507((class_437)null);
               if (this.getUseCommandSetting().isEnabled()) {
                  String cmd = this.getCommandTextSetting().getText();
                  if (cmd.startsWith("/")) {
                     cmd = cmd.substring(1);
                  }

                  if (this.mc.field_1724.field_3944 != null && !cmd.isEmpty()) {
                     this.mc.field_1724.field_3944.method_45730(cmd);
                  }
               }

               this.setActionPending(true);
            }
         } else {
            this.setActionPending(false);
         }

      }
   }

   private BooleanSetting getUseCommandSetting() {
      return this.ispolzovatKomanduBooleanSetting;
   }

   private TextSetting getCommandTextSetting() {
      return this.komandaTextSetting;
   }

   private boolean isActionPending() {
      return this.field_47826ddf;
   }

   private void setActionPending(boolean var1) {
      this.field_47826ddf = var1;
   }

}
