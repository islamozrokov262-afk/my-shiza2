package atheryx.module.misc;

import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.TextSetting;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@NewFunction(
   name = "StreamerMode",
   desc = "Визуально скрывает ник, донат и баланс",
   category = Category.MISC
)
public class StreamerMode extends Function {
   private static final Pattern obf_u2210_u221c = Pattern.compile("(Баланс\\D*)([\\d\\s.,]+)");
   private static final long obf_u220b_u221c = 80L;
   private final ModeSetting rezhimModeSetting = new ModeSetting("Режим", new String[]{"ReallyWorld", "Простой"});
   private final BooleanSetting donatBooleanSetting = new BooleanSetting("Донат", true);
   private final BooleanSetting balansBooleanSetting = new BooleanSetting("Баланс", true);
   private final TextSetting znachenieBalansaTextSetting = new TextSetting("Значение баланса", "0", 32);
   private final BooleanSetting nikRwBooleanSetting = new BooleanSetting("Ник RW", true);
   private final BooleanSetting nikBooleanSetting = new BooleanSetting("Ник", true);
   private final TextSetting kastomnyyNikTextSetting = new TextSetting("Кастомный ник", "MrDomer", 32);
   private long field_695bcfa8;
   private boolean field_d687499d;

   public StreamerMode() {
      this.addSettings(new Setting[]{this.getModeSetting(), this.getRankSetting(), this.getBalanceSetting(), this.getBalanceValueTextSetting(), this.getReallyWorldNicknameSetting(), this.getNicknameSetting(), this.getCustomNicknameTextSetting()});
      this.getModeSetting().setChangeListener(this::refreshTarget);
      this.getBalanceSetting().setChangeListener(this::refreshTarget);
      this.getNicknameSetting().setChangeListener(this::refreshTarget);
      this.refreshTarget();
   }

   public static String resolveText(String text) {
      StreamerMode streamerMode = (StreamerMode)FunctionManager.getFunction(StreamerMode.class);
      return streamerMode != null && streamerMode.isEnabled() ? streamerMode.resolveTextPrimary(text) : text;
   }

   private String resolveTextPrimary(String text) {
      if (text != null && this.mc.method_1548() != null) {
         String result = text;
         String username = this.mc.method_1548().method_1676();
         if (this.getModeSetting().isSelected("ReallyWorld")) {
            if (this.getRankSetting().isEnabled() && this.matchesText(text)) {
               return text.replaceAll("\\S", "");
            } else {
               if (this.getRankSetting().isEnabled()) {
                  result = this.resolveTextSecondary(text);
               }

               if (this.getBalanceSetting().isEnabled()) {
                  result = this.resolveTextCurrent(result);
               }

               if (this.getReallyWorldNicknameSetting().isEnabled()) {
                  result = this.resolveText(result, username, "MrDomer");
               }

               return result;
            }
         } else {
            if (this.getNicknameSetting().isEnabled()) {
               result = this.resolveText(text, username, this.getCustomNicknameTextSetting().getText());
            }

            return result;
         }
      } else {
         return text;
      }
   }

   private String resolveTextSecondary(String text) {
      int index = text.indexOf("Ранг:");
      if (index < 0) {
         return text;
      } else {
         this.setLastActionTime(System.currentTimeMillis() + 80L);
         this.setActionPending(false);
         String var3 = text.substring(0, index + "Ранг:".length());
         return String.valueOf(var3) + " ꔷ";
      }
   }

   private boolean matchesText(String text) {
      if (!this.isActionPending() && System.currentTimeMillis() <= this.getLastActionTime()) {
         String trimmed = text.trim();
         if (!trimmed.isEmpty() && !trimmed.contains("Ранг:") && trimmed.length() <= 3) {
            boolean hasLetterOrDigit = trimmed.codePoints().anyMatch(Character::isLetterOrDigit);
            if (hasLetterOrDigit) {
               return false;
            } else {
               this.setActionPending(true);
               return true;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private String resolveTextCurrent(String text) {
      Matcher matcher = obf_u2210_u221c.matcher(text);
      if (!matcher.find()) {
         return text;
      } else {
         String var10001 = matcher.group(1);
         return matcher.replaceFirst(Matcher.quoteReplacement(var10001 + this.getBalanceValueTextSetting().getText()));
      }
   }

   private String resolveText(String text, String from, String to) {
      return from != null && !from.isBlank() && to != null && !to.isBlank() ? Pattern.compile(Pattern.quote(from), 66).matcher(text).replaceAll(Matcher.quoteReplacement(to)) : text;
   }

   private void refreshTarget() {
      boolean reallyWorld = this.getModeSetting().isSelected("ReallyWorld");
      boolean simple = !reallyWorld;
      this.getRankSetting().setVisible(reallyWorld);
      this.getBalanceSetting().setVisible(reallyWorld);
      this.getBalanceValueTextSetting().setVisible(reallyWorld && this.getBalanceSetting().isEnabled());
      this.getReallyWorldNicknameSetting().setVisible(reallyWorld);
      this.getNicknameSetting().setVisible(simple);
      this.getCustomNicknameTextSetting().setVisible(simple && this.getNicknameSetting().isEnabled());
   }

   private ModeSetting getModeSetting() {
      return this.rezhimModeSetting;
   }

   private BooleanSetting getRankSetting() {
      return this.donatBooleanSetting;
   }

   private BooleanSetting getBalanceSetting() {
      return this.balansBooleanSetting;
   }

   private TextSetting getBalanceValueTextSetting() {
      return this.znachenieBalansaTextSetting;
   }

   private BooleanSetting getReallyWorldNicknameSetting() {
      return this.nikRwBooleanSetting;
   }

   private BooleanSetting getNicknameSetting() {
      return this.nikBooleanSetting;
   }

   private TextSetting getCustomNicknameTextSetting() {
      return this.kastomnyyNikTextSetting;
   }

   private long getLastActionTime() {
      return this.field_695bcfa8;
   }

   private void setLastActionTime(long var1) {
      this.field_695bcfa8 = var1;
   }

   private boolean isActionPending() {
      return this.field_d687499d;
   }

   private void setActionPending(boolean var1) {
      this.field_d687499d = var1;
   }

}
