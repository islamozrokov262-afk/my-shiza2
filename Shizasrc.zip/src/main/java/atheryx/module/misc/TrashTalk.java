package atheryx.module.misc;

import atheryx.event.EventHandler;
import atheryx.event.impl.AttackEntityEvent;
import atheryx.event.impl.EntityStatusEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.TextSetting;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

@NewFunction(
   name = "TrashTalk",
   desc = "Отправляет сообщения в чат после снятия тотема и убийств",
   category = Category.MISC
)
public class TrashTalk extends Function {
   private static final byte obf_u044c_u221c = (byte)35;
   private static final long obf_u2213_u221c = 10000L;
   private static final long obf_u041c_u221c = 1000L;
   private final BooleanSetting pisatZaTotemBooleanSetting = new BooleanSetting("Писать за тотем", true);
   private final TextSetting tekstZaTotemTextSetting = new TextSetting("Текст за тотем", "попнул тотем");
   private final BooleanSetting pisatZaKillBooleanSetting = new BooleanSetting("Писать за килл", true);
   private final TextSetting tekstZaKillTextSetting = new TextSetting("Текст за килл", "убит");
   private final Map<UUID, Long> field_21d961c9 = new HashMap<UUID, Long>();
   private UUID field_8f04dbbe;
   private String field_fc3055b3;
   private long field_695bcfa8;

   public TrashTalk() {
      this.addSettings(new Setting[]{this.getSendOnTotemSetting(), this.getTotemMessageTextSetting(), this.getSendOnKillSetting(), this.getKillMessageTextSetting()});
   }

   public void onDisable() {
      this.getTrackedEntries().clear();
      this.setTargetUuid((UUID)null);
      this.setDisplayName((String)null);
      this.setLastActionTime(0L);
   }

   @EventHandler
   public void onAttackEntity(AttackEntityEvent event) {
      if (event.getPlayer() == this.mc.field_1724) {
         class_1297 var3 = event.getTarget();
         if (var3 instanceof class_1657) {
            class_1657 player = (class_1657)var3;
            if (player != this.mc.field_1724) {
               this.setTargetUuid(player.method_5667());
               this.setDisplayName(player.method_7334().name());
               this.setLastActionTime(System.currentTimeMillis());
               return;
            }
         }
      }

   }

   @EventHandler
   public void onEntityStatus(EntityStatusEvent event) {
      if (this.getSendOnTotemSetting().isEnabled()) {
         if (event.getStatusPacket().method_11470() == 35) {
            class_1297 var3 = event.getEntity();
            if (var3 instanceof class_1657) {
               class_1657 player = (class_1657)var3;
               if (player != this.mc.field_1724) {
                  this.updateTimedState(player.method_5667(), player.method_7334().name(), this.getTotemMessageTextSetting().getText());
                  return;
               }
            }
         }

      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.getSendOnKillSetting().isEnabled()) {
         if (this.mc.field_1687 != null && this.getTargetUuid() != null && System.currentTimeMillis() - this.getLastActionTime() <= 10000L) {
            class_1297 entity = this.mc.field_1687.method_18470(this.getTargetUuid());
            if (entity instanceof class_1657) {
               class_1657 player = (class_1657)entity;
               if (!player.method_5805() || player.method_6032() <= 0.0F) {
                  this.updateTimedState(this.getTargetUuid(), this.getDisplayName(), this.getKillMessageTextSetting().getText());
                  this.setTargetUuid((UUID)null);
                  this.setDisplayName((String)null);
               }

            }
         }
      }
   }

   private void updateTimedState(UUID uuid, String playerName, String text) {
      if (this.mc.field_1724 != null && this.mc.field_1724.field_3944 != null && text != null && !text.isBlank() && playerName != null && !playerName.isBlank()) {
         long now = System.currentTimeMillis();
         Long lastMessageTime = (Long)this.getTrackedEntries().get(uuid);
         if (lastMessageTime == null || now - lastMessageTime >= 1000L) {
            this.getTrackedEntries().put(uuid, now);
            this.mc.field_1724.field_3944.method_45729(playerName + text.trim());
         }
      }
   }

   private BooleanSetting getSendOnTotemSetting() {
      return this.pisatZaTotemBooleanSetting;
   }

   private TextSetting getTotemMessageTextSetting() {
      return this.tekstZaTotemTextSetting;
   }

   private BooleanSetting getSendOnKillSetting() {
      return this.pisatZaKillBooleanSetting;
   }

   private TextSetting getKillMessageTextSetting() {
      return this.tekstZaKillTextSetting;
   }

   private Map getTrackedEntries() {
      return this.field_21d961c9;
   }

   private UUID getTargetUuid() {
      return this.field_8f04dbbe;
   }

   private void setTargetUuid(UUID var1) {
      this.field_8f04dbbe = var1;
   }

   private String getDisplayName() {
      return this.field_fc3055b3;
   }

   private void setDisplayName(String var1) {
      this.field_fc3055b3 = var1;
   }

   private long getLastActionTime() {
      return this.field_695bcfa8;
   }

   private void setLastActionTime(long var1) {
      this.field_695bcfa8 = var1;
   }

}
