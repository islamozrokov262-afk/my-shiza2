package atheryx.module.misc;

import atheryx.event.EventHandler;
import atheryx.event.impl.GameMessageEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.manager.FriendManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import java.util.Locale;

@NewFunction(
   name = "AutoTpAccept",
   desc = "Автоматически принимает запросы телепортации",
   category = Category.MISC
)
public class AutoTpAccept extends Function {
   private static final String[] obf_u221a_u221c = new String[]{"has requested teleport", "просит телепортироваться", "хочет телепортироваться к вам", "просит к вам телепортироваться"};
   private final BooleanSetting prinimatTolkoDruzeyBooleanSetting = new BooleanSetting("Принимать только друзей", true);
   private boolean field_da56f3ea;

   public AutoTpAccept() {
      this.addSettings(new Setting[]{this.getAcceptFriendsOnlySetting()});
   }

   @EventHandler
   public void onGameMessage(GameMessageEvent event) {
      String message = event.getMessage().comp_763().getString();
      String lower = message.toLowerCase(Locale.ROOT);
      if (this.matchesLowerMessage(lower)) {
         this.setActionPending(!this.getAcceptFriendsOnlySetting().isEnabled() || FriendManager.getFriends().values().stream().anyMatch((friend) -> {
            return lower.contains(friend.toLowerCase(Locale.ROOT));
         }));
      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.isActionPending() && this.mc.field_1724 != null && this.mc.field_1724.field_3944 != null) {
         this.mc.field_1724.field_3944.method_45730("tpaccept");
         this.setActionPending(false);
      }
   }

   public void onDisable() {
      this.setActionPending(false);
   }

   private boolean matchesLowerMessage(String lowerMessage) {
      for(String marker : obf_u221a_u221c) {
         if (lowerMessage.contains(marker)) {
            return true;
         }
      }

      return false;
   }

   private BooleanSetting getAcceptFriendsOnlySetting() {
      return this.prinimatTolkoDruzeyBooleanSetting;
   }

   private boolean isActionPending() {
      return this.field_da56f3ea;
   }

   private void setActionPending(boolean var1) {
      this.field_da56f3ea = var1;
   }

}
