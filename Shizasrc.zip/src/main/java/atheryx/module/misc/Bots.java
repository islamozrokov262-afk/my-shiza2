package atheryx.module.misc;

import atheryx.event.EventHandler;
import atheryx.event.impl.KeyEvent;
import atheryx.gui.screen.BotsWheelScreen;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.KeybindSetting;

@NewFunction(
   name = "Bots",
   desc = "Управление ботами через GUI",
   category = Category.PLAYER
)
public class Bots extends Function {
   private final KeybindSetting bindGuiKeybindSetting = new KeybindSetting("Бинд GUI", -1);

   public Bots() {
      this.addSettings(new Setting[]{this.getGuiKeybindSetting()});
   }

   @EventHandler
   public void onKey(KeyEvent event) {
      if (event.getAction() == 1) {
         if (this.getGuiKeybindSetting().matchesKey(event.getInput().comp_4795()) && this.mc.field_1755 == null) {
            this.mc.method_1507(new BotsWheelScreen());
         }

      }
   }

   private KeybindSetting getGuiKeybindSetting() {
      return this.bindGuiKeybindSetting;
   }

}
