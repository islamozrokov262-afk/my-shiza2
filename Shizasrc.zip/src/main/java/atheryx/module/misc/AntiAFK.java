package atheryx.module.misc;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import net.minecraft.class_1268;

@NewFunction(
   name = "AntiAFK",
   desc = "Предотвращает кик за AFK",
   category = Category.PLAYER
)
public class AntiAFK extends Function {
   private long field_6d2b79f5;

   public AntiAFK() {
      this.setLastActionTime(0L);
   }

   @EventHandler
   public void onUpdate(UpdateEvent e) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         if (System.currentTimeMillis() - this.getLastActionTime() >= 10000L) {
            this.mc.field_1724.method_6104(class_1268.field_5808);
            this.mc.field_1724.method_6043();
            this.setLastActionTime(System.currentTimeMillis());
         }

      }
   }

   public void onEnable() {
      super.onEnable();
      this.setLastActionTime(System.currentTimeMillis());
   }

   private long getLastActionTime() {
      return this.field_6d2b79f5;
   }

   private void setLastActionTime(long var1) {
      this.field_6d2b79f5 = var1;
   }

}
