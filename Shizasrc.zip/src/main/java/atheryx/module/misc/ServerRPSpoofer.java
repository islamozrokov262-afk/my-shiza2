package atheryx.module.misc;

import atheryx.event.EventHandler;
import atheryx.event.impl.PacketReceiveEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import net.minecraft.class_2596;
import net.minecraft.class_2720;
import net.minecraft.class_2856;
import net.minecraft.class_634;
import net.minecraft.class_2856.class_2857;

@NewFunction(
   name = "ServerRPSpoof",
   desc = "Отправляет серверу статус успешной загрузки ресурс-пака",
   category = Category.MISC
)
public class ServerRPSpoofer extends Function {
   private class_2720 field_6d2b79f5;
   private long field_da56f3ea;

   @EventHandler
   public void onPacketReceive(PacketReceiveEvent event) {
      class_2596 var3 = event.getPacket();
      if (var3 instanceof class_2720 packet) {
         this.setPacket(packet);
         this.setLastActionTime(0L);
         event.cancel();
      }

   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.getPacket() != null && this.mc.field_1724 != null) {
         class_634 networkHandler = this.mc.method_1562();
         if (networkHandler != null) {
            if (this.getLastActionTime() == 0L) {
               networkHandler.method_52787(new class_2856(this.getPacket().comp_2158(), class_2857.field_13016));
               this.setLastActionTime(System.currentTimeMillis());
            } else {
               if (System.currentTimeMillis() - this.getLastActionTime() >= 300L) {
                  networkHandler.method_52787(new class_2856(this.getPacket().comp_2158(), class_2857.field_13017));
                  this.setPacket((class_2720)null);
                  this.setLastActionTime(0L);
               }

            }
         }
      }
   }

   public void onDisable() {
      this.setPacket((class_2720)null);
      this.setLastActionTime(0L);
   }

   private class_2720 getPacket() {
      return this.field_6d2b79f5;
   }

   private void setPacket(class_2720 var1) {
      this.field_6d2b79f5 = var1;
   }

   private long getLastActionTime() {
      return this.field_da56f3ea;
   }

   private void setLastActionTime(long var1) {
      this.field_da56f3ea = var1;
   }

}
