package atheryx.module.player;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.mixin.interfaces.IMinecraftClient;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;

@NewFunction(
   name = "TapeMouse",
   desc = "Автоматические клики для фоновых ботов",
   category = Category.PLAYER
)
public class TapeMouse extends Function {
   private final NumberSetting cpsNumberSetting = new NumberSetting("CPS", (double)1.0F, (double)0.0F, 2.0D, 0.05);
   private final ModeSetting knopkaModeSetting = new ModeSetting("Кнопка", new String[]{"Левая", "Правая"});
   private long field_47826ddf;

   public TapeMouse() {
      this.addSettings(new Setting[]{this.getCpsSetting(), this.getKeySetting()});
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      long delay = (long)(1000.0D / this.getCpsSetting().getValue());
      long now = System.currentTimeMillis();
      if (now - this.getNow() >= delay) {
         this.refreshTarget();
         this.setNow(now);
      }
   }

   private void refreshTarget() {
      if (this.mc.field_1724 != null && this.mc.field_1755 == null) {
         if (this.getKeySetting().isSelected("Правая")) {
            ((IMinecraftClient)this.mc).invokeDoItemUse();
         } else {
            ((IMinecraftClient)this.mc).invokeDoAttack();
         }

      }
   }

   private NumberSetting getCpsSetting() {
      return this.cpsNumberSetting;
   }

   private ModeSetting getKeySetting() {
      return this.knopkaModeSetting;
   }

   private long getNow() {
      return this.field_47826ddf;
   }

   private void setNow(long var1) {
      this.field_47826ddf = var1;
   }

}
