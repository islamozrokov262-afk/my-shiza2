package atheryx.module.player;

import atheryx.event.EventHandler;
import atheryx.event.impl.InputEvent;
import atheryx.event.impl.KeyEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.module.combat.AttackAura;
import atheryx.setting.Setting;
import atheryx.setting.impl.KeybindSetting;
import atheryx.setting.impl.ModeSetting;
import net.minecraft.class_1041;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2828;
import net.minecraft.class_3675;

@NewFunction(
   name = "ClickAction",
   desc = "Использование эндер перла по бинду",
   category = Category.PLAYER
)
public class ClickAction extends Function {
   private final ModeSetting tipModeSetting = new ModeSetting("Тип", new String[]{"Обычный", "Легитный"});
   private final KeybindSetting knopkaEnderZhemchugaKeybindSetting = new KeybindSetting("Кнопка эндер-жемчуга", 0);
   private int field_47826ddf;
   private int field_b4ade7d4;
   private PearlUseState field_21d961c9;
   private long field_8f04dbbe;
   private long field_fc3055b3;
   private boolean field_695bcfa8;
   private boolean field_d687499d;
   private boolean field_43b2c392;
   private boolean field_b0de3d87;
   private boolean field_1e09b77c;
   private boolean field_8b353171;
   private boolean field_f860ab66;
   private boolean field_658c255b;

   public ClickAction() {
      this.setHand(-1);
      this.setCooldownTicks(-1);
      this.setActionPhase(ClickAction.PearlUseState.START);
      this.addSettings(new Setting[]{this.getTypeSetting(), this.getEnderPearlKeybindSetting()});
   }

   public void onDisable() {
      this.updateAnimation();
   }

   @EventHandler
   public void onKey(KeyEvent event) {
      if (event.getAction() == 1 && !this.nullCheck.isPlayerOrWorldMissing() && this.mc.field_1755 == null && this.mc.field_1761 != null) {
         if (this.getEnderPearlKeybindSetting().matchesKey(event.getInput().comp_4795())) {
            this.restoreSelectedSlot();
         }

      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing() && this.mc.field_1755 == null && this.mc.field_1761 != null) {
         if (this.getEnderPearlKeybindSetting().consumeMouseClick(this.mc.method_22683().method_4490())) {
            this.restoreSelectedSlot();
         }

         if (this.getHand() != -1) {
            this.updateTimedState();
         }

      } else {
         this.updateAnimation();
      }
   }

   @EventHandler
   public void onInput(InputEvent event) {
      if (this.isInputCaptured()) {
         event.setForward(0.0F);
         event.setStrafe(0.0F);
         event.setJumping(false);
         event.setSneaking(false);
         event.setSprinting(false);
      }
   }

   private void restoreSelectedSlot() {
      if (this.getHand() == -1 && this.mc.field_1724.field_7512.method_34255().method_7960() && !(this.mc.field_1724.method_7357().method_7905(class_1802.field_8634.method_7854(), 0.0F) > 0.0F)) {
         this.refreshTarget();
         if (this.mc.field_1724.method_6079().method_31574(class_1802.field_8634)) {
            if (this.getTypeSetting().isSelected("Обычный")) {
               this.sendInteraction(class_1268.field_5810);
            } else {
               this.restoreSelectedSlotPrimary(40);
            }

         } else {
            class_1661 inventory = this.mc.field_1724.method_31548();
            int pearlSlot = this.calculateAnimationFactor(inventory);
            if (pearlSlot != -1) {
               if (this.getTypeSetting().isSelected("Обычный")) {
                  this.restoreSelectedSlot(pearlSlot);
               } else {
                  this.restoreSelectedSlotPrimary(pearlSlot);
               }

            }
         }
      }
   }

   private void restoreSelectedSlot(int pearlSlot) {
      class_1661 inventory = this.mc.field_1724.method_31548();
      int selectedSlot = inventory.method_67532();
      if (pearlSlot != selectedSlot) {
         if (pearlSlot < 9) {
            this.restoreSelectedSlotSecondary(pearlSlot);
         } else {
            this.updateRotation(this.calculateMovementSpeed(pearlSlot), selectedSlot, class_1713.field_7791);
         }
      }

      this.refreshTarget();
      this.sendInteraction(class_1268.field_5808);
      if (pearlSlot != selectedSlot) {
         if (pearlSlot < 9) {
            this.restoreSelectedSlotSecondary(selectedSlot);
         } else {
            this.updateRotation(this.calculateMovementSpeed(pearlSlot), selectedSlot, class_1713.field_7791);
         }
      }

   }

   private void restoreSelectedSlotPrimary(int pearlSlot) {
      this.setHand(pearlSlot);
      this.setCooldownTicks(this.mc.field_1724.method_31548().method_67532());
      this.setActionPhase(ClickAction.PearlUseState.SLOWING_DOWN);
      this.setLastActionTime(System.currentTimeMillis());
      this.setLastActionTimePrimary(this.getLastActionTime());
      this.setActionPending(false);
      this.advanceActionPhase();
      this.prepareInteraction();
      this.setInputCaptured(true);
      this.setRestoreRequired(true);
   }

   private void updateTimedState() {
      class_1268 hand = this.getHand() == 40 ? class_1268.field_5810 : class_1268.field_5808;
      switch (this.getActionPhase().ordinal()) {
         case 0:
            this.prepareInteraction();
            if (this.mc.field_1724.method_5624()) {
               this.mc.field_1724.method_5728(false);
            }

            if (System.currentTimeMillis() - this.getLastActionTime() >= 50L) {
               this.setActionPhase(ClickAction.PearlUseState.START);
               this.setLastActionTime(System.currentTimeMillis());
            }
            break;
         case 1:
            if (hand != class_1268.field_5810 && this.getHand() != this.getCooldownTicks()) {
               if (this.getHand() < 9) {
                  this.restoreSelectedSlotSecondary(this.getHand());
               } else {
                  this.updateRotation(this.calculateMovementSpeed(this.getHand()), this.getCooldownTicks(), class_1713.field_7791);
                  this.setActionPending(true);
               }
            }

            this.setActionPhase(ClickAction.PearlUseState.WAIT);
            this.setLastActionTime(System.currentTimeMillis());
            break;
         case 2:
            if (System.currentTimeMillis() - this.getLastActionTime() >= 50L) {
               this.setActionPhase(ClickAction.PearlUseState.USE_ITEM);
            }
            break;
         case 3:
            this.refreshTarget();
            this.sendInteraction(hand);
            this.setActionPhase(ClickAction.PearlUseState.SWAP_BACK);
            this.setLastActionTimePrimary(System.currentTimeMillis());
            break;
         case 4:
            if (System.currentTimeMillis() - this.getLastActionTimePrimary() < 300L) {
               return;
            }

            if (hand != class_1268.field_5810 && this.getHand() != this.getCooldownTicks()) {
               if (this.isActionPending()) {
                  this.updateRotation(this.calculateMovementSpeed(this.getHand()), this.getCooldownTicks(), class_1713.field_7791);
               } else {
                  this.restoreSelectedSlotSecondary(this.getCooldownTicks());
               }
            }

            this.setActionPhase(ClickAction.PearlUseState.SPEEDING_UP);
            this.setLastActionTime(System.currentTimeMillis());
            break;
         case 5:
            this.resetTransientState();
            this.updateAnimation();
            break;
         default:
            this.updateAnimation();
      }

   }

   private int calculateAnimationFactor(class_1661 inventory) {
      for(int slot = 0; slot < inventory.method_67533().size(); ++slot) {
         if (inventory.method_5438(slot).method_31574(class_1802.field_8634)) {
            return slot;
         }
      }

      return -1;
   }

   private int calculateMovementSpeed(int slot) {
      return slot < 9 ? slot + 36 : slot;
   }

   private void restoreSelectedSlotSecondary(int slot) {
      if (slot >= 0 && slot < 9 && slot != this.mc.field_1724.method_31548().method_67532()) {
         this.mc.field_1724.method_31548().method_61496(slot);
      }
   }

   private void sendInteraction(class_1268 hand) {
      this.mc.field_1761.method_2919(this.mc.field_1724, hand);
      this.mc.field_1724.method_6104(hand);
   }

   private void refreshTarget() {
      AttackAura attackAura = (AttackAura)FunctionManager.getFunction(AttackAura.class);
      if (attackAura != null && attackAura.findTarget() != null) {
         this.mc.field_1724.field_3944.method_52787(new class_2828.class_2831(this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455(), this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
      }

   }

   private void updateRotation(int slot, int button, class_1713 actionType) {
      this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, slot, button, actionType, this.mc.field_1724);
   }

   private void advanceActionPhase() {
      class_1041 window = this.mc.method_22683();
      this.setTransitionActive(class_3675.method_15987(window, this.mc.field_1690.field_1894.method_1429().method_1444()));
      this.setTargetVisible(class_3675.method_15987(window, this.mc.field_1690.field_1881.method_1429().method_1444()));
      this.setInitialized(class_3675.method_15987(window, this.mc.field_1690.field_1913.method_1429().method_1444()));
      this.setMovementSuppressed(class_3675.method_15987(window, this.mc.field_1690.field_1849.method_1429().method_1444()));
      this.setAttackQueued(class_3675.method_15987(window, this.mc.field_1690.field_1903.method_1429().method_1444()));
   }

   private void prepareInteraction() {
      this.mc.field_1690.field_1894.method_23481(false);
      this.mc.field_1690.field_1881.method_23481(false);
      this.mc.field_1690.field_1913.method_23481(false);
      this.mc.field_1690.field_1849.method_23481(false);
      this.mc.field_1690.field_1903.method_23481(false);
   }

   private void resetTransientState() {
      if (this.isRestoreRequired() && this.mc.method_22683() != null) {
         class_1041 window = this.mc.method_22683();
         boolean currentForward = class_3675.method_15987(window, this.mc.field_1690.field_1894.method_1429().method_1444());
         boolean currentBack = class_3675.method_15987(window, this.mc.field_1690.field_1881.method_1429().method_1444());
         boolean currentLeft = class_3675.method_15987(window, this.mc.field_1690.field_1913.method_1429().method_1444());
         boolean currentRight = class_3675.method_15987(window, this.mc.field_1690.field_1849.method_1429().method_1444());
         boolean currentJump = class_3675.method_15987(window, this.mc.field_1690.field_1903.method_1429().method_1444());
         this.mc.field_1690.field_1894.method_23481(this.isTransitionActive() && currentForward);
         this.mc.field_1690.field_1881.method_23481(this.isTargetVisible() && currentBack);
         this.mc.field_1690.field_1913.method_23481(this.isInitialized() && currentLeft);
         this.mc.field_1690.field_1849.method_23481(this.isMovementSuppressed() && currentRight);
         this.mc.field_1690.field_1903.method_23481(this.isAttackQueued() && currentJump);
         this.setRestoreRequired(false);
      }
   }

   private void updateAnimation() {
      if (this.isRestoreRequired()) {
         this.resetTransientState();
      }

      this.setHand(-1);
      this.setCooldownTicks(-1);
      this.setActionPhase(ClickAction.PearlUseState.START);
      this.setLastActionTime(0L);
      this.setLastActionTimePrimary(0L);
      this.setActionPending(false);
      this.setInputCaptured(false);
      this.setRestoreRequired(false);
   }

   private ModeSetting getTypeSetting() {
      return this.tipModeSetting;
   }

   private KeybindSetting getEnderPearlKeybindSetting() {
      return this.knopkaEnderZhemchugaKeybindSetting;
   }

   private int getHand() {
      return this.field_47826ddf;
   }

   private void setHand(int var1) {
      this.field_47826ddf = var1;
   }

   private int getCooldownTicks() {
      return this.field_b4ade7d4;
   }

   private void setCooldownTicks(int var1) {
      this.field_b4ade7d4 = var1;
   }

   private PearlUseState getActionPhase() {
      return this.field_21d961c9;
   }

   private void setActionPhase(PearlUseState var1) {
      this.field_21d961c9 = var1;
   }

   private long getLastActionTime() {
      return this.field_8f04dbbe;
   }

   private void setLastActionTime(long var1) {
      this.field_8f04dbbe = var1;
   }

   private long getLastActionTimePrimary() {
      return this.field_fc3055b3;
   }

   private void setLastActionTimePrimary(long var1) {
      this.field_fc3055b3 = var1;
   }

   private boolean isActionPending() {
      return this.field_695bcfa8;
   }

   private void setActionPending(boolean var1) {
      this.field_695bcfa8 = var1;
   }

   private boolean isInputCaptured() {
      return this.field_d687499d;
   }

   private void setInputCaptured(boolean var1) {
      this.field_d687499d = var1;
   }

   private boolean isRestoreRequired() {
      return this.field_43b2c392;
   }

   private void setRestoreRequired(boolean var1) {
      this.field_43b2c392 = var1;
   }

   private boolean isTransitionActive() {
      return this.field_b0de3d87;
   }

   private void setTransitionActive(boolean var1) {
      this.field_b0de3d87 = var1;
   }

   private boolean isTargetVisible() {
      return this.field_1e09b77c;
   }

   private void setTargetVisible(boolean var1) {
      this.field_1e09b77c = var1;
   }

   private boolean isInitialized() {
      return this.field_8b353171;
   }

   private void setInitialized(boolean var1) {
      this.field_8b353171 = var1;
   }

   private boolean isMovementSuppressed() {
      return this.field_f860ab66;
   }

   private void setMovementSuppressed(boolean var1) {
      this.field_f860ab66 = var1;
   }

   private boolean isAttackQueued() {
      return this.field_658c255b;
   }

   private void setAttackQueued(boolean var1) {
      this.field_658c255b = var1;
   }


   private static enum PearlUseState {
      SLOWING_DOWN,
      START,
      WAIT,
      USE_ITEM,
      SWAP_BACK,
      SPEEDING_UP;

   }
}
