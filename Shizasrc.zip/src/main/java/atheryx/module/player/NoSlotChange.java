package atheryx.module.player;

import atheryx.event.EventHandler;
import atheryx.event.impl.PacketReceiveEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;

@NewFunction(
   name = "NoSlotChange",
   desc = "Запрещает серверу менять слот хотбара",
   category = Category.PLAYER
)
public class NoSlotChange extends Function {
   @EventHandler
   public void onPacketReceive(PacketReceiveEvent event) {
      String packetName = event.getPacket().getClass().getSimpleName();
      if (packetName.contains("UpdateSelectedSlot") || packetName.contains("HeldItemChange") || packetName.contains("SetCarriedItem")) {
         event.cancel();
      }

   }

}
