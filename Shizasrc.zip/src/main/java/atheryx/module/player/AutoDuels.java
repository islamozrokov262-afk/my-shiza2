package atheryx.module.player;

import atheryx.event.EventHandler;
import atheryx.event.impl.GameMessageEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_640;

@NewFunction(
   name = "AutoDuels",
   desc = "Автоматически отправляет игрокам приглашения на дуэль",
   category = Category.PLAYER
)
public class AutoDuels extends Function {
   private final Pattern field_6d2b79f5 = Pattern.compile("^\\w{3,16}$");
   private final ModeSetting rezhimModeSetting = new ModeSetting("Режим", new String[]{"balls", "shield", "thorns", "bow", "totems", "nodebuff", "classic", "cheaterparadise", "netherite"});
   private final NumberSetting skorostOtpravkiNumberSetting = new NumberSetting("Скорость отправки", 500.0D, 300.0D, 1000.0D, 100.0D);
   private final BooleanSetting igratNaDengiBooleanSetting = new BooleanSetting("Играть на деньги", false);
   private final ModeSetting monetModeSetting = new ModeSetting("Монет", new String[]{"10000", "100", "500", "1000", "5000", "50000", "100000"});
   private double field_8f04dbbe;
   private double field_fc3055b3;
   private double field_695bcfa8;
   private final List<String> field_d687499d = new ArrayList<String>();
   private final CooldownTimer field_43b2c392 = new CooldownTimer();
   private final CooldownTimer field_b0de3d87 = new CooldownTimer();
   private final CooldownTimer field_1e09b77c = new CooldownTimer();
   private final CooldownTimer field_8b353171 = new CooldownTimer();

   public AutoDuels() {
      this.addSettings(new Setting[]{this.getModeSetting(), this.getSendSpeedSetting(), this.getPlayForMoneySetting(), this.getCoinsSetting()});
   }

   public void onEnable() {
      super.onEnable();
      if (this.nullCheck.isPlayerOrWorldMissing()) {
         this.toggle();
      } else {
         this.getInviteTimer().reset();
         this.getScanTimer().reset();
         this.getKitSelectionTimer().reset();
         this.getDuelSettingsTimer().reset();
         this.getTrackedItems().clear();
         this.setDistance(this.mc.field_1724.method_23317());
         this.setTargetDistance(this.mc.field_1724.method_23318());
         this.setCurrentValue(this.mc.field_1724.method_23321());
      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         this.resetState();
      }
   }

   @EventHandler
   public void onGameMessage(GameMessageEvent event) {
      String text = event.getMessage().comp_763().getString();
      if (text.contains("начало") && text.contains("через") && text.contains("секунд!") || text.contains("дуэли » во время поединка запрещено использовать команды")) {
         this.toggle();
      }

   }

   private void resetState() {
      List<String> players = this.collectItems();
      double var2 = Math.sqrt(Math.pow(this.getDistance() - this.mc.field_1724.method_23317(), 2.0D) + Math.pow(this.getTargetDistance() - this.mc.field_1724.method_23318(), 2.0D) + Math.pow(this.getCurrentValue() - this.mc.field_1724.method_23321(), 2.0D));
      if (var2 > 500.0D) {
         this.toggle();
      } else {
         this.setDistance(this.mc.field_1724.method_23317());
         this.setTargetDistance(this.mc.field_1724.method_23318());
         this.setCurrentValue(this.mc.field_1724.method_23321());
         if (this.getScanTimer().isValidDelay(800L * (long)players.size())) {
            this.getTrackedItems().clear();
            this.getScanTimer().reset();
         }

         for(String player : players) {
            if (!this.getTrackedItems().contains(player) && !player.equals(this.mc.field_1724.method_7334().name()) && this.getInviteTimer().isValidDelay((long)this.getSendSpeedSetting().getValue())) {
               if (this.getPlayForMoneySetting().isEnabled()) {
                  this.mc.field_1724.field_3944.method_45730(player + this.getCoinsSetting().getValue());
               } else {
                  this.mc.field_1724.field_3944.method_45730("duel " + String.valueOf(player));
               }

               this.getTrackedItems().add(player);
               this.getInviteTimer().reset();
            }
         }

         if (this.mc.field_1755 != null) {
            class_1703 title = this.mc.field_1724.field_7512;
            if (title instanceof class_1707) {
               class_1707 chest = (class_1707)title;
               String screenTitle = this.mc.field_1755.method_25440().getString();
               if (screenTitle.contains("Выбор набора (1/1)") && this.getKitSelectionTimer().isValidDelay(150L)) {
                  this.mc.field_1761.method_2906(chest.field_7763, this.calculateCheaterparadise(), 0, class_1713.field_7794, this.mc.field_1724);
                  this.getKitSelectionTimer().reset();
               } else if (screenTitle.contains("Настройка поединка") && this.getDuelSettingsTimer().isValidDelay(150L)) {
                  this.mc.field_1761.method_2906(chest.field_7763, 0, 0, class_1713.field_7794, this.mc.field_1724);
                  this.getDuelSettingsTimer().reset();
               }
            }
         }

      }
   }

   private int calculateCheaterparadise() {
      String var1 = this.getModeSetting().getValue();
      byte var2 = -1;
      switch (var1.hashCode()) {
         case -1428698569:
            if (var1.equals("cheaterparadise")) {
               var2 = 6;
            }
            break;
         case -903340183:
            if (var1.equals("shield")) {
               var2 = 0;
            }
            break;
         case -874519716:
            if (var1.equals("thorns")) {
               var2 = 1;
            }
            break;
         case -867918638:
            if (var1.equals("totems")) {
               var2 = 3;
            }
            break;
         case 97738:
            if (var1.equals("bow")) {
               var2 = 2;
            }
            break;
         case 853620882:
            if (var1.equals("classic")) {
               var2 = 5;
            }
            break;
         case 1123495253:
            if (var1.equals("nodebuff")) {
               var2 = 4;
            }
            break;
         case 1624109378:
            if (var1.equals("netherite")) {
               var2 = 7;
            }
      }

      byte var3;
      switch (var2) {
         case 0 -> var3 = 0;
         case 1 -> var3 = 1;
         case 2 -> var3 = 2;
         case 3 -> var3 = 3;
         case 4 -> var3 = 4;
         case 5 -> var3 = 6;
         case 6 -> var3 = 7;
         case 7 -> var3 = 8;
         default -> var3 = 5;
      }

      return var3;
   }

   private List<String> collectItems() {
      return (List)this.mc.field_1724.field_3944.method_2880().stream().map(class_640::method_2966).map(GameProfile::name).filter((name) -> {
         return this.getNamePattern().matcher(name).matches();
      }).collect(Collectors.toList());
   }

   private Pattern getNamePattern() {
      return this.field_6d2b79f5;
   }

   private ModeSetting getModeSetting() {
      return this.rezhimModeSetting;
   }

   private NumberSetting getSendSpeedSetting() {
      return this.skorostOtpravkiNumberSetting;
   }

   private BooleanSetting getPlayForMoneySetting() {
      return this.igratNaDengiBooleanSetting;
   }

   private ModeSetting getCoinsSetting() {
      return this.monetModeSetting;
   }

   private double getDistance() {
      return this.field_8f04dbbe;
   }

   private void setDistance(double var1) {
      this.field_8f04dbbe = var1;
   }

   private double getTargetDistance() {
      return this.field_fc3055b3;
   }

   private void setTargetDistance(double var1) {
      this.field_fc3055b3 = var1;
   }

   private double getCurrentValue() {
      return this.field_695bcfa8;
   }

   private void setCurrentValue(double var1) {
      this.field_695bcfa8 = var1;
   }

   private List getTrackedItems() {
      return this.field_d687499d;
   }

   private CooldownTimer getInviteTimer() {
      return this.field_43b2c392;
   }

   private CooldownTimer getScanTimer() {
      return this.field_b0de3d87;
   }

   private CooldownTimer getKitSelectionTimer() {
      return this.field_1e09b77c;
   }

   private CooldownTimer getDuelSettingsTimer() {
      return this.field_8b353171;
   }


   private static class CooldownTimer {
      private long field_6d2b79f5;

      private CooldownTimer() {
         this.setLastActionTime(System.currentTimeMillis());
      }

      private boolean isValidDelay(long delay) {
         return System.currentTimeMillis() - this.getLastActionTime() >= delay;
      }

      private void reset() {
         this.setLastActionTime(System.currentTimeMillis());
      }

      private long getLastActionTime() {
         return this.field_6d2b79f5;
      }

      private void setLastActionTime(long var1) {
         this.field_6d2b79f5 = var1;
      }

   }
}
