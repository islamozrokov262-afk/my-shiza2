package atheryx.module.player;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.util.InventoryUtil;
import net.minecraft.class_1041;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3675;
import net.minecraft.class_3965;

@NewFunction(
   name = "AutoTool",
   desc = "Выбирает лучший инструмент для добычи блоков",
   category = Category.PLAYER
)
public class AutoTool extends Function {
   private int field_6d2b79f5;
   private int field_da56f3ea;
   private boolean field_47826ddf;
   private ToolSwapState field_b4ade7d4;
   private boolean field_21d961c9;
   private boolean field_8f04dbbe;
   private boolean field_fc3055b3;
   private boolean field_695bcfa8;
   private boolean field_d687499d;
   private boolean field_43b2c392;

   public AutoTool() {
      this.setIndex(-1);
      this.setCooldownTicks(-1);
      this.setActionPhase(AutoTool.ToolSwapState.READY);
      this.setMovementSuppressed(false);
   }

   @EventHandler
   public void onUpdate(UpdateEvent e) {
      if (!this.nullCheck.isPlayerMissing() && !this.mc.field_1724.method_68878()) {
         if (!this.mc.field_1724.method_6115()) {
            if (this.shouldProcess()) {
               if (this.getCooldownTicks() == -1 && this.getActionPhase() == AutoTool.ToolSwapState.READY) {
                  this.setIndex(this.calculateAnimationFactor());
                  if (this.getIndex() != -1) {
                     if (this.getIndex() >= 0 && this.getIndex() <= 8) {
                        this.setCooldownTicks(this.mc.field_1724.method_31548().method_67532());
                        this.mc.field_1724.method_31548().method_61496(this.getIndex());
                        this.setActionPending(true);
                     } else {
                        this.updateRotation(this.getIndex());
                     }
                  }
               }
            } else if (this.getCooldownTicks() != -1 && this.getActionPhase() == AutoTool.ToolSwapState.READY) {
               if (this.getCooldownTicks() >= 0 && this.getCooldownTicks() <= 8) {
                  this.mc.field_1724.method_31548().method_61496(this.getCooldownTicks());
                  this.setCooldownTicks(-1);
                  this.setActionPending(false);
               } else {
                  this.beginSwapBack();
               }
            }

            if (this.getActionPhase() != AutoTool.ToolSwapState.READY) {
               this.updateTimedState();
            }

         }
      } else {
         this.setIndex(-1);
         this.processInput();
      }
   }

   private void updateTimedState() {
      switch (this.getActionPhase().ordinal()) {
         case 0:
         default:
            break;
         case 1:
            this.prepareInteraction();
            this.setMovementSuppressed(true);
            if (this.mc.field_1724.method_5624()) {
               this.mc.field_1724.method_5728(false);
            }

            this.setActionPhase(AutoTool.ToolSwapState.SWAP);
            break;
         case 2:
            InventoryUtil.runWithoutMovementInput(this::restoreSelectedSlot);
            this.setCooldownTicks(this.getIndex());
            this.setActionPhase(AutoTool.ToolSwapState.RESTORE);
            break;
         case 3:
            this.resetTransientState();
            this.setActionPhase(AutoTool.ToolSwapState.READY);
            break;
         case 4:
            this.prepareInteraction();
            this.setMovementSuppressed(true);
            if (this.mc.field_1724.method_5624()) {
               this.mc.field_1724.method_5728(false);
            }

            this.setActionPhase(AutoTool.ToolSwapState.SWAP_BACK);
            break;
         case 5:
            InventoryUtil.runWithoutMovementInput(this::restoreSelectedSlotPrimary);
            this.setActionPhase(AutoTool.ToolSwapState.SWAP_BACK_RESTORE);
            break;
         case 6:
            this.resetTransientState();
            this.setActionPhase(AutoTool.ToolSwapState.READY);
      }

   }

   private void updateRotation(int index) {
      this.setIndex(index);
      this.advanceActionPhase();
      this.setActionPhase(AutoTool.ToolSwapState.SLOWING_DOWN);
   }

   private void beginSwapBack() {
      this.advanceActionPhase();
      this.setActionPhase(AutoTool.ToolSwapState.SWAP_BACK_SLOWING_DOWN);
   }

   private void advanceActionPhase() {
      if (this.mc.method_22683() != null) {
         class_1041 window = this.mc.method_22683();
         this.setInputCaptured(class_3675.method_15987(window, this.mc.field_1690.field_1894.method_1429().method_1444()));
         this.setRestoreRequired(class_3675.method_15987(window, this.mc.field_1690.field_1881.method_1429().method_1444()));
         this.setTransitionActive(class_3675.method_15987(window, this.mc.field_1690.field_1913.method_1429().method_1444()));
         this.setTargetVisible(class_3675.method_15987(window, this.mc.field_1690.field_1849.method_1429().method_1444()));
         this.setInitialized(class_3675.method_15987(window, this.mc.field_1690.field_1903.method_1429().method_1444()));
         this.setMovementSuppressed(false);
      }
   }

   private void prepareInteraction() {
      this.mc.field_1690.field_1894.method_23481(false);
      this.mc.field_1690.field_1881.method_23481(false);
      this.mc.field_1690.field_1913.method_23481(false);
      this.mc.field_1690.field_1849.method_23481(false);
      this.mc.field_1690.field_1903.method_23481(false);
   }

   private void resetTransientState() {
      if (this.isMovementSuppressed() && this.mc.method_22683() != null) {
         class_1041 window = this.mc.method_22683();
         boolean currentForward = class_3675.method_15987(window, this.mc.field_1690.field_1894.method_1429().method_1444());
         boolean currentBack = class_3675.method_15987(window, this.mc.field_1690.field_1881.method_1429().method_1444());
         boolean currentLeft = class_3675.method_15987(window, this.mc.field_1690.field_1913.method_1429().method_1444());
         boolean currentRight = class_3675.method_15987(window, this.mc.field_1690.field_1849.method_1429().method_1444());
         boolean currentJump = class_3675.method_15987(window, this.mc.field_1690.field_1903.method_1429().method_1444());
         this.mc.field_1690.field_1894.method_23481(this.isInputCaptured() && currentForward);
         this.mc.field_1690.field_1881.method_23481(this.isRestoreRequired() && currentBack);
         this.mc.field_1690.field_1913.method_23481(this.isTransitionActive() && currentLeft);
         this.mc.field_1690.field_1849.method_23481(this.isTargetVisible() && currentRight);
         this.mc.field_1690.field_1903.method_23481(this.isInitialized() && currentJump);
         this.setMovementSuppressed(false);
      }
   }

   private void processInput() {
      if (this.isMovementSuppressed()) {
         this.resetTransientState();
      }

      this.setActionPhase(AutoTool.ToolSwapState.READY);
      this.setCooldownTicks(-1);
      this.setActionPending(false);
      this.setMovementSuppressed(false);
   }

   private void restoreSelectedSlot() {
      if (this.getIndex() != -1) {
         this.setActionPending(true);
         this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, this.getIndex(), this.mc.field_1724.method_31548().method_67532(), class_1713.field_7791, this.mc.field_1724);
      }
   }

   private void restoreSelectedSlotPrimary() {
      if (this.getCooldownTicks() != -1 && this.isActionPending()) {
         this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, this.getCooldownTicks(), this.mc.field_1724.method_31548().method_67532(), class_1713.field_7791, this.mc.field_1724);
         this.setCooldownTicks(-1);
         this.setActionPending(false);
      }
   }

   public void onDisable() {
      super.onDisable();
      this.processInput();
      this.setIndex(-1);
   }

   private int calculateAnimationFactor() {
      class_239 var2 = this.mc.field_1765;
      if (var2 instanceof class_3965 blockHitResult) {
         class_2338 var9 = blockHitResult.method_17777();
         class_2680 state = this.mc.field_1687.method_8320(var9);
         int bestSlot = -1;
         float bestSpeed = 1.0F;

         for(int slot = 0; slot < 36; ++slot) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(slot);
            float speed = stack.method_7924(state);
            if (speed > bestSpeed) {
               bestSpeed = speed;
               bestSlot = slot;
            }
         }

         return bestSlot;
      } else {
         return -1;
      }
   }

   private boolean shouldProcess() {
      return this.mc.field_1765 != null && this.mc.field_1690.field_1886.method_1434();
   }

   private int getIndex() {
      return this.field_6d2b79f5;
   }

   private void setIndex(int var1) {
      this.field_6d2b79f5 = var1;
   }

   private int getCooldownTicks() {
      return this.field_da56f3ea;
   }

   private void setCooldownTicks(int var1) {
      this.field_da56f3ea = var1;
   }

   private boolean isActionPending() {
      return this.field_47826ddf;
   }

   private void setActionPending(boolean var1) {
      this.field_47826ddf = var1;
   }

   private ToolSwapState getActionPhase() {
      return this.field_b4ade7d4;
   }

   private void setActionPhase(ToolSwapState var1) {
      this.field_b4ade7d4 = var1;
   }

   private boolean isInputCaptured() {
      return this.field_21d961c9;
   }

   private void setInputCaptured(boolean var1) {
      this.field_21d961c9 = var1;
   }

   private boolean isRestoreRequired() {
      return this.field_8f04dbbe;
   }

   private void setRestoreRequired(boolean var1) {
      this.field_8f04dbbe = var1;
   }

   private boolean isTransitionActive() {
      return this.field_fc3055b3;
   }

   private void setTransitionActive(boolean var1) {
      this.field_fc3055b3 = var1;
   }

   private boolean isTargetVisible() {
      return this.field_695bcfa8;
   }

   private void setTargetVisible(boolean var1) {
      this.field_695bcfa8 = var1;
   }

   private boolean isInitialized() {
      return this.field_d687499d;
   }

   private void setInitialized(boolean var1) {
      this.field_d687499d = var1;
   }

   private boolean isMovementSuppressed() {
      return this.field_43b2c392;
   }

   private void setMovementSuppressed(boolean var1) {
      this.field_43b2c392 = var1;
   }


   private static enum ToolSwapState {
      READY,
      SLOWING_DOWN,
      SWAP,
      RESTORE,
      SWAP_BACK_SLOWING_DOWN,
      SWAP_BACK,
      SWAP_BACK_RESTORE;

   }
}
