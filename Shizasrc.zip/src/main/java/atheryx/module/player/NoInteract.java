package atheryx.module.player;

import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.module.combat.AttackAura;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.MultiListSetting;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1531;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_7923;

@NewFunction(
   name = "NoInteract",
   desc = "Блокирует взаимодействие с выбранными объектами",
   category = Category.PLAYER
)
public class NoInteract extends Function {
   private final BooleanSetting stoykiDlyaBroniBooleanSetting = new BooleanSetting("Стойки для брони", true);
   private final MultiListSetting blokiMultiListSetting = new MultiListSetting("Блоки", new String[]{"Сундуки", "Двери", "Воронки", "Кнопки", "Раздатчики", "Нотные блоки", "Верстаки", "Люки", "Печки", "Калитки", "Наковальни", "Рычаги"});
   private final BooleanSetting tolkoSAttackauraBooleanSetting = new BooleanSetting("Только с AttackAura", false);
   private final Map<String, Predicate<class_2248>> field_b4ade7d4 = new LinkedHashMap<String, Predicate<class_2248>>();

   public NoInteract() {
      this.getTrackedEntries().put("Сундуки", (Predicate)(block) -> {
         return this.matchesBlock(block, "chest");
      });
      this.getTrackedEntries().put("Двери", (Predicate)(block) -> {
         return this.matchesBlock(block, "door");
      });
      this.getTrackedEntries().put("Воронки", (Predicate)(block) -> {
         return this.matchesBlock(block, "hopper");
      });
      this.getTrackedEntries().put("Кнопки", (Predicate)(block) -> {
         return this.matchesBlock(block, "button");
      });
      this.getTrackedEntries().put("Раздатчики", (Predicate)(block) -> {
         return this.matchesBlock(block, "dispenser");
      });
      this.getTrackedEntries().put("Нотные блоки", (Predicate)(block) -> {
         return this.matchesBlock(block, "note");
      });
      this.getTrackedEntries().put("Верстаки", (Predicate)(block) -> {
         return this.matchesBlock(block, "crafting_table");
      });
      this.getTrackedEntries().put("Люки", (Predicate)(block) -> {
         return this.matchesBlock(block, "trapdoor");
      });
      this.getTrackedEntries().put("Печки", (Predicate)(block) -> {
         return this.matchesBlock(block, "furnace");
      });
      this.getTrackedEntries().put("Калитки", (Predicate)(block) -> {
         return this.matchesBlock(block, "fence_gate");
      });
      this.getTrackedEntries().put("Наковальни", (Predicate)(block) -> {
         return this.matchesBlock(block, "anvil");
      });
      this.getTrackedEntries().put("Рычаги", (Predicate)(block) -> {
         return this.matchesBlock(block, "lever");
      });
      this.addSettings(new Setting[]{this.getArmorStandsSetting(), this.getBlocksSetting(), this.getAttackAuraOnlySetting()});
   }

   public boolean matchesPos(class_2338 pos) {
      if (!this.isFeatureActive()) {
         return false;
      } else {
         class_310 client = class_310.method_1551();
         class_1937 world = client.field_1687;
         if (world != null && pos != null) {
            class_2680 state = world.method_8320(pos);
            class_2248 block = state.method_26204();

            for(Map.Entry<String, Predicate<class_2248>> entry : this.getTrackedEntries().entrySet()) {
               if (this.getBlocksSetting().isSelected(entry.getKey()) && ((Predicate)entry.getValue()).test(block)) {
                  return true;
               }
            }

            return false;
         } else {
            return false;
         }
      }
   }

   public boolean isValidEntity(class_1297 entity) {
      return this.isFeatureActive() && this.getArmorStandsSetting().isEnabled() && entity instanceof class_1531;
   }

   private boolean matchesBlock(Object block, String idPart) {
      class_2248 minecraftBlock = (class_2248)block;
      String registryId = class_7923.field_41175.method_10221(minecraftBlock).method_12832();
      String translationKey = minecraftBlock.method_63499();
      return registryId.contains(idPart) || translationKey.contains(idPart);
   }

   private boolean isFeatureActive() {
      if (!this.isEnabled()) {
         return false;
      } else if (!this.getAttackAuraOnlySetting().isEnabled()) {
         return true;
      } else {
         AttackAura attackAura = (AttackAura)FunctionManager.getFunction(AttackAura.class);
         return attackAura != null && attackAura.isEnabled();
      }
   }

   private BooleanSetting getArmorStandsSetting() {
      return this.stoykiDlyaBroniBooleanSetting;
   }

   private MultiListSetting getBlocksSetting() {
      return this.blokiMultiListSetting;
   }

   private BooleanSetting getAttackAuraOnlySetting() {
      return this.tolkoSAttackauraBooleanSetting;
   }

   private Map<String, Predicate<class_2248>> getTrackedEntries() {
      return this.field_b4ade7d4;
   }

}
