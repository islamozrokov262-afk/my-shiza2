package atheryx.module.player;

import atheryx.event.EventHandler;
import atheryx.event.impl.Render2DEvent;
import atheryx.mixin.interfaces.IHandledScreen;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.NumberSetting;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;

@NewFunction(
   name = "ItemScroller",
   desc = "Быстрое перемещение предметов при зажатом Shift и ЛКМ",
   category = Category.PLAYER
)
public class ItemScroller extends Function {
   private final NumberSetting cooldownNumberSetting = new NumberSetting("Cooldown", 30.0D, (double)1.0F, 200.0D, 0.01);
   private long field_da56f3ea;

   public ItemScroller() {
      this.addSettings(new Setting[]{this.getCooldownSetting()});
   }

   @EventHandler
   public void onRender2D(Render2DEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing() && this.mc.field_1755 != null && this.mc.field_1761 != null) {
         class_437 var3 = this.mc.field_1755;
         if (var3 instanceof class_465) {
            class_465<?> screen = (class_465)var3;
            if (this.shouldProcess() && GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), 0) == 1 && this.isValidDelay((long)this.getCooldownSetting().getValue())) {
               class_1735 slot = ((IHandledScreen)screen).getFocusedSlot();
               if (slot != null && slot.method_7681()) {
                  this.mc.field_1761.method_2906(screen.method_17577().field_7763, slot.field_7874, 0, class_1713.field_7794, this.mc.field_1724);
                  this.updateTimedState();
                  return;
               }

               return;
            }
         }
      }

   }

   private boolean shouldProcess() {
      return this.mc.field_1690.field_1832.method_1434() || class_3675.method_15987(this.mc.method_22683(), this.mc.field_1690.field_1832.method_1429().method_1444());
   }

   private boolean isValidDelay(long delay) {
      return System.currentTimeMillis() - this.getLastActionTime() >= delay;
   }

   private void updateTimedState() {
      this.setLastActionTime(System.currentTimeMillis());
   }

   private NumberSetting getCooldownSetting() {
      return this.cooldownNumberSetting;
   }

   private long getLastActionTime() {
      return this.field_da56f3ea;
   }

   private void setLastActionTime(long var1) {
      this.field_da56f3ea = var1;
   }

}
