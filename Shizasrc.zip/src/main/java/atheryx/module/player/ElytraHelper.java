package atheryx.module.player;

import atheryx.event.EventHandler;
import atheryx.event.impl.InputEvent;
import atheryx.event.impl.KeyEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.KeybindSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.util.MoveUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2848;
import net.minecraft.class_2848.class_2849;

@NewFunction(
   name = "ElytraHelper",
   desc = "Помощник свапа элитры и полета",
   category = Category.PLAYER
)
public class ElytraHelper extends Function {
   private static final int obf_u03b7_u221b = 6;
   private final KeybindSetting knopkaSvapaKeybindSetting = new KeybindSetting("Кнопка свапа", 0);
   private final ModeSetting rezhimSvapaModeSetting = new ModeSetting("Режим свапа", new String[]{"Legit", "Packet"});
   private final BooleanSetting nadetKogdaPadaeshBooleanSetting = new BooleanSetting("Надеть когда падаешь", false);
   private final KeybindSetting knopkaFeerverkaKeybindSetting = new KeybindSetting("Кнопка феерверка", 0);
   private final BooleanSetting avtoflayBooleanSetting = new BooleanSetting("Автофлай", false);
   private final BooleanSetting yuzatFeerverkBooleanSetting = new BooleanSetting("Юзать феерверк", false);
   private final BooleanSetting matrixBypassBooleanSetting = new BooleanSetting("Matrix bypass", true);
   private boolean field_695bcfa8;
   private boolean field_d687499d;
   private boolean field_43b2c392;
   private boolean field_b0de3d87;
   private int field_1e09b77c;
   private int field_8b353171;
   private boolean field_f860ab66;
   private int field_658c255b;

   public ElytraHelper() {
      this.setFireworkSlot(-1);
      this.addSettings(new Setting[]{this.getSwapKeybindSetting(), this.getSwapModeSetting(), this.getEquipWhenFallingSetting(), this.getFireworkKeybindSetting(), this.getAutoFlySetting(), this.getUseFireworkSetting(), this.getMatrixBypassSetting()});
      this.getEquipWhenFallingSetting().setChangeListener(() -> {
         this.getEquipWhenFallingSetting().setVisible(this.getSwapKeybindSetting().getKeybind() != 0);
      });
      this.getUseFireworkSetting().setChangeListener(() -> {
         this.getUseFireworkSetting().setVisible(this.getAutoFlySetting().isEnabled());
      });
      this.getSwapModeSetting().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   public void onDisable() {
      this.setActionPending(false);
      this.setFireworkSlot(-1);
      this.setCooldownTicks(0);
      this.setTargetVisible(false);
      this.setInputCaptured(false);
      this.setRestoreRequired(false);
      this.setTransitionActive(false);
      this.setRetryCount(0);
   }

   public boolean shouldProcess() {
      return this.isActionPending() || this.getFireworkSlot() != -1;
   }

   @EventHandler
   public void onKey(KeyEvent event) {
      if (event.getAction() == 1 && !this.nullCheck.isPlayerOrWorldMissing() && this.mc.field_1755 == null && this.mc.field_1761 != null) {
         if (this.getSwapKeybindSetting().matchesKey(event.getInput().comp_4795())) {
            this.restoreSelectedSlot();
         }

         if (this.getFireworkKeybindSetting().matchesKey(event.getInput().comp_4795())) {
            this.restoreSelectedSlotPrimary();
         }

      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing() && this.mc.field_1755 == null && this.mc.field_1761 != null) {
         if (this.getSwapKeybindSetting().consumeMouseClick(this.mc.method_22683().method_4490())) {
            this.restoreSelectedSlot();
         }

         if (this.getFireworkKeybindSetting().consumeMouseClick(this.mc.method_22683().method_4490())) {
            this.restoreSelectedSlotPrimary();
         }

         if (this.getRetryCount() > 0) {
            this.setRetryCount(this.getRetryCount() - 1);
         }

         if (this.isActionPending() && this.shouldProcessSecondary()) {
            this.restoreSelectedSlotSecondary();
            this.setActionPending(false);
         }

         if (this.getFireworkSlot() != -1 && this.shouldProcessSecondary()) {
            this.sendInteraction();
         }

         if (this.mc.field_1724.method_6128()) {
            this.setTransitionActive(true);
         }

         if (this.getEquipWhenFallingSetting().isEnabled()) {
            this.restoreSelectedSlotCurrent();
         }

         this.updateRotation();
      } else {
         this.setActionPending(false);
         this.refreshCache();
      }
   }

   @EventHandler
   public void onInput(InputEvent event) {
      if (this.isFeatureActive() && this.getRetryCount() > 0) {
         event.setForward(0.0F);
         event.setStrafe(0.0F);
         event.setJumping(false);
         event.setSneaking(false);
         event.setSprinting(false);
      }

   }

   public void restoreSelectedSlot() {
      class_1661 inventory = this.mc.field_1724.method_31548();
      boolean hasElytra = this.calculateMovementSpeed(inventory, class_1802.field_8833) != -1;
      boolean hasChestplate = this.calculateAnimationFactor(inventory) != -1;
      if (hasElytra || hasChestplate) {
         if (this.getSwapModeSetting().isSelected("Packet")) {
            this.restoreSelectedSlotSecondary();
         } else {
            this.setRetryCount(2);
            this.setActionPending(true);
         }
      }
   }

   private boolean shouldProcessPrimary() {
      return this.mc.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833);
   }

   private void useFirework() {
      this.restoreSelectedSlotPrimary();
   }

   public void restoreSelectedSlotPrimary() {
      if (!this.isActionPending() && this.getFireworkSlot() == -1 && !(this.mc.field_1724.method_7357().method_7905(class_1802.field_8639.method_7854(), 0.0F) > 0.0F)) {
         if (this.mc.field_1724.method_6079().method_31574(class_1802.field_8639)) {
            this.setFireworkSlot(40);
            this.setCooldownTicks(0);
            this.setTargetVisible(true);
            this.setRetryCount(2);
         } else {
            class_1661 inventory = this.mc.field_1724.method_31548();
            int fireworkSlot = this.calculateMovementSpeed(inventory, class_1802.field_8639);
            if (fireworkSlot != -1) {
               this.setFireworkSlot(fireworkSlot);
               this.setCooldownTicks(fireworkSlot == inventory.method_67532() ? 1 : 0);
               this.setTargetVisible(false);
               this.setRetryCount(2);
            }
         }
      }
   }

   private void sendInteraction() {
      if (this.isTargetVisible()) {
         this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5810);
         this.mc.field_1724.method_6104(class_1268.field_5810);
         this.refreshCache();
      } else {
         switch (this.getCooldownTicks()) {
            case 0:
               this.updateRotation(this.calculateMovementSpeed(this.getFireworkSlot()), 0, class_1713.field_7790);
               this.updateRotation(45, 0, class_1713.field_7790);
               this.updateRotation(this.calculateMovementSpeed(this.getFireworkSlot()), 0, class_1713.field_7790);
               this.setCooldownTicks(1);
               this.setRetryCount(2);
               break;
            case 1:
               this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5810);
               this.mc.field_1724.method_6104(class_1268.field_5810);
               this.setCooldownTicks(2);
               this.setRetryCount(2);
               break;
            case 2:
               this.updateRotation(this.calculateMovementSpeed(this.getFireworkSlot()), 0, class_1713.field_7790);
               this.updateRotation(45, 0, class_1713.field_7790);
               this.updateRotation(this.calculateMovementSpeed(this.getFireworkSlot()), 0, class_1713.field_7790);
               this.refreshCache();
               break;
            default:
               this.refreshCache();
         }

      }
   }

   private void restoreSelectedSlotSecondary() {
      if (this.mc.field_1724.field_7512.method_34255().method_7960()) {
         class_1661 inventory = this.mc.field_1724.method_31548();
         int targetSlot = this.shouldProcessPrimary() ? this.calculateAnimationFactor(inventory) : this.calculateMovementSpeed(inventory, class_1802.field_8833);
         if (targetSlot != -1) {
            this.advanceActionPhase(targetSlot);
         }
      }
   }

   private void restoreSelectedSlotCurrent() {
      if (this.mc.field_1724.method_24828() && !this.isRestoreRequired() && this.isTransitionActive() && this.shouldProcessPrimary()) {
         class_1661 inventory = this.mc.field_1724.method_31548();
         int chestplateSlot = this.calculateAnimationFactor(inventory);
         if (chestplateSlot != -1) {
            this.advanceActionPhase(chestplateSlot);
         } else {
            int emptySlot = this.calculateTargetDistance(inventory);
            if (emptySlot != -1) {
               this.prepareInteraction(emptySlot);
            }
         }

         this.setTransitionActive(false);
      }

      this.setRestoreRequired(this.mc.field_1724.method_24828());
   }

   private void updateRotation() {
      if (this.getAutoFlySetting().isEnabled() && this.shouldProcessPrimary()) {
         if (!this.mc.field_1724.method_6128() && !this.mc.field_1724.method_24828()) {
            this.mc.field_1724.field_3944.method_52787(new class_2848(this.mc.field_1724, class_2849.field_12982));
            this.setTransitionActive(true);
            if (this.getUseFireworkSetting().isEnabled() && !this.isInputCaptured()) {
               this.useFirework();
               this.setInputCaptured(true);
            }
         } else if (this.mc.field_1724.method_24828()) {
            this.mc.field_1724.method_6043();
            this.setInputCaptured(false);
         }

      }
   }

   private int calculateAnimationFactor(class_1661 inventory) {
      class_1792[] chestplates = new class_1792[]{class_1802.field_22028, class_1802.field_8058, class_1802.field_8523, class_1802.field_8873, class_1802.field_8678, class_1802.field_8577};

      for(class_1792 chestplate : chestplates) {
         int slot = this.calculateMovementSpeed(inventory, chestplate);
         if (slot != -1) {
            return slot;
         }
      }

      return -1;
   }

   private int calculateMovementSpeed(class_1661 inventory, class_1792 item) {
      for(int slot = 0; slot < inventory.method_67533().size(); ++slot) {
         if (inventory.method_5438(slot).method_31574(item)) {
            return slot;
         }
      }

      return -1;
   }

   private int calculateTargetDistance(class_1661 inventory) {
      for(int slot = 0; slot < inventory.method_67533().size(); ++slot) {
         if (inventory.method_5438(slot).method_7960()) {
            return slot;
         }
      }

      return -1;
   }

   private int calculateMovementSpeed(int slot) {
      return slot < 9 ? slot + 36 : slot;
   }

   private void advanceActionPhase(int slot) {
      int sourceSlot = this.calculateMovementSpeed(slot);
      this.updateRotation(sourceSlot, 0, class_1713.field_7790);
      this.updateRotation(6, 0, class_1713.field_7790);
      this.updateRotation(sourceSlot, 0, class_1713.field_7790);
   }

   private void prepareInteraction(int slot) {
      int targetSlot = this.calculateMovementSpeed(slot);
      this.updateRotation(6, 0, class_1713.field_7790);
      this.updateRotation(targetSlot, 0, class_1713.field_7790);
   }

   private void updateRotation(int slot, int button, class_1713 actionType) {
      this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, slot, button, actionType, this.mc.field_1724);
   }

   private boolean shouldProcessSecondary() {
      return !this.isFeatureActive() || !MoveUtil.isMoving();
   }

   private boolean isFeatureActive() {
      return this.getSwapModeSetting().isSelected("Legit") && this.getMatrixBypassSetting().isEnabled();
   }

   private void updateSettingVisibility() {
      this.getMatrixBypassSetting().setVisible(this.getSwapModeSetting().isSelected("Legit"));
   }

   private void refreshCache() {
      this.setFireworkSlot(-1);
      this.setCooldownTicks(0);
      this.setTargetVisible(false);
   }

   private KeybindSetting getSwapKeybindSetting() {
      return this.knopkaSvapaKeybindSetting;
   }

   private ModeSetting getSwapModeSetting() {
      return this.rezhimSvapaModeSetting;
   }

   private BooleanSetting getEquipWhenFallingSetting() {
      return this.nadetKogdaPadaeshBooleanSetting;
   }

   private KeybindSetting getFireworkKeybindSetting() {
      return this.knopkaFeerverkaKeybindSetting;
   }

   private BooleanSetting getAutoFlySetting() {
      return this.avtoflayBooleanSetting;
   }

   private BooleanSetting getUseFireworkSetting() {
      return this.yuzatFeerverkBooleanSetting;
   }

   private BooleanSetting getMatrixBypassSetting() {
      return this.matrixBypassBooleanSetting;
   }

   private boolean isActionPending() {
      return this.field_695bcfa8;
   }

   private void setActionPending(boolean var1) {
      this.field_695bcfa8 = var1;
   }

   private boolean isInputCaptured() {
      return this.field_d687499d;
   }

   private void setInputCaptured(boolean var1) {
      this.field_d687499d = var1;
   }

   private boolean isRestoreRequired() {
      return this.field_43b2c392;
   }

   private void setRestoreRequired(boolean var1) {
      this.field_43b2c392 = var1;
   }

   private boolean isTransitionActive() {
      return this.field_b0de3d87;
   }

   private void setTransitionActive(boolean var1) {
      this.field_b0de3d87 = var1;
   }

   private int getFireworkSlot() {
      return this.field_1e09b77c;
   }

   private void setFireworkSlot(int var1) {
      this.field_1e09b77c = var1;
   }

   private int getCooldownTicks() {
      return this.field_8b353171;
   }

   private void setCooldownTicks(int var1) {
      this.field_8b353171 = var1;
   }

   private boolean isTargetVisible() {
      return this.field_f860ab66;
   }

   private void setTargetVisible(boolean var1) {
      this.field_f860ab66 = var1;
   }

   private int getRetryCount() {
      return this.field_658c255b;
   }

   private void setRetryCount(int var1) {
      this.field_658c255b = var1;
   }

}
