package atheryx.module.player;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.mixin.interfaces.IClientPlayerInteractionManager;
import atheryx.mixin.interfaces.ILivingEntity;
import atheryx.mixin.interfaces.IMinecraftClient;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.MultiSetting;

@NewFunction(
   name = "NoDelay",
   desc = "Убирает задержку у выбранных элементов",
   category = Category.PLAYER
)
public class NoDelay extends Function {
   final MultiSetting delay = new MultiSetting("Убрать задержку", new String[]{"Прыжка", "Ломания", "ПКМ"});

   public NoDelay() {
      this.addSettings(new Setting[]{this.getDelay()});
   }

   @EventHandler
   public void onUpdate(UpdateEvent e) {
      if (!this.nullCheck.isPlayerMissing()) {
         if (this.getDelay().isSelected("Ломания")) {
            ((IClientPlayerInteractionManager)this.mc.field_1761).setBlockBreakingCooldown(0);
         }

         if (this.getDelay().isSelected("Прыжка")) {
            ((ILivingEntity)this.mc.field_1724).setJumpingCooldown(0);
         }

         if (this.getDelay().isSelected("ПКМ")) {
            ((IMinecraftClient)this.mc).setItemUseCooldown(0);
         }

      }
   }

   private MultiSetting getDelay() {
      return this.delay;
   }

}
