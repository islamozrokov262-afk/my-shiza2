package atheryx.module;

import atheryx.module.combat.AntiBot;
import atheryx.module.combat.AttackAura;
import atheryx.module.combat.AutoExplosion;
import atheryx.module.combat.AutoPotion;
import atheryx.module.combat.AutoSwap;
import atheryx.module.combat.AutoTotem;
import atheryx.module.combat.HitBox;
import atheryx.module.combat.NoFriendDamage;
import atheryx.module.combat.PacketCriticals;
import atheryx.module.combat.SpamCrossbow;
import atheryx.module.combat.TargetStrafe;
import atheryx.module.combat.TriggerBot;
import atheryx.module.combat.Velocity;
import atheryx.module.misc.Ambience;
import atheryx.module.misc.AntiAFK;
import atheryx.module.misc.AutoLeave;
import atheryx.module.misc.AutoRespawn;
import atheryx.module.misc.AutoTpAccept;
import atheryx.module.misc.Bots;
import atheryx.module.misc.FreeCam;
import atheryx.module.misc.JoinerHelper;
import atheryx.module.misc.ServerRPSpoofer;
import atheryx.module.misc.Sounds;
import atheryx.module.misc.StreamerMode;
import atheryx.module.misc.TrashTalk;
import atheryx.module.movement.AirStuck;
import atheryx.module.movement.Fly;
import atheryx.module.movement.GrimExploit;
import atheryx.module.movement.GrimGlide;
import atheryx.module.movement.GuiMove;
import atheryx.module.movement.NoPush;
import atheryx.module.movement.NoSlow;
import atheryx.module.movement.NoWeb;
import atheryx.module.movement.Scaffold;
import atheryx.module.movement.Speed;
import atheryx.module.movement.Spider;
import atheryx.module.movement.Sprint;
import atheryx.module.movement.SuperFireWork;
import atheryx.module.movement.Timer;
import atheryx.module.player.AutoDuels;
import atheryx.module.player.AutoTool;
import atheryx.module.player.ClickAction;
import atheryx.module.player.ElytraHelper;
import atheryx.module.player.ItemScroller;
import atheryx.module.player.NoDelay;
import atheryx.module.player.NoInteract;
import atheryx.module.player.NoSlotChange;
import atheryx.module.player.TapeMouse;
import atheryx.module.render.Arrows;
import atheryx.module.render.BeautifulHands;
import atheryx.module.render.BlockOverlay;
import atheryx.module.render.ChinaHat;
import atheryx.module.render.EntityESP;
import atheryx.module.render.FireFly;
import atheryx.module.render.Fog;
import atheryx.module.render.FullBright;
import atheryx.module.render.HUD;
import atheryx.module.render.HandChams;
import atheryx.module.render.HitIndicator;
import atheryx.module.render.HitWave;
import atheryx.module.render.JumpCircles;
import atheryx.module.render.NameTags;
import atheryx.module.render.NoRender;
import atheryx.module.render.Particles;
import atheryx.module.render.Predictions;
import atheryx.module.render.ScoreboardHealth;
import atheryx.module.render.ShaderSky;
import atheryx.module.render.SmokeHands;
import atheryx.module.render.SwingAnimations;
import atheryx.module.render.TargetESP;
import atheryx.module.render.ViewModel;
import atheryx.module.world.AresFarm;
import atheryx.module.world.TrapViewer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import lombok.Generated;

public class FunctionManager {
   private static final List<Function> FUNCTIONS = new ArrayList<Function>();

   public static void init() {
      registerAll(new AttackAura(), new TargetStrafe(), new AntiBot(), new AutoExplosion(), new AutoTotem(), new NoFriendDamage(), new TriggerBot(), new AutoSwap(), new Velocity(), new AutoPotion(), new SpamCrossbow(), new PacketCriticals(), new HitBox());
      registerAll(new Sprint(), new Speed(), new NoSlow(), new NoPush(), new Fly(), new AirStuck(), new GrimGlide(), new GrimExploit(), new NoWeb(), new GuiMove(), new Scaffold(), new SuperFireWork(), new Spider(), new Timer());
      registerAll(new HUD(), new Particles(), new FireFly(), new JumpCircles(), new TargetESP(), new BlockOverlay(), new Predictions(), new ShaderSky(), new SwingAnimations(), new ViewModel(), new BeautifulHands(), new HandChams(), new SmokeHands(), new EntityESP(), new Fog(), new NoRender(), new Arrows(), new HitWave(), new HitIndicator(), new FullBright(), new NameTags(), new ChinaHat());
      registerAll(new NoDelay(), new AutoDuels(), new ElytraHelper(), new ClickAction(), new NoInteract(), new ItemScroller(), new AutoTool(), new TapeMouse(), new NoSlotChange());
      registerAll(new Sounds(), new Ambience(), new TrashTalk(), new AntiAFK(), new ScoreboardHealth(), new Bots(), new AutoTpAccept(), new FreeCam(), new ServerRPSpoofer(), new JoinerHelper(), new AutoLeave(), new StreamerMode(), new AutoRespawn());
      registerAll(new AresFarm(), new TrapViewer());
   }

   private static void registerAll(Function... functionArray) {
      FUNCTIONS.addAll(Arrays.asList(functionArray));
   }

   public static <T extends Function> T getFunction(Class<T> clazz) {
      return (T)(FUNCTIONS.stream().filter((f) -> {
         return f.getClass() == clazz;
      }).findFirst().orElse(null));
   }

   public static List<Function> getByCategory(Category category) {
      return (List)FUNCTIONS.stream().filter((f) -> {
         return f.getCategory() == category;
      }).collect(Collectors.toList());
   }

   @Generated
   public static List<Function> getFunctions() {
      return FUNCTIONS;
   }

}
