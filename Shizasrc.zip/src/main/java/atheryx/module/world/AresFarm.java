package atheryx.module.world;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.manager.RotationManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_1268;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@NewFunction(
   name = "AresFarm",
   desc = "Скрытая ферма бамбука и тростника с подсветкой блоков",
   category = Category.MISC
)
public class AresFarm extends Function {
   private static final RenderPipeline obf_u2230_u0432;
   private static final class_1921 obf_u03ac_u0432;
   public static AresFarm Instance;
   private final ModeSetting presetModeSetting = new ModeSetting("Preset", new String[]{"Aresmine", "Свой"});
   private final NumberSetting scanRangeNumberSetting = new NumberSetting("Scan Range", 32.0D, 4.0D, 32.0D, (double)1.0F);
   private final NumberSetting breakRangeNumberSetting = new NumberSetting("Break Range", 3.0D, 2.0D, 5.0D, 0.1);
   private final NumberSetting yRangeNumberSetting = new NumberSetting("Y Range", 2.0D, 2.0D, 12.0D, (double)1.0F);
   private final NumberSetting rotateSpeedNumberSetting = new NumberSetting("Rotate Speed", 60.0D, 20.0D, 180.0D, 5.0D);
   private final NumberSetting aimDelayNumberSetting = new NumberSetting("Aim Delay", (double)1.0F, (double)1.0F, 10.0D, (double)1.0F);
   private final NumberSetting breakDelayNumberSetting = new NumberSetting("Break Delay", (double)0.0F, (double)0.0F, 15.0D, (double)1.0F);
   private final BooleanSetting keepBaseBooleanSetting = new BooleanSetting("Keep Base", false);
   private final BooleanSetting renderBooleanSetting = new BooleanSetting("Render", true);
   private double field_43b2c392;
   private double field_b0de3d87;
   private double field_1e09b77c;
   private float field_8b353171;
   private int field_f860ab66;
   private int field_658c255b;
   private boolean field_d2b79f50;
   private boolean field_3fe31945;
   private class_2338 field_ad0e933a;
   private class_2338 field_1a3a0d2f;
   private class_243 field_87658724;
   private int field_f4910119;
   private int field_61bc7b0e;
   private int field_cee7f503;
   private int field_3c136ef8;

   public AresFarm() {
      Instance = this;
      this.getPresetSetting().setChangeListener(this::refreshTarget);
      this.addSettings(new Setting[]{this.getPresetSetting(), this.getScanRangeSetting(), this.getBreakRangeSetting(), this.getYRangeSetting(), this.getRotateSpeedSetting(), this.getAimDelaySetting(), this.getBreakDelaySetting(), this.getKeepBaseSetting(), this.getRenderSetting()});
   }

   public void onDisable() {
      this.setTargetBlockPos((class_2338)null);
      this.setPlacementPos((class_2338)null);
      this.setCurrentPosition((class_243)null);
      this.setActionCooldownTicks(0);
      this.setSelectedSlot(0);
      this.setTargetEntityId(0);
      this.setElapsedTicks(0);
      RotationManager.reset();
      if (this.mc.field_1690 != null) {
         this.mc.field_1690.field_1886.method_23481(false);
      }

   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing() && this.mc.field_1761 != null) {
         this.updateRotation();
         if (this.getElapsedTicks() > 0) {
            this.setElapsedTicks(this.getElapsedTicks() - 1);
         }

         if (!this.isPosInRange(this.getTargetBlockPos())) {
            if (this.getTargetBlockPos() != null) {
               this.setElapsedTicks(this.getRetryCount());
            }

            this.setTargetBlockPos((class_2338)null);
            this.setPlacementPos((class_2338)null);
            this.setCurrentPosition((class_243)null);
            this.setSelectedSlot(0);
            this.setTargetEntityId(0);
         }

         label78: {
            if (this.getTargetBlockPos() != null) {
               int var10002 = this.getActionCooldownTicks();
               this.setActionCooldownTicks(var10002 - 1);
               if (var10002 > 0) {
                  break label78;
               }
            }

            this.setTargetBlockPos(this.findTargetBlockPos());
            this.setActionCooldownTicks(5);
         }

         if (this.getTargetBlockPos() == null) {
            this.updateRotationForTarget();
         } else if (!this.isValidPosSecondary(this.getTargetBlockPos())) {
            this.setCurrentPosition((class_243)null);
            this.advanceActionPhase();
            RotationManager.reset();
         } else {
            this.setCurrentPosition(this.calculatePosition(this.getTargetBlockPos()));
            if (this.getCurrentPosition() == null) {
               this.advanceActionPhase();
               this.setTargetEntityId(0);
            } else {
               this.processPosition(this.getCurrentPosition());
               if (!this.isValidPos(this.getCurrentPosition())) {
                  this.advanceActionPhase();
                  this.setTargetEntityId(0);
               } else {
                  this.setTargetEntityId(this.getTargetEntityId() + 1);
                  if (this.getElapsedTicks() == 0 && this.getTargetEntityId() >= this.getCooldownTicks()) {
                     this.setPlacementPos(this.getTargetBlockPos());
                     this.processPosition(this.getTargetBlockPos());
                  }

               }
            }
         }
      } else {
         this.updateRotationForTarget();
      }
   }

   public static void onWorldRender(WorldRenderContext context) {
      if (Instance != null && Instance.isEnabled() && Instance.isInputCaptured()) {
         Instance.renderWorldOverlay(context);
      }
   }

   private void refreshTarget() {
      boolean custom = this.getPresetSetting().isSelected("Свой");
      this.getScanRangeSetting().setVisible(custom);
      this.getBreakRangeSetting().setVisible(custom);
      this.getYRangeSetting().setVisible(custom);
      this.getRotateSpeedSetting().setVisible(custom);
      this.getAimDelaySetting().setVisible(custom);
      this.getBreakDelaySetting().setVisible(custom);
      this.getKeepBaseSetting().setVisible(custom);
      this.getRenderSetting().setVisible(custom);
      this.updateRotation();
   }

   private void updateRotation() {
      if (this.getPresetSetting().isSelected("Свой")) {
         this.setMaxDistanceSq(this.getScanRangeSetting().getValue());
         this.setDistance(this.getBreakRangeSetting().getValue());
         this.setTargetDistance(this.getYRangeSetting().getValue());
         this.setAnimationProgress((float)this.getRotateSpeedSetting().getValue());
         this.setCooldownTicks((int)this.getAimDelaySetting().getValue());
         this.setRetryCount((int)this.getBreakDelaySetting().getValue());
         this.setActionPending(this.getKeepBaseSetting().isEnabled());
         this.setInputCaptured(this.getRenderSetting().isEnabled());
      } else {
         this.setMaxDistanceSq(32.0D);
         this.setDistance(3.0D);
         this.setTargetDistance(2.0D);
         this.setAnimationProgress(60.0F);
         this.setCooldownTicks(1);
         this.setRetryCount(0);
         this.setActionPending(false);
         this.setInputCaptured(true);
      }
   }

   private void processPosition(class_243 pos) {
      RotationManager.Rotation rotation = RotationManager.rotationTo(pos);
      RotationManager.requestRotation(rotation, RotationManager.MoveCorrection.SILENT, this.getAnimationProgress(), this.getAnimationProgress(), 90.0F);
   }

   private void processPosition(class_2338 pos) {
      class_2350 side = this.findHorizontalDirection(pos);
      if (this.getSelectedSlot() == 0) {
         this.mc.field_1761.method_2910(pos, side);
      } else {
         this.mc.field_1761.method_2902(pos, side);
      }

      this.mc.field_1724.method_6104(class_1268.field_5808);
      this.setSelectedSlot(this.getSelectedSlot() + 1);
   }

   private class_2338 findTargetBlockPos() {
      class_2338 playerPos = this.mc.field_1724.method_24515();
      int horizontal = (int)this.getMaxDistanceSq();
      int vertical = (int)this.getTargetDistance();
      double maxDistanceSq = this.getMaxDistanceSq() * this.getMaxDistanceSq();
      ArrayList<class_2338> blocks = new ArrayList<class_2338>();

      for(int x = -horizontal; x <= horizontal; ++x) {
         for(int y = -vertical; y <= vertical; ++y) {
            for(int z = -horizontal; z <= horizontal; ++z) {
               class_2338 pos = playerPos.method_10069(x, y, z);
               if (!(this.mc.field_1724.method_5707(class_243.method_24953(pos)) > maxDistanceSq) && this.isValidPos(pos)) {
                  blocks.add(pos.method_10062());
               }
            }
         }
      }

      return blocks.stream().min(Comparator.comparingDouble((posx) -> {
         return this.calculateAnimationFactor(posx, playerPos);
      })).orElse(null);
   }

   private double calculateAnimationFactor(class_2338 pos, class_2338 playerPos) {
      return this.mc.field_1724.method_5707(class_243.method_24953(pos));
   }

   private boolean isValidPos(class_2338 pos) {
      if (!this.isValidPosPrimary(pos)) {
         return false;
      } else {
         class_2680 state = this.mc.field_1687.method_8320(pos);
         boolean sameBelow = this.isValidPos(pos.method_10074(), state);
         boolean sameTwoBelow = this.isValidPos(pos.method_10087(2), state);
         if (!this.isActionPending()) {
            return !sameBelow;
         } else {
            return sameBelow && !sameTwoBelow;
         }
      }
   }

   private boolean isPosInRange(class_2338 pos) {
      return pos != null && this.mc.field_1687 != null && this.isValidPos(pos) && this.mc.field_1724.method_5707(class_243.method_24953(pos)) <= this.getMaxDistanceSq() * this.getMaxDistanceSq();
   }

   private boolean isValidPosPrimary(class_2338 pos) {
      if (pos != null && this.mc.field_1687 != null) {
         class_2680 state = this.mc.field_1687.method_8320(pos);
         return this.isValidState(state);
      } else {
         return false;
      }
   }

   private boolean isValidPos(class_2338 pos, class_2680 cropState) {
      if (pos != null && this.mc.field_1687 != null) {
         class_2680 state = this.mc.field_1687.method_8320(pos);
         if (!cropState.method_27852(class_2246.field_10211) && !cropState.method_27852(class_2246.field_10108)) {
            return cropState.method_27852(class_2246.field_10424) && state.method_27852(class_2246.field_10424);
         } else {
            return state.method_27852(class_2246.field_10211) || state.method_27852(class_2246.field_10108);
         }
      } else {
         return false;
      }
   }

   private boolean isValidState(class_2680 state) {
      return state.method_27852(class_2246.field_10211) || state.method_27852(class_2246.field_10108) || state.method_27852(class_2246.field_10424);
   }

   private boolean isValidPosSecondary(class_2338 pos) {
      class_243 closest = this.calculatePositionPrimary(pos);
      return this.mc.field_1724.method_33571().method_1025(closest) <= this.getDistance() * this.getDistance();
   }

   private class_243 calculatePosition(class_2338 pos) {
      for(class_243 point : this.collectItems(pos)) {
         if (this.matchesPos(pos, point)) {
            return point;
         }
      }

      return null;
   }

   private boolean matchesPos(class_2338 pos, class_243 point) {
      class_3965 result = this.mc.field_1687.method_17742(new class_3959(this.mc.field_1724.method_33571(), point, class_3960.field_17559, class_242.field_1348, this.mc.field_1724));
      return result.method_17783() == class_240.field_1332 && result.method_17777().equals(pos);
   }

   private boolean isValidPos(class_243 pos) {
      RotationManager.Rotation required = RotationManager.rotationTo(pos);
      RotationManager.Rotation current = RotationManager.getCurrentRotation();
      float yawDelta = Math.abs(class_3532.method_15393(required.yaw() - current.yaw()));
      float pitchDelta = Math.abs(class_3532.method_15393(required.pitch() - current.pitch()));
      return yawDelta <= 6.0F && pitchDelta <= 6.0F;
   }

   private List<class_243> collectItems(class_2338 pos) {
      class_238 box = this.calculateBoundingBox(pos).method_1014(0.01);
      class_243 eyes = this.mc.field_1724.method_33571();
      class_243 center = box.method_1005();
      class_243 nearest = new class_243(class_3532.method_15350(eyes.field_1352, box.field_1323, box.field_1320), class_3532.method_15350(eyes.field_1351, box.field_1322, box.field_1325), class_3532.method_15350(eyes.field_1350, box.field_1321, box.field_1324));
      ArrayList points = new ArrayList();
      points.add(nearest);
      points.add(center);
      points.add(new class_243(center.field_1352, box.field_1322 + box.method_17940() * (double)0.25F, center.field_1350));
      points.add(new class_243(center.field_1352, box.field_1322 + box.method_17940() * 0.55, center.field_1350));
      points.add(new class_243(center.field_1352, box.field_1322 + box.method_17940() * 0.85, center.field_1350));
      return points;
   }

   private class_243 calculatePositionPrimary(class_2338 pos) {
      class_238 box = this.calculateBoundingBox(pos);
      class_243 eyes = this.mc.field_1724.method_33571();
      return new class_243(class_3532.method_15350(eyes.field_1352, box.field_1323, box.field_1320), class_3532.method_15350(eyes.field_1351, box.field_1322, box.field_1325), class_3532.method_15350(eyes.field_1350, box.field_1321, box.field_1324));
   }

   private class_238 calculateBoundingBox(class_2338 pos) {
      class_265 shape = this.mc.field_1687.method_8320(pos).method_26218(this.mc.field_1687, pos);
      return shape.method_1110() ? new class_238(pos) : shape.method_1107().method_996(pos);
   }

   private class_2350 findHorizontalDirection(class_2338 pos) {
      class_243 eyes = this.mc.field_1724.method_33571();
      class_243 center = class_243.method_24953(pos);
      class_243 delta = eyes.method_1020(center);
      return class_2350.method_10142(delta.field_1352, delta.field_1351, delta.field_1350);
   }

   private void updateRotationForTarget() {
      this.setTargetBlockPos((class_2338)null);
      this.setPlacementPos((class_2338)null);
      this.setCurrentPosition((class_243)null);
      this.setSelectedSlot(0);
      this.setTargetEntityId(0);
      this.setElapsedTicks(0);
      RotationManager.reset();
      if (this.mc.field_1690 != null) {
         this.mc.field_1690.field_1886.method_23481(false);
      }

   }

   private void advanceActionPhase() {
      if (this.getPlacementPos() != null && this.getSelectedSlot() > 0 && this.mc.field_1761 != null) {
         this.mc.field_1761.method_2925();
      }

      this.setPlacementPos((class_2338)null);
      this.setCurrentPosition((class_243)null);
      this.setSelectedSlot(0);
      this.mc.field_1690.field_1886.method_23481(false);
   }

   private void renderWorldOverlay(WorldRenderContext context) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
         class_243 camera = context.worldState().field_63082.field_63078;
         class_4588 buffer = context.consumers().method_73477(obf_u03ac_u0432);
         class_4587.class_4665 entry = context.matrices().method_23760();
         if (this.getTargetBlockPos() != null) {
            this.renderWorldOverlay(buffer, entry, context, this.getTargetBlockPos(), camera, new Color(60, 255, 90), 2.0F);
         }

         if (this.getPlacementPos() != null) {
            this.renderWorldOverlay(buffer, entry, context, this.getPlacementPos(), camera, new Color(255, 80, 80), 3.0F);
         }

      }
   }

   private void renderWorldOverlay(class_4588 buffer, class_4587.class_4665 entry, WorldRenderContext context, class_2338 pos, class_243 camera, Color color, float width) {
      class_265 shape = this.mc.field_1687.method_8320(pos).method_26218(this.mc.field_1687, pos);
      class_238 box = (shape.method_1110() ? new class_238(pos) : shape.method_1107().method_996(pos)).method_1014(0.002).method_989(-camera.field_1352, -camera.field_1351, -camera.field_1350);
      this.drawBox(buffer, entry, box, color, width);
   }

   private void drawBox(class_4588 buffer, class_4587.class_4665 entry, class_238 box, Color color, float width) {
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1323, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1320, box.field_1325, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1325, box.field_1324, width);
   }

   private void emitLine(class_4588 buffer, class_4587.class_4665 entry, Color color, double x1, double y1, double z1, double x2, double y2, double z2, float width) {
      float dx = (float)(x2 - x1);
      float dy = (float)(y2 - y1);
      float dz = (float)(z2 - z1);
      float length = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
      if (!(length <= 1.0E-4F)) {
         buffer.method_56824(entry, (float)x1, (float)y1, (float)z1).method_1336(color.getRed(), color.getGreen(), color.getBlue(), 255).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
         buffer.method_56824(entry, (float)x2, (float)y2, (float)z2).method_1336(color.getRed(), color.getGreen(), color.getBlue(), 255).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
      }
   }

   static {
      obf_u2230_u0432 = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56859}).withLocation(class_2960.method_60655("atheryx", "aresfarm_lines")).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).build());
      obf_u03ac_u0432 = class_1921.method_75940("atheryx_aresfarm_lines", class_12247.method_75927(obf_u2230_u0432).method_75930(class_12245.field_63976).method_75931(class_12246.field_63983).method_75938());
   }

   private ModeSetting getPresetSetting() {
      return this.presetModeSetting;
   }

   private NumberSetting getScanRangeSetting() {
      return this.scanRangeNumberSetting;
   }

   private NumberSetting getBreakRangeSetting() {
      return this.breakRangeNumberSetting;
   }

   private NumberSetting getYRangeSetting() {
      return this.yRangeNumberSetting;
   }

   private NumberSetting getRotateSpeedSetting() {
      return this.rotateSpeedNumberSetting;
   }

   private NumberSetting getAimDelaySetting() {
      return this.aimDelayNumberSetting;
   }

   private NumberSetting getBreakDelaySetting() {
      return this.breakDelayNumberSetting;
   }

   private BooleanSetting getKeepBaseSetting() {
      return this.keepBaseBooleanSetting;
   }

   private BooleanSetting getRenderSetting() {
      return this.renderBooleanSetting;
   }

   private double getMaxDistanceSq() {
      return this.field_43b2c392;
   }

   private void setMaxDistanceSq(double var1) {
      this.field_43b2c392 = var1;
   }

   private double getDistance() {
      return this.field_b0de3d87;
   }

   private void setDistance(double var1) {
      this.field_b0de3d87 = var1;
   }

   private double getTargetDistance() {
      return this.field_1e09b77c;
   }

   private void setTargetDistance(double var1) {
      this.field_1e09b77c = var1;
   }

   private float getAnimationProgress() {
      return this.field_8b353171;
   }

   private void setAnimationProgress(float var1) {
      this.field_8b353171 = var1;
   }

   private int getCooldownTicks() {
      return this.field_f860ab66;
   }

   private void setCooldownTicks(int var1) {
      this.field_f860ab66 = var1;
   }

   private int getRetryCount() {
      return this.field_658c255b;
   }

   private void setRetryCount(int var1) {
      this.field_658c255b = var1;
   }

   private boolean isActionPending() {
      return this.field_d2b79f50;
   }

   private void setActionPending(boolean var1) {
      this.field_d2b79f50 = var1;
   }

   private boolean isInputCaptured() {
      return this.field_3fe31945;
   }

   private void setInputCaptured(boolean var1) {
      this.field_3fe31945 = var1;
   }

   private class_2338 getTargetBlockPos() {
      return this.field_ad0e933a;
   }

   private void setTargetBlockPos(class_2338 var1) {
      this.field_ad0e933a = var1;
   }

   private class_2338 getPlacementPos() {
      return this.field_1a3a0d2f;
   }

   private void setPlacementPos(class_2338 var1) {
      this.field_1a3a0d2f = var1;
   }

   private class_243 getCurrentPosition() {
      return this.field_87658724;
   }

   private void setCurrentPosition(class_243 var1) {
      this.field_87658724 = var1;
   }

   private int getActionCooldownTicks() {
      return this.field_f4910119;
   }

   private void setActionCooldownTicks(int var1) {
      this.field_f4910119 = var1;
   }

   private int getSelectedSlot() {
      return this.field_61bc7b0e;
   }

   private void setSelectedSlot(int var1) {
      this.field_61bc7b0e = var1;
   }

   private int getTargetEntityId() {
      return this.field_cee7f503;
   }

   private void setTargetEntityId(int var1) {
      this.field_cee7f503 = var1;
   }

   private int getElapsedTicks() {
      return this.field_3c136ef8;
   }

   private void setElapsedTicks(int var1) {
      this.field_3c136ef8 = var1;
   }

}
