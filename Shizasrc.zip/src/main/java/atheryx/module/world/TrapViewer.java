package atheryx.module.world;

import atheryx.event.EventHandler;
import atheryx.event.impl.Render2DEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.render.RenderUtil;
import atheryx.render.font.Msdf;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import java.awt.Color;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_10789;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

@NewFunction(
   name = "TrapViewer",
   desc = "Подсвечивает ловушки из верстаков под игроком",
   category = Category.MISC
)
public class TrapViewer extends Function {
   private static final RenderPipeline obf_u040d_u0432;
   private static final class_1921 obf_u00d8_u0432;
   private static final class_2960 obf_u2215_u0432;
   private static final RenderPipeline obf_u00eb_u0432;
   private static final class_1921 obf_u0423_u0432;
   private static final RenderPipeline obf_u00ff_u0432;
   private static final class_1921 obf_u041d_u0432;
   public static TrapViewer Instance;
   private final NumberSetting horizontalRangeNumberSetting = new NumberSetting("Horizontal Range", 16.0D, 4.0D, 32.0D, (double)1.0F);
   private final NumberSetting downRangeNumberSetting = new NumberSetting("Down Range", 128.0D, 4.0D, 128.0D, (double)1.0F);
   private final NumberSetting fadeSpeedNumberSetting = new NumberSetting("Fade Speed", 0.15, 0.02, (double)1.0F, 0.01);
   private final BooleanSetting fillBooleanSetting = new BooleanSetting("Fill", true);
   private final NumberSetting fillAlphaNumberSetting = new NumberSetting("Fill Alpha", 0.45, 0.1, (double)1.0F, 0.05);
   private final ModeSetting shaderModeSetting = new ModeSetting("Shader", new String[]{"Full", "WebShader", "Plasma", "ChamsFill", "BaseWarp", "Waves"});
   private final Set<class_2338> field_fc3055b3 = new HashSet<class_2338>();
   private final Map<class_2338, Float> field_695bcfa8 = new HashMap<class_2338, Float>();
   private class_238 field_d687499d;
   private class_243 field_43b2c392;
   private float field_b0de3d87;
   private int field_1e09b77c;
   private float field_8b353171;
   private float field_f860ab66;
   private float field_658c255b;
   private boolean field_d2b79f50;
   private float field_3fe31945;

   public TrapViewer() {
      this.setScale(1.0F);
      this.setCurrentAlpha(1.0F);
      Instance = this;
      this.addSettings(new Setting[]{this.getHorizontalRangeSetting(), this.getDownRangeSetting(), this.getFadeSpeedSetting(), this.getFillSetting(), this.getFillAlphaSetting(), this.getShaderSetting()});
   }

   public void onDisable() {
      this.getTrackedPositions().clear();
      this.getTrackedEntries().clear();
      this.setRenderBox((class_238)null);
      this.setCurrentPosition((class_243)null);
      this.setAnimationProgress(0.0F);
      this.setCooldownTicks(0);
      this.setScale(1.0F);
      this.setX(0.0F);
      this.setY(0.0F);
      this.setActionPending(false);
      this.setCurrentAlpha(1.0F);
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.nullCheck.isPlayerOrWorldMissing()) {
         this.getTrackedPositions().clear();
         this.getTrackedEntries().clear();
         this.setRenderBox((class_238)null);
         this.setCurrentPosition((class_243)null);
         this.setAnimationProgress(this.lerp(this.getAnimationProgress(), 0.0F, 0.15F));
         this.setCooldownTicks(0);
      } else {
         this.getTrackedPositions().clear();
         class_2338 playerPos = this.mc.field_1724.method_24515();
         int h = (int)this.getHorizontalRangeSetting().getValue();
         int down = (int)this.getDownRangeSetting().getValue();

         for(int x = -h; x <= h; ++x) {
            for(int y = -down; y <= -1; ++y) {
               for(int z = -h; z <= h; ++z) {
                  class_2338 pos = playerPos.method_10069(x, y, z);
                  if (this.mc.field_1687.method_8320(pos).method_27852(class_2246.field_9980)) {
                     this.getTrackedPositions().add(pos.method_10062());
                  }
               }
            }
         }

         this.setCooldownTicks(this.getTrackedPositions().size());
         float speed = (float)this.getFadeSpeedSetting().getValue();

         for(class_2338 pos : this.getTrackedPositions()) {
            this.getTrackedEntries().put(pos, Math.min(1.0F, (Float)this.getTrackedEntries().getOrDefault(pos, 0.0F) + speed));
         }

         this.getTrackedEntries().entrySet().removeIf((entry) -> {
            if (this.getTrackedPositions().contains(entry.getKey())) {
               return false;
            } else {
               float alpha = (Float)entry.getValue() - speed;
               if (alpha <= 0.0F) {
                  return true;
               } else {
                  entry.setValue(alpha);
                  return false;
               }
            }
         });
         this.setAnimationProgress(this.lerp(this.getAnimationProgress(), this.getTrackedPositions().isEmpty() ? 0.0F : 1.0F, 0.12F));
      }
   }

   @EventHandler
   public void onRender2D(Render2DEvent event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null && !this.mc.field_1690.field_1842 && !this.mc.method_53526().method_53536()) {
         if (!(this.getAnimationProgress() <= 0.02F) && this.getCurrentPosition() != null) {
            class_332 context = event.getDrawContext();
            if (context != null) {
               ScreenPosition screen = this.projectToScreen(this.getCurrentPosition());
               if (screen == null) {
                  this.setActionPending(false);
               } else {
                  float eased = this.easeOutCubic(this.getAnimationProgress());
                  String text = "Трапка";
                  float distance = (float)Math.sqrt(this.mc.field_1724.method_5707(this.getCurrentPosition()));
                  float targetScale = Math.clamp(7.0F / Math.max(1.0F, distance), 0.45F, 1.15F);
                  targetScale *= 0.85F + 0.15F * eased;
                  this.setScale(this.lerp(this.getScale(), targetScale, 0.12F));
                  float scale = this.getScale();
                  float textSize = 8.5F * scale;
                  float var10 = 8.0F * scale;
                  float paddingX = 7.0F * scale;
                  float paddingY = 4.0F * scale;
                  float gap = 5.0F * scale;
                  float var14 = Msdf.getTextWidth(text, textSize);
                  float width = var14 + gap + paddingX * 2.0F;
                  float height = 18.0F * scale;
                  float targetX = screen.x - width / 2.0F;
                  float targetY = screen.y - height / 2.0F;
                  if (!this.isActionPending()) {
                     this.setX(targetX);
                     this.setY(targetY);
                     this.setActionPending(true);
                  }

                  this.setX(this.lerp(this.getX(), targetX, 0.18F));
                  this.setY(this.lerp(this.getY(), targetY, 0.18F));
                  float x = this.getX();
                  float y = this.getY();
                  RenderUtil.drawRoundedRect(x, y, width, height, 6.0F * scale, this.applyOpacity(new Color(20, 20, 22, 190), eased));
                  RenderUtil.drawText(context, x + paddingX, y + paddingY, text, textSize, this.applyOpacity(new Color(248, 248, 250), eased));
               }
            }
         }
      }
   }

   public static void onWorldRender(WorldRenderContext context) {
      if (Instance != null && Instance.isEnabled()) {
         Instance.renderWorldOverlay(context);
      }
   }

   private void renderWorldOverlay(WorldRenderContext context) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null && !this.getTrackedEntries().isEmpty()) {
         class_243 camera = context.worldState().field_63082.field_63078;
         class_4587.class_4665 matrix = context.matrices().method_23760();
         class_238 targetBox = null;
         float maxAlpha = 0.0F;

         for(Map.Entry<class_2338, Float> animEntry : this.getTrackedEntries().entrySet()) {
            class_2338 pos = animEntry.getKey();
            class_265 shape = this.mc.field_1687.method_8320(pos).method_26218(this.mc.field_1687, pos);
            class_238 box = shape.method_1110() ? new class_238(pos) : shape.method_1107().method_996(pos);
            targetBox = targetBox == null ? box : targetBox.method_991(box);
            maxAlpha = Math.max(maxAlpha, (Float)animEntry.getValue());
         }

         if (targetBox == null) {
            this.setRenderBox((class_238)null);
            this.setCurrentPosition((class_243)null);
         } else {
            boolean insideX = this.mc.field_1724.method_23317() >= targetBox.field_1323 && this.mc.field_1724.method_23317() <= targetBox.field_1320;
            this.setCurrentAlpha(this.lerp(this.getCurrentAlpha(), insideX ? 0.0F : 1.0F, 0.1F));
            if (this.getRenderBox() == null) {
               if (this.getCurrentAlpha() < 0.01F) {
                  this.setCurrentPosition((class_243)null);
                  return;
               }

               class_243 center = targetBox.method_1005();
               this.setRenderBox(new class_238(center.field_1352, center.field_1351, center.field_1350, center.field_1352, center.field_1351, center.field_1350));
            }

            float speed = (float)this.getFadeSpeedSetting().getValue();
            this.setRenderBox(new class_238(this.lerp(this.getRenderBox().field_1323, targetBox.field_1323, (double)speed), this.lerp(this.getRenderBox().field_1322, targetBox.field_1322, (double)speed), this.lerp(this.getRenderBox().field_1321, targetBox.field_1321, (double)speed), this.lerp(this.getRenderBox().field_1320, targetBox.field_1320, (double)speed), this.lerp(this.getRenderBox().field_1325, targetBox.field_1325, (double)speed), this.lerp(this.getRenderBox().field_1324, targetBox.field_1324, (double)speed)));
            this.setCurrentPosition(this.calculatePosition(this.getTargetPosition(targetBox).method_1031((double)0.0F, 0.65, (double)0.0F)));
            class_238 renderBox = this.getRenderBox().method_1014(0.01).method_989(-camera.field_1352, -camera.field_1351, -camera.field_1350);
            float renderAlpha = maxAlpha * this.getCurrentAlpha();
            if (this.getFillSetting().isEnabled()) {
               this.renderWorldOverlay(context, renderBox, renderAlpha);
            }

            class_4588 lineBuffer = context.consumers().method_73477(obf_u00d8_u0432);
            this.drawBox(lineBuffer, matrix, renderBox, this.applyOpacity(ThemeManager.getCurrentColor(), renderAlpha), 3.0F);
         }
      } else {
         this.setRenderBox((class_238)null);
         this.setCurrentPosition((class_243)null);
      }
   }

   private class_243 getTargetPosition(class_238 box) {
      return new class_243((box.field_1323 + box.field_1320) / 2.0D, box.field_1325, (box.field_1321 + box.field_1324) / 2.0D);
   }

   private class_243 calculatePosition(class_243 pos) {
      return new class_243(Math.floor(pos.field_1352 * 100.0D) / 100.0D, Math.floor(pos.field_1351 * 100.0D) / 100.0D, Math.floor(pos.field_1350 * 100.0D) / 100.0D);
   }

   private ScreenPosition projectToScreen(class_243 position) {
      class_243 cameraPos = this.mc.field_1773.method_19418().method_71156();
      class_243 cameraForward = class_243.method_1030(this.mc.field_1773.method_19418().method_19329(), this.mc.field_1773.method_19418().method_19330());
      if (position.method_1020(cameraPos).method_1029().method_1026(cameraForward) <= (double)0.0F) {
         return null;
      } else {
         class_243 projected = this.mc.field_1773.method_70778(position);
         if (!(projected.field_1350 < (double)-1.0F) && !(projected.field_1350 > (double)1.0F)) {
            float x = (float)((projected.field_1352 + (double)1.0F) * (double)0.5F * (double)RenderUtil.getScaledWidth());
            float y = (float)(((double)1.0F - projected.field_1351) * (double)0.5F * (double)RenderUtil.getScaledHeight());
            return !(x < -100.0F) && !(x > (float)RenderUtil.getScaledWidth() + 100.0F) && !(y < -60.0F) && !(y > (float)RenderUtil.getScaledHeight() + 60.0F) ? new ScreenPosition(x, y) : null;
         } else {
            return null;
         }
      }
   }

   private float lerp(float current, float target, float speed) {
      return current + (target - current) * speed;
   }

   private double lerp(double current, double target, double speed) {
      return current + (target - current) * speed;
   }

   private float easeOutCubic(float progress) {
      float t = this.clamp(progress, 0.0F, 1.0F) - 1.0F;
      return t * t * t + 1.0F;
   }

   private float clamp(float value, float min, float max) {
      return Math.max(min, Math.min(max, value));
   }

   private Color applyOpacity(Color color, float opacity) {
      int alpha = (int)((float)color.getAlpha() * this.clamp(opacity, 0.0F, 1.0F));
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
   }

   private void drawBox(class_4588 buffer, class_4587.class_4665 entry, class_238 box, Color color, float width) {
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1323, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1320, box.field_1325, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1325, box.field_1324, width);
   }

   private void emitLine(class_4588 buffer, class_4587.class_4665 entry, Color color, double x1, double y1, double z1, double x2, double y2, double z2, float width) {
      float dx = (float)(x2 - x1);
      float dy = (float)(y2 - y1);
      float dz = (float)(z2 - z1);
      float length = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
      if (!(length <= 1.0E-4F)) {
         buffer.method_56824(entry, (float)x1, (float)y1, (float)z1).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
         buffer.method_56824(entry, (float)x2, (float)y2, (float)z2).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
      }
   }

   private void renderWorldOverlay(WorldRenderContext context, class_238 box, float maxAlpha) {
      boolean chamsFill = this.getShaderSetting().isSelected("ChamsFill");
      class_4588 buffer = context.consumers().method_73477(chamsFill ? obf_u041d_u0432 : obf_u0423_u0432);
      class_4587.class_4665 entry = context.matrices().method_23760();
      Color color = ThemeManager.getCurrentColor();
      float alpha = maxAlpha * (float)this.getFillAlphaSetting().getValue();
      float inset = 0.001F;
      float modeOffset = chamsFill ? 0.0F : (float)this.getShaderMode() * 2.0F;
      float x1 = (float)box.field_1323;
      float y1 = (float)box.field_1322;
      float z1 = (float)box.field_1321;
      float x2 = (float)box.field_1320;
      float y2 = (float)box.field_1325;
      float z2 = (float)box.field_1324;
      this.emitVertex(buffer, entry, color, x1, y2 + inset, z2, x2, y2 + inset, z2, x2, y2 + inset, z1, x1, y2 + inset, z1, alpha, modeOffset);
      this.emitVertex(buffer, entry, color, x1, y1 - inset, z1, x2, y1 - inset, z1, x2, y1 - inset, z2, x1, y1 - inset, z2, alpha, modeOffset);
      this.emitVertex(buffer, entry, color, x1, y1, z1 - inset, x1, y2, z1 - inset, x2, y2, z1 - inset, x2, y1, z1 - inset, alpha, modeOffset);
      this.emitVertex(buffer, entry, color, x1, y1, z2 + inset, x2, y1, z2 + inset, x2, y2, z2 + inset, x1, y2, z2 + inset, alpha, modeOffset);
      this.emitVertex(buffer, entry, color, x1 - inset, y1, z1, x1 - inset, y1, z2, x1 - inset, y2, z2, x1 - inset, y2, z1, alpha, modeOffset);
      this.emitVertex(buffer, entry, color, x2 + inset, y1, z1, x2 + inset, y2, z1, x2 + inset, y2, z2, x2 + inset, y1, z2, alpha, modeOffset);
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4, float alpha, float modeOffset) {
      this.emitVertex(buffer, entry, color, x1, y1, z1, 0.0F, 1.0F + modeOffset, alpha);
      this.emitVertex(buffer, entry, color, x2, y2, z2, 1.0F, 1.0F + modeOffset, alpha);
      this.emitVertex(buffer, entry, color, x3, y3, z3, 1.0F, 0.0F + modeOffset, alpha);
      this.emitVertex(buffer, entry, color, x4, y4, z4, 0.0F, 0.0F + modeOffset, alpha);
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, float x, float y, float z, float u, float v, float alpha) {
      buffer.method_56824(entry, x, y, z).method_22913(u, v).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F));
   }

   private int getShaderMode() {
      if (this.getShaderSetting().isSelected("WebShader")) {
         return 2;
      } else if (this.getShaderSetting().isSelected("Plasma")) {
         return 4;
      } else if (this.getShaderSetting().isSelected("BaseWarp")) {
         return 8;
      } else {
         return this.getShaderSetting().isSelected("Waves") ? 10 : 0;
      }
   }

   static {
      obf_u040d_u0432 = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56859}).withLocation(class_2960.method_60655("atheryx", "trapviewer_lines")).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).build());
      obf_u00d8_u0432 = class_1921.method_75940("atheryx_trapviewer_lines", class_12247.method_75927(obf_u040d_u0432).method_75930(class_12245.field_63976).method_75931(class_12246.field_63983).method_75938());
      obf_u2215_u0432 = class_2960.method_60655("minecraft", "textures/block/white_concrete.png");
      obf_u00eb_u0432 = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56864}).withLocation(class_2960.method_60655("atheryx", "trapviewer_shader")).withVertexShader(class_2960.method_60655("atheryx", "trapviewer_shader_vertex")).withFragmentShader(class_2960.method_60655("atheryx", "trapviewer_shader_fragment")).withUniform("Globals", class_10789.field_60031).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build());
      obf_u0423_u0432 = class_1921.method_75940("atheryx_trapviewer_shader", class_12247.method_75927(obf_u00eb_u0432).method_75934("Sampler0", obf_u2215_u0432).method_75937().method_75929(1536).method_75938());
      obf_u00ff_u0432 = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56864}).withLocation(class_2960.method_60655("atheryx", "trapviewer_chams_fill")).withVertexShader(class_2960.method_60655("atheryx", "trapviewer_shader_vertex")).withFragmentShader(class_2960.method_60655("atheryx", "trapviewer_chams_fill_fragment")).withUniform("Globals", class_10789.field_60031).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build());
      obf_u041d_u0432 = class_1921.method_75940("atheryx_trapviewer_chams_fill", class_12247.method_75927(obf_u00ff_u0432).method_75934("Sampler0", obf_u2215_u0432).method_75937().method_75929(1536).method_75938());
   }

   private NumberSetting getHorizontalRangeSetting() {
      return this.horizontalRangeNumberSetting;
   }

   private NumberSetting getDownRangeSetting() {
      return this.downRangeNumberSetting;
   }

   private NumberSetting getFadeSpeedSetting() {
      return this.fadeSpeedNumberSetting;
   }

   private BooleanSetting getFillSetting() {
      return this.fillBooleanSetting;
   }

   private NumberSetting getFillAlphaSetting() {
      return this.fillAlphaNumberSetting;
   }

   private ModeSetting getShaderSetting() {
      return this.shaderModeSetting;
   }

   private Set<class_2338> getTrackedPositions() {
      return this.field_fc3055b3;
   }

   private Map<class_2338, Float> getTrackedEntries() {
      return this.field_695bcfa8;
   }

   private class_238 getRenderBox() {
      return this.field_d687499d;
   }

   private void setRenderBox(class_238 var1) {
      this.field_d687499d = var1;
   }

   private class_243 getCurrentPosition() {
      return this.field_43b2c392;
   }

   private void setCurrentPosition(class_243 var1) {
      this.field_43b2c392 = var1;
   }

   private float getAnimationProgress() {
      return this.field_b0de3d87;
   }

   private void setAnimationProgress(float var1) {
      this.field_b0de3d87 = var1;
   }

   private int getCooldownTicks() {
      return this.field_1e09b77c;
   }

   private void setCooldownTicks(int var1) {
      this.field_1e09b77c = var1;
   }

   private float getScale() {
      return this.field_8b353171;
   }

   private void setScale(float var1) {
      this.field_8b353171 = var1;
   }

   private float getX() {
      return this.field_f860ab66;
   }

   private void setX(float var1) {
      this.field_f860ab66 = var1;
   }

   private float getY() {
      return this.field_658c255b;
   }

   private void setY(float var1) {
      this.field_658c255b = var1;
   }

   private boolean isActionPending() {
      return this.field_d2b79f50;
   }

   private void setActionPending(boolean var1) {
      this.field_d2b79f50 = var1;
   }

   private float getCurrentAlpha() {
      return this.field_3fe31945;
   }

   private void setCurrentAlpha(float var1) {
      this.field_3fe31945 = var1;
   }


   private static record ScreenPosition(float x, float y) {
      public float x() {
         return this.getX();
      }

      public float y() {
         return this.getY();
      }

      private float getX() {
         return this.x;
      }

      private float getY() {
         return this.y;
      }

   }
}
