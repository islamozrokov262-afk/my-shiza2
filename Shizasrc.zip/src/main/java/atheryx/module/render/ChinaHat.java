package atheryx.module.render;

import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ColorSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;
import java.lang.reflect.Field;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1921;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_9799;

@NewFunction(
   name = "ChinaHat",
   desc = "Китайская шляпа на голове",
   category = Category.RENDER
)
public class ChinaHat extends Function {
   public static ChinaHat Instance;
   public static class_4597.class_4598 consumers;
   private final BooleanSetting tsvetTemyBooleanSetting = new BooleanSetting("Цвет темы", true);
   private final ColorSetting tsvetColorSetting = new ColorSetting("Цвет", new Color(255, 255, 255));
   private final NumberSetting prozrachnostNumberSetting = new NumberSetting("Прозрачность", 0.65, 0.05, (double)1.0F, 0.05);
   private final ModeSetting tipZalivkiModeSetting = new ModeSetting("Тип заливки", new String[]{"Обычная", "Full", "WebShader", "Plasma", "ChamsFill", "Waves"});
   private final BooleanSetting obvodkaBooleanSetting = new BooleanSetting("Обводка", true);
   private final NumberSetting radiusNumberSetting = new NumberSetting("Радиус", 0.8, 0.3, (double)1.5F, 0.05);
   private final NumberSetting vysotaNumberSetting = new NumberSetting("Высота", 0.3, 0.1, 0.8, 0.05);
   private final NumberSetting pozitsiyaYNumberSetting = new NumberSetting("Позиция Y", (double)0.0F, (double)-0.5F, (double)0.5F, 0.05);
   private final BooleanSetting neVidetSkvozStenyBooleanSetting = new BooleanSetting("Не видеть сквозь стены", true);
   private static Field obf_u03a9_u221b = resolveField(class_630.class, "originX", "pivotX", "x");
   private static Field obf_u0451_u221b = resolveField(class_630.class, "originY", "pivotY", "y");
   private static Field obf_u2203_u221b = resolveField(class_630.class, "originZ", "pivotZ", "z");
   private static Field obf_u0393_u221b = resolveField(class_630.class, "pitch", "xRot");
   private static Field obf_u2231_u221b = resolveField(class_630.class, "yaw", "yRot");
   private static Field obf_u03b9_u221b = resolveField(class_630.class, "roll", "zRot");

   public ChinaHat() {
      Instance = this;
      this.addSettings(new Setting[]{this.getThemeColorSetting(), this.getColorSetting(), this.getTransparencySetting(), this.getFillTypeSetting(), this.getOutlineSetting(), this.getRadiusSetting(), this.getHeightSetting(), this.getPositionYSetting(), this.getRespectWallsSetting()});
      this.getThemeColorSetting().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   private void updateSettingVisibility() {
      this.getColorSetting().setVisible(!this.getThemeColorSetting().isEnabled());
   }

   private Color resolveColor() {
      Color selected = this.getThemeColorSetting().isEnabled() ? ThemeManager.getCurrentColor() : this.getColorSetting().getColor();
      return !this.getThemeColorSetting().isEnabled() ? selected : new Color(brightenChannel(selected.getRed()), brightenChannel(selected.getGreen()), brightenChannel(selected.getBlue()));
   }

   private static int brightenChannel(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.45F)), 0, 255);
   }

   private int getShaderMode() {
      if (this.getFillTypeSetting().isSelected("Обычная")) {
         return 10;
      } else if (this.getFillTypeSetting().isSelected("Full")) {
         return 0;
      } else if (this.getFillTypeSetting().isSelected("WebShader")) {
         return 2;
      } else if (this.getFillTypeSetting().isSelected("Plasma")) {
         return 4;
      } else if (this.getFillTypeSetting().isSelected("ChamsFill")) {
         return 6;
      } else {
         return this.getFillTypeSetting().isSelected("Waves") ? 8 : 10;
      }
   }

   public void updateRotation(class_4587 matrices, class_572<?> model) {
      if (consumers == null) {
         consumers = class_4597.method_22991(new class_9799(786432));
      }

      boolean chamsFill = this.getFillTypeSetting().isSelected("ChamsFill");
      class_1921 layer;
      if (this.getRespectWallsSetting().isEnabled()) {
         layer = chamsFill ? EntityESP.ENTITY_CHAMS_FILL : EntityESP.ENTITY_SHADER;
      } else {
         layer = chamsFill ? BlockOverlay.SEE_THROUGH_CHAMS_FILL : BlockOverlay.SEE_THROUGH_SHADER;
      }

      class_4588 fillBuffer = consumers.method_73477(layer);
      Color renderColor = this.resolveColor();
      float alpha = (float)this.getTransparencySetting().getValue();
      if (!(alpha <= 0.0F)) {
         float modeOffset = chamsFill ? 0.0F : (float)this.getShaderMode() * 2.0F;
         matrices.method_22903();
         matrices.method_22905(0.0625F, 0.0625F, 0.0625F);
         this.advanceActionPhase(matrices, model.field_3398);
         float yPos = -8.0F - (float)(this.getPositionYSetting().getValue() * 16.0D);
         float h = (float)(this.getHeightSetting().getValue() * 16.0D);
         float r = (float)(this.getRadiusSetting().getValue() * 16.0D);
         class_4587.class_4665 entry = matrices.method_23760();
         byte segments = 30;

         for(int i = 0; i < segments; ++i) {
            float angle1 = (float)((double)i * 3.1415926535897931D * 2.0D / (double)segments);
            float angle2 = (float)((double)(i + 1) * 3.1415926535897931D * 2.0D / (double)segments);
            float x1 = (float)Math.cos((double)angle1) * r;
            float z1 = (float)Math.sin((double)angle1) * r;
            float x2 = (float)Math.cos((double)angle2) * r;
            float z2 = (float)Math.sin((double)angle2) * r;
            float u1 = x1 / r * 0.5F + 0.5F;
            float v1 = z1 / r * 0.5F + 0.5F + modeOffset;
            float u2 = x2 / r * 0.5F + 0.5F;
            float v2 = z2 / r * 0.5F + 0.5F + modeOffset;
            float u3 = 0.5F;
            float v3 = 0.5F + modeOffset;
            this.emitVertex(fillBuffer, entry, renderColor, x1, yPos, z1, u1, v1, x2, yPos, z2, u2, v2, 0.0F, yPos - h, 0.0F, u3, v3, 0.0F, yPos - h, 0.0F, u3, v3, alpha);
            this.emitVertex(fillBuffer, entry, renderColor, x2, yPos, z2, u2, v2, x1, yPos, z1, u1, v1, 0.0F, yPos - h, 0.0F, u3, v3, 0.0F, yPos - h, 0.0F, u3, v3, alpha);
         }

         matrices.method_22909();
         if (this.getOutlineSetting().isEnabled()) {
            class_4588 lineBuffer = consumers.method_73477(this.getRespectWallsSetting().isEnabled() ? EntityESP.GLOW_BOX_LINES : EntityESP.GLOW_BOX_LINES_NO_DEPTH);
            matrices.method_22903();
            matrices.method_22905(0.0625F, 0.0625F, 0.0625F);
            this.advanceActionPhase(matrices, model.field_3398);
            entry = matrices.method_23760();

            for(int i = 0; i < segments; ++i) {
               float angle1 = (float)((double)i * 3.1415926535897931D * 2.0D / (double)segments);
               float angle2 = (float)((double)(i + 1) * 3.1415926535897931D * 2.0D / (double)segments);
               float x1 = (float)Math.cos((double)angle1) * r;
               float z1 = (float)Math.sin((double)angle1) * r;
               float x2 = (float)Math.cos((double)angle2) * r;
               float z2 = (float)Math.sin((double)angle2) * r;
               this.emitLineWithAlpha(lineBuffer, entry, renderColor, (double)x1, (double)yPos, (double)z1, (double)x2, (double)yPos, (double)z2, 2.0F, 1.0F);
               if (i % 5 == 0) {
                  this.emitLineWithAlpha(lineBuffer, entry, renderColor, (double)x1, (double)yPos, (double)z1, (double)0.0F, (double)(yPos - h), (double)0.0F, 2.0F, 1.0F);
               }
            }

            matrices.method_22909();
         }

      }
   }

   public static void onWorldRender(WorldRenderContext context) {
      if (consumers != null) {
         consumers.method_22993();
      }

   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, float x1, float y1, float z1, float u1, float v1, float x2, float y2, float z2, float u2, float v2, float x3, float y3, float z3, float u3, float v3, float x4, float y4, float z4, float u4, float v4, float alpha) {
      this.emitVertex(buffer, entry, color, x1, y1, z1, u1, v1, alpha);
      this.emitVertex(buffer, entry, color, x2, y2, z2, u2, v2, alpha);
      this.emitVertex(buffer, entry, color, x3, y3, z3, u3, v3, alpha);
      this.emitVertex(buffer, entry, color, x4, y4, z4, u4, v4, alpha);
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, float x, float y, float z, float u, float v, float alpha) {
      buffer.method_56824(entry, x, y, z).method_22913(u, v).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F));
   }

   private void emitLineWithAlpha(class_4588 buffer, class_4587.class_4665 entry, Color color, double x1, double y1, double z1, double x2, double y2, double z2, float width, float alpha) {
      float dx = (float)(x2 - x1);
      float dy = (float)(y2 - y1);
      float dz = (float)(z2 - z1);
      float length = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
      if (!(length <= 1.0E-4F)) {
         buffer.method_56824(entry, (float)x1, (float)y1, (float)z1).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F)).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
         buffer.method_56824(entry, (float)x2, (float)y2, (float)z2).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F)).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
      }
   }

   private void advanceActionPhase(class_4587 matrices, class_630 part) {
      matrices.method_46416(this.calculateAnimationFactor(part, obf_u03a9_u221b), this.calculateAnimationFactor(part, obf_u0451_u221b), this.calculateAnimationFactor(part, obf_u2203_u221b));
      float r = this.calculateAnimationFactor(part, obf_u03b9_u221b);
      if (r != 0.0F) {
         matrices.method_22907(class_7833.field_40718.rotation(r));
      }

      float y = this.calculateAnimationFactor(part, obf_u2231_u221b);
      if (y != 0.0F) {
         matrices.method_22907(class_7833.field_40716.rotation(y));
      }

      float p = this.calculateAnimationFactor(part, obf_u0393_u221b);
      if (p != 0.0F) {
         matrices.method_22907(class_7833.field_40714.rotation(p));
      }

   }

   private float calculateAnimationFactor(class_630 part, Field f) {
      try {
         return f != null ? f.getFloat(part) : 0.0F;
      } catch (Exception var4) {
         return 0.0F;
      }
   }

   private static Field resolveField(Class<?> clazz, String... names) {
      for(String name : names) {
         try {
            Field f = clazz.getDeclaredField(name);
            f.setAccessible(true);
            return f;
         } catch (Exception var7) {
         }
      }

      return null;
   }

   private BooleanSetting getThemeColorSetting() {
      return this.tsvetTemyBooleanSetting;
   }

   private ColorSetting getColorSetting() {
      return this.tsvetColorSetting;
   }

   private NumberSetting getTransparencySetting() {
      return this.prozrachnostNumberSetting;
   }

   private ModeSetting getFillTypeSetting() {
      return this.tipZalivkiModeSetting;
   }

   private BooleanSetting getOutlineSetting() {
      return this.obvodkaBooleanSetting;
   }

   private NumberSetting getRadiusSetting() {
      return this.radiusNumberSetting;
   }

   private NumberSetting getHeightSetting() {
      return this.vysotaNumberSetting;
   }

   private NumberSetting getPositionYSetting() {
      return this.pozitsiyaYNumberSetting;
   }

   private BooleanSetting getRespectWallsSetting() {
      return this.neVidetSkvozStenyBooleanSetting;
   }

}
