package atheryx.module.render;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.mixin.interfaces.ISimpleOption;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1944;
import net.minecraft.class_2338;

@NewFunction(
   name = "FullBright",
   desc = "Полная яркость мира с 3 режимами",
   category = Category.RENDER
)
public class FullBright extends Function {
   public static FullBright Instance;
   private final ModeSetting rezhimModeSetting = new ModeSetting("Режим", new String[]{"Гамма", "Ночное видение", "Динамичный"});
   private final NumberSetting skorostNumberSetting = new NumberSetting("Скорость", 50.0D, 5.0D, 200.0D, 5.0D);
   private final NumberSetting porogSvetaNumberSetting = new NumberSetting("Порог света", 4.0D, (double)0.0F, 15.0D, (double)1.0F);
   private double field_b4ade7d4;
   private double field_21d961c9;
   private boolean field_8f04dbbe;

   public FullBright() {
      this.setDistance((double)-1.0F);
      Instance = this;
      this.addSettings(new Setting[]{this.getModeSetting(), this.getSpeedSetting(), this.getLightThresholdSetting()});
   }

   public void onEnable() {
      this.prepareInteraction();
      this.setTargetDistance(this.calculateAnimationFactor());
   }

   public void onDisable() {
      this.resetTransientState();
      this.refreshCache();
      this.setActionPending(false);
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         String var2 = this.getModeSetting().getValue();
         byte var3 = -1;
         switch (var2.hashCode()) {
            case -52196841:
               if (var2.equals("Динамичный")) {
                  var3 = 2;
               }
               break;
            case 996244755:
               if (var2.equals("Гамма")) {
                  var3 = 0;
               }
               break;
            case 1088790401:
               if (var2.equals("Ночное видение")) {
                  var3 = 1;
               }
         }

         switch (var3) {
            case 0 -> this.refreshTarget();
            case 1 -> this.updateRotation();
            case 2 -> this.advanceActionPhase();
         }

      }
   }

   private void refreshTarget() {
      this.refreshCache();
      this.setActionPending(false);
      this.updateAnimation(1000.0D);
   }

   private void updateRotation() {
      this.updateAnimation(this.getDistance() != (double)-1.0F ? this.getDistance() : (double)1.0F);
      class_1293 existing = this.mc.field_1724.method_6112(class_1294.field_5925);
      if (existing == null || existing.method_5584() < 400) {
         this.mc.field_1724.method_26082(new class_1293(class_1294.field_5925, 2147483647, 0, false, false, false), (class_1297)null);
         this.setActionPending(true);
      }

   }

   private void advanceActionPhase() {
      this.refreshCache();
      this.setActionPending(false);
      boolean isDark = this.shouldProcess();
      double target = isDark ? 1000.0D : (this.getDistance() != (double)-1.0F ? this.getDistance() : (double)1.0F);
      double speed = this.getSpeedSetting().getValue() / 1000.0D;
      if (this.getTargetDistance() < target) {
         this.setTargetDistance(Math.min(this.getTargetDistance() + speed * (target - this.getTargetDistance() + (double)1.0F), target));
      } else if (this.getTargetDistance() > target) {
         this.setTargetDistance(Math.max(this.getTargetDistance() - speed * (this.getTargetDistance() - target + (double)1.0F), target));
      }

      this.updateAnimation(this.getTargetDistance());
   }

   private boolean shouldProcess() {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
         class_2338 pos = this.mc.field_1724.method_24515();
         int blockLight = this.mc.field_1687.method_8314(class_1944.field_9282, pos);
         int skyLight = this.mc.field_1687.method_8314(class_1944.field_9284, pos);
         int threshold = (int)this.getLightThresholdSetting().getValue();
         return blockLight <= threshold && skyLight <= threshold;
      } else {
         return false;
      }
   }

   private void prepareInteraction() {
      this.setDistance(this.calculateAnimationFactor());
   }

   private void resetTransientState() {
      if (this.getDistance() != (double)-1.0F) {
         this.updateAnimation(this.getDistance());
         this.setDistance((double)-1.0F);
      }

   }

   private void updateAnimation(double value) {
      if (this.mc.field_1690 != null) {
         ((ISimpleOption)(Object)this.mc.field_1690.method_42473()).minar$setValue(value);
      }
   }

   private double calculateAnimationFactor() {
      return this.mc.field_1690 == null ? (double)1.0F : (Double)this.mc.field_1690.method_42473().method_41753();
   }

   private void refreshCache() {
      if (this.isActionPending() && this.mc.field_1724 != null) {
         this.mc.field_1724.method_6016(class_1294.field_5925);
      }

   }

   private ModeSetting getModeSetting() {
      return this.rezhimModeSetting;
   }

   private NumberSetting getSpeedSetting() {
      return this.skorostNumberSetting;
   }

   private NumberSetting getLightThresholdSetting() {
      return this.porogSvetaNumberSetting;
   }

   private double getDistance() {
      return this.field_b4ade7d4;
   }

   private void setDistance(double var1) {
      this.field_b4ade7d4 = var1;
   }

   private double getTargetDistance() {
      return this.field_21d961c9;
   }

   private void setTargetDistance(double var1) {
      this.field_21d961c9 = var1;
   }

   private boolean isActionPending() {
      return this.field_8f04dbbe;
   }

   private void setActionPending(boolean var1) {
      this.field_8f04dbbe = var1;
   }

}
