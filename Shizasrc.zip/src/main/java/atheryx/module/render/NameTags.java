package atheryx.module.render;

import atheryx.event.EventHandler;
import atheryx.event.impl.Render2DEvent;
import atheryx.manager.FriendManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.module.combat.AntiBot;
import atheryx.render.RenderUtil;
import atheryx.render.WorldToScreen;
import atheryx.render.font.Msdf;
import atheryx.render.pipeline.TexturePipeline;
import atheryx.setting.Setting;
import atheryx.setting.impl.MultiSetting;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.awt.Color;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1068;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1739;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_5250;
import net.minecraft.class_742;
import net.minecraft.class_8685;

@NewFunction(
   name = "NameTags",
   desc = "Далбаебы тока не поймут",
   category = Category.RENDER
)
public class NameTags extends Function {
   public static NameTags Instance;
   private final MultiSetting tseliMultiSetting = new MultiSetting("Цели", new String[]{"Игроки", "Предметы"});
   private static final float obf_u0401_u222f = 7.19999981F;
   private static final float obf_u0405_u222f = 11.5F;
   private static final float obf_u044d_u222f = 3.5F;
   private static final float obf_u2224_u222f = 2.5F;
   private static final float obf_u0450_u222f = 3.5F;
   private static final float obf_u0402_u222f = 10.8000002F;
   private static final float obf_u00cb_u222f = 1.10000002F;
   private static final float obf_u03ba_u222f = 2.0999999F;
   private static final float obf_u00c4_u222f = 0.720000029F;
   private static final float obf_u00cd_u222f = -0.0F;
   private static final float obf_u00f0_u222f = 0.699999988F;
   private static final float obf_u00e0_u222f = -0.850000024F;
   private static final float obf_u2209_u222f = 0.75F;
   private static final float obf_u0411_u222f = 1.60000002F;
   private static final Color obf_u039b_u222f = new Color(238, 238, 242);
   private static final Color obf_u2225_u222f = new Color(18, 18, 22, 120);
   private static final Color obf_u03ad_u222f = new Color(18, 18, 22, 120);
   private static final Color obf_u039d_u222f = new Color(3, 4, 5, 65);
   private static final Color obf_u00ea_u222f = new Color(3, 177, 76, 92);
   private static final Color obf_u00f5_u222f = new Color(104, 255, 114);
   private static final Color obf_u041e_u222f = new Color(255, 235, 92);
   private static final Color obf_u00c8_u222f = new Color(255, 170, 72);
   private static final Color obf_u042c_u222f = new Color(255, 85, 92);
   private static final Color obf_u00e7_u222f = new Color(230, 230, 235);

   public NameTags() {
      Instance = this;
      this.addSettings(new Setting[]{this.getTargetsMultiSetting()});
   }

   public boolean shouldProcess() {
      return this.getTargetsMultiSetting().isSelected("Игроки");
   }

   @EventHandler
   public void onRender2D(Render2DEvent event) {
      class_332 context = event.getDrawContext();
      if (context != null && this.mc.field_1724 != null && this.mc.field_1687 != null) {
         if (!this.mc.field_1690.field_1842 && !this.mc.method_53526().method_53536()) {
            float tickDelta = this.mc.method_61966().method_60637(false);
            if (this.getTargetsMultiSetting().isSelected("Игроки")) {
               this.renderHudElement(context, tickDelta);
            }

            if (this.getTargetsMultiSetting().isSelected("Предметы")) {
               this.renderHudElementPrimary(context, tickDelta);
            }

         }
      }
   }

   private void renderHudElement(class_332 context, float tickDelta) {
      int screenW = RenderUtil.getScaledWidth();
      int screenH = RenderUtil.getScaledHeight();
      AntiBot antiBot = (AntiBot)FunctionManager.getFunction(AntiBot.class);
      class_243 cameraPos = this.mc.field_1773.method_19418().method_71156();

      for(class_1657 player : this.mc.field_1687.method_18456()) {
         if ((player != this.mc.field_1724 || !this.mc.field_1690.method_31044().method_31034()) && player.method_5805() && (antiBot == null || !antiBot.isEnabled() || !antiBot.matchesPlayer(player))) {
            class_243 interp = WorldToScreen.interpolateEntityPosition(player, tickDelta);
            float dist = (float)cameraPos.method_1022(interp);
            if (!(dist > 150.0F)) {
               class_243 headTop = interp.method_1031((double)0.0F, (double)player.method_17682() + (double)0.0F, (double)0.0F);
               float[] screen = WorldToScreen.project(headTop);
               if (screen != null && !(screen[0] < -50.0F) && !(screen[0] > (float)(screenW + 50)) && !(screen[1] < -50.0F) && !(screen[1] > (float)(screenH + 50))) {
                  this.renderHudElement(context, player, screen[0], screen[1], dist);
               }
            }
         }
      }

   }

   private void renderHudElement(class_332 context, class_1657 player, float x, float y, float dist) {
      float scaleFactor = Math.max(1.0F, 9.0F / Math.max(dist, 3.0F));
      float sc = 0.7F * scaleFactor;
      boolean isFriend = FriendManager.isFriend(player.method_5477().getString());
      class_2561 rpPrefix = this.resolveText(player);
      class_2561 rpSuffix = this.resolveTextPrimary(player);
      boolean hasRpPrefix = this.isValidText(rpPrefix);
      boolean hasRpSuffix = this.isValidText(rpSuffix);
      String displayName = this.resolveText(player, hasRpPrefix || hasRpSuffix);
      float health = player.method_6032() + player.method_6067();
      float maxHealth = Math.max(1.0F, player.method_6063());
      ScoreboardHealth sbHealth = (ScoreboardHealth)FunctionManager.getFunction(ScoreboardHealth.class);
      float displayHealth = health;
      if (sbHealth != null && sbHealth.isEnabled() && sbHealth.calculateAnimationFactor() > 0.0F) {
         displayHealth = sbHealth.calculateAnimationFactor();
      }

      class_2561 rpPrefixText = (class_2561)(hasRpPrefix ? this.resolveText(rpPrefix) : class_2561.method_43473());
      class_2561 rpSuffixText = (class_2561)(hasRpSuffix ? this.resolveText(rpSuffix) : class_2561.method_43473());
      float textSize = 7.19999981F * sc;
      float textGap = 2.0999999F * sc;
      float vanillaScale = 0.72F * sc;
      String healthText = this.formatText(displayHealth);
      float nameWidth = Msdf.getTextWidth(Msdf.SF_BOLD, displayName, textSize);
      float healthWidth = Msdf.getTextWidth(Msdf.SF_BOLD, healthText, textSize);
      float prefixWidth = hasRpPrefix ? this.calculateAnimationFactor(rpPrefixText, vanillaScale) : 0.0F;
      float suffixWidth = hasRpSuffix ? this.calculateAnimationFactor(rpSuffixText, vanillaScale) : 0.0F;
      float textWidth = nameWidth + prefixWidth + suffixWidth;
      if (hasRpPrefix) {
         textWidth += textGap;
      }

      if (hasRpSuffix) {
         textWidth += textGap;
      }

      textWidth += textGap + healthWidth;
      float msdfHeight = Msdf.getTextHeight(Msdf.SF_BOLD, textSize);
      Objects.requireNonNull(this.mc.field_1772);
      float vanillaHeight = 9.0F * vanillaScale;
      float textHeight = Math.max(msdfHeight, vanillaHeight);
      float headW = 11.5F * sc + textGap;
      float paddingX = 3.5F * sc;
      float paddingY = 2.5F * sc;
      float totalW = headW + textWidth + paddingX * 2.0F;
      float totalH = Math.max(11.5F * sc, textHeight) + paddingY * 2.0F;
      float tagX = x - totalW / 2.0F;
      float tagY = y - totalH - 10.0F * sc;
      if (HUD.Instance != null) {
         HUD.Instance.renderModuleElement((HUD.HudElement)null, tagX, tagY, totalW, totalH, 3.5F * sc, 1.0F);
      } else {
         RenderUtil.drawHudBlur(tagX, tagY, totalW, totalH, 3.5F * sc, 25.0F, 1.0F, obf_u03ad_u222f);
      }

      if (isFriend) {
         RenderUtil.drawRoundedRect(tagX, tagY, totalW, totalH, 3.5F * sc, obf_u039d_u222f, obf_u00ea_u222f, obf_u00ea_u222f, obf_u039d_u222f);
      }

      float contentX = tagX + paddingX;
      float msdfY = tagY + (totalH - msdfHeight) / 2.0F - 0.45F * sc;
      float vanillaY = tagY + (totalH - vanillaHeight) / 2.0F + -0.0F * sc;
      float headSize = 11.5F * sc;
      this.processTarget(player, contentX, tagY + (totalH - headSize) / 2.0F, headSize);
      contentX += headSize + textGap;
      float drawX = contentX;
      if (hasRpPrefix) {
         this.renderHudElement(context, rpPrefixText, contentX + -0.85F * sc, vanillaY, vanillaScale);
         drawX = contentX + prefixWidth + textGap;
      }

      RenderUtil.drawText(context, Msdf.SF_BOLD, drawX, msdfY, displayName, textSize, obf_u039b_u222f);
      drawX += nameWidth;
      if (hasRpSuffix) {
         drawX += textGap;
         this.renderHudElement(context, rpSuffixText, drawX, vanillaY, vanillaScale);
         drawX += suffixWidth;
      }

      drawX += textGap;
      RenderUtil.drawText(context, Msdf.SF_BOLD, drawX + 0.75F * sc, msdfY, healthText, textSize, this.resolveColor(displayHealth, maxHealth));
      this.renderHudElementPrimary(context, player, x, tagY, sc);
   }

   private class_2561 resolveText(class_1657 player) {
      if (player.method_5781() == null) {
         return class_2561.method_43470("");
      } else {
         class_2561 prefix = player.method_5781().method_1144();
         return (class_2561)(prefix == null ? class_2561.method_43470("") : prefix);
      }
   }

   private class_2561 resolveTextPrimary(class_1657 player) {
      if (player.method_5781() == null) {
         return class_2561.method_43470("");
      } else {
         class_2561 suffix = player.method_5781().method_1136();
         return (class_2561)(suffix == null ? class_2561.method_43470("") : suffix);
      }
   }

   private String resolveText(class_1657 player, boolean hasRpText) {
      String realName = player.method_7334().name();
      if (hasRpText) {
         return realName;
      } else {
         class_2561 customName = player.method_5797();
         if (customName != null) {
            String custom = customName.getString().trim();
            if (!custom.isEmpty() && !custom.equals(realName)) {
               return custom;
            }
         }

         String displayStr = player.method_5476().getString().trim();
         return !displayStr.isEmpty() && !displayStr.equals(realName) ? displayStr : realName;
      }
   }

   private boolean isValidText(class_2561 text) {
      return text != null && !text.getString().trim().isEmpty();
   }

   private class_2561 resolveText(class_2561 text) {
      class_5250 result = class_2561.method_43473();
      text.method_27658((style, string) -> {
         this.refreshTarget(result, string, style);
         return Optional.empty();
      }, class_2583.field_24360);
      return result;
   }

   private String resolveText(String text) {
      return text.trim().replace("[", "").replace("]", "");
   }

   private void refreshTarget(class_5250 result, String text, class_2583 baseStyle) {
      String value = this.resolveText(text);
      if (!value.isEmpty()) {
         class_2583 style = baseStyle;
         StringBuilder builder = new StringBuilder();

         for(int i = 0; i < value.length(); ++i) {
            char c = value.charAt(i);
            if (c == 167 && i + 1 < value.length()) {
               this.updateRotation(result, builder, style);
               class_124 formatting = class_124.method_544(value.charAt(i + 1));
               if (formatting != null) {
                  style = formatting == class_124.field_1070 ? class_2583.field_24360 : style.method_27706(formatting);
               }

               ++i;
            } else {
               builder.append(c);
            }
         }

         this.updateRotation(result, builder, style);
      }
   }

   private void updateRotation(class_5250 result, StringBuilder builder, class_2583 style) {
      if (!builder.isEmpty()) {
         result.method_10852(class_2561.method_43470(builder.toString()).method_10862(style));
         builder.setLength(0);
      }
   }

   private float calculateAnimationFactor(class_2561 text, float scale) {
      return (float)this.mc.field_1772.method_27525(text) * scale;
   }

   private void renderHudElement(class_332 context, class_2561 text, float x, float y, float scale) {
      context.method_51448().pushMatrix();
      context.method_51448().translate(x, y);
      context.method_51448().scale(scale, scale);
      context.method_51439(this.mc.field_1772, text, 0, 0, -1, false);
      context.method_51448().popMatrix();
   }

   private String formatText(float health) {
      return String.format(Locale.US, "%.1f", health);
   }

   private Color resolveColor(float health, float maxHealth) {
      float ratio = health / maxHealth;
      if (ratio > 0.75F) {
         return obf_u00f5_u222f;
      } else if (ratio > 0.5F) {
         return obf_u041e_u222f;
      } else {
         return ratio > 0.25F ? obf_u00c8_u222f : obf_u042c_u222f;
      }
   }

   private float calculateMovementSpeed(String text, float size) {
      return Msdf.getTextWidth(Msdf.SF_BOLD, this.resolveTextPrimary(text), size);
   }

   private String resolveTextPrimary(String text) {
      return text.replaceAll("§.", "");
   }

   private float calculateTargetDistance(class_332 context, String text, float x, float y, float size) {
      float drawX = x;
      StringBuilder current = new StringBuilder();
      Color currentColor = obf_u00e7_u222f;

      for(int i = 0; i < text.length(); ++i) {
         if (text.charAt(i) == 167 && i + 1 < text.length()) {
            if (!current.isEmpty()) {
               RenderUtil.drawText(context, Msdf.SF_BOLD, drawX, y, current.toString(), size, currentColor);
               drawX += Msdf.getTextWidth(Msdf.SF_BOLD, current.toString(), size);
               current.setLength(0);
            }

            char code = text.charAt(i + 1);
            currentColor = this.resolveColor(code);
            ++i;
         } else {
            current.append(text.charAt(i));
         }
      }

      if (!current.isEmpty()) {
         RenderUtil.drawText(context, Msdf.SF_BOLD, drawX, y, current.toString(), size, currentColor);
         drawX += Msdf.getTextWidth(Msdf.SF_BOLD, current.toString(), size);
      }

      return drawX;
   }

   private Color resolveColor(char code) {
      Color var2;
      switch (code) {
         case '0':
            var2 = new Color(0, 0, 0);
            break;
         case '1':
            var2 = new Color(0, 0, 170);
            break;
         case '2':
            var2 = new Color(0, 170, 0);
            break;
         case '3':
            var2 = new Color(0, 170, 170);
            break;
         case '4':
            var2 = new Color(170, 0, 0);
            break;
         case '5':
            var2 = new Color(170, 0, 170);
            break;
         case '6':
            var2 = new Color(255, 170, 0);
            break;
         case '7':
            var2 = new Color(170, 170, 170);
            break;
         case '8':
            var2 = new Color(85, 85, 85);
            break;
         case '9':
            var2 = new Color(85, 85, 255);
            break;
         case ':':
         case ';':
         case '<':
         case '=':
         case '>':
         case '?':
         case '@':
         case 'A':
         case 'B':
         case 'C':
         case 'D':
         case 'E':
         case 'F':
         case 'G':
         case 'H':
         case 'I':
         case 'J':
         case 'K':
         case 'L':
         case 'M':
         case 'N':
         case 'O':
         case 'P':
         case 'Q':
         case 'R':
         case 'S':
         case 'T':
         case 'U':
         case 'V':
         case 'W':
         case 'X':
         case 'Y':
         case 'Z':
         case '[':
         case '\\':
         case ']':
         case '^':
         case '_':
         case '`':
         case 'g':
         case 'h':
         case 'i':
         case 'j':
         case 'k':
         case 'l':
         case 'm':
         case 'n':
         case 'o':
         case 'p':
         case 'q':
         default:
            var2 = new Color(230, 230, 235);
            break;
         case 'a':
            var2 = new Color(85, 255, 85);
            break;
         case 'b':
            var2 = new Color(85, 255, 255);
            break;
         case 'c':
            var2 = new Color(255, 85, 85);
            break;
         case 'd':
            var2 = new Color(255, 85, 255);
            break;
         case 'e':
            var2 = new Color(255, 255, 85);
            break;
         case 'f':
            var2 = new Color(255, 255, 255);
            break;
         case 'r':
            var2 = new Color(230, 230, 235);
      }

      return var2;
   }

   private void processTarget(class_1657 player, float x, float y, float size) {
      if (player instanceof class_742 clientPlayer) {
         class_8685 skin = clientPlayer.method_52814();
         class_2960 texture = skin.comp_1626().comp_3627();
         this.renderModuleElement(texture, x, y, size);
      } else {
         class_2960 texture = class_1068.method_4648(player.method_5667()).comp_1626().comp_3627();
         this.renderModuleElement(texture, x, y, size);
      }

   }

   private void renderModuleElement(class_2960 texture, float x, float y, float size) {
      GpuTextureView view = this.mc.method_1531().method_4619(texture).method_71659();
      float radius = 2.5F;
      TexturePipeline.drawSquareTextureRegionFiltered(RenderUtil.createGuiProjection(), x, y, size, view, -1, radius, 0.0F, 0.125F, 0.125F, 0.125F, 0.125F, false);
      TexturePipeline.drawSquareTextureRegionFiltered(RenderUtil.createGuiProjection(), x, y, size, view, -1, radius, 0.0F, 0.625F, 0.125F, 0.125F, 0.125F, false);
   }

   private void renderHudElementPrimary(class_332 context, class_1657 player, float x, float y, float sc) {
      class_1799[] stacks = new class_1799[]{player.method_6047(), player.method_6118(class_1304.field_6166), player.method_6118(class_1304.field_6172), player.method_6118(class_1304.field_6174), player.method_6118(class_1304.field_6169), player.method_6079()};
      int visible = 0;

      for(class_1799 stack : stacks) {
         if (!this.isValidStack(stack)) {
            ++visible;
         }
      }

      if (visible != 0) {
         float itemSize = 10.8000002F * sc;
         float var21 = 1.1F * sc;
         float var22 = (float)visible * itemSize + (float)(visible - 1) * var21;
         float startX = x - var22 / 2.0F;
         float itemY = y - itemSize - 1.6F * sc;
         int visibleIndex = 0;

         for(class_1799 stack : stacks) {
            if (!this.isValidStack(stack)) {
               float ix = startX + (float)visibleIndex * (itemSize + var21);
               context.method_51448().pushMatrix();
               context.method_51448().translate(ix, itemY);
               float itemScale = itemSize / 16.0F;
               context.method_51448().scale(itemScale, itemScale);
               context.method_51427(stack, 0, 0);
               context.method_51431(this.mc.field_1772, stack, 0, 0);
               context.method_51448().popMatrix();
               ++visibleIndex;
            }
         }

      }
   }

   private boolean isValidStack(class_1799 stack) {
      return stack.method_7960() || stack.method_7909() instanceof class_1739;
   }

   private void renderHudElementPrimary(class_332 context, float tickDelta) {
      int screenW = RenderUtil.getScaledWidth();
      int screenH = RenderUtil.getScaledHeight();
      class_243 cameraPos = this.mc.field_1773.method_19418().method_71156();

      for(class_1297 entity : this.mc.field_1687.method_18112()) {
         if (entity instanceof class_1542 itemEntity) {
            class_243 interp = WorldToScreen.interpolateEntityPosition(entity, tickDelta);
            float dist = (float)cameraPos.method_1022(interp);
            if (!(dist > 150.0F)) {
               class_243 top = interp.method_1031((double)0.0F, (double)0.5F, (double)0.0F);
               float[] screen = WorldToScreen.project(top);
               if (screen != null && !(screen[0] < -50.0F) && !(screen[0] > (float)(screenW + 50)) && !(screen[1] < -50.0F) && !(screen[1] > (float)(screenH + 50))) {
                  class_1799 stack = itemEntity.method_6983();
                  String name = itemEntity.method_5477().getString();
                  int count = stack.method_7947();
                  if (count > 1) {
                     name = name + count;
                  }

                  float scaleFactor = Math.max(1.0F, 9.0F / Math.max(dist, 3.0F));
                  float sc = 0.7F * scaleFactor;
                  float textW = this.calculateMovementSpeed(name, 7.19999981F * sc);
                  float itemSize = 10.8000002F * sc;
                  float itemSpacing = 1.1F * sc;
                  float paddingX = 3.5F * sc;
                  float paddingY = 2.5F * sc;
                  float var23 = itemSize + itemSpacing + textW;
                  float totalW = var23 + paddingX * 2.0F;
                  float var25 = Math.max(itemSize, 7.19999981F * sc);
                  float totalH = var25 + paddingY * 2.0F;
                  float tagX = screen[0] - totalW / 2.0F;
                  float tagY = screen[1] - totalH;
                  if (HUD.Instance != null) {
                     HUD.Instance.renderModuleElement((HUD.HudElement)null, tagX, tagY, totalW, totalH, 3.5F * sc, 1.0F);
                  } else {
                     RenderUtil.drawHudBlur(tagX, tagY, totalW, totalH, 3.5F * sc, 25.0F, 1.0F, obf_u03ad_u222f);
                  }

                  float contentX = tagX + paddingX;
                  float itemDrawY = tagY + (totalH - itemSize) / 2.0F;
                  float textDrawY = tagY + (totalH - 7.19999981F * sc) / 2.0F - 0.5F * sc;
                  context.method_51448().pushMatrix();
                  context.method_51448().translate(contentX, itemDrawY);
                  float itemScale = itemSize / 16.0F;
                  context.method_51448().scale(itemScale, itemScale);
                  context.method_51427(stack, 0, 0);
                  context.method_51448().popMatrix();
                  this.calculateTargetDistance(context, name, contentX + itemSize + itemSpacing, textDrawY, 7.19999981F * sc);
               }
            }
         }
      }

   }

   private MultiSetting getTargetsMultiSetting() {
      return this.tseliMultiSetting;
   }

}
