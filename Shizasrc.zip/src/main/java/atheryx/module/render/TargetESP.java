package atheryx.module.render;

import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.module.combat.AttackAura;
import atheryx.module.combat.TriggerBot;
import atheryx.render.Render3DUtils;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import atheryx.util.color.ColorHelper;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import java.awt.Color;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_7833;

@NewFunction(
   name = "TargetESP",
   desc = "Ghost glow around aimed target",
   category = Category.RENDER
)
public class TargetESP extends Function {
   private static final class_2960 obf_u2229_u222f = class_2960.method_60655("atheryx", "images/particles/glow.png");
   private static final class_2960 obf_u039c_u222f = class_2960.method_60655("atheryx", "images/targetesp/target.png");
   private static final class_2960 obf_u040c_u222f = class_2960.method_60655("minecraft", "textures/block/white_concrete.png");
   private static final class_2960 obf_u0446_u222f = class_2960.method_60655("atheryx", "images/targetesp/skull_state_0.png");
   private static final class_2960 obf_u0457_u222f = class_2960.method_60655("atheryx", "images/targetesp/skull_state_1.png");
   private static final class_2960 obf_u045d_u222f = class_2960.method_60655("atheryx", "images/targetesp/skull_state_2.png");
   private static final class_2960 obf_u2223_u222f = class_2960.method_60655("atheryx", "images/targetesp/capture2.png");
   private static final class_2960 obf_u03c8_u222f = class_2960.method_60655("atheryx", "images/targetesp/targetpro.png");
   private static final RenderPipeline obf_u221c_u0432;
   public static final class_1921 CUBES_LINES;
   private static final RenderPipeline obf_u221b_u0432;
   private static final class_1921 obf_u2208_u0432;
   private static final RenderPipeline obf_u222f_u0432;
   public static final class_1921 CUBES_LINES_NO_DEPTH;
   private static final RenderPipeline obf_u0432_u0432;
   private static final class_1921 obf_u03b2_u0432;
   public static TargetESP Instance;
   public final ModeSetting mode = new ModeSetting("Режим", new String[]{"Призраки", "Ромб", "Cylinder", "Кубы", "Череп", "Кресты"});
   public final ModeSetting ghostModel = new ModeSetting("Модель", new String[]{"Обычные", "Nursultan", "Rock"});
   public final BooleanSetting hitColor = new BooleanSetting("Краснеть", true);
   public final BooleanSetting throughWalls = new BooleanSetting("Через стены", true);
   public final NumberSetting radius = new NumberSetting("Радиус", 0.72, 0.35, 1.6, 0.05);
   public final NumberSetting size = new NumberSetting("Размер", 0.48, 0.15, 1.1, 0.05);
   public final NumberSetting speed = new NumberSetting("Скорость", 120.0D, 30.0D, 300.0D, 5.0D);
   public final NumberSetting tailLength = new NumberSetting("Длина хвоста", 7.0D, (double)1.0F, 20.0D, (double)1.0F);
   public final NumberSetting diamondSize = new NumberSetting("Размер ромба", 0.48, 0.15, 1.1, 0.05);
   public final NumberSetting diamondSpeed = new NumberSetting("Скорость ромба", 120.0D, 30.0D, 300.0D, 5.0D);
   public final ModeSetting diamondTexture = new ModeSetting("Текстура ромба", new String[]{"Target", "Capture2", "TargetPro"});
   public final NumberSetting skullSize = new NumberSetting("Размер черепа", 0.6, 0.1, (double)1.5F, 0.05);
   public final NumberSetting chainSize = new NumberSetting("Размер цепей", 0.18, 0.08, 0.6, 0.01);
   public final NumberSetting chainSpeed = new NumberSetting("Скорость цепей", 55.0D, 5.0D, 120.0D, (double)1.0F);
   public final NumberSetting chainRadius = new NumberSetting("Радиус цепей", 1.15, 0.6, 2.5D, 0.05);
   public final NumberSetting cubesFillAlpha = new NumberSetting("Прозрачность кубов", (double)0.5F, 0.1, (double)1.0F, 0.05);
   private class_1297 field_3fe31945;
   private float field_ad0e933a;
   private long field_1a3a0d2f;
   private float field_87658724;
   private int field_f4910119;

   public TargetESP() {
      this.setCurrentAlpha(0.0F);
      this.setCooldownTicks(0);
      Instance = this;
      this.addSettings(new Setting[]{this.getMode(), this.getGhostModel(), this.getHitColor(), this.getThroughWalls(), this.getRadius(), this.getSize(), this.getSpeed(), this.getTailLength(), this.getDiamondSize(), this.getDiamondSpeed(), this.getDiamondTexture(), this.getSkullSize(), this.getChainSize(), this.getChainSpeed(), this.getChainRadius(), this.getCubesFillAlpha()});
      this.getMode().setChangeListener(this::updateSettingVisibility);
      this.getGhostModel().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   public void onDisable() {
      this.setWidth((class_1297)null);
      this.setAnimationProgress(0.0F);
      this.setDelta(0L);
      this.setCurrentAlpha(0.0F);
      this.setCooldownTicks(0);
   }

   public static void onWorldRender(WorldRenderContext context) {
      if (Instance != null && Instance.isEnabled()) {
         Instance.renderWorldOverlay(context);
      }
   }

   private void renderWorldOverlay(WorldRenderContext context) {
      this.updateSettingVisibility();
      long now = System.nanoTime();
      float delta = this.getDelta() == 0L ? 0.0F : Math.min((float)(now - this.getDelta()) / 1e+09F, 0.05F);
      this.setDelta(now);
      class_1297 auraTarget = this.findTarget();
      if (auraTarget != null) {
         this.setWidth(auraTarget);
      } else if (!this.isValidEntity(this.getWidth())) {
         this.setWidth((class_1297)null);
      }

      this.setAnimationProgress(this.clamp(this.getAnimationProgress(), auraTarget != null ? 1.0F : 0.0F, delta * 6.5F));
      if (this.getWidth() != null && !(this.getAnimationProgress() <= 0.01F)) {
         class_1297 var7 = this.getWidth();
         if (var7 instanceof class_1309) {
            class_1309 living = (class_1309)var7;
            if (living.field_6235 > this.getCooldownTicks() && living.field_6235 > 0) {
               this.setCurrentAlpha(1.0F);
            }

            this.setCooldownTicks(living.field_6235);
         }

         this.setCurrentAlpha(Math.max(0.0F, this.getCurrentAlpha() - delta * 3.5F));
         Color theme = ThemeManager.getCurrentColor();
         if (this.getHitColor().isEnabled() && this.getCurrentAlpha() > 0.0F) {
            theme = new Color(ColorHelper.lerpArgb(theme.getRGB(), Color.RED.getRGB(), this.getCurrentAlpha()));
         }

         float tickDelta = this.mc.method_61966().method_60637(false);
         class_243 targetPos = this.getWidth().method_30950(tickDelta);
         float alpha = this.smoothstep(this.getAnimationProgress());
         if (this.getMode().isSelected("Cylinder")) {
            this.renderWorldOverlay(context, targetPos, (double)this.getWidth().method_17682(), theme, alpha);
         } else if (this.getMode().isSelected("Кубы")) {
            this.renderWorldOverlay(context, targetPos, (double)this.getWidth().method_17682(), theme, alpha, now);
         } else if (this.getMode().isSelected("Кресты")) {
            this.renderWorldOverlayPrimary(context, targetPos, (double)this.getWidth().method_17682(), theme, alpha, now);
         } else if (this.getMode().isSelected("Череп")) {
            this.renderWorldOverlay(context, targetPos, (double)this.getWidth().method_17682(), this.calculateMovementSpeed(theme.getRed()), this.calculateMovementSpeed(theme.getGreen()), this.calculateMovementSpeed(theme.getBlue()), alpha);
         } else if (this.getMode().isSelected("Ромб")) {
            this.renderWorldOverlay(context, targetPos, (double)this.getWidth().method_17682(), this.calculateAnimationFactor(now, this.getDiamondSpeed().getValue()), (float)this.getDiamondSize().getValue(), this.calculateMovementSpeed(theme.getRed()), this.calculateMovementSpeed(theme.getGreen()), this.calculateMovementSpeed(theme.getBlue()), alpha);
         } else if (this.getGhostModel().isSelected("Nursultan")) {
            this.renderWorldOverlayPrimary(context, targetPos, (double)this.getWidth().method_17682(), theme, alpha);
         } else if (this.getGhostModel().isSelected("Rock")) {
            this.renderWorldOverlaySecondary(context, targetPos, (double)this.getWidth().method_17682(), theme, alpha);
         } else {
            int red = this.brightenChannel(theme.getRed());
            int green = this.brightenChannel(theme.getGreen());
            int blue = this.brightenChannel(theme.getBlue());
            double baseRadius = this.getRadius().getValue();
            float baseSize = (float)this.getSize().getValue();
            float angle = this.calculateAnimationFactor(now, this.getSpeed().getValue());
            Render3DUtils.BillboardBatch batch = this.getThroughWalls().isEnabled() ? Render3DUtils.beginAdditiveBillboardsNoDepth(context, obf_u2229_u222f) : Render3DUtils.beginAdditiveBillboards(context, obf_u2229_u222f);

            for(int ghost = 0; ghost < 3; ++ghost) {
               this.processPosition(batch, targetPos, (double)this.getWidth().method_17682(), angle + (float)ghost * 120.0F, baseRadius, baseSize, red, green, blue, alpha);
            }
         }

      }
   }

   private void renderWorldOverlay(WorldRenderContext context, class_243 targetPos, double targetHeight, Color color, float alpha) {
      Render3DUtils.BillboardBatch batch = this.getThroughWalls().isEnabled() ? Render3DUtils.beginAdditiveBillboardsNoDepth(context, obf_u2229_u222f) : Render3DUtils.beginAdditiveBillboards(context, obf_u2229_u222f);
      long now = System.nanoTime();
      short segments = 180;
      byte tailParts = 50;
      double radius = Math.max((double)(this.getWidth().method_17681() * 0.9F), 0.42);
      double bottom = 0.1;
      double top = Math.max(bottom + 0.1, targetHeight - 0.04);
      double range = top - bottom;
      double speed = 0.62;
      double t = (double)now / 1000000000.0D * speed;
      double headY = bottom + (Math.sin(t * 3.1415926535897931D) + (double)1.0F) * (double)0.5F * range;
      double smoothTailDirection = -Math.cos(t * 3.1415926535897931D) * 0.82;
      int red = this.calculateMovementSpeed(color.getRed());
      int green = this.calculateMovementSpeed(color.getGreen());
      int blue = this.calculateMovementSpeed(color.getBlue());
      double angleStep = 6.2831853071795862D / (double)segments;
      double tailLength = range * 0.8;

      for(int tail = 0; tail < tailParts; ++tail) {
         float trail = (float)tail / (float)(tailParts - 1);
         double y = headY + smoothTailDirection * tailLength * (double)trail;
         if (!(y < bottom - 0.15) && !(y > top + 0.15)) {
            float fade = 1.0F - trail;
            float partAlpha = alpha * fade * fade * 0.25F;
            if (!(partAlpha <= 0.004F)) {
               float glowSize = 0.17F * (0.72F + fade * 0.28F) - 0.2F;

               for(int i = 0; i < segments; ++i) {
                  double angle = angleStep * (double)i;
                  batch.drawColoredBillboard(targetPos.method_1031(Math.cos(angle) * radius, y, Math.sin(angle) * radius), glowSize, 0.0F, red, green, blue, partAlpha);
               }
            }
         }
      }

   }

   private class_1297 findTarget() {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         AttackAura aura = (AttackAura)FunctionManager.getFunction(AttackAura.class);
         if (aura != null && aura.isEnabled() && this.isValidEntity(aura.findTarget())) {
            return aura.findTarget();
         } else {
            TriggerBot trigger = (TriggerBot)FunctionManager.getFunction(TriggerBot.class);
            return trigger != null && trigger.isEnabled() && this.isValidEntity(trigger.findTarget()) ? trigger.findTarget() : null;
         }
      } else {
         return null;
      }
   }

   private boolean isValidEntity(class_1297 entity) {
      return entity != null && entity != this.mc.field_1724 && entity.method_5805();
   }

   private void updateSettingVisibility() {
      boolean diamond = this.getMode().isSelected("Ромб");
      boolean cylinder = this.getMode().isSelected("Cylinder");
      boolean chain = this.getMode().isSelected("Chain");
      boolean cubes = this.getMode().isSelected("Кубы");
      boolean skull = this.getMode().isSelected("Череп");
      boolean crosses = this.getMode().isSelected("Кресты");
      boolean ghostRock = this.getMode().isSelected("Ghost Rock");
      boolean isOther = !diamond && !cylinder && !chain && !cubes && !skull && !crosses && !ghostRock;
      boolean isGhost = this.getMode().isSelected("Призраки");
      this.getGhostModel().setVisible(isGhost);
      boolean showNormal = isOther && (!isGhost || this.getGhostModel().isSelected("Обычные"));
      this.getRadius().setVisible(showNormal);
      this.getSize().setVisible(showNormal);
      this.getSpeed().setVisible(isOther);
      this.getTailLength().setVisible(showNormal);
      this.getDiamondSize().setVisible(diamond);
      this.getDiamondSpeed().setVisible(diamond);
      this.getDiamondTexture().setVisible(diamond);
      this.getSkullSize().setVisible(skull);
      this.getChainSize().setVisible(chain);
      this.getChainSpeed().setVisible(chain);
      this.getChainRadius().setVisible(chain);
      this.getCubesFillAlpha().setVisible(cubes || crosses);
   }

   private void processPosition(Render3DUtils.BillboardBatch batch, class_243 targetPos, double targetHeight, float angleDegrees, double radius, float baseSize, int red, int green, int blue, float alpha) {
      int trailParts = Math.max(1, (int)Math.round(this.getTailLength().getValue()));

      for(int part = trailParts - 1; part >= 0; --part) {
         float trail = trailParts <= 1 ? 0.0F : (float)part / (float)(trailParts - 1);
         float trailAngle = angleDegrees - (float)part * 7.0F;
         class_243 position = this.calculateDirectionVector(targetPos, targetHeight, trailAngle, radius, trail);
         float partSize = baseSize * (1.0F - trail * 0.48F) * (0.45F + alpha * 0.55F);
         float partAlpha = alpha * (1.0F - trail * 0.74F);
         if (!(partAlpha <= 0.01F)) {
            batch.drawColoredBillboard(position, partSize, trailAngle * 1.35F, red, green, blue, partAlpha);
         }
      }

   }

   private void renderWorldOverlayPrimary(WorldRenderContext context, class_243 targetPos, double targetHeight, Color theme, float alpha) {
      long now = System.nanoTime();
      double timeSec = (double)now / 1000000000.0D;
      double iAge = timeSec % 100000.0D * 20.0D;
      float halfHeight = (float)(targetHeight / 2.0D + 0.1);
      float width = this.getWidth().method_17681();
      float[] heightOffsets = new float[]{halfHeight * 0.6F, -halfHeight * 0.6F, 0.0F};
      float[] radiusMultipliers = new float[]{1.35F, 1.35F, 1.27F};
      float[] tiltAngles = new float[]{-15.0F, -15.0F, -15.0F};
      float orbitSpeed = 2.5F;
      float waveSpeed = 3.0F;
      double speedVal = this.getSpeed().getValue() / 100.0D;
      class_1921 layer = this.getThroughWalls().isEnabled() ? (class_1921)Render3DUtils.ADDITIVE_TEXTURE_NO_DEPTH_LAYER.apply(obf_u2229_u222f) : (class_1921)Render3DUtils.ADDITIVE_TEXTURE_LAYER.apply(obf_u2229_u222f);
      class_4588 buffer = context.consumers().method_73477(layer);
      class_243 cameraPos = context.worldState().field_63082.field_63078;
      class_4184 camera = this.mc.method_1561().field_4686;
      float cameraYaw = camera.method_19330();
      float cameraPitch = camera.method_19329();

      for(int j = 0; j < 3; ++j) {
         int i = 0;

         for(int length = 11; i <= length; ++i) {
            double radians = Math.toRadians((((double)((float)i / 1.8F) + iAge * speedVal * (double)orbitSpeed) * (double)length + (double)(j * 90)) % (double)(length * 360));
            if (j == 1) {
               radians = -radians;
            }

            double sinQuad = Math.sin(Math.toRadians(iAge * (double)waveSpeed * speedVal + (double)i * ((double)j / 2.0D + (double)halfHeight)) * 5.5D) / 3.0D;
            float offset = (float)(i + length) / (float)(length + length);
            float radiusVal = width + 0.19F * radiusMultipliers[j];
            double x = Math.cos(radians) * (double)radiusVal;
            double y = (double)halfHeight + sinQuad + (double)heightOffsets[j] - 0.1;
            double z = Math.sin(radians) * (double)radiusVal;
            class_243 position = targetPos.method_1031(x, y, z);
            float partAlpha = offset * alpha;
            if (!(partAlpha <= 0.01F)) {
               float scale = 0.52F * offset;
               int redPart = this.calculateMovementSpeed(theme.getRed());
               int greenPart = this.calculateMovementSpeed(theme.getGreen());
               int bluePart = this.calculateMovementSpeed(theme.getBlue());
               int color = redPart << 16 | greenPart << 8 | bluePart;
               this.emitVertex(buffer, cameraPos, cameraYaw, cameraPitch, position, scale, tiltAngles[j], color, partAlpha);
            }
         }
      }

   }

   private void emitVertex(class_4588 buffer, class_243 cameraPos, float cameraYaw, float cameraPitch, class_243 position, float scale, float rotX, int color, float alpha) {
      class_4587 matrices = new class_4587();
      matrices.method_22904(position.field_1352 - cameraPos.field_1352, position.field_1351 - cameraPos.field_1351, position.field_1350 - cameraPos.field_1350);
      matrices.method_22907(class_7833.field_40716.rotationDegrees(-cameraYaw));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(cameraPitch));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(rotX));
      class_4587.class_4665 entry = matrices.method_23760();
      float minX = -scale / 3.0F;
      float minY = -scale / 2.0F;
      int r = color >> 16 & 255;
      int g = color >> 8 & 255;
      int b = color & 255;
      int a = (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F);
      this.emitVertex(buffer, entry, minX, scale, 0.0F, 0.0F, 1.0F, r, g, b, a);
      this.emitVertex(buffer, entry, scale, scale, 0.0F, 1.0F, 1.0F, r, g, b, a);
      this.emitVertex(buffer, entry, scale, minY, 0.0F, 1.0F, 0.0F, r, g, b, a);
      this.emitVertex(buffer, entry, minX, minY, 0.0F, 0.0F, 0.0F, r, g, b, a);
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, float x, float y, float z, float u, float v, int r, int g, int b, int a) {
      buffer.method_56824(entry, x, y, z).method_1336(r, g, b, a).method_22913(u, v).method_22922(class_4608.field_21444).method_60803(15728880).method_60831(entry, 0.0F, 1.0F, 0.0F);
   }

   private void renderWorldOverlaySecondary(WorldRenderContext context, class_243 targetPos, double targetHeight, Color theme, float alpha) {
      class_1921 layer = this.getThroughWalls().isEnabled() ? (class_1921)Render3DUtils.ADDITIVE_TEXTURE_NO_DEPTH_LAYER.apply(obf_u2229_u222f) : (class_1921)Render3DUtils.ADDITIVE_TEXTURE_LAYER.apply(obf_u2229_u222f);
      class_4588 buffer = context.consumers().method_73477(layer);
      class_243 cameraPos = context.worldState().field_63082.field_63078;
      class_4184 camera = this.mc.method_1561().field_4686;
      float cameraYaw = camera.method_19330();
      float cameraPitch = camera.method_19329();
      long var13 = System.nanoTime();
      double var15 = (double)var13 / 1000000000.0D;
      double moving = var15 * this.getSpeed().getValue() * 5.0D;
      float width = this.getWidth().method_17681() * 1.5F;
      byte step = 2;
      int wormTick = 0;
      int wormCD = 0;
      int red = this.calculateMovementSpeed(theme.getRed());
      int green = this.calculateMovementSpeed(theme.getGreen());
      int blue = this.calculateMovementSpeed(theme.getBlue());
      int color = red << 16 | green << 8 | blue;

      for(int i = 0; i < 360; i += step) {
         float size = 0.13F + 0.005F * (float)wormTick;
         float bigSize = 0.7F + 0.005F * (float)wormTick;
         if (wormCD > 0) {
            wormCD -= step;
         } else {
            wormTick += step;
            if (wormTick > 50) {
               wormCD = 100;
               wormTick = 0;
            } else {
               float val = Math.max(0.5F, 1.2F - 0.5F * alpha);
               double sin = Math.sin(Math.toRadians((double)i + moving * (double)1.0F)) * (double)width * (double)val;
               double cos = Math.cos(Math.toRadians((double)i + moving * (double)1.0F)) * (double)width * (double)val;
               double yOffset = targetHeight / (double)1.5F + targetHeight / 3.0D * Math.sin(Math.toRadians((double)i / 2.0D + moving / 5.0D));
               class_243 position = targetPos.method_1031(sin, yOffset, cos);
               float partAlphaGlow = alpha * 0.05F;
               float partAlphaCore = alpha * 0.6F;
               if (partAlphaGlow > 0.01F) {
                  this.emitVertex(buffer, cameraPos, cameraYaw, cameraPitch, position, bigSize, color, partAlphaGlow);
               }

               if (partAlphaCore > 0.01F) {
                  this.emitVertex(buffer, cameraPos, cameraYaw, cameraPitch, position, size, color, partAlphaCore);
               }
            }
         }
      }

   }

   private void emitVertex(class_4588 buffer, class_243 cameraPos, float cameraYaw, float cameraPitch, class_243 position, float scale, int color, float alpha) {
      class_4587 matrices = new class_4587();
      matrices.method_22904(position.field_1352 - cameraPos.field_1352, position.field_1351 - cameraPos.field_1351, position.field_1350 - cameraPos.field_1350);
      matrices.method_22907(class_7833.field_40716.rotationDegrees(-cameraYaw));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(cameraPitch));
      class_4587.class_4665 entry = matrices.method_23760();
      float minX = -scale / 2.0F;
      float minY = -scale / 2.0F;
      float maxX = scale / 2.0F;
      float maxY = scale / 2.0F;
      int r = color >> 16 & 255;
      int g = color >> 8 & 255;
      int b = color & 255;
      int a = (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F);
      this.emitVertex(buffer, entry, minX, maxY, 0.0F, 0.0F, 1.0F, r, g, b, a);
      this.emitVertex(buffer, entry, maxX, maxY, 0.0F, 1.0F, 1.0F, r, g, b, a);
      this.emitVertex(buffer, entry, maxX, minY, 0.0F, 1.0F, 0.0F, r, g, b, a);
      this.emitVertex(buffer, entry, minX, minY, 0.0F, 0.0F, 0.0F, r, g, b, a);
   }

   private void renderWorldOverlay(WorldRenderContext context, class_243 targetPos, double targetHeight, int red, int green, int blue, float alpha) {
      class_1297 var10 = this.getWidth();
      if (var10 instanceof class_1309 living) {
         float var19 = living.method_6032() / living.method_6063();
         class_2960 texture = obf_u0446_u222f;
         if (var19 <= 0.33F) {
            texture = obf_u045d_u222f;
         } else if (var19 <= 0.66F) {
            texture = obf_u0457_u222f;
         }

         class_243 position = targetPos.method_1031((double)0.0F, targetHeight * 0.56, (double)0.0F);
         float bounceScale = 1.0F + 0.35F * (float)(Math.sin((double)this.getCurrentAlpha() * 3.1415926535897931D * 2.5D) * (double)this.getCurrentAlpha());
         float shakeAngle = (float)(Math.sin((double)this.getCurrentAlpha() * 3.1415926535897931D * 4.0D) * 15.0D * (double)this.getCurrentAlpha());
         float baseSize = (float)this.getSkullSize().getValue() * 0.92F * bounceScale * (0.55F + alpha * 0.45F);
         float easedAlpha = Math.clamp(alpha, 0.0F, 1.0F);
         Render3DUtils.BillboardBatch glowBatch = this.getThroughWalls().isEnabled() ? Render3DUtils.beginAdditiveBillboardsNoDepth(context, obf_u2229_u222f) : Render3DUtils.beginAdditiveBillboards(context, obf_u2229_u222f);
         glowBatch.drawColoredBillboard(position, baseSize * 1.85F, -shakeAngle * 0.85F, red, green, blue, easedAlpha * 0.65F);
         Render3DUtils.BillboardBatch skullBatch = this.getThroughWalls().isEnabled() ? Render3DUtils.beginAdditiveBillboardsNoDepth(context, texture) : Render3DUtils.beginAdditiveBillboards(context, texture);
         skullBatch.drawColoredGlowingBillboard(position, baseSize, shakeAngle, red, green, blue, easedAlpha, 0.0F, 0.4F);
      }
   }

   private void renderWorldOverlay(WorldRenderContext context, class_243 targetPos, double targetHeight, float angleDegrees, float baseSize, int red, int green, int blue, float alpha) {
      class_243 position = targetPos.method_1031((double)0.0F, targetHeight * 0.56, (double)0.0F);
      float pulse = 0.94F + 0.06F * (float)Math.sin(Math.toRadians((double)(angleDegrees * 2.0F)));
      float diamondSizeVal = baseSize * 0.92F * pulse * (0.55F + alpha * 0.45F);
      float easedAlpha = Math.clamp(alpha, 0.0F, 1.0F);
      Render3DUtils.BillboardBatch glowBatch = this.getThroughWalls().isEnabled() ? Render3DUtils.beginAdditiveBillboardsNoDepth(context, obf_u2229_u222f) : Render3DUtils.beginAdditiveBillboards(context, obf_u2229_u222f);
      glowBatch.drawColoredBillboard(position, diamondSizeVal * 1.85F, -angleDegrees * 0.85F, red, green, blue, easedAlpha * 0.85F);
      class_2960 texture = obf_u039c_u222f;
      if (this.getDiamondTexture().isSelected("Capture2")) {
         texture = obf_u2223_u222f;
      } else if (this.getDiamondTexture().isSelected("TargetPro")) {
         texture = obf_u03c8_u222f;
      }

      Render3DUtils.BillboardBatch diamondBatch = this.getThroughWalls().isEnabled() ? Render3DUtils.beginAdditiveBillboardsNoDepth(context, texture) : Render3DUtils.beginAdditiveBillboards(context, texture);
      diamondBatch.drawColoredGlowingBillboard(position, diamondSizeVal, angleDegrees, red, green, blue, easedAlpha, 0.0F, 0.4F);
   }

   private float calculateAnimationFactor(long now, double speed) {
      return (float)((double)now / 1000000000.0D * speed % 360.0D);
   }

   private class_243 calculateDirectionVector(class_243 targetPos, double targetHeight, float angleDegrees, double radius, float trail) {
      double radians = Math.toRadians((double)angleDegrees);
      double x = Math.cos(radians) * radius;
      double z = Math.sin(radians) * radius;
      double wave = Math.sin(radians * 2.0D) * targetHeight * 0.18;
      double y = targetHeight * (0.52 + (double)trail * 0.06) + wave;
      return targetPos.method_1031(x, y, z);
   }

   private float clamp(float current, float target, float step) {
      return current < target ? Math.min(current + step, target) : Math.max(current - step, target);
   }

   private float smoothstep(float value) {
      value = Math.clamp(value, 0.0F, 1.0F);
      return value * value * (3.0F - 2.0F * value);
   }

   private int brightenChannel(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.35F)), 0, 255);
   }

   private int calculateMovementSpeed(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.45F)), 0, 255);
   }

   private void renderWorldOverlay(WorldRenderContext context, class_243 targetPos, double targetHeight, Color theme, float alpha, long now) {
      int amount = 3;
      float cSize = 0.2F;
      double cRadius = 1.6;
      float cSpeed = 95.0F;
      class_243 camera = context.worldState().field_63082.field_63078;
      int red = this.calculateMovementSpeed(theme.getRed());
      int green = this.calculateMovementSpeed(theme.getGreen());
      int blue = this.calculateMovementSpeed(theme.getBlue());
      Render3DUtils.BillboardBatch glowBatch = this.getThroughWalls().isEnabled() ? Render3DUtils.beginAdditiveBillboardsNoDepth(context, obf_u2229_u222f) : Render3DUtils.beginAdditiveBillboards(context, obf_u2229_u222f);
      double entityRadius = Math.max(0.2, (double)this.getWidth().method_17681() / 2.0D);
      double entityHeight = Math.max(0.2, targetHeight);
      int totalCubes = amount * 3;
      class_243[] cubePositions = new class_243[totalCubes];
      double baseAngle = Math.toRadians((double)this.calculateAnimationFactor(now, (double)cSpeed));
      double angleStep = 6.2831853071795862D / (double)amount;
      double smallRadius = entityRadius * cRadius * 1.2;
      double largeRadius = entityRadius * cRadius * 1.8;

      for(int ring = 0; ring < 3; ++ring) {
         double currentRadius = ring == 1 ? largeRadius : smallRadius;
         double yOffset = ring == 0 ? entityHeight * 0.15 : (ring == 1 ? entityHeight * (double)0.5F : entityHeight * 0.85);
         double ringAngleOffset = ring == 1 ? angleStep / 2.0D : (double)0.0F;

         for(int i = 0; i < amount; ++i) {
            double angle = (ring == 1 ? -baseAngle : baseAngle) + ringAngleOffset + (double)i * angleStep;
            double x = Math.cos(angle) * currentRadius;
            double z = Math.sin(angle) * currentRadius;
            int index = ring * amount + i;
            cubePositions[index] = targetPos.method_1031(x, yOffset, z);
            glowBatch.drawColoredBillboard(cubePositions[index], cSize * 2.79999995F, 0.0F, red, green, blue, alpha * 0.85F);
         }
      }

      for(int i = 0; i < totalCubes; ++i) {
         class_243 cubePos = cubePositions[i];
         class_4587 stack = context.matrices();
         stack.method_22903();
         class_243 centerRel = cubePos.method_1020(camera);
         stack.method_22904(centerRel.field_1352, centerRel.field_1351, centerRel.field_1350);
         float spin = this.calculateAnimationFactor(now, (double)(cSpeed * 1.5F));
         stack.method_22907(class_7833.field_40716.rotationDegrees(spin));
         stack.method_22907(class_7833.field_40714.rotationDegrees(spin * 0.5F));
         class_238 localBox = new class_238((double)(-cSize / 2.0F), (double)(-cSize / 2.0F), (double)(-cSize / 2.0F), (double)(cSize / 2.0F), (double)(cSize / 2.0F), (double)(cSize / 2.0F));
         Color brightColor = new Color(red, green, blue);
         this.renderWorldOverlay(context, stack.method_23760(), localBox, brightColor, alpha * (float)this.getCubesFillAlpha().getValue());
         stack.method_22909();
      }

   }

   private void renderWorldOverlayPrimary(WorldRenderContext context, class_243 targetPos, double targetHeight, Color theme, float alpha, long now) {
      int amount = 3;
      float cSize = 0.2F;
      double cRadius = 1.4;
      float cSpeed = 95.0F;
      class_243 camera = context.worldState().field_63082.field_63078;
      int red = this.calculateMovementSpeed(theme.getRed());
      int green = this.calculateMovementSpeed(theme.getGreen());
      int blue = this.calculateMovementSpeed(theme.getBlue());
      Render3DUtils.BillboardBatch glowBatch = this.getThroughWalls().isEnabled() ? Render3DUtils.beginAdditiveBillboardsNoDepth(context, obf_u2229_u222f) : Render3DUtils.beginAdditiveBillboards(context, obf_u2229_u222f);
      double entityRadius = Math.max(0.2, (double)this.getWidth().method_17681() / 2.0D);
      double entityHeight = Math.max(0.2, targetHeight);
      int totalCrosses = amount;
      class_243[] crossPositions = new class_243[amount];
      double baseAngle = Math.toRadians((double)this.calculateAnimationFactor(now, (double)cSpeed));
      double angleStep = 6.2831853071795862D / (double)amount;
      double currentRadius = entityRadius * cRadius * (double)1.5F;
      double yOffset = entityHeight * (double)0.5F;

      for(int i = 0; i < amount; ++i) {
         double angle = baseAngle + (double)i * angleStep;
         double x = Math.cos(angle) * currentRadius;
         double z = Math.sin(angle) * currentRadius;
         crossPositions[i] = targetPos.method_1031(x, yOffset, z);
         glowBatch.drawColoredBillboard(crossPositions[i], cSize * 4.0F, 0.0F, red, green, blue, alpha * 0.85F);
      }

      for(int i = 0; i < totalCrosses; ++i) {
         class_243 crossPos = crossPositions[i];
         class_4587 stack = context.matrices();
         stack.method_22903();
         class_243 centerRel = crossPos.method_1020(camera);
         stack.method_22904(centerRel.field_1352, centerRel.field_1351, centerRel.field_1350);
         float spin = this.calculateAnimationFactor(now, (double)(cSpeed * 1.5F));
         stack.method_22907(class_7833.field_40716.rotationDegrees(spin));
         float thickness = cSize / 8.0F;
         class_238 verticalBox = new class_238((double)(-thickness), (double)(-cSize), (double)(-thickness), (double)thickness, (double)cSize * (double)1.5F, (double)thickness);
         class_238 horizontalBox = new class_238((double)(-cSize) * 0.8, (double)cSize * 0.35, (double)(-thickness), (double)cSize * 0.8, (double)cSize * 0.35 + (double)(thickness * 2.0F), (double)thickness);
         Color brightColor = new Color(red, green, blue);
         this.renderWorldOverlay(context, stack.method_23760(), verticalBox, brightColor, alpha * (float)this.getCubesFillAlpha().getValue());
         this.renderWorldOverlay(context, stack.method_23760(), horizontalBox, brightColor, alpha * (float)this.getCubesFillAlpha().getValue());
         stack.method_22909();
      }

   }

   private void renderWorldOverlay(WorldRenderContext context, class_4587.class_4665 entry, class_238 box, Color color, float alpha) {
      class_4588 buffer = context.consumers().method_73477(this.getThroughWalls().isEnabled() ? obf_u03b2_u0432 : obf_u2208_u0432);
      float inset = 0.001F;
      float x1 = (float)box.field_1323;
      float y1 = (float)box.field_1322;
      float z1 = (float)box.field_1321;
      float x2 = (float)box.field_1320;
      float y2 = (float)box.field_1325;
      float z2 = (float)box.field_1324;
      this.emitVertex(buffer, entry, color, x1, y2 + inset, z2, x2, y2 + inset, z2, x2, y2 + inset, z1, x1, y2 + inset, z1, alpha);
      this.emitVertex(buffer, entry, color, x1, y1 - inset, z1, x2, y1 - inset, z1, x2, y1 - inset, z2, x1, y1 - inset, z2, alpha);
      this.emitVertex(buffer, entry, color, x1, y1, z1 - inset, x1, y2, z1 - inset, x2, y2, z1 - inset, x2, y1, z1 - inset, alpha);
      this.emitVertex(buffer, entry, color, x1, y1, z2 + inset, x2, y1, z2 + inset, x2, y2, z2 + inset, x1, y2, z2 + inset, alpha);
      this.emitVertex(buffer, entry, color, x1 - inset, y1, z1, x1 - inset, y1, z2, x1 - inset, y2, z2, x1 - inset, y2, z1, alpha);
      this.emitVertex(buffer, entry, color, x2 + inset, y1, z1, x2 + inset, y2, z1, x2 + inset, y2, z2, x2 + inset, y1, z2, alpha);
   }

   private void renderWorldOverlay(WorldRenderContext context, class_4587.class_4665 entry, class_238 box, Color color, float alpha, float width) {
      class_4588 buffer = context.consumers().method_73477(this.getThroughWalls().isEnabled() ? CUBES_LINES_NO_DEPTH : CUBES_LINES);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1321, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1324, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1324, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1321, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1323, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1321, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1320, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1324, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1320, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1324, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1323, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1321, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1323, box.field_1325, box.field_1321, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1321, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1320, box.field_1325, box.field_1324, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1325, box.field_1324, width, alpha);
   }

   private void emitLineWithAlpha(class_4588 buffer, class_4587.class_4665 entry, Color color, double x1, double y1, double z1, double x2, double y2, double z2, float width, float alpha) {
      float dx = (float)(x2 - x1);
      float dy = (float)(y2 - y1);
      float dz = (float)(z2 - z1);
      float length = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
      if (!(length <= 1.0E-4F)) {
         buffer.method_56824(entry, (float)x1, (float)y1, (float)z1).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F)).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
         buffer.method_56824(entry, (float)x2, (float)y2, (float)z2).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F)).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
      }
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4, float alpha) {
      this.drawGeometry(buffer, entry, color, x1, y1, z1, alpha);
      this.drawGeometry(buffer, entry, color, x2, y2, z2, alpha);
      this.drawGeometry(buffer, entry, color, x3, y3, z3, alpha);
      this.drawGeometry(buffer, entry, color, x4, y4, z4, alpha);
   }

   private void drawGeometry(class_4588 buffer, class_4587.class_4665 entry, Color color, float x, float y, float z, float alpha) {
      buffer.method_56824(entry, x, y, z).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F));
   }

   static {
      obf_u221c_u0432 = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56859}).withLocation(class_2960.method_60655("atheryx", "targetesp_cubes_lines")).withBlend(BlendFunction.TRANSLUCENT).withDepthWrite(false).build());
      CUBES_LINES = class_1921.method_75940("atheryx_targetesp_cubes_lines", class_12247.method_75927(obf_u221c_u0432).method_75930(class_12245.field_63976).method_75931(class_12246.field_63983).method_75938());
      obf_u221b_u0432 = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56860}).withLocation(class_2960.method_60655("atheryx", "targetesp_cubes_fill")).withBlend(BlendFunction.TRANSLUCENT).withDepthWrite(false).withCull(false).build());
      obf_u2208_u0432 = class_1921.method_75940("atheryx_targetesp_cubes_fill", class_12247.method_75927(obf_u221b_u0432).method_75937().method_75929(1536).method_75938());
      obf_u222f_u0432 = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56859}).withLocation(class_2960.method_60655("atheryx", "targetesp_cubes_lines_nodepth")).withBlend(BlendFunction.TRANSLUCENT).withDepthWrite(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).build());
      CUBES_LINES_NO_DEPTH = class_1921.method_75940("atheryx_targetesp_cubes_lines_nodepth", class_12247.method_75927(obf_u222f_u0432).method_75930(class_12245.field_63976).method_75931(class_12246.field_63983).method_75938());
      obf_u0432_u0432 = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56860}).withLocation(class_2960.method_60655("atheryx", "targetesp_cubes_fill_nodepth")).withBlend(BlendFunction.TRANSLUCENT).withDepthWrite(false).withCull(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).build());
      obf_u03b2_u0432 = class_1921.method_75940("atheryx_targetesp_cubes_fill_nodepth", class_12247.method_75927(obf_u0432_u0432).method_75937().method_75929(1536).method_75938());
   }

   private ModeSetting getMode() {
      return this.mode;
   }

   private ModeSetting getGhostModel() {
      return this.ghostModel;
   }

   private BooleanSetting getHitColor() {
      return this.hitColor;
   }

   private BooleanSetting getThroughWalls() {
      return this.throughWalls;
   }

   private NumberSetting getRadius() {
      return this.radius;
   }

   private NumberSetting getSize() {
      return this.size;
   }

   private NumberSetting getSpeed() {
      return this.speed;
   }

   private NumberSetting getTailLength() {
      return this.tailLength;
   }

   private NumberSetting getDiamondSize() {
      return this.diamondSize;
   }

   private NumberSetting getDiamondSpeed() {
      return this.diamondSpeed;
   }

   private ModeSetting getDiamondTexture() {
      return this.diamondTexture;
   }

   private NumberSetting getSkullSize() {
      return this.skullSize;
   }

   private NumberSetting getChainSize() {
      return this.chainSize;
   }

   private NumberSetting getChainSpeed() {
      return this.chainSpeed;
   }

   private NumberSetting getChainRadius() {
      return this.chainRadius;
   }

   private NumberSetting getCubesFillAlpha() {
      return this.cubesFillAlpha;
   }

   private class_1297 getWidth() {
      return this.field_3fe31945;
   }

   private void setWidth(class_1297 var1) {
      this.field_3fe31945 = var1;
   }

   private float getAnimationProgress() {
      return this.field_ad0e933a;
   }

   private void setAnimationProgress(float var1) {
      this.field_ad0e933a = var1;
   }

   private long getDelta() {
      return this.field_1a3a0d2f;
   }

   private void setDelta(long var1) {
      this.field_1a3a0d2f = var1;
   }

   private float getCurrentAlpha() {
      return this.field_87658724;
   }

   private void setCurrentAlpha(float var1) {
      this.field_87658724 = var1;
   }

   private int getCooldownTicks() {
      return this.field_f4910119;
   }

   private void setCooldownTicks(int var1) {
      this.field_f4910119 = var1;
   }

}
