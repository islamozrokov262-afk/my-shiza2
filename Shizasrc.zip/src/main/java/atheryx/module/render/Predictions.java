package atheryx.module.render;

import atheryx.event.EventHandler;
import atheryx.event.impl.Render2DEvent;
import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.render.RenderUtil;
import atheryx.render.WorldToScreen;
import atheryx.render.font.Msdf;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ColorSetting;
import atheryx.setting.impl.NumberSetting;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1536;
import net.minecraft.class_1665;
import net.minecraft.class_1671;
import net.minecraft.class_1676;
import net.minecraft.class_1682;
import net.minecraft.class_1685;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3855;
import net.minecraft.class_3857;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_9236;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@NewFunction(
   name = "Predictions",
   desc = "Показывает шейдерную траекторию полета снарядов",
   category = Category.RENDER
)
public class Predictions extends Function {
   private static final int obf_u00ef_u222f = 2;
   private static final double obf_u0454_u222f = 0.00040000000000000002D;
   private static final RenderPipeline obf_u0396_u222f;
   private static final class_1921 obf_u2235_u222f;
   public static Predictions Instance;
   private static final double obf_u220a_u222f = 14.0D;
   private List<class_238> field_6d2b79f5;
   private long field_da56f3ea;
   private final NumberSetting field_47826ddf;
   private final NumberSetting field_b4ade7d4;
   private final BooleanSetting field_21d961c9;
   private final BooleanSetting field_8f04dbbe;
   private final ColorSetting field_fc3055b3;
   private final List<LandingLabel> field_695bcfa8;

   public Predictions() {
      this.setPos(new ArrayList<class_238>());
      this.field_47826ddf = new NumberSetting("Line Width", 2.2000000000000002D, 0.8, 6.0D, 0.1);
      this.field_b4ade7d4 = new NumberSetting("Prediction Ticks", 80.0D, 10.0D, 180.0D, 5.0D);
      this.field_21d961c9 = new BooleanSetting("Only Mine", true);
      this.field_8f04dbbe = new BooleanSetting("Theme Color", true);
      this.field_fc3055b3 = new ColorSetting("Color", new Color(120, 210, 255));
      this.field_695bcfa8 = new ArrayList<LandingLabel>();
      Instance = this;
      this.addSettings(new Setting[]{this.getCurrentValue(), this.getPreviousValue(), this.getOnlyMineSetting(), this.getSelectedColor(), this.getCurrentValueForRender()});
      this.getSelectedColor().setChangeListener(this::updateSettingVisibility);
   }

   public void onDisable() {
      this.getPos().clear();
      this.setDelta(0L);
   }

   public static void onWorldRender(WorldRenderContext context) {
      if (Instance != null && Instance.isEnabled()) {
         Instance.renderWorldOverlay(context);
      }
   }

   private void renderWorldOverlay(WorldRenderContext context) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
         Color selectedColor = this.getSelectedColor().isEnabled() ? ThemeManager.getCurrentColor() : this.getCurrentValueForRender().getColor();
         class_243 camera = context.worldState().field_63082.field_63078;
         float tickDelta = this.mc.method_61966().method_60637(false);
         this.getTrackedItems().clear();
         boolean holdingPearl = this.mc.field_1724.method_6047().method_7909() == class_1802.field_8634 || this.mc.field_1724.method_6079().method_7909() == class_1802.field_8634;
         boolean holdingBow = this.mc.field_1724.method_6047().method_7909() instanceof class_1753 || this.mc.field_1724.method_6079().method_7909() instanceof class_1753;
         boolean holdingCrossbow = this.mc.field_1724.method_6047().method_7909() instanceof class_1764 || this.mc.field_1724.method_6079().method_7909() instanceof class_1764;
         ArrayList targetBoxes = new ArrayList();
         if (holdingPearl || holdingBow || holdingCrossbow) {
            float pitch = this.mc.field_1724.method_36455();
            float yaw = this.mc.field_1724.method_36454();
            float power = 1.5F;
            double gravity = 0.03;
            boolean multishot = false;
            if (holdingBow) {
               gravity = 0.05;
               if (this.mc.field_1724.method_6115() && this.mc.field_1724.method_6030().method_7909() instanceof class_1753) {
                  int useTime = this.mc.field_1724.method_6048();
                  float pull = class_1753.method_7722(useTime);
                  power = pull * 3.0F;
                  if (power < 0.15F) {
                     power = 0.15F;
                  }
               } else {
                  power = 3.0F;
               }
            } else if (holdingCrossbow) {
               gravity = 0.05;
               power = 3.1500001F;
               class_1799 holdingStack = this.mc.field_1724.method_6047().method_7909() instanceof class_1764 ? this.mc.field_1724.method_6047() : this.mc.field_1724.method_6079();
               if (holdingStack != null && holdingStack.method_58657().toString().contains("multishot")) {
                  multishot = true;
               }
            }

            List<class_243> velocities = new ArrayList<class_243>();
            if (multishot) {
               velocities.add(this.getTargetPosition(yaw - 10.0F, pitch).method_1021((double)power));
               velocities.add(this.getTargetPosition(yaw, pitch).method_1021((double)power));
               velocities.add(this.getTargetPosition(yaw + 10.0F, pitch).method_1021((double)power));
            } else {
               velocities.add(this.getTargetPosition(yaw, pitch).method_1021((double)power));
            }

            double eyeHeightOffset = this.mc.field_1724.method_33571().field_1351 - this.mc.field_1724.method_23318();
            class_243 realPosition = this.mc.field_1724.method_30950(tickDelta).method_1031((double)0.0F, eyeHeightOffset - 0.1, (double)0.0F);

            for(class_243 velocity : velocities) {
               TrajectoryResult result = this.simulateTrajectory(realPosition, velocity, (class_1676)null, 0.99, gravity, this.mc.field_1724);
               if (result.points.size() >= 2 && result.hitResult != null) {
                  class_238 box = this.calculateBoundingBox(result.hitResult);
                  if (box != null) {
                     targetBoxes.add(box);
                  }
               }
            }
         }

         for(class_1297 entity : this.mc.field_1687.method_18112()) {
            if (entity instanceof class_1676) {
               class_1676 projectile = (class_1676)entity;
               if (this.isValidProjectile(projectile)) {
                  TrajectoryResult result = this.simulateProjectileTrajectory(projectile, tickDelta);
                  List<class_243> points = result.points;
                  if (points.size() >= 2) {
                     this.renderWorldOverlay(points, context, camera, selectedColor);
                     if (result.hitResult != null) {
                        class_238 box = this.calculateBoundingBox(result.hitResult);
                        if (box != null) {
                           targetBoxes.add(box);
                        }
                     }

                     class_243 endPos = points.get(points.size() - 1);
                     int ticksToLand = points.size() - 1;
                     double seconds = (double)ticksToLand / 20.0D;
                     String timeStr = String.format("%.1f s", seconds);
                     this.getTrackedItems().add(new LandingLabel(endPos, this.resolveItemStack(projectile), timeStr));
                  }
               }
            }
         }

         this.refreshTarget(targetBoxes);

         for(class_238 renderBox : this.getPos()) {
            class_238 cameraBox = renderBox.method_989(-camera.field_1352, -camera.field_1351, -camera.field_1350);
            this.drawGeometry(context.consumers().method_73477(obf_u2235_u222f), context.matrices().method_23760(), cameraBox, selectedColor);
         }

      }
   }

   private class_243 getTargetPosition(float yaw, float pitch) {
      float f = -class_3532.method_15374((double)(yaw * ((float)Math.PI / 180F))) * class_3532.method_15362((double)(pitch * ((float)Math.PI / 180F)));
      float g = -class_3532.method_15374((double)(pitch * ((float)Math.PI / 180F)));
      float h = class_3532.method_15362((double)(yaw * ((float)Math.PI / 180F))) * class_3532.method_15362((double)(pitch * ((float)Math.PI / 180F)));
      return (new class_243((double)f, (double)g, (double)h)).method_1029();
   }

   private void renderWorldOverlay(List<class_243> points, WorldRenderContext context, class_243 camera, Color selectedColor) {
      this.drawGeometry(context.consumers().method_73477(obf_u2235_u222f), context.matrices().method_23760(), points, camera, selectedColor);
   }

   @EventHandler
   public void onRender2D(Render2DEvent event) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
         class_332 context = event.getDrawContext();

         for(LandingLabel label : this.getTrackedItems()) {
            float[] screen = WorldToScreen.project(label.pos);
            if (screen != null) {
               String var17 = label.stack.method_7964().getString();
               String text = var17 + label.timeStr;
               float textW = Msdf.getTextWidth(Msdf.SF_BOLD, text, 7.5F);
               float textH = Msdf.getTextHeight(Msdf.SF_BOLD, 7.5F);
               float paddingX = 5.0F;
               float paddingY = 4.0F;
               float totalW = textW + paddingX * 2.0F;
               float totalH = textH + paddingY * 2.0F;
               float startX = screen[0] - totalW / 2.0F;
               float startY = screen[1] - totalH / 2.0F;
               RenderUtil.drawHudBlur(startX, startY, totalW, totalH, 3.0F, 25.0F, 1.0F, new Color(4, 4, 6, 180));
               float textX = startX + paddingX;
               float var16 = startY + paddingY - 0.5F;
               RenderUtil.drawText(context, Msdf.SF_BOLD, textX, var16, text, 7.5F, new Color(230, 230, 235));
            }
         }

      }
   }

   private class_238 calculateBoundingBox(class_239 hitResult) {
      if (hitResult instanceof class_3965 blockHit) {
         class_2338 pos = blockHit.method_17777();
         if (this.mc.field_1687 != null) {
            class_265 shape = this.mc.field_1687.method_8320(pos).method_26218(this.mc.field_1687, pos);
            if (!shape.method_1110()) {
               return shape.method_1107().method_996(pos);
            }
         }
      } else if (hitResult instanceof class_3966 entityHit) {
         class_1297 entity = entityHit.method_17782();
         float tickDelta = this.mc.method_61966().method_60637(false);
         class_243 lerped = entity.method_30950(tickDelta);
         double w = (double)entity.method_17681() / 2.0D;
         return new class_238(lerped.field_1352 - w, lerped.field_1351, lerped.field_1350 - w, lerped.field_1352 + w, lerped.field_1351 + (double)entity.method_17682(), lerped.field_1350 + w);
      }

      return null;
   }

   private void refreshTarget(List<class_238> targetBoxes) {
      long now = System.nanoTime();
      double delta = this.getDelta() == 0L ? (double)1.0F : Math.min((double)(now - this.getDelta()) / 1000000000.0D, 0.05);
      this.setDelta(now);
      double progress = (double)1.0F - Math.exp(-14.0D * delta);
      if (targetBoxes.isEmpty()) {
         for(int i = 0; i < this.getPos().size(); ++i) {
            class_238 b = (class_238)this.getPos().get(i);
            class_243 animatedBox = b.method_1005();
            class_238 newB = new class_238(animatedBox, animatedBox);
            class_238 var12 = new class_238(this.lerp(b.field_1323, newB.field_1323, progress), this.lerp(b.field_1322, newB.field_1322, progress), this.lerp(b.field_1321, newB.field_1321, progress), this.lerp(b.field_1320, newB.field_1320, progress), this.lerp(b.field_1325, newB.field_1325, progress), this.lerp(b.field_1324, newB.field_1324, progress));
            this.getPos().set(i, var12);
         }

         this.getPos().removeIf((bx) -> {
            return bx.field_1320 - bx.field_1323 < 0.01;
         });
         if (this.getPos().isEmpty()) {
            this.setDelta(0L);
         }

      } else {
         while(this.getPos().size() < targetBoxes.size()) {
            class_243 center = ((class_238)targetBoxes.get(this.getPos().size())).method_1005();
            this.getPos().add(new class_238(center, center));
         }

         while(this.getPos().size() > targetBoxes.size()) {
            this.getPos().remove(this.getPos().size() - 1);
         }

         for(int i = 0; i < targetBoxes.size(); ++i) {
            class_238 targetBox = targetBoxes.get(i);
            class_238 animatedBox = (class_238)this.getPos().get(i);
            class_238 zeroBox = new class_238(this.lerp(animatedBox.field_1323, targetBox.field_1323, progress), this.lerp(animatedBox.field_1322, targetBox.field_1322, progress), this.lerp(animatedBox.field_1321, targetBox.field_1321, progress), this.lerp(animatedBox.field_1320, targetBox.field_1320, progress), this.lerp(animatedBox.field_1325, targetBox.field_1325, progress), this.lerp(animatedBox.field_1324, targetBox.field_1324, progress));
            this.getPos().set(i, zeroBox);
         }

      }
   }

   private double lerp(double from, double to, double progress) {
      return from + (to - from) * progress;
   }

   private class_1799 resolveItemStack(class_1676 projectile) {
      if (projectile instanceof class_3857 thrownItem) {
         return thrownItem.method_7495();
      } else if (projectile instanceof class_1685) {
         return new class_1799(class_1802.field_8547);
      } else {
         return projectile instanceof class_1665 ? new class_1799(class_1802.field_8107) : new class_1799(class_1802.field_8634);
      }
   }

   private boolean isValidProjectile(class_1676 projectile) {
      if (projectile.method_5805() && !(projectile.method_18798().method_1027() < 4.0E-4)) {
         if (this.getOnlyMineSetting().isEnabled() && projectile.method_24921() != this.mc.field_1724) {
            return false;
         } else if (projectile instanceof class_1536) {
            return false;
         } else {
            if (projectile instanceof class_1665) {
               class_1665 persistent = (class_1665)projectile;
               if (!persistent.method_5863()) {
                  return false;
               }
            }

            return projectile instanceof class_1682 || projectile instanceof class_1665 || projectile instanceof class_1685 || projectile instanceof class_1671 || projectile instanceof class_3855 || projectile instanceof class_9236;
         }
      } else {
         return false;
      }
   }

   private TrajectoryResult simulateTrajectory(class_243 position, class_243 velocity, class_1676 projectile, double defaultDrag, double gravity, class_1297 entityForRaycast) {
      List<class_243> points = new ArrayList<class_243>();
      points.add(position);
      Object finalHit = null;
      int steps = (int)this.getPreviousValue().getValue();

      for(int i = 0; i < steps && !(velocity.method_1027() < 4.0E-4); ++i) {
         class_243 next = position.method_1019(velocity);
         class_239 hit = this.mc.field_1687.method_61717(new class_3959(position, next, class_3960.field_17558, class_242.field_1348, entityForRaycast));
         double minDistanceSq = hit.method_17783() != class_240.field_1333 ? position.method_1025(hit.method_17784()) : 1.7976931348623157e+308D;
         class_3966 entityHit = null;
         class_238 box = (new class_238(position, next)).method_1014((double)1.0F);

         for(class_1297 entity : this.mc.field_1687.method_8335(entityForRaycast, box)) {
            if (entity.method_5863() || entity instanceof class_1309) {
               class_238 entityBox = entity.method_5829().method_1014(0.3);
               Optional<class_243> entityHitPos = entityBox.method_992(position, next);
               if (entityHitPos.isPresent()) {
                  double distSq = position.method_1025(entityHitPos.get());
                  if (distSq < minDistanceSq) {
                     minDistanceSq = distSq;
                     entityHit = new class_3966(entity, entityHitPos.get());
                  }
               }
            }
         }

         if (entityHit != null) {
            hit = entityHit;
         }

         if (hit != null && hit.method_17783() != class_240.field_1333) {
            points.add(hit.method_17784());
            finalHit = hit;
            break;
         }

         points.add(next);
         position = next;
         double drag;
         if (projectile != null) {
            drag = this.calculateMovementSpeed(projectile, next);
         } else {
            boolean inFluid = !this.mc.field_1687.method_8316(class_2338.method_49638(next)).method_15769();
            drag = inFluid ? 0.8 : defaultDrag;
         }

         velocity = velocity.method_1021(drag);
         if (gravity > (double)0.0F) {
            velocity = velocity.method_1031((double)0.0F, -gravity, (double)0.0F);
         }
      }

      return new TrajectoryResult(points, (class_239)finalHit);
   }

   private TrajectoryResult simulateProjectileTrajectory(class_1676 projectile, float tickDelta) {
      double gravity = projectile.method_5740() ? (double)0.0F : this.calculateTargetDistance(projectile);
      TrajectoryResult result = this.simulateTrajectory(projectile.method_30950(1.0F), projectile.method_18798(), projectile, 0.99, gravity, projectile);
      if (!result.points.isEmpty()) {
         result.points.set(0, projectile.method_30950(tickDelta));
      }

      return result;
   }

   private double calculateMovementSpeed(class_1676 projectile, class_243 position) {
      boolean inFluid = !this.mc.field_1687.method_8316(class_2338.method_49638(position)).method_15769();
      if (projectile instanceof class_1685) {
         return inFluid ? 0.99 : 0.99;
      } else if (projectile instanceof class_1665) {
         return inFluid ? 0.6 : 0.99;
      } else if (projectile instanceof class_1682) {
         return inFluid ? 0.8 : 0.99;
      } else {
         return !(projectile instanceof class_3855) && !(projectile instanceof class_9236) ? 0.99 : 0.95;
      }
   }

   private double calculateTargetDistance(class_1676 projectile) {
      class_1299<?> type = projectile.method_5864();
      if (type != class_1299.field_6066 && type != class_1299.field_6049 && type != class_1299.field_6129 && type != class_1299.field_6130) {
         if (projectile instanceof class_1665) {
            return 0.05;
         } else if (projectile instanceof class_1682) {
            return 0.03;
         } else if (projectile instanceof class_9236) {
            return (double)0.0F;
         } else {
            return projectile instanceof class_1671 ? (double)0.0F : 0.03;
         }
      } else {
         return (double)0.0F;
      }
   }

   private void drawGeometry(class_4588 buffer, class_4587.class_4665 entry, List<class_243> points, class_243 camera, Color color) {
      float width = (float)this.getCurrentValue().getValue();

      for(int i = 0; i < points.size() - 1; ++i) {
         class_243 start = ((class_243)points.get(i)).method_1020(camera);
         class_243 end = ((class_243)points.get(i + 1)).method_1020(camera);
         this.emitLine(buffer, entry, color, start.field_1352, start.field_1351, start.field_1350, end.field_1352, end.field_1351, end.field_1350, width);
      }

   }

   private void drawGeometry(class_4588 buffer, class_4587.class_4665 entry, class_238 box, Color color) {
      float width = (float)this.getCurrentValue().getValue();
      double minX = box.field_1323;
      double minY = box.field_1322;
      double minZ = box.field_1321;
      double maxX = box.field_1320;
      double maxY = box.field_1325;
      double maxZ = box.field_1324;
      this.emitLine(buffer, entry, color, minX, minY, minZ, maxX, minY, minZ, width);
      this.emitLine(buffer, entry, color, maxX, minY, minZ, maxX, minY, maxZ, width);
      this.emitLine(buffer, entry, color, maxX, minY, maxZ, minX, minY, maxZ, width);
      this.emitLine(buffer, entry, color, minX, minY, maxZ, minX, minY, minZ, width);
      this.emitLine(buffer, entry, color, minX, maxY, minZ, maxX, maxY, minZ, width);
      this.emitLine(buffer, entry, color, maxX, maxY, minZ, maxX, maxY, maxZ, width);
      this.emitLine(buffer, entry, color, maxX, maxY, maxZ, minX, maxY, maxZ, width);
      this.emitLine(buffer, entry, color, minX, maxY, maxZ, minX, maxY, minZ, width);
      this.emitLine(buffer, entry, color, minX, minY, minZ, minX, maxY, minZ, width);
      this.emitLine(buffer, entry, color, maxX, minY, minZ, maxX, maxY, minZ, width);
      this.emitLine(buffer, entry, color, maxX, minY, maxZ, maxX, maxY, maxZ, width);
      this.emitLine(buffer, entry, color, minX, minY, maxZ, minX, maxY, maxZ, width);
   }

   private void emitLine(class_4588 buffer, class_4587.class_4665 entry, Color color, double x1, double y1, double z1, double x2, double y2, double z2, float width) {
      float dx = (float)(x2 - x1);
      float dy = (float)(y2 - y1);
      float dz = (float)(z2 - z1);
      float length = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
      if (!(length <= 1.0E-4F)) {
         buffer.method_56824(entry, (float)x1, (float)y1, (float)z1).method_1336(color.getRed(), color.getGreen(), color.getBlue(), 255).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
         buffer.method_56824(entry, (float)x2, (float)y2, (float)z2).method_1336(color.getRed(), color.getGreen(), color.getBlue(), 255).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
      }
   }

   private void updateSettingVisibility() {
      this.getCurrentValueForRender().setVisible(!this.getSelectedColor().isEnabled());
   }

   static {
      obf_u0396_u222f = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56859}).withLocation(class_2960.method_60655("atheryx", "predictions_lines")).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).build());
      obf_u2235_u222f = class_1921.method_75940("atheryx_predictions_lines", class_12247.method_75927(obf_u0396_u222f).method_75930(class_12245.field_63976).method_75931(class_12246.field_63983).method_75938());
   }

   private List<class_238> getPos() {
      return this.field_6d2b79f5;
   }

   private void setPos(List var1) {
      this.field_6d2b79f5 = var1;
   }

   private long getDelta() {
      return this.field_da56f3ea;
   }

   private void setDelta(long var1) {
      this.field_da56f3ea = var1;
   }

   private NumberSetting getCurrentValue() {
      return this.field_47826ddf;
   }

   private NumberSetting getPreviousValue() {
      return this.field_b4ade7d4;
   }

   private BooleanSetting getOnlyMineSetting() {
      return this.field_21d961c9;
   }

   private BooleanSetting getSelectedColor() {
      return this.field_8f04dbbe;
   }

   private ColorSetting getCurrentValueForRender() {
      return this.field_fc3055b3;
   }

   private List<LandingLabel> getTrackedItems() {
      return this.field_695bcfa8;
   }


   private static class LandingLabel {
      class_243 pos;
      class_1799 stack;
      String timeStr;

      LandingLabel(class_243 pos, class_1799 stack, String timeStr) {
         this.setPos(pos);
         this.setStack(stack);
         this.setTimeStr(timeStr);
      }

      private class_243 getPos() {
         return this.pos;
      }

      private void setPos(class_243 var1) {
         this.pos = var1;
      }

      private class_1799 getStack() {
         return this.stack;
      }

      private void setStack(class_1799 var1) {
         this.stack = var1;
      }

      private String getTimeStr() {
         return this.timeStr;
      }

      private void setTimeStr(String var1) {
         this.timeStr = var1;
      }

   }

   private static class TrajectoryResult {
      public final List<class_243> points;
      public final class_239 hitResult;

      public TrajectoryResult(List<class_243> points, class_239 hitResult) {
         this.points = points;
         this.hitResult = hitResult;
      }

      private List getPoints() {
         return this.points;
      }

      private class_239 getHitResult() {
         return this.hitResult;
      }

   }
}
