package atheryx.module.render;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.render.Render3DUtils;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ColorSetting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_243;
import net.minecraft.class_2960;

@NewFunction(
   name = "JumpCircles",
   desc = "Эффект кругов под ногами при прыжке",
   category = Category.RENDER
)
public class JumpCircles extends Function {
   private static final class_2960 obf_u03b7_u222f = class_2960.method_60655("atheryx", "images/world/circle.png");
   private static final List<JumpCircle> obf_u2217_u222f = new ArrayList<JumpCircle>();
   private static final long obf_u00c5_u222f = 850000000L;
   private static final double obf_u0447_u222f = 0.025000000000000001D;
   private static final float obf_u0410_u222f = 0.5F;
   private static final float obf_u00e9_u222f = 2.3499999F;
   private static final float obf_u03ae_u222f = 0.280000001F;
   private static final float obf_u03bc_u222f = 1.17999995F;
   private static final float obf_u043b_u222f = 0.720000029F;
   public static JumpCircles Instance;
   private final NumberSetting sizeNumberSetting = new NumberSetting("Size", (double)1.25F, 0.35, 3.0D, 0.05);
   private final BooleanSetting themeColorBooleanSetting = new BooleanSetting("Theme color", true);
   private final ColorSetting colorColorSetting = new ColorSetting("Color", new Color(255, 255, 255));
   private boolean field_b4ade7d4;
   private double field_21d961c9;

   public JumpCircles() {
      Instance = this;
      this.addSettings(new Setting[]{this.getSizeSetting(), this.getThemeColorSetting(), this.getColorSetting()});
      this.getThemeColorSetting().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   public void onEnable() {
      this.setOnGround(this.mc.field_1724 != null && this.mc.field_1724.method_24828());
      this.setDistance(this.mc.field_1724 != null ? this.mc.field_1724.method_23318() : (double)0.0F);
   }

   public void onDisable() {
      obf_u2217_u222f.clear();
      this.setOnGround(false);
   }

   @EventHandler
   private void onUpdate(UpdateEvent event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         boolean onGround = this.mc.field_1724.method_24828();
         if (onGround) {
            this.setDistance(this.mc.field_1724.method_23318());
         } else if (this.isOnGround() && this.mc.field_1724.method_18798().field_1351 > (double)0.0F) {
            this.spawnTarget();
         }

         this.setOnGround(onGround);
      } else {
         this.setOnGround(false);
         obf_u2217_u222f.clear();
      }
   }

   private void spawnTarget() {
      class_243 position = new class_243(this.mc.field_1724.method_23317(), this.getDistance() + 0.025, this.mc.field_1724.method_23321());
      obf_u2217_u222f.add(new JumpCircle(position, (float)(Math.random() * 360.0D), System.nanoTime()));
   }

   public static void onWorldRender(WorldRenderContext context) {
      if (Instance != null && Instance.isEnabled() && !obf_u2217_u222f.isEmpty()) {
         Instance.renderWorldOverlay(context);
      }
   }

   private void renderWorldOverlay(WorldRenderContext context) {
      long now = System.nanoTime();
      Color selectedColor = this.getThemeColorSetting().isEnabled() ? ThemeManager.getCurrentColor() : this.getColorSetting().getColor();
      int red = this.getThemeColorSetting().isEnabled() ? brightenChannel(selectedColor.getRed()) : selectedColor.getRed();
      int green = this.getThemeColorSetting().isEnabled() ? brightenChannel(selectedColor.getGreen()) : selectedColor.getGreen();
      int blue = this.getThemeColorSetting().isEnabled() ? brightenChannel(selectedColor.getBlue()) : selectedColor.getBlue();
      float baseSize = (float)this.getSizeSetting().getValue();
      Iterator iterator = obf_u2217_u222f.iterator();
      Render3DUtils.GroundQuadBatch batch = Render3DUtils.beginAdditiveGroundQuads(context, obf_u03b7_u222f);

      while(iterator.hasNext()) {
         JumpCircle circle = (JumpCircle)iterator.next();
         float age = (float)(now - circle.colorColorSetting) / 850000000.0F;
         if (age >= 1.0F) {
            iterator.remove();
         } else {
            float scale = smoothstep(Math.clamp(age / 0.48F, 0.0F, 1.0F));
            float fade = smoothstep(Math.clamp((1.0F - age) / 0.34F, 0.0F, 1.0F));
            float currentSize = baseSize * scale;
            float currentAlpha = 0.5F * fade;
            batch.drawColoredBillboard(circle.sizeNumberSetting, currentSize * 1.18F, circle.themeColorBooleanSetting, red, green, blue, currentAlpha * 0.72F);
            batch.drawColoredBillboard(circle.sizeNumberSetting, currentSize, circle.themeColorBooleanSetting, calculateMovementSpeed(red), calculateMovementSpeed(green), calculateMovementSpeed(blue), Math.clamp(currentAlpha * 1.25F, 0.0F, 1.0F));
         }
      }

   }

   private static float smoothstep(float value) {
      return value * value * (3.0F - 2.0F * value);
   }

   private static int brightenChannel(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.45F)), 0, 255);
   }

   private static int calculateMovementSpeed(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.72F)), 0, 255);
   }

   private void updateSettingVisibility() {
      this.getColorSetting().setVisible(!this.getThemeColorSetting().isEnabled());
   }

   private NumberSetting getSizeSetting() {
      return this.sizeNumberSetting;
   }

   private BooleanSetting getThemeColorSetting() {
      return this.themeColorBooleanSetting;
   }

   private ColorSetting getColorSetting() {
      return this.colorColorSetting;
   }

   private boolean isOnGround() {
      return this.field_b4ade7d4;
   }

   private void setOnGround(boolean var1) {
      this.field_b4ade7d4 = var1;
   }

   private double getDistance() {
      return this.field_21d961c9;
   }

   private void setDistance(double var1) {
      this.field_21d961c9 = var1;
   }


   private static class JumpCircle {
      private final class_243 sizeNumberSetting;
      private final float themeColorBooleanSetting;
      private final long colorColorSetting;

      private JumpCircle(class_243 position, float rotation, long spawnedAt) {
         this.sizeNumberSetting = position;
         this.themeColorBooleanSetting = rotation;
         this.colorColorSetting = spawnedAt;
      }

      private class_243 getSizeSetting() {
         return this.sizeNumberSetting;
      }

      private float getThemeColorSetting() {
         return this.themeColorBooleanSetting;
      }

      private long getColorSetting() {
         return this.colorColorSetting;
      }

   }
}
