package atheryx.module.render;

import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_7285;
import org.joml.Vector4f;

@NewFunction(
   name = "Fog",
   desc = "Кастомный атмосферный туман для мира",
   category = Category.RENDER
)
public class Fog extends Function {
   public static Fog Instance;
   private final NumberSetting distantsiyaStartaNumberSetting = new NumberSetting("Дистанция старта", 8.0D, (double)0.0F, 256.0D, (double)1.0F);
   private final NumberSetting distantsiyaKontsaNumberSetting = new NumberSetting("Дистанция конца", 64.0D, 4.0D, 512.0D, (double)1.0F);
   private final NumberSetting distantsiyaNebaNumberSetting = new NumberSetting("Дистанция неба", 96.0D, 4.0D, 512.0D, (double)1.0F);
   private final NumberSetting distantsiyaOblakovNumberSetting = new NumberSetting("Дистанция облаков", 128.0D, 4.0D, 512.0D, (double)1.0F);
   private final NumberSetting yarkostNumberSetting = new NumberSetting("Яркость", 0.45, (double)0.0F, (double)1.0F, 0.05);

   public Fog() {
      Instance = this;
      this.addSettings(new Setting[]{this.getStartDistanceSetting(), this.getEndDistanceSetting(), this.getSkyDistanceSetting(), this.getCloudDistanceSetting(), this.getBrightnessSetting()});
   }

   public static void refreshTarget(class_7285 data) {
      if (Instance != null && Instance.isEnabled()) {
         float start = (float)Instance.getStartDistanceSetting().getValue();
         float end = Math.max(start + 1.0F, (float)Instance.getEndDistanceSetting().getValue());
         data.field_60582 = start;
         data.field_60584 = end;
         data.field_60099 = (float)Instance.getSkyDistanceSetting().getValue();
         data.field_60100 = (float)Instance.getCloudDistanceSetting().getValue();
      }
   }

   public static Vector4f calculateFogColor(class_4184 camera, Vector4f vanillaColor) {
      if (Instance != null && Instance.isEnabled() && camera.method_19334() == class_5636.field_27888) {
         Color fogColor = ThemeManager.getCurrentColor();
         float intensity = (float)Instance.getBrightnessSetting().getValue();
         Vector4f configuredColor = new Vector4f((float)fogColor.getRed() / 255.0F, (float)fogColor.getGreen() / 255.0F, (float)fogColor.getBlue() / 255.0F, 1.0F);
         return (new Vector4f(vanillaColor)).lerp(configuredColor, intensity);
      } else {
         return vanillaColor;
      }
   }

   private NumberSetting getStartDistanceSetting() {
      return this.distantsiyaStartaNumberSetting;
   }

   private NumberSetting getEndDistanceSetting() {
      return this.distantsiyaKontsaNumberSetting;
   }

   private NumberSetting getSkyDistanceSetting() {
      return this.distantsiyaNebaNumberSetting;
   }

   private NumberSetting getCloudDistanceSetting() {
      return this.distantsiyaOblakovNumberSetting;
   }

   private NumberSetting getBrightnessSetting() {
      return this.yarkostNumberSetting;
   }

}
