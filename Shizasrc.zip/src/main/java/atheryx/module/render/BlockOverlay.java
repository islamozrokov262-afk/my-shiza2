package atheryx.module.render;

import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ColorSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import java.awt.Color;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_10789;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2960;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_239.class_240;

@NewFunction(
   name = "BlockOverlay",
   desc = "Подсветка блока, на который вы смотрите",
   category = Category.RENDER
)
public class BlockOverlay extends Function {
   private static final class_2960 obf_u03a6_u221b = class_2960.method_60655("minecraft", "textures/block/white_concrete.png");
   private static final double obf_u223c_u221b = 14.0D;
   private static final RenderPipeline obf_u03c4_u221b;
   private static final class_1921 obf_u041f_u221b;
   private static final RenderPipeline obf_u041b_u221b;
   public static final class_1921 SEE_THROUGH_SHADER;
   private static final RenderPipeline obf_u00f3_u221b;
   public static final class_1921 SEE_THROUGH_CHAMS_FILL;
   public static BlockOverlay Instance;
   private final BooleanSetting zapolnenieBooleanSetting = new BooleanSetting("Заполнение", true);
   private final BooleanSetting konturBooleanSetting = new BooleanSetting("Контур", true);
   private final NumberSetting tolschinaLiniyNumberSetting = new NumberSetting("Толщина линий", 2.0D, (double)0.5F, 5.0D, 0.1);
   private final NumberSetting prozrachnostNumberSetting = new NumberSetting("Прозрачность", (double)0.5F, 0.1, (double)1.0F, 0.05);
   private final ModeSetting shaderModeSetting = new ModeSetting("Shader", new String[]{"Full", "WebShader", "Plasma", "ChamsFill", "BaseWarp"});
   private final ColorSetting tsvetColorSetting = new ColorSetting("Цвет", new Color(255, 255, 255));
   private class_238 field_fc3055b3;
   private long field_695bcfa8;

   public BlockOverlay() {
      Instance = this;
      this.addSettings(new Setting[]{this.getFillSetting(), this.getOutlineSetting(), this.getLineThicknessSetting(), this.getTransparencySetting(), this.getColorSetting(), this.getShaderSetting()});
   }

   public void onDisable() {
      this.setTargetBox((class_238)null);
      this.setDelta(0L);
   }

   public static void onWorldRender(WorldRenderContext context) {
      if (Instance != null && Instance.isEnabled()) {
         Instance.renderWorldOverlay(context);
      }
   }

   public static boolean shouldRenderBlockOutline() {
      return Instance == null || !Instance.isEnabled();
   }

   private void renderWorldOverlay(WorldRenderContext context) {
      class_239 var3 = this.mc.field_1765;
      if (var3 instanceof class_3965 result) {
         if (result.method_17783() == class_240.field_1332 && this.mc.field_1687 != null) {
            class_2338 pos = result.method_17777();
            class_265 shape = this.mc.field_1687.method_8320(pos).method_26218(this.mc.field_1687, pos);
            if (shape.method_1110()) {
               this.setTargetBox((class_238)null);
               this.setDelta(0L);
               return;
            }

            class_238 renderBox = this.calculateBoundingBox(shape.method_1107().method_996(pos));
            if (renderBox == null) {
               return;
            }

            class_243 camera = context.worldState().field_63082.field_63078;
            class_238 cameraBox = renderBox.method_989(-camera.field_1352, -camera.field_1351, -camera.field_1350);
            if (this.getFillSetting().isEnabled()) {
               this.renderWorldOverlay(context, cameraBox);
            }

            if (this.getOutlineSetting().isEnabled()) {
               this.renderWorldOverlayPrimary(context, cameraBox);
            }

            return;
         }
      }

      this.setTargetBox((class_238)null);
      this.setDelta(0L);
   }

   private class_238 calculateBoundingBox(class_238 targetBox) {
      long now = System.nanoTime();
      double delta = this.getDelta() == 0L ? (double)1.0F : Math.min((double)(now - this.getDelta()) / 1000000000.0D, 0.05);
      this.setDelta(now);
      if (this.getTargetBox() == null) {
         this.setTargetBox(targetBox);
         return this.getTargetBox();
      } else {
         double progress = (double)1.0F - Math.exp(-14.0D * delta);
         this.setTargetBox(new class_238(this.lerp(this.getTargetBox().field_1323, targetBox.field_1323, progress), this.lerp(this.getTargetBox().field_1322, targetBox.field_1322, progress), this.lerp(this.getTargetBox().field_1321, targetBox.field_1321, progress), this.lerp(this.getTargetBox().field_1320, targetBox.field_1320, progress), this.lerp(this.getTargetBox().field_1325, targetBox.field_1325, progress), this.lerp(this.getTargetBox().field_1324, targetBox.field_1324, progress)));
         return this.getTargetBox();
      }
   }

   private double lerp(double from, double to, double progress) {
      return from + (to - from) * progress;
   }

   private void renderWorldOverlay(WorldRenderContext context, class_238 box) {
      boolean chamsFill = this.getShaderSetting().isSelected("ChamsFill");
      class_4588 buffer = context.consumers().method_73477(chamsFill ? SEE_THROUGH_CHAMS_FILL : SEE_THROUGH_SHADER);
      class_4587.class_4665 entry = context.matrices().method_23760();
      Color color = this.getColorSetting().getColor();
      float alpha = (float)this.getTransparencySetting().getValue();
      float inset = 0.001F;
      float modeOffset = chamsFill ? 0.0F : (float)this.getShaderMode() * 2.0F;
      float x1 = (float)box.field_1323;
      float y1 = (float)box.field_1322;
      float z1 = (float)box.field_1321;
      float x2 = (float)box.field_1320;
      float y2 = (float)box.field_1325;
      float z2 = (float)box.field_1324;
      this.emitVertex(buffer, entry, color, x1, y2 + inset, z2, x2, y2 + inset, z2, x2, y2 + inset, z1, x1, y2 + inset, z1, alpha, modeOffset);
      this.emitVertex(buffer, entry, color, x1, y1 - inset, z1, x2, y1 - inset, z1, x2, y1 - inset, z2, x1, y1 - inset, z2, alpha, modeOffset);
      this.emitVertex(buffer, entry, color, x1, y1, z1 - inset, x1, y2, z1 - inset, x2, y2, z1 - inset, x2, y1, z1 - inset, alpha, modeOffset);
      this.emitVertex(buffer, entry, color, x1, y1, z2 + inset, x2, y1, z2 + inset, x2, y2, z2 + inset, x1, y2, z2 + inset, alpha, modeOffset);
      this.emitVertex(buffer, entry, color, x1 - inset, y1, z1, x1 - inset, y1, z2, x1 - inset, y2, z2, x1 - inset, y2, z1, alpha, modeOffset);
      this.emitVertex(buffer, entry, color, x2 + inset, y1, z1, x2 + inset, y2, z1, x2 + inset, y2, z2, x2 + inset, y1, z2, alpha, modeOffset);
   }

   private void renderWorldOverlayPrimary(WorldRenderContext context, class_238 box) {
      class_4588 buffer = context.consumers().method_73477(obf_u041f_u221b);
      class_4587.class_4665 entry = context.matrices().method_23760();
      Color color = this.getColorSetting().getColor();
      float width = (float)this.getLineThicknessSetting().getValue();
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1323, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1320, box.field_1325, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1325, box.field_1324, width);
   }

   private void emitLine(class_4588 buffer, class_4587.class_4665 entry, Color color, double x1, double y1, double z1, double x2, double y2, double z2, float width) {
      float dx = (float)(x2 - x1);
      float dy = (float)(y2 - y1);
      float dz = (float)(z2 - z1);
      float length = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
      if (!(length <= 1.0E-4F)) {
         buffer.method_56824(entry, (float)x1, (float)y1, (float)z1).method_1336(color.getRed(), color.getGreen(), color.getBlue(), 255).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
         buffer.method_56824(entry, (float)x2, (float)y2, (float)z2).method_1336(color.getRed(), color.getGreen(), color.getBlue(), 255).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
      }
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4, float alpha, float modeOffset) {
      this.emitVertex(buffer, entry, color, x1, y1, z1, 0.0F, 1.0F + modeOffset, alpha);
      this.emitVertex(buffer, entry, color, x2, y2, z2, 1.0F, 1.0F + modeOffset, alpha);
      this.emitVertex(buffer, entry, color, x3, y3, z3, 1.0F, 0.0F + modeOffset, alpha);
      this.emitVertex(buffer, entry, color, x4, y4, z4, 0.0F, 0.0F + modeOffset, alpha);
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, float x, float y, float z, float u, float v, float alpha) {
      buffer.method_56824(entry, x, y, z).method_22913(u, v).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F));
   }

   private int getShaderMode() {
      if (this.getShaderSetting().isSelected("WebShader")) {
         return 2;
      } else if (this.getShaderSetting().isSelected("Plasma")) {
         return 4;
      } else {
         return this.getShaderSetting().isSelected("BaseWarp") ? 8 : 0;
      }
   }

   static {
      obf_u03c4_u221b = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56859}).withLocation(class_2960.method_60655("atheryx", "blockoverlay_see_through_lines")).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).build());
      obf_u041f_u221b = class_1921.method_75940("atheryx_blockoverlay_see_through_lines", class_12247.method_75927(obf_u03c4_u221b).method_75930(class_12245.field_63976).method_75931(class_12246.field_63983).method_75938());
      obf_u041b_u221b = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56864}).withLocation(class_2960.method_60655("atheryx", "blockoverlay_shader")).withVertexShader(class_2960.method_60655("atheryx", "block_overlay_shader_vertex")).withFragmentShader(class_2960.method_60655("atheryx", "block_overlay_shader_fragment")).withUniform("Globals", class_10789.field_60031).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build());
      SEE_THROUGH_SHADER = class_1921.method_75940("atheryx_blockoverlay_shader", class_12247.method_75927(obf_u041b_u221b).method_75934("Sampler0", obf_u03a6_u221b).method_75937().method_75931(class_12246.field_63983).method_75929(1536).method_75938());
      obf_u00f3_u221b = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56864}).withLocation(class_2960.method_60655("atheryx", "blockoverlay_chams_fill")).withVertexShader(class_2960.method_60655("atheryx", "block_overlay_shader_vertex")).withFragmentShader(class_2960.method_60655("atheryx", "block_overlay_chams_fill_fragment")).withUniform("Globals", class_10789.field_60031).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build());
      SEE_THROUGH_CHAMS_FILL = class_1921.method_75940("atheryx_blockoverlay_chams_fill", class_12247.method_75927(obf_u00f3_u221b).method_75934("Sampler0", obf_u03a6_u221b).method_75937().method_75931(class_12246.field_63983).method_75929(1536).method_75938());
   }

   private BooleanSetting getFillSetting() {
      return this.zapolnenieBooleanSetting;
   }

   private BooleanSetting getOutlineSetting() {
      return this.konturBooleanSetting;
   }

   private NumberSetting getLineThicknessSetting() {
      return this.tolschinaLiniyNumberSetting;
   }

   private NumberSetting getTransparencySetting() {
      return this.prozrachnostNumberSetting;
   }

   private ModeSetting getShaderSetting() {
      return this.shaderModeSetting;
   }

   private ColorSetting getColorSetting() {
      return this.tsvetColorSetting;
   }

   private class_238 getTargetBox() {
      return this.field_fc3055b3;
   }

   private void setTargetBox(class_238 var1) {
      this.field_fc3055b3 = var1;
   }

   private long getDelta() {
      return this.field_695bcfa8;
   }

   private void setDelta(long var1) {
      this.field_695bcfa8 = var1;
   }

}
