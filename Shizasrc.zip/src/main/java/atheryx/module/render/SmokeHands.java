package atheryx.module.render;

import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.render.pipeline.SmokeHandsRenderer;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_7923;

@NewFunction(
   name = "SmokeHands",
   desc = "Огненно-дымный шлейф на руках и предметах",
   category = Category.RENDER
)
public final class SmokeHands extends Function {
   public static SmokeHands Instance;
   public final ModeSetting mode = new ModeSetting("Мод", new String[]{"Дым", "Красивый"});
   public final NumberSetting intensity = new NumberSetting("Интенсивность", 0.85, 0.1, (double)1.5F, 0.01);
   public final NumberSetting speed = new NumberSetting("Скорость", 1.15, 0.2, 3.0D, 0.05);
   public final NumberSetting length = new NumberSetting("Длина", 0.72, 0.1, (double)1.0F, 0.05);
   public final NumberSetting prettyGlow = new NumberSetting("Глоу", 2.0D, (double)0.5F, 5.0D, 0.1);
   public final NumberSetting prettyHeight = new NumberSetting("Высота", 0.06, 0.02, 0.6, 0.01);
   public final NumberSetting prettyWind = new NumberSetting("Ветер", (double)1.0F, (double)0.0F, 3.0D, 0.1);
   public final NumberSetting prettyWave = new NumberSetting("Волны", (double)1.0F, (double)0.0F, 3.0D, 0.1);
   public final NumberSetting trailFade = new NumberSetting("Затухание шлейфа", 0.91, 0.55, 0.98, 0.01);
   public final NumberSetting trailSoftness = new NumberSetting("Мягкость шлейфа", 1.35, 0.45, 2.5D, 0.05);
   public final NumberSetting trailBlur = new NumberSetting("Размытие шлейфа", 1.55, 0.2, 3.0D, 0.05);
   public final NumberSetting handFade = new NumberSetting("Затухание рук", 0.68, 0.45, 0.9, 0.01);
   public final NumberSetting handSoftness = new NumberSetting("Мягкость рук", 1.3, 0.45, 2.5D, 0.05);
   public final NumberSetting handBlur = new NumberSetting("Размытие рук", 1.45, 0.2, 3.0D, 0.05);
   public final NumberSetting smoke = new NumberSetting("Дым", 0.55, (double)0.0F, 0.8, 0.05);
   public final BooleanSetting useItemColor = new BooleanSetting("Цвет предмета", true);
   public final BooleanSetting useThemeColor = new BooleanSetting("В цвет темы", false);

   public SmokeHands() {
      Instance = this;
      this.addSettings(new Setting[]{this.getMode(), this.getIntensity(), this.getSpeed(), this.getLength(), this.getPrettyGlow(), this.getPrettyHeight(), this.getPrettyWind(), this.getPrettyWave(), this.getTrailFade(), this.getTrailSoftness(), this.getTrailBlur(), this.getHandFade(), this.getHandSoftness(), this.getHandBlur(), this.getSmoke(), this.getUseItemColor(), this.getUseThemeColor()});
      this.getMode().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   private void updateSettingVisibility() {
      boolean smokeMode = this.getMode().isSelected("Дым");
      this.getLength().setVisible(smokeMode);
      this.getPrettyGlow().setVisible(!smokeMode);
      this.getPrettyHeight().setVisible(!smokeMode);
      this.getPrettyWind().setVisible(!smokeMode);
      this.getPrettyWave().setVisible(!smokeMode);
      this.getTrailFade().setVisible(smokeMode);
      this.getTrailSoftness().setVisible(smokeMode);
      this.getTrailBlur().setVisible(smokeMode);
      this.getHandFade().setVisible(smokeMode);
      this.getHandSoftness().setVisible(smokeMode);
      this.getHandBlur().setVisible(smokeMode);
      this.getSmoke().setVisible(smokeMode);
   }

   public void onEnable() {
      super.onEnable();
      SmokeHandsRenderer.getInstance().setEnabled(true);
   }

   public void onDisable() {
      SmokeHandsRenderer.getInstance().setEnabled(false);
      super.onDisable();
   }

   public float[] resolveProgress() {
      if (this.getUseThemeColor().isEnabled()) {
         Color c = ThemeManager.getCurrentColor();
         return new float[]{(float)c.getRed() / 255.0F, (float)c.getGreen() / 255.0F, (float)c.getBlue() / 255.0F};
      } else {
         Color color = this.getUseItemColor().isEnabled() ? this.resolveColor() : new Color(6697983);
         return new float[]{(float)color.getRed() / 255.0F, (float)color.getGreen() / 255.0F, (float)color.getBlue() / 255.0F};
      }
   }

   private Color resolveColor() {
      class_310 mc = class_310.method_1551();
      if (mc.field_1724 == null) {
         return Color.WHITE;
      } else {
         class_1799 stack = mc.field_1724.method_6047();
         if (stack.method_7960()) {
            stack = mc.field_1724.method_6079();
         }

         if (stack.method_7960()) {
            return Color.WHITE;
         } else {
            String path = class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
            if (path.contains("diamond")) {
               return new Color(5627360);
            } else if (path.contains("netherite")) {
               return new Color(5982823);
            } else if (path.contains("gold")) {
               return new Color(16766042);
            } else if (path.contains("iron")) {
               return new Color(14212840);
            } else if (path.contains("emerald")) {
               return new Color(3526767);
            } else if (path.contains("redstone")) {
               return new Color(14826299);
            } else {
               return path.contains("lapis") ? new Color(3233492) : new Color(15132390);
            }
         }
      }
   }

   private ModeSetting getMode() {
      return this.mode;
   }

   private NumberSetting getIntensity() {
      return this.intensity;
   }

   private NumberSetting getSpeed() {
      return this.speed;
   }

   private NumberSetting getLength() {
      return this.length;
   }

   private NumberSetting getPrettyGlow() {
      return this.prettyGlow;
   }

   private NumberSetting getPrettyHeight() {
      return this.prettyHeight;
   }

   private NumberSetting getPrettyWind() {
      return this.prettyWind;
   }

   private NumberSetting getPrettyWave() {
      return this.prettyWave;
   }

   private NumberSetting getTrailFade() {
      return this.trailFade;
   }

   private NumberSetting getTrailSoftness() {
      return this.trailSoftness;
   }

   private NumberSetting getTrailBlur() {
      return this.trailBlur;
   }

   private NumberSetting getHandFade() {
      return this.handFade;
   }

   private NumberSetting getHandSoftness() {
      return this.handSoftness;
   }

   private NumberSetting getHandBlur() {
      return this.handBlur;
   }

   private NumberSetting getSmoke() {
      return this.smoke;
   }

   private BooleanSetting getUseItemColor() {
      return this.useItemColor;
   }

   private BooleanSetting getUseThemeColor() {
      return this.useThemeColor;
   }

}
