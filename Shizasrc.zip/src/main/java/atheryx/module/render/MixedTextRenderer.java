package atheryx.module.render;

import atheryx.render.font.Msdf;
import atheryx.render.font.MsdfFont;
import atheryx.render.font.MsdfGlyph;
import atheryx.render.font.MsdfManager;
import java.util.ArrayList;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class MixedTextRenderer {
   public static float calculateAnimationFactor(MsdfFont font, ColoredTextRenderer.ColoredText cs, float size) {
      if (font == null) {
         font = MsdfManager.getDefaultFont();
      }

      class_327 tr = class_310.method_1551().field_1772;
      float width = 0.0F;
      float scale = size / font.getEmSize();
      int guiScale = class_310.method_1551().method_22683().method_4495();
      float vanillaScale = 2.0F / (float)guiScale;

      for(int i = 0; i < cs.plainText.length(); ++i) {
         char c = cs.plainText.charAt(i);
         boolean isSupported = font.getGlyph(c) != null || c == ' ';
         if (isSupported) {
            if (c == ' ') {
               MsdfGlyph glyph = font.getGlyph(32);
               width += glyph != null ? glyph.advance * scale : 0.25F * size;
            } else {
               width += font.getGlyph(c).advance * scale;
            }
         } else {
            width += (float)tr.method_1727(String.valueOf(c)) * vanillaScale;
         }
      }

      return width;
   }

   public static void renderHudElement(class_332 context, MsdfFont font, ColoredTextRenderer.ColoredText cs, float x, float y, float size) {
      if (font == null) {
         font = MsdfManager.getDefaultFont();
      }

      class_327 tr = class_310.method_1551().field_1772;
      int guiScale = class_310.method_1551().method_22683().method_4495();
      float vanillaScale = 2.0F / (float)guiScale;
      float currentX = x;
      StringBuilder currentSegment = new StringBuilder();
      ArrayList segmentColors = new ArrayList();
      boolean wasSupported = true;

      for(int i = 0; i <= cs.plainText.length(); ++i) {
         boolean isSupported = true;
         char c = 0;
         if (i < cs.plainText.length()) {
            c = cs.plainText.charAt(i);
            isSupported = font.getGlyph(c) != null || c == ' ';
         }

         if (i == 0) {
            wasSupported = isSupported;
         }

         if (i != cs.plainText.length() && isSupported == wasSupported) {
            currentSegment.append(c);
            segmentColors.add(cs.colors[i]);
         } else {
            if (currentSegment.length() > 0) {
               if (wasSupported) {
                  int[] cArr = new int[segmentColors.size()];

                  for(int j = 0; j < segmentColors.size(); ++j) {
                     cArr[j] = (Integer)segmentColors.get(j);
                  }

                  Msdf.drawMulticolorText(context, font, currentSegment.toString(), currentX, y - 2.0F, size, false, cArr);
                  float scale = size / font.getEmSize();

                  for(int j = 0; j < currentSegment.length(); ++j) {
                     char sc = currentSegment.charAt(j);
                     if (sc == ' ') {
                        MsdfGlyph glyph = font.getGlyph(32);
                        currentX += glyph != null ? glyph.advance * scale : 0.25F * size;
                     } else {
                        currentX += font.getGlyph(sc).advance * scale;
                     }
                  }
               } else {
                  for(int j = 0; j < currentSegment.length(); ++j) {
                     char sc = currentSegment.charAt(j);
                     int var24 = (Integer)segmentColors.get(j);
                     context.method_51448().pushMatrix();
                     context.method_51448().translate(currentX, y + size / 2.0F - 4.5F * vanillaScale);
                     context.method_51448().scale(vanillaScale, vanillaScale);
                     context.method_51439(tr, class_2561.method_43470(String.valueOf(sc)), 0, 0, var24, false);
                     context.method_51448().popMatrix();
                     currentX += (float)tr.method_1727(String.valueOf(sc)) * vanillaScale;
                  }
               }
            }

            if (i < cs.plainText.length()) {
               currentSegment = new StringBuilder();
               segmentColors = new ArrayList();
               currentSegment.append(c);
               segmentColors.add(cs.colors[i]);
               wasSupported = isSupported;
            }
         }
      }

   }

}
