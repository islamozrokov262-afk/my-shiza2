package atheryx.module.render;

import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import net.minecraft.class_1306;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

@NewFunction(
   name = "Swing Animations",
   desc = "Кастомные анимации ударов от первого лица",
   category = Category.RENDER
)
public class SwingAnimations extends Function {
   private static final float obf_u0427_u222f = 7.0F;
   public static SwingAnimations Instance;
   private final ModeSetting modModeSetting = new ModeSetting("Мод", new String[]{"Никакой", "Swipe", "Down", "Smooth", "Smooth 2", "Power", "Feast", "Twist", "Default", "Self", "Self 2", "Forward", "Touch", "BlockHit", "Pander", "Curt"});
   private final NumberSetting silaNumberSetting = new NumberSetting("Сила", 3.0D, (double)0.0F, 10.0D, (double)1.0F);
   private final NumberSetting silaVzmahaNumberSetting = new NumberSetting("Сила взмаха", (double)1.0F, (double)0.5F, 3.0D, 0.1);
   public final NumberSetting speed = new NumberSetting("Скорость", 7.0D, (double)0.0F, 10.0D, (double)1.0F);
   public final NumberSetting angle = new NumberSetting("Угол", 90.0D, (double)0.0F, 360.0D, 5.0D);
   private int field_8f04dbbe;
   private boolean field_fc3055b3;

   public SwingAnimations() {
      Instance = this;
      this.addSettings(new Setting[]{this.getModeSetting(), this.getStrengthSetting(), this.getSwingStrengthSetting(), this.getSpeed(), this.getAngle()});
      this.getModeSetting().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   public void onEnable() {
      this.resetAnimationState();
   }

   public void onDisable() {
      this.resetAnimationState();
   }

   public boolean matchesValue(String value) {
      return this.getModeSetting().isSelected(value);
   }

   public boolean isFeatureActive() {
      return this.isEnabled() && !this.getModeSetting().isSelected("Никакой");
   }

   public void refreshTarget(class_4587 matrices, float swingProgress, float equipProgress, class_1306 arm, float tickProgress, float lastEquipProgress, float currentEquipProgress) {
      swingProgress = class_3532.method_15363(swingProgress, 0.0F, 1.0F);
      float anim = (float)Math.sin((double)swingProgress * 3.1415926535897931D);
      float sin1 = class_3532.method_15374((double)(swingProgress * swingProgress * 3.14159274F));
      float sin2 = class_3532.method_15374((double)(class_3532.method_15355(swingProgress) * 3.14159274F));
      float sinSmooth = class_3532.method_15374((double)(swingProgress * 3.14159274F)) * 0.5F;
      float strength = (float)this.getSwingStrengthSetting().getValue();
      int side = arm == class_1306.field_6183 ? 1 : -1;
      String var14 = this.getModeSetting().getValue();
      byte var15 = -1;
      switch (var14.hashCode()) {
         case -1911677324:
            if (var14.equals("Pander")) {
               var15 = 14;
            }
            break;
         case -1822155650:
            if (var14.equals("Self 2")) {
               var15 = 9;
            }
            break;
         case -1814666802:
            if (var14.equals("Smooth")) {
               var15 = 5;
            }
            break;
         case -1085510111:
            if (var14.equals("Default")) {
               var15 = 3;
            }
            break;
         case -599960602:
            if (var14.equals("BlockHit")) {
               var15 = 15;
            }
            break;
         case -138073504:
            if (var14.equals("Smooth 2")) {
               var15 = 6;
            }
            break;
         case 2112084:
            if (var14.equals("Curt")) {
               var15 = 13;
            }
            break;
         case 2136258:
            if (var14.equals("Down")) {
               var15 = 4;
            }
            break;
         case 2573164:
            if (var14.equals("Self")) {
               var15 = 11;
            }
            break;
         case 67752259:
            if (var14.equals("Feast")) {
               var15 = 8;
            }
            break;
         case 77306085:
            if (var14.equals("Power")) {
               var15 = 7;
            }
            break;
         case 80301850:
            if (var14.equals("Swipe")) {
               var15 = 2;
            }
            break;
         case 80998175:
            if (var14.equals("Touch")) {
               var15 = 12;
            }
            break;
         case 81225479:
            if (var14.equals("Twist")) {
               var15 = 1;
            }
            break;
         case 125477796:
            if (var14.equals("Никакой")) {
               var15 = 0;
            }
            break;
         case 987507365:
            if (var14.equals("Forward")) {
               var15 = 10;
            }
      }

      switch (var15) {
         case 0:
            this.updateRotation(matrices, swingProgress, equipProgress, arm);
            break;
         case 1:
            matrices.method_46416((float)side * 0.56F, -0.36F, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(80.0F * (float)side));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -90.0F * strength));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((sin1 - sin2) * 60.0F * (float)side * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-30.0F));
            matrices.method_46416(0.0F, -0.1F, 0.05F);
            break;
         case 2:
            matrices.method_46416((float)side * 0.56F, -0.32F, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(70.0F * (float)side));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(-20.0F * (float)side));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(sin2 * sin1 * -5.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * sin1 * -120.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-70.0F));
            break;
         case 3:
            matrices.method_46416((float)side * 0.56F, -0.52F - sin2 * 0.5F * strength, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(45.0F * (float)side));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(-45.0F * (float)side));
            break;
         case 4:
            matrices.method_46416((float)side * 0.56F, -0.32F, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(76.0F * (float)side));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(sin2 * -5.0F * strength));
            matrices.method_22907(class_7833.field_40713.rotationDegrees(sin2 * -100.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -155.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-100.0F));
            break;
         case 5:
            matrices.method_46416((float)side * 0.56F, -0.42F, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * (45.0F + sin1 * -20.0F * strength)));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)side * sin2 * -20.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -80.0F * strength));
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * -45.0F));
            matrices.method_46416(0.0F, -0.1F, 0.0F);
            break;
         case 6:
            matrices.method_46416((float)side * 0.56F, -0.42F, -0.72F);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -80.0F * strength));
            matrices.method_46416(0.0F, -0.1F, 0.0F);
            break;
         case 7:
            matrices.method_46416((float)side * 0.56F, -0.32F, -0.72F);
            matrices.method_46416(-sinSmooth * sinSmooth * sin1 * (float)side * strength, 0.0F, 0.0F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(61.0F * (float)side));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(sin2 * strength));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(sin2 * sin1 * -5.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * sin1 * -30.0F * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-60.0F));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sinSmooth * -60.0F * strength));
            break;
         case 8:
            matrices.method_46416((float)side * 0.56F, -0.32F, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(30.0F * (float)side));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(sin2 * 75.0F * (float)side * strength));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -45.0F * strength));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(30.0F * (float)side));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(35.0F * (float)side));
            break;
         case 9:
            matrices.method_46416((float)side * 0.56F, -0.52F, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * 90.0F));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)side * -30.0F));
            matrices.method_22907(class_7833.field_40714.rotationDegrees((float)(-this.getAngle().getValue() - this.getStrengthSetting().getValue() * 10.0D * (double)sin2)));
            break;
         case 10:
            matrices.method_46416((float)side * 0.56F, -0.52F, -0.72F);
            matrices.method_46416(0.0F, 0.0F, -0.3F * sin2);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sin2 * -35.0F));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)side * sin2 * 35.0F));
            break;
         case 11:
            matrices.method_46416((float)side * 0.56F, -0.52F, -0.72F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * 90.0F));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)side * -60.0F));
            matrices.method_22907(class_7833.field_40714.rotationDegrees((float)(-this.getAngle().getValue() - this.getStrengthSetting().getValue() * 10.0D * (double)sin2)));
            break;
         case 12:
            matrices.method_46416((float)side * 0.56F, -0.52F, -0.72F);
            matrices.method_22905(1.0F, 1.0F, (float)((double)1.0F + (double)anim * this.getStrengthSetting().getValue() / 4.0D));
            matrices.method_46416(0.0F, 0.0F, -0.265F);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-100.0F));
            break;
         case 13:
            matrices.method_46416((float)side * 0.56F, -0.52F, -0.72F);
            float sqrtSwing = class_3532.method_15355(swingProgress);
            float g = class_3532.method_15374((double)(sqrtSwing * 3.14159274F));
            float sinExtra = class_3532.method_15374((double)(swingProgress * 3.14159274F));
            matrices.method_46416((float)side * (0.4F - g * 0.2F), -0.2F + g * 0.3F, -0.5F - sinExtra * 0.2F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * 91.0F));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)side * (-40.0F + g * -100.0F)));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-60.0F));
            break;
         case 14:
            matrices.method_46416((float)side * 0.56F, -0.52F, -0.72F);
            matrices.method_22905(0.8F, 0.8F, 0.8F);
            float anim2 = 1.0F - class_3532.method_16439(tickProgress, lastEquipProgress, currentEquipProgress);
            matrices.method_46416((float)side * (0.3F - anim * 0.15F), 0.2F - anim2 * 0.12F, -0.15F - anim * 0.13F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * (76.0F - 10.0F * anim)));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)side * (-16.0F - 8.0F * anim)));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-83.0F - 26.0F * anim));
            break;
         case 15:
            matrices.method_46416((float)side * 0.56F, -0.52F, -0.72F);
            float squaredSwing = class_3532.method_15374((double)(swingProgress * swingProgress * 3.14159274F));
            float sinMain = class_3532.method_15374((double)(class_3532.method_15355(swingProgress) * 3.14159274F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * 45.0F));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(squaredSwing * -20.0F));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)side * sinMain * -20.0F));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(sinMain * -80.0F));
            matrices.method_46416((float)side * 0.4F, 0.2F, 0.2F);
            matrices.method_46416((float)side * -0.5F, 0.08F, 0.0F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * 20.0F));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * 20.0F));
      }

   }

   private void updateRotation(class_4587 matrices, float swingProgress, float equipProgress, class_1306 arm) {
      int side = arm == class_1306.field_6183 ? 1 : -1;
      matrices.method_46416((float)side * 0.56F, -0.52F + equipProgress * -0.6F, -0.72F);
      float f = -0.4F * class_3532.method_15374((double)(class_3532.method_15355(swingProgress) * 3.14159274F));
      float g = 0.2F * class_3532.method_15374((double)(class_3532.method_15355(swingProgress) * 6.28318548F));
      float h = -0.2F * class_3532.method_15374((double)(swingProgress * 3.14159274F));
      matrices.method_46416((float)side * f, g, h);
      float f2 = class_3532.method_15374((double)(swingProgress * swingProgress * 3.14159274F));
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * (45.0F + f2 * -20.0F)));
      float g2 = class_3532.method_15374((double)(class_3532.method_15355(swingProgress) * 3.14159274F));
      matrices.method_22907(class_7833.field_40718.rotationDegrees((float)side * g2 * -20.0F));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(g2 * -80.0F));
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * -45.0F));
   }

   public int calculateAnimationFactor(int vanillaDuration, boolean handSwinging, int handSwingTicks) {
      if (!this.isHandSwinging() || !handSwinging || handSwingTicks < 0) {
         float speedValue = Math.max((float)this.getSpeed().getValue(), 0.1F);
         this.setCooldownTicks(Math.max(1, Math.round((float)vanillaDuration * 7.0F / speedValue)));
         this.setHandSwinging(handSwinging);
      }

      return this.getCooldownTicks();
   }

   private void resetAnimationState() {
      this.setCooldownTicks(0);
      this.setHandSwinging(false);
   }

   private void updateSettingVisibility() {
      boolean usesLegacyPower = this.getModeSetting().isSelected("Self") || this.getModeSetting().isSelected("Self 2") || this.getModeSetting().isSelected("Touch");
      boolean usesHitStrength = this.getModeSetting().isSelected("Swipe") || this.getModeSetting().isSelected("Down") || this.getModeSetting().isSelected("Smooth") || this.getModeSetting().isSelected("Smooth 2") || this.getModeSetting().isSelected("Power") || this.getModeSetting().isSelected("Feast") || this.getModeSetting().isSelected("Twist") || this.getModeSetting().isSelected("Default");
      this.getStrengthSetting().setVisible(usesLegacyPower);
      this.getSwingStrengthSetting().setVisible(usesHitStrength);
      this.getAngle().setVisible(this.getModeSetting().isSelected("Self") || this.getModeSetting().isSelected("Self 2"));
   }

   private ModeSetting getModeSetting() {
      return this.modModeSetting;
   }

   private NumberSetting getStrengthSetting() {
      return this.silaNumberSetting;
   }

   private NumberSetting getSwingStrengthSetting() {
      return this.silaVzmahaNumberSetting;
   }

   private NumberSetting getSpeed() {
      return this.speed;
   }

   private NumberSetting getAngle() {
      return this.angle;
   }

   private int getCooldownTicks() {
      return this.field_8f04dbbe;
   }

   private void setCooldownTicks(int var1) {
      this.field_8f04dbbe = var1;
   }

   private boolean isHandSwinging() {
      return this.field_fc3055b3;
   }

   private void setHandSwinging(boolean var1) {
      this.field_fc3055b3 = var1;
   }

}
