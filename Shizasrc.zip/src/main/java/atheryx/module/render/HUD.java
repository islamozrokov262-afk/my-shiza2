package atheryx.module.render;

import atheryx.event.EventHandler;
import atheryx.event.impl.Render2DEvent;
import atheryx.gui.ClickGui;
import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.module.combat.AttackAura;
import atheryx.neuro.NeuroManager;
import atheryx.render.RenderUtil;
import atheryx.render.font.Msdf;
import atheryx.render.font.MsdfFont;
import atheryx.render.font.MsdfManager;
import atheryx.render.pipeline.SweepPipeline;
import atheryx.render.pipeline.TexturePipeline;
import atheryx.render.scissor.Scissor;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ListSetting;
import atheryx.setting.impl.NumberSetting;
import atheryx.util.KeyHelper;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1068;
import net.minecraft.class_10799;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_2960;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_408;
import net.minecraft.class_4081;
import net.minecraft.class_742;
import net.minecraft.class_8646;
import net.minecraft.class_8685;
import net.minecraft.class_9011;
import org.lwjgl.glfw.GLFW;

@NewFunction(
   name = "HUD",
   desc = "Минималистичный HUD с ватермаркой и активными биндами",
   category = Category.RENDER
)
public class HUD extends Function {
   public static HUD Instance;
   private static final float obf_u220b_u2208 = 7.0F;
   private static final float obf_u00df_u2208 = 5.0F;
   private static final float obf_u045b_u2208 = 24.0F;
   private static final float obf_u03c2_u2208 = 22.0F;
   private static final float obf_u00c6_u2208 = 17.0F;
   private static final float obf_u0439_u2208 = 9.19999981F;
   private static final float obf_u03a8_u2208 = 10.0F;
   private static final float obf_u2212_u2208 = 4.0F;
   private static final float obf_u0425_u2208 = 8.0F;
   private static final float obf_u0437_u2208 = 0.00749999983F;
   private static final float obf_u00d1_u2208 = 0.0179999992F;
   private static final float obf_u0394_u2208 = 0.0179999992F;
   private static final float obf_u044c_u2208 = 14.0F;
   private static final float obf_u2213_u2208 = 0.449999988F;
   private static final float obf_u041c_u2208 = 22.0F;
   private static final float obf_u0409_u2208 = 17.0F;
   private static final float obf_u044a_u2208 = 8.0F;
   private static final float obf_u00d9_u2208 = 0.00749999983F;
   private static final float obf_u00fa_u2208 = 0.0179999992F;
   private static final float obf_u03b6_u2208 = 0.0179999992F;
   private static final float obf_u223d_u2208 = 14.0F;
   private static final float obf_u042a_u2208 = 0.449999988F;
   private static final float obf_u00de_u2208 = 100.0F;
   private static final float obf_u03a6_u2208 = 34.0F;
   private static final float obf_u223c_u2208 = 17.0F;
   private static final float obf_u03c4_u2208 = 0.0179999992F;
   private static final float obf_u041f_u2208 = 118.0F;
   private static final String obf_u041b_u2208 = "Default";
   private static final String obf_u00f3_u2208 = "Лёд";
   private static final String obf_u043f_u2208 = "Жидкое стекло";
   private static final float obf_u00da_u2208 = 0.579999983F;
   private static final float obf_u0415_u2208 = 0.0120000001F;
   private final BooleanSetting watermarkBooleanSetting = new BooleanSetting("Watermark", true);
   private final ListSetting stilHudListSetting = new ListSetting("Стиль HUD", new String[]{"Default", "Лёд", "Жидкое стекло"});
   private final ListSetting watermarkStyleListSetting = new ListSetting("Watermark Style", new String[]{"Default", "LiquidGlass Watermark"});
   private final BooleanSetting watermarkLyodBooleanSetting = new BooleanSetting("Watermark Лёд", false);
   private final BooleanSetting watermarkZhidkoeStekloBooleanSetting = new BooleanSetting("Watermark Жидкое стекло", false);
   private final BooleanSetting keybindsLyodBooleanSetting = new BooleanSetting("Keybinds Лёд", false);
   private final BooleanSetting keybindsZhidkoeStekloBooleanSetting = new BooleanSetting("Keybinds Жидкое стекло", false);
   private final BooleanSetting potionsLyodBooleanSetting = new BooleanSetting("Potions Лёд", false);
   private final BooleanSetting potionsZhidkoeStekloBooleanSetting = new BooleanSetting("Potions Жидкое стекло", false);
   private final BooleanSetting targethudLyodBooleanSetting = new BooleanSetting("TargetHUD Лёд", false);
   private final BooleanSetting targethudZhidkoeStekloBooleanSetting = new BooleanSetting("TargetHUD Жидкое стекло", false);
   private final BooleanSetting hotbarLyodBooleanSetting = new BooleanSetting("Hotbar Лёд", false);
   private final BooleanSetting hotbarZhidkoeStekloBooleanSetting = new BooleanSetting("Hotbar Жидкое стекло", false);
   private final BooleanSetting keybindsBooleanSetting = new BooleanSetting("Keybinds", true);
   private final BooleanSetting targethudBooleanSetting = new BooleanSetting("TargetHUD", true);
   private final BooleanSetting neuroAimBooleanSetting = new BooleanSetting("Neuro Aim", true);
   private final BooleanSetting potionsBooleanSetting = new BooleanSetting("Potions", true);
   private final BooleanSetting hotbarBooleanSetting = new BooleanSetting("Hotbar", true);
   private final BooleanSetting scoreboardBooleanSetting = new BooleanSetting("Scoreboard", true);
   private final NumberSetting silaBlyuraNumberSetting = new NumberSetting("Сила блюра", 25.0D, (double)0.0F, 100.0D, (double)1.0F);
   private final BooleanSetting sheyderBooleanSetting = new BooleanSetting("Шейдер", false);
   private DragTarget field_61bc7b0e;
   private boolean field_cee7f503;
   private boolean field_3c136ef8;
   private float field_a93ee8ed;
   private float field_166a62e2;
   private float field_8395dcd7;
   private float field_f0c156cc;
   private float field_5decd0c1;
   private float field_cb184ab6;
   private float field_3843c4ab;
   private float field_a56f3ea0;
   private float field_129ab895;
   private float field_7fc6328a;
   private float field_ecf1ac7f;
   private float field_5a1d2674;
   private float field_c748a069;
   private float field_34741a5e;
   private float field_a19f9453;
   private float field_ecb0e48;
   private float field_7bf6883d;
   private float field_e9220232;
   private float field_564d7c27;
   private float field_c378f61c;
   private float field_30a47011;
   private float field_9dcfea06;
   private float field_afb63fb;
   private float field_7826ddf0;
   private float field_e55257e5;
   private float field_527dd1da;
   private float field_bfa94bcf;
   private float field_2cd4c5c4;
   private float field_9a003fb9;
   private float field_72bb9ae;
   private float field_745733a3;
   private long field_e182ad98;
   private boolean field_4eae278d;
   private float field_bbd9a182;
   private float field_29051b77;
   private float field_9630956c;
   private HudElement field_35c0f61;
   private float field_70878956;
   private float field_ddb3034b;
   private class_1309 field_4ade7d40;
   private long field_b809f735;
   private long field_2535712a;
   private boolean field_9260eb1f;
   private float field_ff8c6514;
   private float field_6cb7df09;
   private String field_d9e358fe;
   private String field_470ed2f3;
   private long field_b43a4ce8;
   private boolean field_2165c6dd;
   private float field_8e9140d2;
   private float field_fbbcbac7;
   private float field_68e834bc;
   private float field_d613aeb1;
   private float field_433f28a6;
   private float field_b06aa29b;
   private float field_1d961c90;
   private final float[] field_8ac19685;
   private final Map<Function, Float> field_f7ed107a;
   private final Map<Function, Float> field_65188a6f;
   private final Map<String, Float> field_d2440464;
   private final Map<String, NumericTextAnimationState> field_3f6f7e59;
   private float field_ac9af84e;
   private float field_19c67243;
   private float field_86f1ec38;
   private static final float obf_u00f1_u222f = 18.0F;
   private static final float obf_u0392_u222f = 2.5F;
   private static final float obf_u03be_u222f = 4.0F;
   private static final float obf_u221d_u222f = 6.0F;
   private static final float obf_u03bf_u222f = 7.0F;
   private static final float obf_u040f_u222f = 5.0F;
   private static final float obf_u0420_u222f = 64.0F;
   private static final float obf_u0458_u222f = 7.0F;
   private static final float obf_u042f_u222f = 9.0F;
   private static final float obf_u2237_u222f = 3.0F;
   private static final float obf_u0429_u222f = 6.19999981F;
   private static final float obf_u040a_u222f = 6.4000001F;
   private static final float obf_u041a_u222f = 7.19999981F;
   private static final float obf_u0417_u222f = 7.5999999F;
   private static final long obf_u00cf_u222f = 1200L;
   private static final long obf_u2200_u222f = 260L;
   private static final float obf_u223a_u222f = 0.0240000002F;
   private static final float obf_u03b8_u222f = 0.0179999992F;
   private static final float obf_u03af_u222f = 0.0140000004F;
   private static final float obf_u2222_u222f = 1.29999995F;
   private static final float obf_u2207_u222f = 0.920000017F;

   public HUD() {
      this.setDraggedElement(HUD.DragTarget.NONE);
      this.setTargetAlpha(8.0F);
      this.setRenderX(8.0F);
      this.setRenderY(8.0F);
      this.setCurrentScale(37.0F);
      this.setTargetScale(39.0F);
      this.setYawOffset(96.0F);
      this.setVerticalSpeed(8.0F);
      this.setInterpolation(63.0F);
      this.setFadeProgress(8.0F);
      this.setWidth(166.0F);
      this.setHeight(8.0F);
      this.setRadius(116.0F);
      this.setOpacity(39.0F);
      this.setRotation(96.0F);
      this.setAlternateCurrentAlpha(8.0F);
      this.setScoreboardY(160.0F);
      this.setTransientRenderX(120.0F);
      this.setPrimaryRenderY(40.0F);
      this.setTargetWidth(-1.0F);
      this.setTargetWidthPrimary(120.0F);
      this.setTargetWidthSecondary(120.0F);
      this.setLastActionTime(0L);
      this.setHoveredElement(HUD.HudElement.WATERMARK);
      this.setTransientYawOffset(0.0F);
      this.setDisplayName("");
      this.setKey("");
      this.field_8ac19685 = new float[9];
      this.field_f7ed107a = new HashMap<Function, Float>();
      this.field_65188a6f = new HashMap<Function, Float>();
      this.field_d2440464 = new HashMap<String, Float>();
      this.field_3f6f7e59 = new HashMap<String, NumericTextAnimationState>();
      this.setTargetHp(0.0F);
      this.setAlternateMovementSpeed(0.0F);
      this.setFallbackVerticalSpeed(0.0F);
      Instance = this;
      this.getWatermarkSetting().setChangeListener(() -> {
         this.getWatermarkStyleSetting().setVisible(false);
         this.getWatermarkIceSetting().setVisible(false);
         this.getWatermarkLiquidGlassSetting().setVisible(false);
      });
      this.getKeybindsSetting().setChangeListener(() -> {
         this.getKeybindsIceSetting().setVisible(false);
         this.getKeybindsLiquidGlassSetting().setVisible(false);
      });
      this.getPotionsSetting().setChangeListener(() -> {
         this.getPotionsIceSetting().setVisible(false);
         this.getPotionsLiquidGlassSetting().setVisible(false);
      });
      this.getTargetHudSetting().setChangeListener(() -> {
         this.getTargetHudIceSetting().setVisible(false);
         this.getTargetHudLiquidGlassSetting().setVisible(false);
      });
      this.getHotbarSetting().setChangeListener(() -> {
         this.getHotbarIceSetting().setVisible(false);
         this.getHotbarLiquidGlassSetting().setVisible(false);
      });
      this.addSettings(new Setting[]{this.getWatermarkSetting(), this.getHudStyleSetting(), this.getWatermarkStyleSetting(), this.getWatermarkIceSetting(), this.getWatermarkLiquidGlassSetting(), this.getKeybindsSetting(), this.getKeybindsIceSetting(), this.getKeybindsLiquidGlassSetting(), this.getTargetHudSetting(), this.getNeuroAimSetting(), this.getTargetHudIceSetting(), this.getTargetHudLiquidGlassSetting(), this.getPotionsSetting(), this.getPotionsIceSetting(), this.getPotionsLiquidGlassSetting(), this.getHotbarSetting(), this.getHotbarIceSetting(), this.getHotbarLiquidGlassSetting(), this.getScoreboardSetting(), this.getBlurStrengthSetting(), this.getShaderSetting()});
   }

   @EventHandler
   public void onRender2D(Render2DEvent event) {
      class_332 context = event.getDrawContext();
      if (context != null && !this.mc.field_1690.field_1842) {
         if (this.shouldProcessPrimary()) {
            boolean chatOpen = this.mc.field_1755 instanceof class_408;
            List<Function> activeBinds = this.collectItemsSecondary();
            List<class_1293> activePotions = this.collectItems();
            boolean keybindsVisible = this.getKeybindsSetting().isEnabled() && (!activeBinds.isEmpty() || chatOpen);
            boolean potionsVisible = this.getPotionsSetting().isEnabled() && (!activePotions.isEmpty() || chatOpen);
            class_1309 auraTarget = this.findTarget();
            class_1309 targetHudEntity = (class_1309)(auraTarget != null ? auraTarget : (this.shouldProcessSecondary() ? this.mc.field_1724 : null));
            boolean targetHudVisible = this.getTargetHudSetting().isEnabled() && targetHudEntity != null;
            this.updateTimedState(keybindsVisible, targetHudVisible, potionsVisible, activeBinds, activePotions);
            this.renderModuleElement();
            if (this.getWatermarkSetting().isEnabled()) {
               this.renderSingleplayer(context, this.getTargetAlpha(), this.getRenderX());
            }

            if (this.getKeybindsSetting().isEnabled() && this.getMovementSpeed() > 0.02F) {
               this.renderHotkeys(context, this.getRenderY(), this.getCurrentScale(), this.collectItemsCurrent(), this.getMovementSpeed());
            }

            if (this.getPotionsSetting().isEnabled() && this.getTargetValue() > 0.02F) {
               this.renderPotions(context, this.getHeight(), this.getRadius(), this.collectItemsPrimary(), this.getTargetValue());
            }

            if (this.getTargetHudSetting().isEnabled() && this.getTargetHudAnimationProgress() > 0.02F) {
               this.renderHudElement(context, this.getVerticalSpeed(), this.getInterpolation(), targetHudEntity, this.getTargetHudAnimationProgress());
            }

            if (this.getNeuroAimSetting().isEnabled() && (NeuroManager.isVisualizationActive() || this.shouldProcessSecondary())) {
               this.renderNeuroAim(context, this.getFadeProgress(), this.getWidth());
            }

            if (this.getAlternateCurrentScale() > 0.02F && this.shouldProcessSecondary()) {
               this.renderHudStyleMenu(context, this.getStylePopupX(), this.getOptionsY(), this.getAlternateCurrentScale());
            }

            if (this.getHotbarSetting().isEnabled()) {
               this.renderHudElement(context);
            }

            if (this.getScoreboardSetting().isEnabled()) {
               this.renderHudElement(context, this.getAlternateCurrentAlpha(), this.getScoreboardY());
            }

         }
      }
   }

   private void renderNeuroAim(class_332 context, float x, float y) {
      float size = 76.0F;
      float progress = this.clamp(NeuroManager.getYawMotion(), 0.0F, 1.0F);
      float shake = this.clamp(NeuroManager.getShakeMotion(), 0.0F, 1.0F);
      float inner = size - 16.0F;
      float originX = x + 8.0F;
      float originY = y + 8.0F;
      this.renderModuleElement("NeuroAim", x, y, size, size, 7.0F, 0.95F);
      RenderUtil.drawRoundedOutline(x + 0.7F, y + 0.7F, size - 1.4F, size - 1.4F, 7.0F, 0.8F, this.resolveColor(ThemeManager.getCurrentColor(), (int)(45.0F + progress * 80.0F)));
      Color grid = new Color(255, 255, 255, 24);
      RenderUtil.drawRoundedRect(originX, y + size / 2.0F, inner, 0.7F, 0.35F, grid);
      RenderUtil.drawRoundedRect(x + size / 2.0F, originY, 0.7F, inner, 0.35F, grid);
      RenderUtil.drawRoundedRect(originX + inner * 0.25F, originY, 0.45F, inner, 0.2F, new Color(255, 255, 255, 13));
      RenderUtil.drawRoundedRect(originX + inner * 0.75F, originY, 0.45F, inner, 0.2F, new Color(255, 255, 255, 13));
      RenderUtil.drawRoundedRect(originX, originY + inner * 0.25F, inner, 0.45F, 0.2F, new Color(255, 255, 255, 13));
      RenderUtil.drawRoundedRect(originX, originY + inner * 0.75F, inner, 0.45F, 0.2F, new Color(255, 255, 255, 13));
      long now = System.currentTimeMillis();
      List trail = NeuroManager.getTrailPoints();

      for(int i = 0; i < trail.size(); ++i) {
         NeuroManager.AimTrailPoint point = (NeuroManager.AimTrailPoint)trail.get(i);
         float age = this.clamp((float)(now - point.createdAt()) / 2200.0F, 0.0F, 1.0F);
         float order = trail.size() <= 1 ? 1.0F : (float)i / (float)(trail.size() - 1);
         float alpha = (1.0F - age) * (0.24F + order * 0.76F);
         float dotSize = 2.20000005F + order * 2.0999999F + point.shake() * 1.8F;
         Color calm = this.resolveColor(new Color(120, 210, 255, 255), ThemeManager.getCurrentColor(), progress);
         Color nervous = new Color(246, 83, 92, 255);
         Color color = this.applyOpacity(this.resolveColor(calm, nervous, point.shake()), alpha);
         float px = originX + point.x() * inner;
         float py = originY + point.y() * inner;
         RenderUtil.drawRoundedRect(px - dotSize / 2.0F, py - dotSize / 2.0F, dotSize, dotSize, dotSize / 2.0F, color);
      }

      if (trail.isEmpty() && this.shouldProcessSecondary()) {
         RenderUtil.drawRoundedRect(x + size / 2.0F - 2.0F, y + size / 2.0F - 2.0F, 4.0F, 4.0F, 2.0F, this.resolveColor(ThemeManager.getCurrentColor(), 180));
      }

      float barY = y + size - 7.0F;
      RenderUtil.drawRoundedRect(originX, barY, inner, 2.4000001F, 1.2F, new Color(38, 42, 52, 230));
      RenderUtil.drawRoundedRect(originX, barY, inner * progress, 2.4000001F, 1.2F, this.resolveColor(new Color(235, 70, 82), ThemeManager.getCurrentColor(), progress), this.resolveColor(new Color(245, 176, 78), new Color(255, 255, 255, 220), progress));
      RenderUtil.drawText(context, x + 6.0F, y + 4.0F, String.valueOf(Math.round(progress * 100.0F)) + "%", 6.5F, this.resolveColor(new Color(245, 247, 252), 215));
      RenderUtil.drawAlignedText(context, x + size - 6.0F, y + 4.0F, String.valueOf(Math.round(shake * 100.0F)) + "%", 6.5F, this.resolveColor(new Color(245, 120, 130), 210), "right");
   }

   private void renderSingleplayer(class_332 context, float x, float y) {
      Msdf.isReady();
      MsdfFont textFont = Msdf.SF_REGULAR;
      MsdfFont iconFont = Msdf.WOQUED_ICONS;
      float h = 24.0F;
      float p = 7.0F;
      float fontSize = 9.19999981F;
      float iconSize = 10.0F;
      float gap = 4.0F;
      this.setTransientYawOffset(class_3532.method_16439(0.1F, this.getTransientYawOffset(), (float)this.mc.method_47599()));
      String fpsText = "FPS: " + String.valueOf(Math.round(this.getTransientYawOffset()));
      String ipText = this.mc.method_1558() != null ? this.mc.method_1558().field_3761 : "singleplayer";
      String pcName = System.getProperty("user.name");
      String clientName = "Shiza";
      String userIcon = "n";
      String serverIcon = "o";
      String fpsIcon = "p";
      float logoNameWidth = Msdf.getTextWidth(textFont, clientName, (float)fontSize);
      float userIconWidth = Msdf.getTextWidth(iconFont, userIcon, (float)iconSize);
      float userNameWidth = Msdf.getTextWidth(textFont, pcName, (float)fontSize);
      float serverIconWidth = Msdf.getTextWidth(iconFont, serverIcon, (float)iconSize);
      float serverIpWidth = Msdf.getTextWidth(textFont, ipText, (float)fontSize);
      float fpsIconWidth = Msdf.getTextWidth(iconFont, fpsIcon, (float)iconSize);
      float fpsTextWidth = Msdf.getTextWidth(textFont, fpsText, (float)fontSize);
      float totalWidth = p + logoNameWidth + gap + userIconWidth + gap + userNameWidth + gap + serverIconWidth + gap + serverIpWidth + gap + fpsIconWidth + gap + fpsTextWidth + p;
      this.setTotalWidth(totalWidth);
      boolean glass = this.resolveHudStyle() != HUD.HudStyle.DEFAULT;
      if (glass) {
         this.renderModuleElement(x, y, totalWidth, (float)h);
      } else {
         this.updateRotation("Watermark", x, y, totalWidth, (float)h, 7.0F);
      }

      Color textColor = new Color(245, 245, 248);
      Color iconColor = ThemeManager.getCurrentColor();
      float textY = y + h / 2.0F - fontSize / 2.0F;
      float iconY = y + h / 2.0F - iconSize / 2.0F + 0.7F;
      float currentX = x + p;
      Msdf.drawText(context, textFont, clientName, currentX, textY, (float)fontSize, textColor.getRGB(), false);
      currentX += logoNameWidth + gap;
      Msdf.drawText(context, iconFont, userIcon, currentX, iconY, (float)iconSize, iconColor.getRGB(), false);
      currentX += userIconWidth + gap;
      Msdf.drawText(context, textFont, pcName, currentX, textY, (float)fontSize, textColor.getRGB(), false);
      currentX += userNameWidth + gap;
      Msdf.drawText(context, iconFont, serverIcon, currentX, iconY, (float)iconSize, iconColor.getRGB(), false);
      currentX += serverIconWidth + gap;
      Msdf.drawText(context, textFont, ipText, currentX, textY, (float)fontSize, textColor.getRGB(), false);
      currentX += serverIpWidth + gap;
      Msdf.drawText(context, iconFont, fpsIcon, currentX, iconY, (float)iconSize, iconColor.getRGB(), false);
      currentX += fpsIconWidth + gap;
      Msdf.drawText(context, textFont, fpsText, currentX, textY, (float)fontSize, textColor.getRGB(), false);
   }

   private void renderModuleElement(float x, float y, float width, float height) {
      float radius = 8.5F;
      RenderUtil.drawShadow(x + 0.5F, y + 1.2F, width - 1.0F, height - 0.4F, radius, 10.0F, 0.34F, 2.4000001F, new Color(0, 0, 0, 170));
      this.renderModuleElement(x, y, width, height, radius, 0.9F);
      RenderUtil.drawRoundedOutline(x + 0.45F, y + 0.45F, width - 0.9F, height - 0.9F, radius, 0.85F, new Color(255, 255, 255, 82), new Color(255, 255, 255, 44), this.resolveColor(ThemeManager.getCurrentColor(), 52), new Color(255, 255, 255, 24));
      RenderUtil.drawRoundedRect(x + 6.0F, y + 2.0999999F, width - 12.0F, 1.05F, 0.5F, new Color(255, 255, 255, 54), new Color(255, 255, 255, 6));
      this.updateTimedState("WatermarkGlass", x, y, width, height, radius, 1.0F);
   }

   private void renderHotkeys(class_332 context, float x, float y, List<Function> activeBinds, float progress) {
      float eased = this.easeOutCubic(progress);
      float h = 16.0F;
      float p = 7.0F;
      float fontSize = 8.0F;
      float round = 4.0F;
      float iconPadding = 7.0F;
      float gap = 2.0F;
      float leftPanelWidth = 30.0F;
      String title = "Hotkeys";
      String icon = "t";
      float titleWidth = Msdf.getTextWidth(MsdfManager.SF_REGULAR, title, fontSize);
      float iconWidth = Msdf.getTextWidth(MsdfManager.WOQUED_ICONS, icon, fontSize);
      float totalTitleContentWidth = titleWidth + iconPadding + iconWidth;
      float maxW = Math.max(72.0F, totalTitleContentWidth + p * 2.0F);
      float rowsHeight = 0.0F;

      for(Function function : activeBinds) {
         float rowAnim = (Float)this.getIterator().getOrDefault(function, 0.0F);
         if (!(rowAnim <= 0.02F)) {
            float moduleNameW = Msdf.getTextWidth(MsdfManager.SF_REGULAR, function.getName(), fontSize);
            float totalRowW = leftPanelWidth + gap + moduleNameW + 10.0F;
            if (totalRowW > maxW) {
               maxW = totalRowW;
            }

            rowsHeight += (h + 2.0F) * this.easeOutCubic(rowAnim);
         }
      }

      boolean isRightSide = x + this.getYawOffset() / 2.0F > (float)RenderUtil.getScaledWidth() / 2.0F;
      float renderX = isRightSide ? x + this.getYawOffset() - maxW : x;
      float panelHeight = h + 3.0F + rowsHeight;
      this.renderModuleElement(HUD.HudElement.KEYBINDS, renderX, y, maxW, panelHeight, round, eased);
      float centerY = y + h / 2.0F - fontSize / 2.0F;
      RenderUtil.drawRoundedRect(renderX, y, maxW, h, round, this.applyOpacity(new Color(255, 255, 255, 22), eased));
      float iconX = renderX + 4.0F;
      Msdf.drawGradientText(context, MsdfManager.WOQUED_ICONS, icon, iconX, centerY, fontSize, this.applyOpacity(ThemeManager.getCurrentColor(), eased).getRGB(), this.applyOpacity(ThemeManager.Theme_Color2, eased).getRGB(), false);
      RenderUtil.drawText(context, MsdfManager.SF_REGULAR, iconX + iconWidth + iconPadding, centerY, title, fontSize, this.applyOpacity(new Color(245, 245, 248), eased));
      float currentY = y + h + 3.0F;
      float rowsOpenProgress = this.clamp((progress - 0.45F) / 0.55F, 0.0F, 1.0F);

      for(Function function : activeBinds) {
         float anim = this.easeOutCubic((Float)this.getIterator().getOrDefault(function, 0.0F)) * this.easeOutCubic(rowsOpenProgress);
         if (!(anim <= 0.05F)) {
            float rowH = h * anim;
            float textCenterY = currentY + rowH / 2.0F - fontSize / 2.0F;
            String moduleName = function.getName();
            String key = KeyHelper.getKeyName(function.getKeybind());
            float sliderBgWidth = 12.0F;
            float sliderBgHeight = 7.0F;
            float sliderPosX = renderX + 4.0F;
            float sliderPosY = currentY + 4.5F;
            RenderUtil.drawRoundedRect(sliderPosX, sliderPosY, (float)sliderBgWidth, (float)sliderBgHeight, 3.5F, this.applyOpacity(new Color(40, 40, 40, 255), eased * anim));
            float sliderAnim = (Float)this.getSliderIterator().getOrDefault(function, function.isEnabled() ? 1.0F : 0.0F);
            float sliderIndicatorSize = 5.0F;
            float sliderIndicatorX = sliderPosX + 1.0F + sliderAnim * (sliderBgWidth - sliderIndicatorSize - 2.0F);
            float var42 = sliderPosY + 1.0F;
            RenderUtil.drawRoundedRect(sliderIndicatorX, var42, (float)sliderIndicatorSize, (float)sliderIndicatorSize, 2.5F, this.applyOpacity(ThemeManager.getCurrentColor(), eased * anim));
            RenderUtil.drawText(context, MsdfManager.SF_REGULAR, renderX + 21.0F, textCenterY, key, fontSize, this.applyOpacity(new Color(245, 245, 248), eased * anim));
            RenderUtil.drawText(context, MsdfManager.SF_REGULAR, renderX + leftPanelWidth + gap + 5.0F, textCenterY, moduleName, fontSize, this.applyOpacity(new Color(245, 245, 248), eased * anim));
            currentY += rowH + 2.0F;
         }
      }

      this.setMaxW(maxW);
      this.setTargetScale(currentY - y);
   }

   private void renderPotions(class_332 context, float x, float y, List<class_1293> effects, float progress) {
      float eased = this.easeOutCubic(progress);
      float h = 16.0F;
      float p = 7.0F;
      float fontSize = 8.0F;
      float round = 4.0F;
      float gap = 2.0F;
      float iconPanelWidth = 16.0F;
      String title = "Potions";
      String icon = "u";
      float titleWidth = Msdf.getTextWidth(MsdfManager.SF_REGULAR, title, (float)fontSize);
      float iconWidth = Msdf.getTextWidth(MsdfManager.WOQUED_ICONS, icon, (float)fontSize);
      float var17 = titleWidth + 12.0F + iconWidth;
      float maxW = Math.max(72.0F, var17 + p * 2.0F);
      float rowsHeight = 0.0F;

      for(class_1293 effect : effects) {
         float rowAnim = (Float)this.getPotionsIterator().getOrDefault(this.resolveText(effect), 0.0F);
         if (!(rowAnim <= 0.02F)) {
            String name = this.resolveTextPrimary(effect);
            String duration = this.resolveTextSecondary(effect);
            float nameWidth = Msdf.getTextWidth(MsdfManager.SF_REGULAR, name, (float)fontSize);
            float durationWidth = Msdf.getTextWidth(MsdfManager.SF_REGULAR, duration, (float)fontSize);
            float rightPanelWidth = Math.max(nameWidth + durationWidth + 16.0F, 40.0F);
            float totalRowW = iconPanelWidth + gap + rightPanelWidth;
            if (totalRowW > maxW) {
               maxW = totalRowW;
            }

            rowsHeight += (h + 2.0F) * this.easeOutCubic(rowAnim);
         }
      }

      boolean isRightSide = x + this.getRotation() / 2.0F > (float)RenderUtil.getScaledWidth() / 2.0F;
      float renderX = isRightSide ? x + this.getRotation() - maxW : x;
      float panelHeight = h + 3.0F + rowsHeight;
      this.renderModuleElement(HUD.HudElement.POTIONS, renderX, y, maxW, panelHeight, (float)round, eased);
      float centerY = y + h / 2.0F - fontSize / 2.0F;
      RenderUtil.drawRoundedRect(renderX, y, maxW, h, (float)round, this.applyOpacity(new Color(255, 255, 255, 22), eased));
      float iconX = renderX + 4.0F;
      Msdf.drawGradientText(context, MsdfManager.WOQUED_ICONS, icon, iconX, y + h / 2.0F - 4.0F + 0.5F, (float)fontSize, this.applyOpacity(ThemeManager.getCurrentColor(), eased).getRGB(), this.applyOpacity(ThemeManager.Theme_Color2, eased).getRGB(), false);
      RenderUtil.drawText(context, MsdfManager.SF_REGULAR, renderX + 16.0F, centerY, title, (float)fontSize, this.applyOpacity(new Color(245, 245, 248), eased));
      float currentY = y + h + 3.0F;
      float rowsOpenProgress = this.clamp((progress - 0.45F) / 0.55F, 0.0F, 1.0F);

      for(class_1293 effect : effects) {
         String id = this.resolveText(effect);
         float anim = this.easeOutCubic((Float)this.getPotionsIterator().getOrDefault(id, 0.0F)) * this.easeOutCubic(rowsOpenProgress);
         if (!(anim <= 0.05F)) {
            float rowH = h * anim;
            float textCenterY = currentY + rowH / 2.0F - fontSize / 2.0F;
            String name = this.resolveTextPrimary(effect);
            String duration = this.resolveTextSecondary(effect);
            float nameWidth = Msdf.getTextWidth(MsdfManager.SF_REGULAR, name, (float)fontSize);
            float durationWidth = Msdf.getTextWidth(MsdfManager.SF_REGULAR, duration, (float)fontSize);
            float rightPanelWidth = Math.max(nameWidth + durationWidth + 16.0F, 40.0F);
            class_2960 spriteId = class_329.method_71644(effect.method_5579());
            if (spriteId != null) {
               int color = (new Color(255, 255, 255, (int)(eased * anim * 255.0F))).getRGB();
               context.method_52707(class_10799.field_56883, spriteId, (int)(renderX + 4.0F), (int)(currentY + 4.5F), 8, 8, color);
            }

            class_1291 effectType = (class_1291)effect.method_5579().comp_349();
            boolean isNegative = effectType.method_18792() == class_4081.field_18272;
            Color nameColor = isNegative ? this.applyOpacity(new Color(255, 85, 85), eased * anim) : this.applyOpacity(new Color(245, 245, 248), eased * anim);
            RenderUtil.drawText(context, MsdfManager.SF_REGULAR, renderX + iconPanelWidth + gap + 5.0F, textCenterY, name, (float)fontSize, nameColor);
            float durationX = renderX + iconPanelWidth + gap + rightPanelWidth - durationWidth - 5.0F;
            RenderUtil.drawText(context, MsdfManager.SF_REGULAR, durationX, textCenterY, duration, (float)fontSize, this.applyOpacity(ThemeManager.getCurrentColor(), eased * anim));
            currentY += rowH + 2.0F;
         }
      }

      this.setMaxWPrimary(maxW);
      this.setOpacity(currentY - y);
   }

   private void renderHudElement(class_332 context, float x, float y, class_1309 auraTarget, float progress) {
      float hudOpacity = this.easeOutCubic(progress);
      if (hudOpacity > 0.02F) {
         this.renderD(context, x, y, auraTarget, hudOpacity);
      }

   }

   private void renderD(class_332 context, float x, float y, class_1309 auraTarget, float progress) {
      class_1309 target = auraTarget != null ? auraTarget : this.getTarget();
      float targetArmorAlpha = auraTarget != null ? 1.0F : 0.0F;
      this.setFallbackVerticalSpeed(this.getFallbackVerticalSpeed() + (targetArmorAlpha - this.getFallbackVerticalSpeed()) * 0.12F);
      if (target != null) {
         this.setTarget(auraTarget != null ? auraTarget : this.getTarget());
         float eased = this.clamp(progress, 0.0F, 1.0F);
         float width = 100.0F;
         float height = 34.0F;
         float spacing = 5.0F;
         this.renderModuleElement(HUD.HudElement.TARGET_HUD, x, y, width, height, 5.0F, eased);
         RenderUtil.drawRoundedRect(x, y, width, height, 5.0F, this.applyOpacity(new Color(0, 0, 0, 40), eased));
         float targetHp = Math.max(0.0F, target.method_6032());
         float maxHp = Math.max(1.0F, target.method_6063());
         if (!(this.getTargetHp() <= 0.0F) && !(targetHp <= 0.0F) && !(Math.abs(this.getTargetHp() - targetHp) < 0.05F)) {
            float factor = targetHp < this.getTargetHp() ? 0.15F : 0.07F;
            this.setTargetHp(class_3532.method_16439(factor, this.getTargetHp(), targetHp));
         } else {
            this.setTargetHp(targetHp);
         }

         float healthPct = class_3532.method_15363(this.getTargetHp() / maxHp, 0.0F, 1.0F);
         this.setAlternateMovementSpeed(this.calculateScale(this.getAlternateMovementSpeed(), healthPct, 0.1F));
         float headSize = height - 6.0F;
         float headX = x + 4.0F;
         float headY = y + (height - headSize) / 2.0F;
         float hurtProgress = (float)target.field_6235 / 10.0F;
         this.renderCenter(context, target, headX, headY, eased, headSize, 4.0F, hurtProgress);
         float contentX = headX + headSize + spacing;
         Scissor.push((double)contentX, (double)y, (double)(width - (headSize + spacing * 2.0F)), (double)height);
         String name = this.ellipsize(target.method_5477().getString(), width - (headSize + spacing * 2.0F), 7.5F);
         RenderUtil.drawText(context, MsdfManager.SF_REGULAR, contentX, y + spacing, name, 7.5F, this.applyOpacity(new Color(245, 245, 248), eased));
         String hpIcon = "d";
         float iconSize = 6.5F;
         float iconWidth = Msdf.getTextWidth(MsdfManager.WOQUED_ICONS, hpIcon, (float)iconSize);
         float hpTextY = y + spacing + 9.0F;
         Msdf.drawGradientText(context, MsdfManager.WOQUED_ICONS, hpIcon, contentX, hpTextY, (float)iconSize, this.applyOpacity(ThemeManager.getCurrentColor(), eased).getRGB(), this.applyOpacity(ThemeManager.Theme_Color2, eased).getRGB(), false);
         String hpText = String.format(Locale.US, "%.1f", this.getTargetHp()).replace(',', '.');
         float var27 = contentX + iconWidth + 2.0F;
         RenderUtil.drawText(context, MsdfManager.SF_BOLD, var27, hpTextY, hpText, (float)iconSize, this.applyOpacity(new Color(245, 245, 248), eased * 0.9F));
         Scissor.popTertiary();
         float barWidth = width - (headSize + spacing * 3.0F);
         float barY = y + height - spacing - 6.0F;
         float barHeight = 6.0F;
         RenderUtil.drawRoundedRect(contentX, barY, barWidth, (float)barHeight, 2.0F, this.applyOpacity(new Color(35, 35, 35), eased));
         float hpWidth = barWidth * this.getAlternateMovementSpeed();
         if (hpWidth > 0.5F) {
            Color theme = this.applyOpacity(ThemeManager.getCurrentColor(), eased);
            if (!ThemeManager.twoColors) {
               RenderUtil.drawRoundedRect(contentX, barY, hpWidth, (float)barHeight, 2.0F, theme);
            } else {
               Color theme2 = this.applyOpacity(ThemeManager.Theme_Color2, eased);
               Color mid = this.resolveColor(theme, theme2, 0.5F);
               RenderUtil.drawRoundedRect(contentX, barY, hpWidth, (float)barHeight, 2.0F, theme, mid, theme2, theme, mid, theme2, theme, mid, theme2);
            }
         }

         this.renderHudElement(context, target, x + 41.0F, y + height + 4.0F, this.getFallbackVerticalSpeed() * eased);
      }
   }

   private void renderHudStyleMenu(class_332 context, float x, float y, float progress) {
      float eased = this.easeOutCubic(progress);
      float height = this.calculateRenderOffset();
      float slide = (1.0F - eased) * 7.0F;
      float drawY = y - slide;
      this.renderModuleElement("HudStyleMenu", x, drawY, 118.0F, height * eased, 6.0F, eased);
      if (!(eased <= 0.08F)) {
         Scissor.push((double)x, (double)drawY, 118.0D, (double)(height * eased));
         RenderUtil.drawText(context, x + 7.0F, drawY + 5.4000001F, "HUD", 7.4000001F, this.applyOpacity(new Color(225, 225, 230), eased));
         this.renderHudElement(context, x, drawY + 17.0F, "Default", this.resolveHudStyle() == HUD.HudStyle.DEFAULT, eased);
         this.renderHudElement(context, x, drawY + 34.0F, "Лёд", this.resolveHudStyle() == HUD.HudStyle.ICE, eased);
         this.renderHudElement(context, x, drawY + 51.0F, "Жидкое стекло", this.resolveHudStyle() == HUD.HudStyle.LIQUID, eased);
         Scissor.popTertiary();
      }
   }

   private void renderHudElement(class_332 context, float x, float y, String label, boolean selected, float opacity) {
      boolean hovered = this.isPointInside(this.getMouseX(), this.getMouseY(), x, y, 118.0F, 17.0F);
      if (hovered || selected) {
         RenderUtil.drawRoundedRect(x + 3.0F, y + 2.0F, 112.0F, 13.0F, 4.0F, selected ? this.applyOpacity(ThemeManager.getCurrentColor(), 0.55F * opacity) : this.applyOpacity(new Color(38, 38, 42, 210), opacity));
      }

      RenderUtil.drawText(context, x + 8.0F, y + 5.19999981F, label, 7.0F, this.applyOpacity(selected ? new Color(255, 255, 255) : new Color(210, 210, 215), opacity));
   }

   private void renderCenter(class_332 context, class_1309 target, float x, float y, float opacity, float size, float radius, float hurtProgress) {
      Color headTint;
      if (hurtProgress > 0.0F) {
         headTint = this.applyOpacity(new Color(255, (int)(255.0F * (1.0F - hurtProgress)), (int)(255.0F * (1.0F - hurtProgress))), opacity);
      } else {
         headTint = this.applyOpacity(new Color(255, 255, 255), opacity);
      }

      if (target instanceof class_1657 player) {
         class_8685 var15;
         if (player instanceof class_742 clientPlayer) {
            var15 = clientPlayer.method_52814();
         } else {
            var15 = class_1068.method_4648(player.method_5667());
         }

         class_8685 skin = var15;
         class_2960 texture = skin.comp_1626().comp_3627();
         this.renderModuleElement(texture, x, y, size, radius, 0.125F, 0.125F, 0.125F, 0.125F, headTint);
         this.renderModuleElement(texture, x, y, size, radius, 0.625F, 0.125F, 0.125F, 0.125F, headTint);
      } else {
         RenderUtil.drawRoundedRect(x, y, size, size, radius, this.applyOpacity(new Color(34, 34, 38), opacity));
         String letter = target.method_5477().getString().isEmpty() ? "?" : target.method_5477().getString().substring(0, 1).toUpperCase(Locale.ROOT);
         RenderUtil.drawAlignedText(context, x + size / 2.0F, y + size * 0.31F, letter, size * 0.35F, this.applyOpacity(new Color(250, 250, 252), opacity), "center");
      }
   }

   private void renderModuleElement(class_2960 texture, float x, float y, float size, float radius, float u, float v, float uvWidth, float uvHeight, Color tint) {
      GpuTextureView view = this.mc.method_1531().method_4619(texture).method_71659();
      TexturePipeline.drawSquareTextureRegionFiltered(RenderUtil.createGuiProjection(), x, y, size, view, tint.getRGB(), radius, 0.0F, u, v, uvWidth, uvHeight, false);
   }

   private void renderHudElement(class_332 context, class_1309 target, float x, float y, float opacity) {
      class_1304[] slots = new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};
      float step = 13.0F;

      for(int i = 0; i < slots.length; ++i) {
         float iconX = x + (float)i * step;
         class_1799 stack = target.method_6118(slots[i]);
         context.method_51448().pushMatrix();
         context.method_51448().translate(iconX, y);
         context.method_51448().scale(0.58F, 0.58F);
         context.method_51427(stack, 0, 0);
         context.method_51431(this.mc.field_1772, stack, 0, 0);
         context.method_51448().popMatrix();
      }

   }

   private List<class_1293> collectItems() {
      List<class_1293> result = new ArrayList<class_1293>();
      if (this.mc.field_1724 == null) {
         return result;
      } else {
         result.addAll(this.mc.field_1724.method_6026());
         result.sort(Comparator.comparingInt((class_1293 effect) -> this.calculateAnimationFactor(effect)).thenComparing(effect -> this.resolveTextPrimary(effect)));
         return result;
      }
   }

   private List<class_1293> collectItemsPrimary() {
      List<class_1293> result = this.collectItems();
      if (this.mc.field_1724 != null) {
         for(class_1293 effect : this.mc.field_1724.method_6026()) {
            this.getPotionsIterator().putIfAbsent(this.resolveText(effect), 0.0F);
         }
      }

      result.sort(Comparator.comparingInt((class_1293 effect) -> this.calculateAnimationFactor(effect)).thenComparing(effect -> this.resolveTextPrimary(effect)));
      return result;
   }

   private int calculateAnimationFactor(class_1293 effect) {
      return ((class_1291)effect.method_5579().comp_349()).method_18792() == class_4081.field_18272 ? 1 : 0;
   }

   private boolean matchesEffects(List<class_1293> effects, String id) {
      for(class_1293 effect : effects) {
         if (this.resolveText(effect).equals(id)) {
            return true;
         }
      }

      return false;
   }

   private String resolveText(class_1293 effect) {
      return ((class_1291)effect.method_5579().comp_349()).method_5567();
   }

   private String resolveTextPrimary(class_1293 effect) {
      String name = ((class_1291)effect.method_5579().comp_349()).method_5560().getString();
      int amplifier = effect.method_5578();
      if (amplifier > 0) {
         name = name + this.resolveText(amplifier + 1);
      }

      return name;
   }

   private String resolveTextSecondary(class_1293 effect) {
      if (effect.method_48559()) {
         return "∞";
      } else {
         int totalSeconds = Math.max(0, effect.method_5584() / 20);
         int minutes = totalSeconds / 60;
         int seconds = totalSeconds % 60;
         return minutes + (seconds < 10 ? "0" : "") + seconds;
      }
   }

   private String resolveText(int value) {
      String var2;
      switch (value) {
         case 2 -> var2 = "II";
         case 3 -> var2 = "III";
         case 4 -> var2 = "IV";
         case 5 -> var2 = "V";
         default -> var2 = String.valueOf(value);
      }

      return var2;
   }

   private List<Function> collectItemsSecondary() {
      List<Function> result = new ArrayList<Function>();

      for(Function function : FunctionManager.getFunctions()) {
         if (function != this && function.isEnabled() && function.getKeybind() > 0) {
            result.add(function);
         }
      }

      result.sort(Comparator.comparing(Function::getName));
      return result;
   }

   private List<Function> collectItemsCurrent() {
      List<Function> result = new ArrayList<Function>();

      for(Function function : FunctionManager.getFunctions()) {
         if (function != this && function.getKeybind() > 0 && (function.isEnabled() || (Float)this.getIterator().getOrDefault(function, 0.0F) > 0.02F)) {
            result.add(function);
         }
      }

      result.sort(Comparator.comparing(Function::getName));
      return result;
   }

   public static boolean isFeatureActive() {
      return Instance != null && Instance.isEnabled() && Instance.getHotbarSetting().isEnabled();
   }

   public static boolean isFeatureActivePrimary() {
      return Instance != null && Instance.isEnabled();
   }

   private void renderHudElement(class_332 context) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         float screenWidth = (float)RenderUtil.getScaledWidth();
         float screenHeight = (float)RenderUtil.getScaledHeight();
         float totalWidth = 190.0F;
         float x = (screenWidth - totalWidth) / 2.0F;
         float y = screenHeight - 29.0F;
         int selectedSlot = this.mc.field_1724.method_31548().method_67532();
         this.updateTimedState(x + 4.0F, selectedSlot);
         float height = 26.0F;
         this.renderModuleElement(HUD.HudElement.HOTBAR, x, y, (float)totalWidth, (float)height, 6.0F, 1.0F);
         float var9 = y + 4.0F;
         float slotX = x + 4.0F;
         float slotY = y + 4.0F;

         for(int i = 0; i < 9; ++i) {
            float progress = this.easeOutCubic(this.getPrimaryPitchOffset()[i]);
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7960()) {
               this.renderCenter(context, slotX, slotY, i, progress);
            } else {
               float scale = this.calculateScale(0.92F, 1.3F, progress);
               float centerX = slotX + 9.0F;
               float centerY = slotY + 9.0F - progress * 1.3F;
               context.method_51448().pushMatrix();
               context.method_51448().translate(centerX, centerY);
               context.method_51448().scale(scale, scale);
               context.method_51427(stack, -8, -8);
               context.method_51431(this.mc.field_1772, stack, -8, -8);
               context.method_51448().popMatrix();
            }

            slotX += 20.5F;
         }

         boolean survivalHud = this.shouldProcess();
         float itemNameY = y - 16.0F;
         if (survivalHud) {
            float experienceY = y - 7.0F - 2.0F;
            this.renderHudElement(context, x, experienceY, (float)totalWidth);
            float barsY = experienceY - 9.0F - 4.0F;
            this.renderK(context, x, barsY);
            this.renderL(context, x + totalWidth, barsY);
            float armorY = barsY - 9.0F - 2.0F;
            this.renderM(context, x, armorY);
            itemNameY = armorY - 16.0F;
         }

         this.renderCenter(context, x + totalWidth / 2.0F, itemNameY);
      }
   }

   private boolean shouldProcess() {
      return this.mc.field_1761 == null || this.mc.field_1761.method_2920() != class_1934.field_9220;
   }

   private void updateTimedState(float firstSlotX, int selectedSlot) {
      long now = System.currentTimeMillis();
      if (this.getNowPrimary() == 0L) {
         this.setNowPrimary(now);
      }

      float delta = Math.min(50.0F, (float)(now - this.getNowPrimary()));
      this.setNowPrimary(now);
      this.refreshTarget(delta);
      float targetSelectorX = firstSlotX + (float)selectedSlot * 20.5F;
      if (!this.isInputCaptured()) {
         this.setTargetSelectorX(targetSelectorX);

         for(int i = 0; i < this.getPrimaryPitchOffset().length; ++i) {
            this.getPrimaryPitchOffset()[i] = i == selectedSlot ? 1.0F : 0.0F;
         }

         this.setInputCaptured(true);
      } else {
         this.setTargetSelectorX(this.animateTowards(this.getTargetSelectorX(), targetSelectorX, 0.024F, delta));

         for(int i = 0; i < this.getPrimaryPitchOffset().length; ++i) {
            this.getPrimaryPitchOffset()[i] = this.animateTowards(this.getPrimaryPitchOffset()[i], i == selectedSlot ? 1.0F : 0.0F, 0.018F, delta);
         }

      }
   }

   private void refreshTarget(float delta) {
      if (this.mc.field_1724 != null) {
         float health = this.mc.field_1724.method_6032();
         float maxHealth = this.mc.field_1724.method_6063();
         float absorption = this.mc.field_1724.method_6067();
         float food = (float)this.mc.field_1724.method_7344().method_7586();
         float armor = (float)this.mc.field_1724.method_6096();
         float experienceProgress = this.clamp(this.mc.field_1724.field_7510, 0.0F, 1.0F);
         float experienceLevel = (float)this.mc.field_1724.field_7520;
         if (!this.isHealth()) {
            this.setHealth(health);
            this.setMaxHealth(maxHealth);
            this.setAbsorption(absorption);
            this.setFood(food);
            this.setArmor(armor);
            this.setExperienceProgress(experienceProgress);
            this.setExperienceLevel(experienceLevel);
            this.setHealth(true);
         } else {
            this.setHealth(this.animateTowards(this.getHealth(), health, 0.014F, delta));
            this.setMaxHealth(this.animateTowards(this.getMaxHealth(), maxHealth, 0.014F, delta));
            this.setAbsorption(this.animateTowards(this.getAbsorption(), absorption, 0.014F, delta));
            this.setFood(this.animateTowards(this.getFood(), food, 0.014F, delta));
            this.setArmor(this.animateTowards(this.getArmor(), armor, 0.014F, delta));
            this.setExperienceProgress(this.animateTowards(this.getExperienceProgress(), experienceProgress, 0.014F, delta));
            this.setExperienceLevel(this.animateTowards(this.getExperienceLevel(), experienceLevel, 0.014F, delta));
         }
      }
   }

   private void renderCenter(class_332 context, float slotX, float slotY, int slot, float selectedProgress) {
      float selected = this.clamp(selectedProgress, 0.0F, 1.0F);
      float eased = this.smoothstep(selected);
      float scale = this.calculateScale(1.0F, 1.8F, eased);
      float size = 7.19999981F * scale;
      String text = String.valueOf(slot + 1);
      RenderUtil.drawAlignedText(context, slotX + 9.0F, slotY + (18.0F - Msdf.getTextHeight(size)) / 2.0F - 0.4F, text, size, new Color(225, 225, 230), "center");
   }

   private void renderK(class_332 context, float x, float y) {
      if (this.mc.field_1724 != null) {
         float health = this.isHealth() ? this.getHealth() : this.mc.field_1724.method_6032();
         float absorption = this.isHealth() ? this.getAbsorption() : this.mc.field_1724.method_6067();
         this.renderHudElement(context, x, y, health, "K", new Color(38, 34, 36, 210), new Color(244, 111, 118));
         if (absorption > 0.05F) {
            this.renderHudElement(context, x, y, absorption, "K", new Color(0, 0, 0, 0), new Color(245, 204, 96));
         }

      }
   }

   private void renderHudElement(class_332 context, float x, float y, float barWidth) {
      if (this.mc.field_1724 != null) {
         float experienceFill = this.isHealth() ? this.getExperienceProgress() : this.clamp(this.mc.field_1724.field_7510, 0.0F, 1.0F);
         RenderUtil.drawRoundedRect(x, y, barWidth, 7.0F, 3.0F, new Color(33, 39, 31, 210));
         if (experienceFill > 0.0F) {
            RenderUtil.drawRoundedRect(x, y, barWidth * experienceFill, 7.0F, 3.0F, new Color(153, 199, 116));
         }

         String text = this.mc.field_1724.field_7520 > 0 ? String.valueOf(Math.round(this.isHealth() ? this.getExperienceLevel() : (float)this.mc.field_1724.field_7520)) : String.valueOf(Math.round(experienceFill * 100.0F)) + "%";
         this.renderCenter(context, "hotbar.experience", x, y, barWidth, text);
      }
   }

   private void renderL(class_332 context, float x, float y) {
      if (this.mc.field_1724 != null) {
         float food = this.isHealth() ? this.getFood() : (float)this.mc.field_1724.method_7344().method_7586();
         float iconSize = 8.39999962F;
         float spacing = 8.0F;
         float startX = x - 10.0F * spacing;
         this.renderHudElement(context, startX, y, food, "L", new Color(39, 35, 31, 210), new Color(191, 143, 103));
      }
   }

   private void renderCenter(class_332 context, float x, float y, float width, String text) {
      RenderUtil.drawAlignedText(context, x + width / 2.0F, y + (9.0F - Msdf.getTextHeight(6.19999981F)) / 2.0F - 0.3F, text, 6.19999981F, new Color(255, 255, 255), "center");
   }

   private void renderHudElement(class_332 context, float x, float y, String icon) {
      RenderUtil.drawText(context, Msdf.WTMICO, x + 4.0F, y + (9.0F - Msdf.getTextHeight(Msdf.WTMICO, 6.4000001F)) / 2.0F - 0.15F, icon, 6.4000001F, new Color(255, 255, 255));
   }

   private void renderM(class_332 context, float x, float y) {
      if (this.mc.field_1724 != null) {
         float armor = this.isHealth() ? this.getArmor() : (float)this.mc.field_1724.method_6096();
         if (!(armor <= 0.05F) || this.mc.field_1724.method_6096() > 0) {
            this.renderHudElement(context, x, y, armor, "M", new Color(35, 36, 38, 210), new Color(184, 188, 193));
         }
      }
   }

   private void renderHudElement(class_332 context, float x, float y, float value, String icon, Color emptyColor, Color fullColor) {
      int maxIcons = 10;
      float spacing = 8.0F;
      float iconSize = 8.39999962F;
      float drawY = y + (9.0F - Msdf.getTextHeight(Msdf.WTMICO, (float)iconSize)) / 2.0F - 0.15F;
      float iconWidth = Msdf.getTextWidth(Msdf.WTMICO, icon, (float)iconSize);

      for(int i = 0; i < maxIcons; ++i) {
         float iconX = x + (float)i * spacing;
         if (emptyColor.getAlpha() > 0) {
            RenderUtil.drawText(context, Msdf.WTMICO, iconX, drawY, icon, (float)iconSize, emptyColor);
         }

         float targetValue = (float)i * 2.0F + 2.0F;
         if (value >= targetValue) {
            RenderUtil.drawText(context, Msdf.WTMICO, iconX, drawY, icon, (float)iconSize, fullColor);
         } else if (value > targetValue - 2.0F) {
            float fraction = (value - (targetValue - 2.0F)) / 2.0F;
            Scissor.push((double)(iconX - 1.0F), (double)(drawY - 2.0F), (double)(iconWidth * fraction + 1.0F), (double)(iconSize + 4.0F));
            RenderUtil.drawText(context, Msdf.WTMICO, iconX, drawY, icon, (float)iconSize, fullColor);
            Scissor.popTertiary();
         }
      }

   }

   private void renderCenter(class_332 context, float centerX, float y) {
      if (this.mc.field_1724 != null) {
         class_1799 stack = this.mc.field_1724.method_31548().method_7391();
         String key = stack.method_7960() ? "" : String.valueOf((Object)stack.method_7909()) + stack.method_7964().getString();
         if (!key.equals(this.getKey())) {
            this.setKey(key);
            this.setDisplayName(stack.method_7960() ? "" : stack.method_7964().getString());
            this.setLastActionTimeForTarget(this.getDisplayName().isEmpty() ? 0L : System.currentTimeMillis());
         }

         if (!this.getDisplayName().isEmpty() && this.getLastActionTimeForTarget() != 0L) {
            long elapsed = System.currentTimeMillis() - this.getLastActionTimeForTarget();
            if (elapsed <= 1200L) {
               float enter = this.clamp((float)elapsed / 280.0F, 0.0F, 1.0F);
               float exit = elapsed <= 940L ? 1.0F : 1.0F - this.clamp((float)(elapsed - 940L) / 260.0F, 0.0F, 1.0F);
               float scale = this.easeOutBack(enter);
               float opacity = this.easeOutCubic(exit);
               float textSize = 7.5999999F * scale;
               float width = Msdf.getTextWidth(this.getDisplayName(), textSize) + 16.0F * scale;
               float height = 14.0F * scale;
               float drawX = centerX - width / 2.0F;
               float drawY = Math.max(2.0F, y - 2.0F * (1.0F - enter));
               if (this.resolveHudStyle() != HUD.HudStyle.DEFAULT) {
                  this.renderModuleElementPrimary(HUD.HudElement.HOTBAR, drawX, drawY, width, height, 5.0F * scale, opacity);
               } else {
                  RenderUtil.drawRoundedRect(drawX, drawY, width, height, 5.0F * scale, this.applyOpacity(new Color(25, 25, 27, 225), opacity));
               }

               RenderUtil.drawAlignedText(context, centerX, drawY + (height - Msdf.getTextHeight(textSize)) / 2.0F - 0.6F, this.getDisplayName(), textSize, this.applyOpacity(new Color(255, 255, 255), opacity), "center");
            }
         }
      }
   }

   private void renderCenter(class_332 context, String key, float x, float y, float width, String text) {
      this.renderHudElement(context, key, text, x + width / 2.0F, y + (9.0F - Msdf.getTextHeight(6.19999981F)) / 2.0F - 0.3F, 6.19999981F, new Color(255, 255, 255), "center");
   }

   private void renderHudElement(class_332 context, String key, String value, float x, float y, float size, Color color, String align) {
      if (value != null && !value.isEmpty()) {
         NumericTextAnimationState state = (NumericTextAnimationState)this.getTrackedEntries().computeIfAbsent(key, (ignored) -> {
            return new NumericTextAnimationState();
         });
         String rendered = this.resolveText(state, value);
         RenderUtil.drawAlignedText(context, x, y, rendered, size, color, align);
      }
   }

   private String resolveText(NumericTextAnimationState state, String value) {
      ParsedNumericText parsed = this.parseAnimatedNumber(value);
      long now = System.currentTimeMillis();
      if (parsed == null) {
         state.watermarkBooleanSetting = false;
         state.targethudZhidkoeStekloBooleanSetting = now;
         return value;
      } else if (state.watermarkBooleanSetting && parsed.matchesState(state)) {
         state.keybindsLyodBooleanSetting = parsed.watermarkLyodBooleanSetting;
         state.potionsLyodBooleanSetting = parsed.watermarkZhidkoeStekloBooleanSetting;
         float delta = state.targethudZhidkoeStekloBooleanSetting == 0L ? 0.0F : Math.min(50.0F, (float)(now - state.targethudZhidkoeStekloBooleanSetting));
         state.targethudZhidkoeStekloBooleanSetting = now;
         state.watermarkZhidkoeStekloBooleanSetting = this.calculateAnimationFactor(state.watermarkZhidkoeStekloBooleanSetting, state.keybindsLyodBooleanSetting, 0.018F, delta);
         state.keybindsZhidkoeStekloBooleanSetting = this.calculateAnimationFactor(state.keybindsZhidkoeStekloBooleanSetting, state.potionsLyodBooleanSetting, 0.018F, delta);
         if (state.stilHudListSetting) {
            String var8 = state.watermarkStyleListSetting;
            return var8 + this.formatText(state.watermarkZhidkoeStekloBooleanSetting, state.potionsZhidkoeStekloBooleanSetting) + this.formatText(state.keybindsZhidkoeStekloBooleanSetting, state.targethudLyodBooleanSetting) + state.watermarkLyodBooleanSetting;
         } else {
            String var7 = state.watermarkStyleListSetting;
            return var7 + this.formatText(state.watermarkZhidkoeStekloBooleanSetting, state.potionsZhidkoeStekloBooleanSetting) + state.watermarkLyodBooleanSetting;
         }
      } else {
         state.watermarkBooleanSetting = true;
         state.targethudZhidkoeStekloBooleanSetting = now;
         state.watermarkStyleListSetting = parsed.watermarkBooleanSetting;
         state.watermarkLyodBooleanSetting = parsed.stilHudListSetting;
         state.stilHudListSetting = parsed.watermarkStyleListSetting;
         state.potionsZhidkoeStekloBooleanSetting = parsed.keybindsLyodBooleanSetting;
         state.targethudLyodBooleanSetting = parsed.keybindsZhidkoeStekloBooleanSetting;
         state.watermarkZhidkoeStekloBooleanSetting = parsed.watermarkLyodBooleanSetting;
         state.keybindsLyodBooleanSetting = parsed.watermarkLyodBooleanSetting;
         state.keybindsZhidkoeStekloBooleanSetting = parsed.watermarkZhidkoeStekloBooleanSetting;
         state.potionsLyodBooleanSetting = parsed.watermarkZhidkoeStekloBooleanSetting;
         return value;
      }
   }

   private void updateRotation(String id, float x, float y, float width, float height, float radius) {
      this.renderModuleElement(id, x, y, width, height, radius, 1.0F);
   }

   private void renderModuleElement(String id, float x, float y, float width, float height, float radius, float opacity) {
      if (!(width <= 0.5F) && !(height <= 0.5F) && !(opacity <= 0.01F)) {
         RenderUtil.drawHudBlur(x, y, width, height, radius, (float)this.getBlurStrengthSetting().getValue(), opacity, new Color(18, 18, 22, 120));
         this.updateTimedState(id, x, y, width, height, radius, opacity);
      }
   }

   public void renderModuleElement(HudElement element, float x, float y, float width, float height, float radius, float opacity) {
      if (this.resolveHudStyle() != HUD.HudStyle.DEFAULT) {
         this.renderModuleElementPrimary(element, x, y, width, height, radius, opacity);
         this.updateTimedState(element != null ? element.name() : "NONE", x, y, width, height, radius, opacity);
      } else if (!(width <= 0.5F) && !(height <= 0.5F) && !(opacity <= 0.01F)) {
         RenderUtil.drawHudBlur(x, y, width, height, radius, (float)this.getBlurStrengthSetting().getValue(), opacity, new Color(18, 18, 22, 120));
         this.updateTimedState(element != null ? element.name() : "NONE", x, y, width, height, radius, opacity);
      }
   }

   private void renderModuleElement(HudElement element, float x, float y, float width, float height, float tl, float tr, float br, float bl, float opacity) {
      if (this.resolveHudStyle() != HUD.HudStyle.DEFAULT) {
         RenderUtil.drawRoundedRect(x, y, width, height, tl, tr, br, bl, this.applyOpacity(new Color(255, 255, 255, 28), opacity), this.applyOpacity(new Color(255, 255, 255, 10), opacity));
      } else {
         RenderUtil.drawHudBlur(x, y, width, height, tl, tr, br, bl, (float)this.getBlurStrengthSetting().getValue(), opacity, new Color(18, 18, 22, 140));
      }
   }

   private void renderModuleElementPrimary(HudElement element, float x, float y, float width, float height, float radius, float opacity) {
      if (!(width <= 0.5F) && !(height <= 0.5F) && !(opacity <= 0.01F)) {
         RenderUtil.drawShadow(x + 0.5F, y + 1.2F, width - 1.0F, height - 0.4F, radius, 10.0F, 0.28F * opacity, 2.4000001F, new Color(0, 0, 0, 170));
         this.renderModuleElement(x, y, width, height, radius, 0.88F * opacity);
         RenderUtil.drawRoundedOutline(x + 0.45F, y + 0.45F, width - 0.9F, height - 0.9F, radius, 0.85F, this.applyOpacity(new Color(255, 255, 255, 82), opacity), this.applyOpacity(new Color(255, 255, 255, 44), opacity), this.applyOpacity(ThemeManager.getCurrentColor(), 0.22F * opacity), this.applyOpacity(new Color(255, 255, 255, 24), opacity));
      }
   }

   private void renderModuleElement(float x, float y, float width, float height, float radius, float alpha) {
      Color tint = this.resolveColor(ThemeManager.getCurrentColor(), (int)(72.0F * Math.clamp(alpha, 0.0F, 1.0F)));
      if (this.resolveHudStyle() == HUD.HudStyle.LIQUID) {
         RenderUtil.drawFluidGlass(x, y, width, height, radius, 1.0F, alpha, tint);
      } else {
         RenderUtil.drawLiquidGlass(x, y, width, height, radius, 1.0F, alpha, tint);
      }

   }

   private HudStyle resolveHudStyle() {
      if (this.getHudStyleSetting().isSelected("Жидкое стекло")) {
         return HUD.HudStyle.LIQUID;
      } else {
         return this.getHudStyleSetting().isSelected("Лёд") ? HUD.HudStyle.ICE : this.inferHudStyle();
      }
   }

   private HudStyle inferHudStyle() {
      if (!this.getWatermarkLiquidGlassSetting().isEnabled() && !this.getKeybindsLiquidGlassSetting().isEnabled() && !this.getPotionsLiquidGlassSetting().isEnabled() && !this.getTargetHudLiquidGlassSetting().isEnabled() && !this.getHotbarLiquidGlassSetting().isEnabled()) {
         return !this.getWatermarkIceSetting().isEnabled() && !this.getWatermarkStyleSetting().isSelected("LiquidGlass Watermark") && !this.getKeybindsIceSetting().isEnabled() && !this.getPotionsIceSetting().isEnabled() && !this.getTargetHudIceSetting().isEnabled() && !this.getHotbarIceSetting().isEnabled() ? HUD.HudStyle.DEFAULT : HUD.HudStyle.ICE;
      } else {
         return HUD.HudStyle.LIQUID;
      }
   }

   private void advanceActionPhase(HudStyle style) {
      this.getHudStyleSetting().setValue(this.resolveText(style));
      this.getWatermarkIceSetting().setEnabled(false);
      this.getWatermarkLiquidGlassSetting().setEnabled(false);
      this.getKeybindsIceSetting().setEnabled(false);
      this.getKeybindsLiquidGlassSetting().setEnabled(false);
      this.getPotionsIceSetting().setEnabled(false);
      this.getPotionsLiquidGlassSetting().setEnabled(false);
      this.getTargetHudIceSetting().setEnabled(false);
      this.getTargetHudLiquidGlassSetting().setEnabled(false);
      this.getHotbarIceSetting().setEnabled(false);
      this.getHotbarLiquidGlassSetting().setEnabled(false);
      this.getWatermarkStyleSetting().setValue("Default");
   }

   private String resolveText(HudStyle style) {
      String var2;
      switch (style.ordinal()) {
         case 0 -> var2 = "Default";
         case 1 -> var2 = "Лёд";
         case 2 -> var2 = "Жидкое стекло";
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var2;
   }

   private void updateTimedState(String id, float x, float y, float width, float height, float radius, float opacity) {
      if (this.getShaderSetting().isEnabled() && !(opacity < 0.01F)) {
         long time = System.currentTimeMillis();
         float cycleDuration = 2500.0F;
         int hash = id.hashCode();
         float var12 = (float)Math.abs(hash % 1000) / 1000.0F;
         float phase = (float)((time + (long)(var12 * cycleDuration)) % (long)cycleDuration) / cycleDuration;
         int var14 = Math.abs(hash) % 4;
         float var15 = 45.0F + (float)var14 * 90.0F;
         float angle = (float)Math.toRadians((double)var15);
         SweepPipeline.drawSweep(RenderUtil.createGuiProjection(), x, y, width, height, radius, radius, radius, radius, 0.0F, phase, angle, opacity);
      }
   }

   private void updateTimedState(boolean keybindsVisible, boolean targetHudVisible, boolean potionsVisible, List<Function> activeBinds, List<class_1293> activePotions) {
      long now = System.currentTimeMillis();
      if (this.getNow() == 0L) {
         this.setNow(now);
      } else {
         float delta = Math.min(50.0F, (float)(now - this.getNow()));
         this.setNow(now);
         this.setMovementSpeed(this.animateTowards(this.getMovementSpeed(), keybindsVisible ? 1.0F : 0.0F, 0.0075F, delta));
         this.setTargetHudAnimationProgress(this.animateTowards(this.getTargetHudAnimationProgress(), targetHudVisible ? 1.0F : 0.0F, 0.012F, delta));
         this.setTargetValue(this.animateTowards(this.getTargetValue(), potionsVisible ? 1.0F : 0.0F, 0.0075F, delta));
         this.setAlternateCurrentScale(this.animateTowards(this.getAlternateCurrentScale(), this.isActionPending() && this.shouldProcessSecondary() ? 1.0F : 0.0F, 0.018F, delta));
         if (this.getTargetHudAnimationProgress() <= 0.001F && !targetHudVisible) {
            this.setTarget((class_1309)null);
         }

         for(Function function : activeBinds) {
            this.getIterator().putIfAbsent(function, 0.0F);
         }

         Iterator<Map.Entry<Function, Float>> iterator = this.getIterator().entrySet().iterator();

         while(iterator.hasNext()) {
            Map.Entry<Function, Float> entry = iterator.next();
            Function function = entry.getKey();
            boolean rowVisible = keybindsVisible && function.isEnabled() && function.getKeybind() > 0;
            float next = this.animateTowards((Float)entry.getValue(), rowVisible ? 1.0F : 0.0F, 0.018F, delta);
            if (!rowVisible && next <= 0.001F) {
               iterator.remove();
            } else {
               entry.setValue(next);
            }
         }

         for(Function function : activeBinds) {
            this.getSliderIterator().putIfAbsent(function, function.isEnabled() ? 1.0F : 0.0F);
         }

         Iterator<Map.Entry<Function, Float>> sliderIterator = this.getSliderIterator().entrySet().iterator();

         while(sliderIterator.hasNext()) {
            Map.Entry<Function, Float> entry = sliderIterator.next();
            Function function = entry.getKey();
            float target = function.isEnabled() ? 1.0F : 0.0F;
            float next = this.animateTowards((Float)entry.getValue(), target, 0.018F, delta);
            if (!function.isEnabled() && next <= 0.001F) {
               sliderIterator.remove();
            } else {
               entry.setValue(next);
            }
         }

         for(class_1293 effect : activePotions) {
            this.getPotionsIterator().putIfAbsent(this.resolveText(effect), 0.0F);
         }

         Iterator<Map.Entry<String, Float>> potionsIterator = this.getPotionsIterator().entrySet().iterator();

         while(potionsIterator.hasNext()) {
            Map.Entry<String, Float> entry = potionsIterator.next();
            boolean rowVisible = potionsVisible && this.matchesEffects(activePotions, entry.getKey());
            float next = this.animateTowards((Float)entry.getValue(), rowVisible ? 1.0F : 0.0F, 0.018F, delta);
            if (!rowVisible && next <= 0.001F) {
               potionsIterator.remove();
            } else {
               entry.setValue(next);
            }
         }

         List<Function> renderableBinds = this.collectItemsCurrent();
         float targetWidth = !keybindsVisible && renderableBinds.isEmpty() ? this.getYawOffset() : this.calculateHotkeys(renderableBinds);
         float targetHeight = this.calculateRotationStep(keybindsVisible, renderableBinds);
         this.setYawOffset(this.animateTowards(this.getYawOffset(), targetWidth, 0.018F, delta));
         this.setPitchOffset(this.animateTowards(this.getPitchOffset(), targetHeight, 0.018F, delta));
         List<class_1293> renderablePotions = this.collectItemsPrimary();
         float targetPotionsWidth = !potionsVisible && renderablePotions.isEmpty() ? this.getRotation() : this.calculatePotions(renderablePotions);
         float targetPotionsHeight = this.calculateMovementSpeed(potionsVisible, renderablePotions);
         this.setRotation(this.animateTowards(this.getRotation(), targetPotionsWidth, 0.018F, delta));
         this.setVelocity(this.animateTowards(this.getVelocity(), targetPotionsHeight, 0.018F, delta));
      }
   }

   private float calculateHotkeys(List<Function> binds) {
      float p = 7.0F;
      float fontSize = 8.0F;
      float iconPadding = 7.0F;
      float gap = 2.0F;
      float leftPanelWidth = 30.0F;
      float titleWidth = Msdf.getTextWidth(MsdfManager.SF_REGULAR, "Hotkeys", (float)fontSize);
      float iconWidth = Msdf.getTextWidth(MsdfManager.WOQUED_ICONS, "t", (float)fontSize);
      float width = Math.max(72.0F, titleWidth + iconPadding + iconWidth + p * 2.0F);

      for(Function function : binds) {
         float rowW = leftPanelWidth + gap + Msdf.getTextWidth(MsdfManager.SF_REGULAR, function.getName(), (float)fontSize) + 10.0F;
         width = Math.max(width, rowW);
      }

      return width;
   }

   private float calculatePotions(List<class_1293> effects) {
      float p = 7.0F;
      float fontSize = 8.0F;
      float gap = 2.0F;
      float iconPanelWidth = 16.0F;
      float titleWidth = Msdf.getTextWidth(MsdfManager.SF_REGULAR, "Potions", (float)fontSize);
      float iconWidth = Msdf.getTextWidth(MsdfManager.WOQUED_ICONS, "u", (float)fontSize);
      float width = Math.max(72.0F, titleWidth + 12.0F + iconWidth + p * 2.0F);

      for(class_1293 effect : effects) {
         float rowW = iconPanelWidth + gap + Math.max(Msdf.getTextWidth(MsdfManager.SF_REGULAR, this.resolveTextPrimary(effect), (float)fontSize) + Msdf.getTextWidth(MsdfManager.SF_REGULAR, this.resolveTextSecondary(effect), (float)fontSize) + 16.0F, 40.0F);
         width = Math.max(width, rowW);
      }

      return width;
   }

   private float calculateAnimationFactor() {
      float height = 0.0F;

      for(float progress : this.getPotionsIterator().values()) {
         height += 18.0F * this.easeOutCubic(progress);
      }

      return height;
   }

   private float calculateMovementSpeed(boolean potionsVisible, List<class_1293> renderablePotions) {
      if (!potionsVisible && renderablePotions.isEmpty()) {
         return 0.0F;
      } else {
         float headerHeight = 16.0F * this.easeOutCubic(this.getTargetValue());
         float rowsProgress = this.clamp((this.getTargetValue() - 0.45F) / 0.55F, 0.0F, 1.0F);
         return headerHeight + this.calculateAnimationFactor() * this.easeOutCubic(rowsProgress);
      }
   }

   private float calculateTargetDistance() {
      float height = 0.0F;

      for(float progress : this.getIterator().values()) {
         height += 18.0F * this.easeOutCubic(progress);
      }

      return height;
   }

   private float calculateRotationStep(boolean keybindsVisible, List<Function> renderableBinds) {
      if (!keybindsVisible && renderableBinds.isEmpty()) {
         return 0.0F;
      } else {
         float headerHeight = 16.0F * this.easeOutCubic(this.getMovementSpeed());
         float rowsProgress = this.clamp((this.getMovementSpeed() - 0.45F) / 0.55F, 0.0F, 1.0F);
         return headerHeight + this.calculateTargetDistance() * this.easeOutCubic(rowsProgress);
      }
   }

   private void renderModuleElement() {
      if (this.shouldProcessSecondary() && this.mc.method_22683() != null) {
         long handle = this.mc.method_22683().method_4490();
         boolean mouseDown = GLFW.glfwGetMouseButton(handle, 0) == 1;
         boolean rightMouseDown = GLFW.glfwGetMouseButton(handle, 1) == 1;
         double[] rawX = new double[1];
         double[] rawY = new double[1];
         GLFW.glfwGetCursorPos(handle, rawX, rawY);
         float mouseX = (float)(rawX[0] * (double)RenderUtil.getScaledWidth() / (double)this.mc.method_22683().method_4480());
         float mouseY = (float)(rawY[0] * (double)RenderUtil.getScaledHeight() / (double)this.mc.method_22683().method_4507());
         this.setMouseX(mouseX);
         this.setMouseY(mouseY);
         if (rightMouseDown && !this.isRightMouseDown()) {
            this.renderModuleElement(mouseX, mouseY);
         }

         if (mouseDown && !this.isMouseDown()) {
            if (this.isValidMouseX(mouseX, mouseY)) {
               this.setMouseDown(mouseDown);
               this.setRightMouseDown(rightMouseDown);
               return;
            }

            this.prepareInteraction(mouseX, mouseY);
         }

         if (!mouseDown) {
            this.setDraggedElement(HUD.DragTarget.NONE);
         } else if (this.getDraggedElement() != HUD.DragTarget.NONE) {
            this.renderModuleElementPrimary(mouseX, mouseY);
         }

         this.setMouseDown(mouseDown);
         this.setRightMouseDown(rightMouseDown);
      } else {
         this.setDraggedElement(HUD.DragTarget.NONE);
         this.setMouseDown(false);
         this.setRightMouseDown(false);
         this.setActionPending(false);
      }
   }

   private void renderModuleElement(float mouseX, float mouseY) {
      HudElement hoveredElement = this.findHoveredHudElement(mouseX, mouseY);
      if (hoveredElement != null) {
         this.setHoveredElement(hoveredElement);
         this.setActionPending(true);
         this.setStylePopupX(this.clamp(mouseX, 2.0F, (float)RenderUtil.getScaledWidth() - 118.0F - 2.0F));
         this.setOptionsY(this.clamp(mouseY, 2.0F, (float)RenderUtil.getScaledHeight() - this.calculateRenderOffset() - 2.0F));
         this.setDraggedElement(HUD.DragTarget.NONE);
      } else if (!this.isPointInside(mouseX, mouseY, this.getStylePopupX(), this.getOptionsY(), 118.0F, this.calculateRenderOffset())) {
         this.setActionPending(false);
      }

   }

   private boolean isValidMouseX(float mouseX, float mouseY) {
      if (!this.isActionPending()) {
         return false;
      } else if (!this.isPointInside(mouseX, mouseY, this.getStylePopupX(), this.getOptionsY(), 118.0F, this.calculateRenderOffset())) {
         this.setActionPending(false);
         return false;
      } else {
         float optionsY = this.getOptionsY() + 17.0F;
         if (mouseY >= optionsY && mouseY < optionsY + 17.0F) {
            this.advanceActionPhase(HUD.HudStyle.DEFAULT);
            this.setActionPending(false);
         } else if (mouseY >= optionsY + 17.0F && mouseY < optionsY + 34.0F) {
            this.advanceActionPhase(HUD.HudStyle.ICE);
            this.setActionPending(false);
         } else if (mouseY >= optionsY + 34.0F && mouseY < optionsY + 51.0F) {
            this.advanceActionPhase(HUD.HudStyle.LIQUID);
            this.setActionPending(false);
         }

         return true;
      }
   }

   private HudElement findHoveredHudElement(float mouseX, float mouseY) {
      if (this.getWatermarkSetting().isEnabled() && this.isPointInside(mouseX, mouseY, this.getTargetAlpha(), this.getRenderX(), this.getTotalWidth(), 24.0F)) {
         return HUD.HudElement.WATERMARK;
      } else if (this.getScoreboardSetting().isEnabled() && this.isPointInside(mouseX, mouseY, this.getAlternateCurrentAlpha(), this.getScoreboardY(), this.getTransientRenderX(), this.getPrimaryRenderY())) {
         return HUD.HudElement.SCOREBOARD;
      } else if (this.getKeybindsSetting().isEnabled() && this.getMovementSpeed() > 0.2F && this.isPointInside(mouseX, mouseY, this.getRenderY(), this.getCurrentScale(), this.getMaxW(), this.getTargetScale())) {
         return HUD.HudElement.KEYBINDS;
      } else if (this.getPotionsSetting().isEnabled() && this.getTargetValue() > 0.2F && this.isPointInside(mouseX, mouseY, this.getHeight(), this.getRadius(), this.getMaxWPrimary(), this.getOpacity())) {
         return HUD.HudElement.POTIONS;
      } else if (this.getTargetHudSetting().isEnabled() && this.getTargetHudAnimationProgress() > 0.2F && this.isPointInside(mouseX, mouseY, this.getVerticalSpeed(), this.getInterpolation(), this.calculateCooldown(), this.calculateInterpolation())) {
         return HUD.HudElement.TARGET_HUD;
      } else if (this.getNeuroAimSetting().isEnabled() && this.isPointInside(mouseX, mouseY, this.getFadeProgress(), this.getWidth(), 76.0F, 76.0F)) {
         return HUD.HudElement.NEURO_AIM;
      } else {
         return this.getHotbarSetting().isEnabled() && this.isValidMouseXPrimary(mouseX, mouseY) ? HUD.HudElement.HOTBAR : null;
      }
   }

   private boolean isValidMouseXPrimary(float mouseX, float mouseY) {
      float totalWidth = 190.0F;
      float x = ((float)RenderUtil.getScaledWidth() - totalWidth) / 2.0F;
      float y = (float)RenderUtil.getScaledHeight() - 29.0F;
      float height = 26.0F;
      return this.isPointInside(mouseX, mouseY, x, y, totalWidth, (float)height);
   }

   private float calculateRenderOffset() {
      return 68.0F;
   }

   private void prepareInteraction(float mouseX, float mouseY) {
      if (!this.isActionPending()) {
         if (this.getTargetHudSetting().isEnabled() && this.getTargetHudAnimationProgress() > 0.2F && this.isPointInside(mouseX, mouseY, this.getVerticalSpeed(), this.getInterpolation(), this.calculateCooldown(), this.calculateInterpolation())) {
            this.setDraggedElement(HUD.DragTarget.TARGET_HUD);
            this.setAnimationProgress(mouseX - this.getVerticalSpeed());
            this.setCurrentAlpha(mouseY - this.getInterpolation());
         } else if (this.getNeuroAimSetting().isEnabled() && this.isPointInside(mouseX, mouseY, this.getFadeProgress(), this.getWidth(), 76.0F, 76.0F)) {
            this.setDraggedElement(HUD.DragTarget.NEURO_AIM);
            this.setAnimationProgress(mouseX - this.getFadeProgress());
            this.setCurrentAlpha(mouseY - this.getWidth());
         } else if (this.getKeybindsSetting().isEnabled() && this.getMovementSpeed() > 0.2F && this.isPointInside(mouseX, mouseY, this.getRenderY(), this.getCurrentScale(), this.getMaxW(), this.getTargetScale())) {
            this.setDraggedElement(HUD.DragTarget.KEYBINDS);
            this.setAnimationProgress(mouseX - this.getRenderY());
            this.setCurrentAlpha(mouseY - this.getCurrentScale());
         } else if (this.getPotionsSetting().isEnabled() && this.getTargetValue() > 0.2F && this.isPointInside(mouseX, mouseY, this.getHeight(), this.getRadius(), this.getMaxWPrimary(), this.getOpacity())) {
            this.setDraggedElement(HUD.DragTarget.POTIONS);
            this.setAnimationProgress(mouseX - this.getHeight());
            this.setCurrentAlpha(mouseY - this.getRadius());
         } else if (this.getWatermarkSetting().isEnabled() && this.isPointInside(mouseX, mouseY, this.getTargetAlpha(), this.getRenderX(), this.getTotalWidth(), 24.0F)) {
            this.setDraggedElement(HUD.DragTarget.WATERMARK);
            this.setAnimationProgress(mouseX - this.getTargetAlpha());
            this.setCurrentAlpha(mouseY - this.getRenderX());
         } else {
            if (this.getScoreboardSetting().isEnabled() && this.isPointInside(mouseX, mouseY, this.getAlternateCurrentAlpha(), this.getScoreboardY(), this.getTransientRenderX(), this.getPrimaryRenderY())) {
               this.setDraggedElement(HUD.DragTarget.SCOREBOARD);
               this.setAnimationProgress(mouseX - this.getAlternateCurrentAlpha());
               this.setCurrentAlpha(mouseY - this.getScoreboardY());
            }

         }
      }
   }

   private void renderModuleElementPrimary(float mouseX, float mouseY) {
      if (this.getDraggedElement() == HUD.DragTarget.WATERMARK) {
         this.setTargetAlpha(this.clamp(mouseX - this.getAnimationProgress(), 2.0F, (float)RenderUtil.getScaledWidth() - this.getTotalWidth() - 2.0F));
         this.setRenderX(this.clamp(mouseY - this.getCurrentAlpha(), 2.0F, (float)RenderUtil.getScaledHeight() - 24.0F - 2.0F));
      } else if (this.getDraggedElement() == HUD.DragTarget.SCOREBOARD) {
         this.setAlternateCurrentAlpha(this.clamp(mouseX - this.getAnimationProgress(), 2.0F, (float)RenderUtil.getScaledWidth() - this.getTransientRenderX() - 2.0F));
         this.setScoreboardY(this.clamp(mouseY - this.getCurrentAlpha(), 2.0F, (float)RenderUtil.getScaledHeight() - this.getPrimaryRenderY() - 2.0F));
      } else if (this.getDraggedElement() == HUD.DragTarget.KEYBINDS) {
         this.setRenderY(this.clamp(mouseX - this.getAnimationProgress(), 2.0F, (float)RenderUtil.getScaledWidth() - this.getMaxW() - 2.0F));
         this.setCurrentScale(this.clamp(mouseY - this.getCurrentAlpha(), 2.0F, (float)RenderUtil.getScaledHeight() - this.getTargetScale() - 2.0F));
      } else if (this.getDraggedElement() == HUD.DragTarget.POTIONS) {
         this.setHeight(this.clamp(mouseX - this.getAnimationProgress(), 2.0F, (float)RenderUtil.getScaledWidth() - this.getMaxWPrimary() - 2.0F));
         this.setRadius(this.clamp(mouseY - this.getCurrentAlpha(), 2.0F, (float)RenderUtil.getScaledHeight() - this.getOpacity() - 2.0F));
      } else if (this.getDraggedElement() == HUD.DragTarget.TARGET_HUD) {
         this.setVerticalSpeed(this.clamp(mouseX - this.getAnimationProgress(), 2.0F, (float)RenderUtil.getScaledWidth() - this.calculateCooldown() - 2.0F));
         this.setInterpolation(this.clamp(mouseY - this.getCurrentAlpha(), 2.0F, (float)RenderUtil.getScaledHeight() - this.calculateInterpolation() - 2.0F));
      } else if (this.getDraggedElement() == HUD.DragTarget.NEURO_AIM) {
         this.setFadeProgress(this.clamp(mouseX - this.getAnimationProgress(), 2.0F, (float)RenderUtil.getScaledWidth() - 76.0F - 2.0F));
         this.setWidth(this.clamp(mouseY - this.getCurrentAlpha(), 2.0F, (float)RenderUtil.getScaledHeight() - 76.0F - 2.0F));
      }

   }

   private float calculateCooldown() {
      return 100.0F;
   }

   private float calculateInterpolation() {
      return 34.0F;
   }

   private class_1309 findTarget() {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         AttackAura aura = (AttackAura)FunctionManager.getFunction(AttackAura.class);
         class_1309 target = aura == null ? null : aura.findTarget();
         return target != null && target != this.mc.field_1724 && target.method_5805() ? target : null;
      } else {
         return null;
      }
   }

   private boolean isPointInside(float mouseX, float mouseY, float x, float y, float width, float height) {
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
   }

   private boolean shouldProcessPrimary() {
      return this.mc.field_1755 == null || this.shouldProcessSecondary();
   }

   private boolean shouldProcessSecondary() {
      return this.mc.field_1755 instanceof class_408 || this.mc.field_1755 instanceof ClickGui;
   }

   private float clamp(float value, float min, float max) {
      return Math.max(min, Math.min(max, value));
   }

   private float animateTowards(float current, float target, float speed, float delta) {
      float factor = 1.0F - (float)Math.exp((double)(-speed * delta));
      float next = current + (target - current) * this.clamp(factor, 0.0F, 1.0F);
      return Math.abs(next - target) < 0.001F ? target : next;
   }

   private double calculateAnimationFactor(double current, double target, float speed, float delta) {
      double factor = (double)1.0F - Math.exp((double)(-speed * delta));
      double next = current + (target - current) * Math.max((double)0.0F, Math.min((double)1.0F, factor));
      return Math.abs(next - target) < 0.001 ? target : next;
   }

   private float calculateScale(float from, float to, float progress) {
      return from + (to - from) * this.clamp(progress, 0.0F, 1.0F);
   }

   private float easeOutCubic(float progress) {
      float t = this.clamp(progress, 0.0F, 1.0F) - 1.0F;
      return t * t * t + 1.0F;
   }

   private float easeOutBack(float progress) {
      float t = this.clamp(progress, 0.0F, 1.0F) - 1.0F;
      float c = 1.70158F;
      return 1.0F + (c + 1.0F) * t * t * t + c * t * t;
   }

   private float smoothstep(float progress) {
      float t = this.clamp(progress, 0.0F, 1.0F);
      return t * t * (3.0F - 2.0F * t);
   }

   private float calculateAngle(float y, float height, float size) {
      return y + (height - Msdf.getTextHeight(size)) / 2.0F;
   }

   private Color applyOpacity(Color color, float opacity) {
      int alpha = (int)((float)color.getAlpha() * this.clamp(opacity, 0.0F, 1.0F));
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
   }

   private Color resolveColor(Color color, int alpha) {
      int clamped = Math.max(0, Math.min(255, alpha));
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), clamped);
   }

   private Color resolveColor(Color from, Color to, float progress) {
      float t = this.clamp(progress, 0.0F, 1.0F);
      return new Color(Math.round((float)from.getRed() + (float)(to.getRed() - from.getRed()) * t), Math.round((float)from.getGreen() + (float)(to.getGreen() - from.getGreen()) * t), Math.round((float)from.getBlue() + (float)(to.getBlue() - from.getBlue()) * t), Math.round((float)from.getAlpha() + (float)(to.getAlpha() - from.getAlpha()) * t));
   }

   private Color resolveColor(Color color, float strength) {
      return new Color(Math.clamp((long)((int)((float)color.getRed() + (float)(255 - color.getRed()) * strength)), 0, 255), Math.clamp((long)((int)((float)color.getGreen() + (float)(255 - color.getGreen()) * strength)), 0, 255), Math.clamp((long)((int)((float)color.getBlue() + (float)(255 - color.getBlue()) * strength)), 0, 255), color.getAlpha());
   }

   private String ellipsize(String text, float maxWidth, float size) {
      if (Msdf.getTextWidth(text, size) <= maxWidth) {
         return text;
      } else {
         String suffix = "...";

         String trimmed;
         for(trimmed = text; !trimmed.isEmpty() && Msdf.getTextWidth(trimmed + suffix, size) > maxWidth; trimmed = trimmed.substring(0, trimmed.length() - 1)) {
         }

         return trimmed.isEmpty() ? suffix : trimmed + suffix;
      }
   }

   private ParsedNumericText parseAnimatedNumber(String value) {
      if (value != null && !value.isEmpty()) {
         Matcher plusMatcher = Pattern.compile("^(-?\\d+(?:[\\.,]\\d+)?)\\+(-?\\d+(?:[\\.,]\\d+)?)$").matcher(value);
         if (plusMatcher.matches()) {
            return new ParsedNumericText("", "", true, this.calculateMovementSpeed(plusMatcher.group(1)), this.calculateMovementSpeed(plusMatcher.group(2)), this.calculateMovementSpeedForTarget(plusMatcher.group(1)), this.calculateMovementSpeedForTarget(plusMatcher.group(2)));
         } else {
            Matcher singleMatcher = Pattern.compile("^(.*?)(-?\\d+(?:[\\.,]\\d+)?)(.*?)$").matcher(value);
            if (singleMatcher.matches()) {
               String prefix = singleMatcher.group(1);
               String number = singleMatcher.group(2);
               String suffix = singleMatcher.group(3);
               if (!this.isValidValue(prefix) && !this.isValidValue(suffix)) {
                  return new ParsedNumericText(prefix, suffix, false, this.calculateMovementSpeed(number), (double)0.0F, this.calculateMovementSpeedForTarget(number), 0);
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private double calculateMovementSpeed(String value) {
      return Double.parseDouble(value.replace(',', '.'));
   }

   private int calculateMovementSpeedForTarget(String value) {
      int dot = value.indexOf(46);
      int comma = value.indexOf(44);
      int index = Math.max(dot, comma);
      return index < 0 ? 0 : value.length() - index - 1;
   }

   private boolean isValidValue(String value) {
      for(int i = 0; i < value.length(); ++i) {
         if (Character.isDigit(value.charAt(i))) {
            return true;
         }
      }

      return false;
   }

   private String formatText(double value, int decimals) {
      return decimals > 0 ? String.format(Locale.US, "%." + String.valueOf(decimals) + "f", value) : String.valueOf(Math.round(value));
   }

   public static boolean isFeatureActiveSecondary() {
      return Instance != null && Instance.isEnabled() && Instance.getScoreboardSetting().isEnabled();
   }

   private void renderHudElement(class_332 context, float x, float y) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
         class_269 board = this.mc.field_1687.method_8428();
         class_266 objective = board.method_1189(class_8646.field_45157);
         if (objective != null) {
            List<class_9011> scores = new ArrayList<class_9011>(board.method_1184(objective));
            scores.sort(Comparator.comparing(class_9011::comp_2128).reversed());
            if (scores.size() > 15) {
               scores = scores.subList(0, 15);
            }

            float titleSize = 8.5F;
            float scoreSize = 7.5F;
            float padding = 6.0F;
            float headerHeight = titleSize + padding * 2.0F;
            ColoredTextRenderer.ColoredText titleColored = ColoredTextRenderer.ColoredText.fromText(objective.method_1114(), ThemeManager.getCurrentColor().getRGB());
            float maxWidth = MixedTextRenderer.calculateAnimationFactor(Msdf.SF_BOLD, titleColored, titleSize);
            ArrayList entryNames = new ArrayList();

            for(class_9011 score : scores) {
               String owner = score.comp_2127();
               class_268 team = board.method_1164(owner);
               class_2561 text = score.comp_2129();
               if (text == null) {
                  text = class_2561.method_43470(owner);
               }

               class_2561 nameText = class_268.method_1142(team, text);
               ColoredTextRenderer.ColoredText nameColored = ColoredTextRenderer.ColoredText.fromText(nameText, (new Color(245, 245, 245)).getRGB());
               entryNames.add(nameColored);
               float width = MixedTextRenderer.calculateAnimationFactor(MsdfManager.getDefaultFont(), nameColored, (float)scoreSize);
               if (width > maxWidth) {
                  maxWidth = width;
               }
            }

            float targetWidth = Math.max(105.0F, maxWidth + padding * 2.0F);
            if (this.getTargetWidth() == -1.0F) {
               this.setTargetWidth(targetWidth);
               this.setTargetWidthPrimary(targetWidth);
               this.setTargetWidthSecondary(targetWidth);
            }

            if (Math.abs(targetWidth - this.getTargetWidth()) > 0.1F) {
               this.setTargetWidthSecondary(this.getTargetWidthPrimary());
               this.setTargetWidth(targetWidth);
               this.setLastActionTime(System.currentTimeMillis());
            }

            float animProgress = Math.min(1.0F, (float)(System.currentTimeMillis() - this.getLastActionTime()) / 400.0F);
            float eased = this.easeOutBack(animProgress);
            this.setTargetWidthPrimary(this.getTargetWidthSecondary() + (targetWidth - this.getTargetWidthSecondary()) * eased);
            this.setTransientRenderX(this.getTargetWidthPrimary());
            this.setPrimaryRenderY(headerHeight + (float)scores.size() * (scoreSize + 3.0F) + padding);
            float drawX = x + (targetWidth - this.getTargetWidthPrimary()) / 2.0F;
            this.renderModuleElement(HUD.HudElement.SCOREBOARD, drawX, y, this.getTransientRenderX(), this.getPrimaryRenderY(), 7.0F, 1.0F);
            this.renderModuleElement(HUD.HudElement.SCOREBOARD, drawX, y, this.getTransientRenderX(), headerHeight, 0.0F, 0.0F, 6.0F, 6.0F, 1.0F);
            MixedTextRenderer.renderHudElement(context, Msdf.SF_BOLD, titleColored, drawX + this.getTransientRenderX() / 2.0F - MixedTextRenderer.calculateAnimationFactor(Msdf.SF_BOLD, titleColored, titleSize) / 2.0F, this.calculateAngle(y, headerHeight, titleSize) + 2.0F, titleSize);
            float var26 = y + headerHeight + padding;

            for(int i = 0; i < scores.size(); ++i) {
               ColoredTextRenderer.ColoredText nameColored = (ColoredTextRenderer.ColoredText)entryNames.get(i);
               MixedTextRenderer.renderHudElement(context, MsdfManager.getDefaultFont(), nameColored, drawX + padding, var26, (float)scoreSize);
               var26 += scoreSize + 3.0F;
            }

         }
      }
   }

   private BooleanSetting getWatermarkSetting() {
      return this.watermarkBooleanSetting;
   }

   private ListSetting getHudStyleSetting() {
      return this.stilHudListSetting;
   }

   private ListSetting getWatermarkStyleSetting() {
      return this.watermarkStyleListSetting;
   }

   private BooleanSetting getWatermarkIceSetting() {
      return this.watermarkLyodBooleanSetting;
   }

   private BooleanSetting getWatermarkLiquidGlassSetting() {
      return this.watermarkZhidkoeStekloBooleanSetting;
   }

   private BooleanSetting getKeybindsIceSetting() {
      return this.keybindsLyodBooleanSetting;
   }

   private BooleanSetting getKeybindsLiquidGlassSetting() {
      return this.keybindsZhidkoeStekloBooleanSetting;
   }

   private BooleanSetting getPotionsIceSetting() {
      return this.potionsLyodBooleanSetting;
   }

   private BooleanSetting getPotionsLiquidGlassSetting() {
      return this.potionsZhidkoeStekloBooleanSetting;
   }

   private BooleanSetting getTargetHudIceSetting() {
      return this.targethudLyodBooleanSetting;
   }

   private BooleanSetting getTargetHudLiquidGlassSetting() {
      return this.targethudZhidkoeStekloBooleanSetting;
   }

   private BooleanSetting getHotbarIceSetting() {
      return this.hotbarLyodBooleanSetting;
   }

   private BooleanSetting getHotbarLiquidGlassSetting() {
      return this.hotbarZhidkoeStekloBooleanSetting;
   }

   private BooleanSetting getKeybindsSetting() {
      return this.keybindsBooleanSetting;
   }

   private BooleanSetting getTargetHudSetting() {
      return this.targethudBooleanSetting;
   }

   private BooleanSetting getNeuroAimSetting() {
      return this.neuroAimBooleanSetting;
   }

   private BooleanSetting getPotionsSetting() {
      return this.potionsBooleanSetting;
   }

   private BooleanSetting getHotbarSetting() {
      return this.hotbarBooleanSetting;
   }

   private BooleanSetting getScoreboardSetting() {
      return this.scoreboardBooleanSetting;
   }

   private NumberSetting getBlurStrengthSetting() {
      return this.silaBlyuraNumberSetting;
   }

   private BooleanSetting getShaderSetting() {
      return this.sheyderBooleanSetting;
   }

   private DragTarget getDraggedElement() {
      return this.field_61bc7b0e;
   }

   private void setDraggedElement(DragTarget var1) {
      this.field_61bc7b0e = var1;
   }

   private boolean isMouseDown() {
      return this.field_cee7f503;
   }

   private void setMouseDown(boolean var1) {
      this.field_cee7f503 = var1;
   }

   private boolean isRightMouseDown() {
      return this.field_3c136ef8;
   }

   private void setRightMouseDown(boolean var1) {
      this.field_3c136ef8 = var1;
   }

   private float getAnimationProgress() {
      return this.field_a93ee8ed;
   }

   private void setAnimationProgress(float var1) {
      this.field_a93ee8ed = var1;
   }

   private float getCurrentAlpha() {
      return this.field_166a62e2;
   }

   private void setCurrentAlpha(float var1) {
      this.field_166a62e2 = var1;
   }

   private float getTargetAlpha() {
      return this.field_8395dcd7;
   }

   private void setTargetAlpha(float var1) {
      this.field_8395dcd7 = var1;
   }

   private float getRenderX() {
      return this.field_f0c156cc;
   }

   private void setRenderX(float var1) {
      this.field_f0c156cc = var1;
   }

   private float getTotalWidth() {
      return this.field_5decd0c1;
   }

   private void setTotalWidth(float var1) {
      this.field_5decd0c1 = var1;
   }

   private float getRenderY() {
      return this.field_cb184ab6;
   }

   private void setRenderY(float var1) {
      this.field_cb184ab6 = var1;
   }

   private float getCurrentScale() {
      return this.field_3843c4ab;
   }

   private void setCurrentScale(float var1) {
      this.field_3843c4ab = var1;
   }

   private float getMaxW() {
      return this.field_a56f3ea0;
   }

   private void setMaxW(float var1) {
      this.field_a56f3ea0 = var1;
   }

   private float getTargetScale() {
      return this.field_129ab895;
   }

   private void setTargetScale(float var1) {
      this.field_129ab895 = var1;
   }

   private float getYawOffset() {
      return this.field_7fc6328a;
   }

   private void setYawOffset(float var1) {
      this.field_7fc6328a = var1;
   }

   private float getPitchOffset() {
      return this.field_ecf1ac7f;
   }

   private void setPitchOffset(float var1) {
      this.field_ecf1ac7f = var1;
   }

   private float getMovementSpeed() {
      return this.field_5a1d2674;
   }

   private void setMovementSpeed(float var1) {
      this.field_5a1d2674 = var1;
   }

   private float getVerticalSpeed() {
      return this.field_c748a069;
   }

   private void setVerticalSpeed(float var1) {
      this.field_c748a069 = var1;
   }

   private float getInterpolation() {
      return this.field_34741a5e;
   }

   private void setInterpolation(float var1) {
      this.field_34741a5e = var1;
   }

   private float getFadeProgress() {
      return this.field_a19f9453;
   }

   private void setFadeProgress(float var1) {
      this.field_a19f9453 = var1;
   }

   private float getWidth() {
      return this.field_ecb0e48;
   }

   private void setWidth(float var1) {
      this.field_ecb0e48 = var1;
   }

   private float getHeight() {
      return this.field_7bf6883d;
   }

   private void setHeight(float var1) {
      this.field_7bf6883d = var1;
   }

   private float getRadius() {
      return this.field_e9220232;
   }

   private void setRadius(float var1) {
      this.field_e9220232 = var1;
   }

   private float getMaxWPrimary() {
      return this.field_564d7c27;
   }

   private void setMaxWPrimary(float var1) {
      this.field_564d7c27 = var1;
   }

   private float getOpacity() {
      return this.field_c378f61c;
   }

   private void setOpacity(float var1) {
      this.field_c378f61c = var1;
   }

   private float getRotation() {
      return this.field_30a47011;
   }

   private void setRotation(float var1) {
      this.field_30a47011 = var1;
   }

   private float getVelocity() {
      return this.field_9dcfea06;
   }

   private void setVelocity(float var1) {
      this.field_9dcfea06 = var1;
   }

   private float getTargetValue() {
      return this.field_afb63fb;
   }

   private void setTargetValue(float var1) {
      this.field_afb63fb = var1;
   }

   private float getTargetHudAnimationProgress() {
      return this.field_7826ddf0;
   }

   private void setTargetHudAnimationProgress(float var1) {
      this.field_7826ddf0 = var1;
   }

   private float getAlternateCurrentAlpha() {
      return this.field_e55257e5;
   }

   private void setAlternateCurrentAlpha(float var1) {
      this.field_e55257e5 = var1;
   }

   private float getScoreboardY() {
      return this.field_527dd1da;
   }

   private void setScoreboardY(float var1) {
      this.field_527dd1da = var1;
   }

   private float getTransientRenderX() {
      return this.field_bfa94bcf;
   }

   private void setTransientRenderX(float var1) {
      this.field_bfa94bcf = var1;
   }

   private float getPrimaryRenderY() {
      return this.field_2cd4c5c4;
   }

   private void setPrimaryRenderY(float var1) {
      this.field_2cd4c5c4 = var1;
   }

   private float getTargetWidth() {
      return this.field_9a003fb9;
   }

   private void setTargetWidth(float var1) {
      this.field_9a003fb9 = var1;
   }

   private float getTargetWidthPrimary() {
      return this.field_72bb9ae;
   }

   private void setTargetWidthPrimary(float var1) {
      this.field_72bb9ae = var1;
   }

   private float getTargetWidthSecondary() {
      return this.field_745733a3;
   }

   private void setTargetWidthSecondary(float var1) {
      this.field_745733a3 = var1;
   }

   private long getLastActionTime() {
      return this.field_e182ad98;
   }

   private void setLastActionTime(long var1) {
      this.field_e182ad98 = var1;
   }

   private boolean isActionPending() {
      return this.field_4eae278d;
   }

   private void setActionPending(boolean var1) {
      this.field_4eae278d = var1;
   }

   private float getAlternateCurrentScale() {
      return this.field_bbd9a182;
   }

   private void setAlternateCurrentScale(float var1) {
      this.field_bbd9a182 = var1;
   }

   private float getStylePopupX() {
      return this.field_29051b77;
   }

   private void setStylePopupX(float var1) {
      this.field_29051b77 = var1;
   }

   private float getOptionsY() {
      return this.field_9630956c;
   }

   private void setOptionsY(float var1) {
      this.field_9630956c = var1;
   }

   private HudElement getHoveredElement() {
      return this.field_35c0f61;
   }

   private void setHoveredElement(HudElement var1) {
      this.field_35c0f61 = var1;
   }

   private float getMouseX() {
      return this.field_70878956;
   }

   private void setMouseX(float var1) {
      this.field_70878956 = var1;
   }

   private float getMouseY() {
      return this.field_ddb3034b;
   }

   private void setMouseY(float var1) {
      this.field_ddb3034b = var1;
   }

   private class_1309 getTarget() {
      return this.field_4ade7d40;
   }

   private void setTarget(class_1309 var1) {
      this.field_4ade7d40 = var1;
   }

   private long getNow() {
      return this.field_b809f735;
   }

   private void setNow(long var1) {
      this.field_b809f735 = var1;
   }

   private long getNowPrimary() {
      return this.field_2535712a;
   }

   private void setNowPrimary(long var1) {
      this.field_2535712a = var1;
   }

   private boolean isInputCaptured() {
      return this.field_9260eb1f;
   }

   private void setInputCaptured(boolean var1) {
      this.field_9260eb1f = var1;
   }

   private float getTransientYawOffset() {
      return this.field_ff8c6514;
   }

   private void setTransientYawOffset(float var1) {
      this.field_ff8c6514 = var1;
   }

   private float getTargetSelectorX() {
      return this.field_6cb7df09;
   }

   private void setTargetSelectorX(float var1) {
      this.field_6cb7df09 = var1;
   }

   private String getDisplayName() {
      return this.field_d9e358fe;
   }

   private void setDisplayName(String var1) {
      this.field_d9e358fe = var1;
   }

   private String getKey() {
      return this.field_470ed2f3;
   }

   private void setKey(String var1) {
      this.field_470ed2f3 = var1;
   }

   private long getLastActionTimeForTarget() {
      return this.field_b43a4ce8;
   }

   private void setLastActionTimeForTarget(long var1) {
      this.field_b43a4ce8 = var1;
   }

   private boolean isHealth() {
      return this.field_2165c6dd;
   }

   private void setHealth(boolean var1) {
      this.field_2165c6dd = var1;
   }

   private float getHealth() {
      return this.field_8e9140d2;
   }

   private void setHealth(float var1) {
      this.field_8e9140d2 = var1;
   }

   private float getMaxHealth() {
      return this.field_fbbcbac7;
   }

   private void setMaxHealth(float var1) {
      this.field_fbbcbac7 = var1;
   }

   private float getAbsorption() {
      return this.field_68e834bc;
   }

   private void setAbsorption(float var1) {
      this.field_68e834bc = var1;
   }

   private float getFood() {
      return this.field_d613aeb1;
   }

   private void setFood(float var1) {
      this.field_d613aeb1 = var1;
   }

   private float getArmor() {
      return this.field_433f28a6;
   }

   private void setArmor(float var1) {
      this.field_433f28a6 = var1;
   }

   private float getExperienceProgress() {
      return this.field_b06aa29b;
   }

   private void setExperienceProgress(float var1) {
      this.field_b06aa29b = var1;
   }

   private float getExperienceLevel() {
      return this.field_1d961c90;
   }

   private void setExperienceLevel(float var1) {
      this.field_1d961c90 = var1;
   }

   private float[] getPrimaryPitchOffset() {
      return this.field_8ac19685;
   }

   private Map<Function, Float> getIterator() {
      return this.field_f7ed107a;
   }

   private Map<Function, Float> getSliderIterator() {
      return this.field_65188a6f;
   }

   private Map<String, Float> getPotionsIterator() {
      return this.field_d2440464;
   }

   private Map<String, NumericTextAnimationState> getTrackedEntries() {
      return this.field_3f6f7e59;
   }

   private float getTargetHp() {
      return this.field_ac9af84e;
   }

   private void setTargetHp(float var1) {
      this.field_ac9af84e = var1;
   }

   private float getAlternateMovementSpeed() {
      return this.field_19c67243;
   }

   private void setAlternateMovementSpeed(float var1) {
      this.field_19c67243 = var1;
   }

   private float getFallbackVerticalSpeed() {
      return this.field_86f1ec38;
   }

   private void setFallbackVerticalSpeed(float var1) {
      this.field_86f1ec38 = var1;
   }


   private static final class NumericTextAnimationState {
      private boolean watermarkBooleanSetting;
      private boolean stilHudListSetting;
      private String watermarkStyleListSetting;
      private String watermarkLyodBooleanSetting;
      private double watermarkZhidkoeStekloBooleanSetting;
      private double keybindsLyodBooleanSetting;
      private double keybindsZhidkoeStekloBooleanSetting;
      private double potionsLyodBooleanSetting;
      private int potionsZhidkoeStekloBooleanSetting;
      private int targethudLyodBooleanSetting;
      private long targethudZhidkoeStekloBooleanSetting;

      private NumericTextAnimationState() {
         this.setWatermarkStyleSetting("");
         this.setWatermarkIceSetting("");
      }

      private boolean isWatermarkSetting() {
         return this.watermarkBooleanSetting;
      }

      private void setWatermarkSetting(boolean var1) {
         this.watermarkBooleanSetting = var1;
      }

      private boolean isHudStyleSetting() {
         return this.stilHudListSetting;
      }

      private void setHudStyleSetting(boolean var1) {
         this.stilHudListSetting = var1;
      }

      private String getWatermarkStyleSetting() {
         return this.watermarkStyleListSetting;
      }

      private void setWatermarkStyleSetting(String var1) {
         this.watermarkStyleListSetting = var1;
      }

      private String getWatermarkIceSetting() {
         return this.watermarkLyodBooleanSetting;
      }

      private void setWatermarkIceSetting(String var1) {
         this.watermarkLyodBooleanSetting = var1;
      }

      private double getWatermarkLiquidGlassSetting() {
         return this.watermarkZhidkoeStekloBooleanSetting;
      }

      private void setWatermarkLiquidGlassSetting(double var1) {
         this.watermarkZhidkoeStekloBooleanSetting = var1;
      }

      private double getKeybindsIceSetting() {
         return this.keybindsLyodBooleanSetting;
      }

      private void setKeybindsIceSetting(double var1) {
         this.keybindsLyodBooleanSetting = var1;
      }

      private double getKeybindsLiquidGlassSetting() {
         return this.keybindsZhidkoeStekloBooleanSetting;
      }

      private void setKeybindsLiquidGlassSetting(double var1) {
         this.keybindsZhidkoeStekloBooleanSetting = var1;
      }

      private double getPotionsIceSetting() {
         return this.potionsLyodBooleanSetting;
      }

      private void setPotionsIceSetting(double var1) {
         this.potionsLyodBooleanSetting = var1;
      }

      private int getPotionsLiquidGlassSetting() {
         return this.potionsZhidkoeStekloBooleanSetting;
      }

      private void setPotionsLiquidGlassSetting(int var1) {
         this.potionsZhidkoeStekloBooleanSetting = var1;
      }

      private int getTargetHudIceSetting() {
         return this.targethudLyodBooleanSetting;
      }

      private void setTargetHudIceSetting(int var1) {
         this.targethudLyodBooleanSetting = var1;
      }

      private long getTargetHudLiquidGlassSetting() {
         return this.targethudZhidkoeStekloBooleanSetting;
      }

      private void setTargetHudLiquidGlassSetting(long var1) {
         this.targethudZhidkoeStekloBooleanSetting = var1;
      }

   }

   private static final class ParsedNumericText {
      private final String watermarkBooleanSetting;
      private final String stilHudListSetting;
      private final boolean watermarkStyleListSetting;
      private final double watermarkLyodBooleanSetting;
      private final double watermarkZhidkoeStekloBooleanSetting;
      private final int keybindsLyodBooleanSetting;
      private final int keybindsZhidkoeStekloBooleanSetting;

      private ParsedNumericText(String prefix, String suffix, boolean plus, double valueA, double valueB, int decimalsA, int decimalsB) {
         this.watermarkBooleanSetting = prefix;
         this.stilHudListSetting = suffix;
         this.watermarkStyleListSetting = plus;
         this.watermarkLyodBooleanSetting = valueA;
         this.watermarkZhidkoeStekloBooleanSetting = valueB;
         this.keybindsLyodBooleanSetting = decimalsA;
         this.keybindsZhidkoeStekloBooleanSetting = decimalsB;
      }

      private boolean matchesState(NumericTextAnimationState state) {
         return this.isWatermarkStyleSetting() == state.stilHudListSetting && this.getWatermarkSetting().equals(state.watermarkStyleListSetting) && this.getHudStyleSetting().equals(state.watermarkLyodBooleanSetting) && this.getKeybindsIceSetting() == state.potionsZhidkoeStekloBooleanSetting && this.getKeybindsLiquidGlassSetting() == state.targethudLyodBooleanSetting;
      }

      private String getWatermarkSetting() {
         return this.watermarkBooleanSetting;
      }

      private String getHudStyleSetting() {
         return this.stilHudListSetting;
      }

      private boolean isWatermarkStyleSetting() {
         return this.watermarkStyleListSetting;
      }

      private double getWatermarkIceSetting() {
         return this.watermarkLyodBooleanSetting;
      }

      private double getWatermarkLiquidGlassSetting() {
         return this.watermarkZhidkoeStekloBooleanSetting;
      }

      private int getKeybindsIceSetting() {
         return this.keybindsLyodBooleanSetting;
      }

      private int getKeybindsLiquidGlassSetting() {
         return this.keybindsZhidkoeStekloBooleanSetting;
      }

   }

   static enum HudElement {
      WATERMARK,
      SCOREBOARD,
      KEYBINDS,
      POTIONS,
      TARGET_HUD,
      NEURO_AIM,
      HOTBAR;

   }

   private static enum HudStyle {
      DEFAULT,
      ICE,
      LIQUID;

   }

   private static enum DragTarget {
      NONE,
      WATERMARK,
      SCOREBOARD,
      KEYBINDS,
      POTIONS,
      TARGET_HUD,
      NEURO_AIM;

   }
}
