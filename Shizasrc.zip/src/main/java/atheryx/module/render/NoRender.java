package atheryx.module.render;

import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;

@NewFunction(
   name = "NoRender",
   desc = "Отключает выбранные визуальные эффекты",
   category = Category.RENDER
)
public class NoRender extends Function {
   public static NoRender Instance;
   private final BooleanSetting vinetkaBooleanSetting = new BooleanSetting("Виньетка", true);
   private final BooleanSetting plohieEffektyBooleanSetting = new BooleanSetting("Плохие эффекты", true);
   private final BooleanSetting ogonNaVesEkranBooleanSetting = new BooleanSetting("Огонь на весь экран", true);
   private final BooleanSetting tryaskaKameryBooleanSetting = new BooleanSetting("Тряска камеры", true);
   private final BooleanSetting skrytPritselBooleanSetting = new BooleanSetting("Скрыть прицел", false);

   public NoRender() {
      Instance = this;
      this.addSettings(new Setting[]{this.getVignetteSetting(), this.getNegativeEffectsSetting(), this.getFullscreenFireSetting(), this.getCameraShakeSetting(), this.getHideCrosshairSetting()});
   }

   public static boolean isFeatureActive() {
      return Instance != null && Instance.isEnabled() && Instance.getVignetteSetting().isEnabled();
   }

   public static boolean isFeatureActivePrimary() {
      return Instance != null && Instance.isEnabled() && Instance.getNegativeEffectsSetting().isEnabled();
   }

   public static boolean isFeatureActiveSecondary() {
      return Instance != null && Instance.isEnabled() && Instance.getFullscreenFireSetting().isEnabled();
   }

   public static boolean isFeatureActiveCurrent() {
      return Instance != null && Instance.isEnabled() && Instance.getCameraShakeSetting().isEnabled();
   }

   public static boolean isFeatureActivePrevious() {
      return Instance != null && Instance.isEnabled() && Instance.getHideCrosshairSetting().isEnabled();
   }

   private BooleanSetting getVignetteSetting() {
      return this.vinetkaBooleanSetting;
   }

   private BooleanSetting getNegativeEffectsSetting() {
      return this.plohieEffektyBooleanSetting;
   }

   private BooleanSetting getFullscreenFireSetting() {
      return this.ogonNaVesEkranBooleanSetting;
   }

   private BooleanSetting getCameraShakeSetting() {
      return this.tryaskaKameryBooleanSetting;
   }

   private BooleanSetting getHideCrosshairSetting() {
      return this.skrytPritselBooleanSetting;
   }

}
