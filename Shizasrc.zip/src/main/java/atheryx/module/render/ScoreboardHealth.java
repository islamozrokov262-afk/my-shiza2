package atheryx.module.render;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_742;
import net.minecraft.class_8646;
import net.minecraft.class_9013;

@NewFunction(
   name = "ScoreboardHealth",
   desc = "Берет здоровье из скорборда",
   category = Category.MISC
)
public class ScoreboardHealth extends Function {
   public float RealHp;

   public float calculateAnimationFactor() {
      return this.getRealHp();
   }

   @EventHandler
   public void onUpdate(UpdateEvent e) {
      if (this.mc.field_1687 != null) {
         for(class_742 player : this.mc.field_1687.method_18456()) {
            class_269 scoreboard = this.mc.field_1687.method_8428();
            if (scoreboard != null) {
               class_266 scoreobjective = scoreboard.method_1189(class_8646.field_45158);
               if (scoreobjective != null) {
                  class_9013 score2 = scoreboard.method_55430(player, scoreobjective);
                  if (score2 != null) {
                     int var11 = score2.method_55397();
                     String scoreText = var11 + scoreobjective.method_1114().getString();
                     String scoreNumber = scoreText.replaceAll("[^0-9]", "");

                     try {
                        if (!scoreNumber.isEmpty()) {
                           int hps = Integer.parseInt(scoreNumber);
                           if ((float)hps <= player.method_6063()) {
                              this.setRealHp((float)hps);
                           }
                        }
                     } catch (NumberFormatException var10) {
                     }
                  }
               }
            }
         }

      }
   }

   private float getRealHp() {
      return this.RealHp;
   }

   private void setRealHp(float var1) {
      this.RealHp = var1;
   }

}
