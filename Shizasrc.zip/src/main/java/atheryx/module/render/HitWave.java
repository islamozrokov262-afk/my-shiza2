package atheryx.module.render;

import atheryx.event.EventHandler;
import atheryx.event.impl.AttackEntityEvent;
import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ColorSetting;
import atheryx.setting.impl.NumberSetting;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;

@NewFunction(
   name = "HitWave",
   desc = "Эффект волны при ударе",
   category = Category.RENDER
)
public class HitWave extends Function {
   private static final class_2960 obf_u00ee_u222f = class_2960.method_60655("minecraft", "textures/block/white_concrete.png");
   private static final RenderPipeline obf_u221f_u222f;
   private static final class_1921 obf_u040d_u222f;
   public static HitWave Instance;
   private final BooleanSetting zalivkaBooleanSetting = new BooleanSetting("Заливка", true);
   private final BooleanSetting konturBooleanSetting = new BooleanSetting("Контур", true);
   private final NumberSetting tolschinaLiniyNumberSetting = new NumberSetting("Толщина линий", 2.0D, (double)0.5F, 5.0D, 0.1);
   private final NumberSetting prozrachnostZalivkiNumberSetting = new NumberSetting("Прозрачность заливки", 0.15, 0.01, (double)1.0F, 0.01);
   private final NumberSetting dlitelnostSekNumberSetting = new NumberSetting("Длительность (сек)", (double)1.5F, (double)0.5F, 3.0D, 0.1);
   private final NumberSetting maksimalnyyRadiusNumberSetting = new NumberSetting("Максимальный радиус", 12.0D, 5.0D, 20.0D, (double)1.0F);
   private final NumberSetting shirinaVolnyNumberSetting = new NumberSetting("Ширина волны", 2.5D, (double)1.0F, 5.0D, (double)0.5F);
   private final BooleanSetting ispolzovatTsvetTemyBooleanSetting = new BooleanSetting("Использовать цвет темы", true);
   private final ColorSetting tsvetVolnyColorSetting = new ColorSetting("Цвет волны", new Color(255, 255, 255));
   private final List<WaveInstance> field_43b2c392 = new ArrayList<WaveInstance>();

   public HitWave() {
      Instance = this;
      this.addSettings(new Setting[]{this.getFillSetting(), this.getOutlineSetting(), this.getLineThicknessSetting(), this.getFillTransparencySetting(), this.getDurationSecondsSetting(), this.getMaximumRadiusSetting(), this.getWaveWidthSetting(), this.getUseThemeColorSetting(), this.getWaveColorSetting()});
      this.getUseThemeColorSetting().setChangeListener(() -> {
         this.getWaveColorSetting().setVisible(!this.getUseThemeColorSetting().isEnabled());
      });
      this.getWaveColorSetting().setVisible(!this.getUseThemeColorSetting().isEnabled());
   }

   public void onDisable() {
      this.getIterator().clear();
   }

   @EventHandler
   private void onAttackEntity(AttackEntityEvent e) {
      if (e.getTarget() != null && this.mc.field_1687 != null) {
         class_243 pos = e.getTarget().method_73189();
         class_2338 basePos = class_2338.method_49637(pos.field_1352, pos.field_1351 - 0.1, pos.field_1350);
         this.getIterator().add(new WaveInstance(basePos, System.currentTimeMillis()));
      }
   }

   public static void onWorldRender(WorldRenderContext context) {
      if (Instance != null && Instance.isEnabled() && !Instance.getIterator().isEmpty()) {
         Instance.renderWorldOverlay(context);
      }
   }

   private void renderWorldOverlay(WorldRenderContext context) {
      Iterator<WaveInstance> iterator = this.getIterator().iterator();

      while(iterator.hasNext()) {
         WaveInstance wave = iterator.next();
         if (wave.shouldProcess()) {
            iterator.remove();
         } else {
            wave.renderWorldOverlay(context);
         }
      }

   }

   private Color getColor() {
      return this.getUseThemeColorSetting().isEnabled() ? ThemeManager.getCurrentColor() : this.getWaveColorSetting().getColor();
   }

   private static int brightenChannel(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.45F)), 0, 255);
   }

   private static int calculateMovementSpeed(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.72F)), 0, 255);
   }

   private void renderWorldOverlay(WorldRenderContext context, class_238 box, Color color, float alpha) {
      class_4588 buffer = context.consumers().method_73477(class_12249.method_75984(obf_u00ee_u222f, false));
      class_4587.class_4665 entry = context.matrices().method_23760();
      float inset = 0.001F;
      float x1 = (float)box.field_1323;
      float y1 = (float)box.field_1322;
      float z1 = (float)box.field_1321;
      float x2 = (float)box.field_1320;
      float y2 = (float)box.field_1325;
      float z2 = (float)box.field_1324;
      this.emitVertex(buffer, entry, color, x1, y2 + inset, z2, x2, y2 + inset, z2, x2, y2 + inset, z1, x1, y2 + inset, z1, alpha);
      this.emitVertex(buffer, entry, color, x1, y1 - inset, z1, x2, y1 - inset, z1, x2, y1 - inset, z2, x1, y1 - inset, z2, alpha);
      this.emitVertex(buffer, entry, color, x1, y1, z1 - inset, x1, y2, z1 - inset, x2, y2, z1 - inset, x2, y1, z1 - inset, alpha);
      this.emitVertex(buffer, entry, color, x1, y1, z2 + inset, x2, y1, z2 + inset, x2, y2, z2 + inset, x1, y2, z2 + inset, alpha);
      this.emitVertex(buffer, entry, color, x1 - inset, y1, z1, x1 - inset, y1, z2, x1 - inset, y2, z2, x1 - inset, y2, z1, alpha);
      this.emitVertex(buffer, entry, color, x2 + inset, y1, z1, x2 + inset, y2, z1, x2 + inset, y2, z2, x2 + inset, y1, z2, alpha);
   }

   private void renderWorldOverlayPrimary(WorldRenderContext context, class_238 box, Color color, float alpha) {
      class_4588 buffer = context.consumers().method_73477(obf_u040d_u222f);
      class_4587.class_4665 entry = context.matrices().method_23760();
      float width = (float)this.getLineThicknessSetting().getValue();
      this.emitLineWithAlpha(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1321, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1324, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1324, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1321, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1323, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1321, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1320, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1324, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1320, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1324, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1323, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1321, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1323, box.field_1325, box.field_1321, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1321, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1320, box.field_1325, box.field_1324, width, alpha);
      this.emitLineWithAlpha(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1325, box.field_1324, width, alpha);
   }

   private void emitLineWithAlpha(class_4588 buffer, class_4587.class_4665 entry, Color color, double x1, double y1, double z1, double x2, double y2, double z2, float width, float alpha) {
      float dx = (float)(x2 - x1);
      float dy = (float)(y2 - y1);
      float dz = (float)(z2 - z1);
      float length = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
      if (!(length <= 1.0E-4F)) {
         buffer.method_56824(entry, (float)x1, (float)y1, (float)z1).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F)).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
         buffer.method_56824(entry, (float)x2, (float)y2, (float)z2).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F)).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
      }
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4, float alpha) {
      this.emitVertex(buffer, entry, color, x1, y1, z1, 0.0F, 1.0F, alpha);
      this.emitVertex(buffer, entry, color, x2, y2, z2, 1.0F, 1.0F, alpha);
      this.emitVertex(buffer, entry, color, x3, y3, z3, 1.0F, 0.0F, alpha);
      this.emitVertex(buffer, entry, color, x4, y4, z4, 0.0F, 0.0F, alpha);
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, float x, float y, float z, float u, float v, float alpha) {
      buffer.method_56824(entry, x, y, z).method_22913(u, v).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F)).method_22922(class_4608.field_21444).method_60803(15728880).method_60831(entry, 0.0F, 1.0F, 0.0F);
   }

   static {
      obf_u221f_u222f = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56859}).withLocation(class_2960.method_60655("atheryx", "hitwave_lines_depth")).withBlend(BlendFunction.TRANSLUCENT).withDepthWrite(false).build());
      obf_u040d_u222f = class_1921.method_75940("atheryx_hitwave_lines_depth", class_12247.method_75927(obf_u221f_u222f).method_75930(class_12245.field_63976).method_75931(class_12246.field_63983).method_75938());
   }

   private BooleanSetting getFillSetting() {
      return this.zalivkaBooleanSetting;
   }

   private BooleanSetting getOutlineSetting() {
      return this.konturBooleanSetting;
   }

   private NumberSetting getLineThicknessSetting() {
      return this.tolschinaLiniyNumberSetting;
   }

   private NumberSetting getFillTransparencySetting() {
      return this.prozrachnostZalivkiNumberSetting;
   }

   private NumberSetting getDurationSecondsSetting() {
      return this.dlitelnostSekNumberSetting;
   }

   private NumberSetting getMaximumRadiusSetting() {
      return this.maksimalnyyRadiusNumberSetting;
   }

   private NumberSetting getWaveWidthSetting() {
      return this.shirinaVolnyNumberSetting;
   }

   private BooleanSetting getUseThemeColorSetting() {
      return this.ispolzovatTsvetTemyBooleanSetting;
   }

   private ColorSetting getWaveColorSetting() {
      return this.tsvetVolnyColorSetting;
   }

   private List getIterator() {
      return this.field_43b2c392;
   }


   private class WaveInstance {
      private final class_2338 zalivkaBooleanSetting;
      private final long konturBooleanSetting;
      private final List<WaveBlock> tolschinaLiniyNumberSetting = new ArrayList<WaveBlock>();

      public WaveInstance(class_2338 centerPos, long startTime) {
         this.zalivkaBooleanSetting = centerPos;
         this.konturBooleanSetting = startTime;
         int maxR = (int)HitWave.this.maksimalnyyRadiusNumberSetting.getValue();

         for(int x = -maxR; x <= maxR; ++x) {
            for(int z = -maxR; z <= maxR; ++z) {
               float distSq = (float)(x * x + z * z);
               if (!(distSq > (float)(maxR * maxR))) {
                  class_2338 checkPos = centerPos.method_10069(x, 0, z);
                  class_2338 renderPos = this.findTargetBlockPos(checkPos);
                  if (renderPos != null) {
                     class_2680 state = HitWave.this.mc.field_1687.method_8320(renderPos);
                     class_265 shape = state.method_26218(HitWave.this.mc.field_1687, renderPos);
                     if (!shape.method_1110()) {
                        this.getLineThicknessSetting().add(new WaveBlock(renderPos, shape.method_1107(), (float)Math.sqrt((double)distSq)));
                     }
                  }
               }
            }
         }

      }

      public boolean shouldProcess() {
         return System.currentTimeMillis() - this.getOutlineSetting() > (long)(this.getBaseColor().dlitelnostSekNumberSetting.getValue() * 1000.0D);
      }

      public void renderWorldOverlay(WorldRenderContext context) {
         if (HitWave.this.mc.field_1687 != null) {
            long elapsed = System.currentTimeMillis() - this.getOutlineSetting();
            float progress = (float)((double)elapsed / (this.getBaseColor().dlitelnostSekNumberSetting.getValue() * 1000.0D));
            float currentRadius = (float)((double)progress * this.getBaseColor().maksimalnyyRadiusNumberSetting.getValue());
            float waveW = (float)this.getBaseColor().shirinaVolnyNumberSetting.getValue();
            float globalAlpha = (float)Math.pow((double)(1.0F - progress), 0.6);
            int rendered = 0;
            short maxPerFrame = 400;
            float var10 = (currentRadius - waveW) * (currentRadius - waveW);
            float var11 = (currentRadius + 0.5F) * (currentRadius + 0.5F);
            Color baseColor = this.getBaseColor().getColor();
            int red = this.getBaseColor().ispolzovatTsvetTemyBooleanSetting.isEnabled() ? HitWave.brightenChannel(baseColor.getRed()) : baseColor.getRed();
            int green = this.getBaseColor().ispolzovatTsvetTemyBooleanSetting.isEnabled() ? HitWave.brightenChannel(baseColor.getGreen()) : baseColor.getGreen();
            int blue = this.getBaseColor().ispolzovatTsvetTemyBooleanSetting.isEnabled() ? HitWave.brightenChannel(baseColor.getBlue()) : baseColor.getBlue();
            Color glowColor = new Color(red, green, blue);
            Color coreColor = new Color(HitWave.calculateMovementSpeed(red), HitWave.calculateMovementSpeed(green), HitWave.calculateMovementSpeed(blue));
            int var18 = (int)this.getBaseColor().maksimalnyyRadiusNumberSetting.getValue();
            class_243 camera = context.worldState().field_63082.field_63078;

            for(WaveBlock cb : this.getLineThicknessSetting()) {
               if (rendered >= maxPerFrame) {
                  break;
               }

               float distance = cb.distance;
               if (!(distance < currentRadius - waveW) && !(distance > currentRadius + 0.5F)) {
                  ++rendered;
                  float localAlpha = 1.0F - Math.abs(distance - currentRadius) / waveW;
                  localAlpha = Math.max(0.0F, Math.min(1.0F, localAlpha)) * globalAlpha;
                  if (localAlpha > 0.05F) {
                     class_238 box = cb.box.method_996(cb.pos).method_989(-camera.field_1352, -camera.field_1351, -camera.field_1350);
                     if (this.getBaseColor().zalivkaBooleanSetting.isEnabled()) {
                        float fAlpha = (float)(this.getBaseColor().prozrachnostZalivkiNumberSetting.getValue() * (double)localAlpha);
                        this.getBaseColor().renderWorldOverlay(context, box, glowColor, fAlpha);
                     }

                     if (this.getBaseColor().konturBooleanSetting.isEnabled()) {
                        this.getBaseColor().renderWorldOverlayPrimary(context, box, coreColor, localAlpha);
                     }
                  }
               }
            }

         }
      }

      private class_2338 findTargetBlockPos(class_2338 pos) {
         for(int y = 2; y >= -4; --y) {
            class_2338 p = pos.method_10086(y);
            class_2680 state = HitWave.this.mc.field_1687.method_8320(p);
            class_2680 upState = HitWave.this.mc.field_1687.method_8320(p.method_10084());
            boolean currentSolid = !state.method_26220(HitWave.this.mc.field_1687, p).method_1110();
            boolean upSolid = !upState.method_26220(HitWave.this.mc.field_1687, p.method_10084()).method_1110();
            if (currentSolid && !upSolid) {
               return p;
            }
         }

         return null;
      }

      private class_2338 getFillSetting() {
         return this.zalivkaBooleanSetting;
      }

      private long getOutlineSetting() {
         return this.konturBooleanSetting;
      }

      private List<WaveBlock> getLineThicknessSetting() {
         return this.tolschinaLiniyNumberSetting;
      }

      private HitWave getBaseColor() {
         return HitWave.this;
      }

   }
}
