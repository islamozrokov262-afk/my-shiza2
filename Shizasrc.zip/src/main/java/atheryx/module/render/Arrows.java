package atheryx.module.render;

import atheryx.event.EventHandler;
import atheryx.event.impl.Render2DEvent;
import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.render.RenderUtil;
import atheryx.render.pipeline.TexturePipeline;
import atheryx.setting.Setting;
import atheryx.setting.impl.NumberSetting;
import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import org.joml.Matrix4f;

@NewFunction(
   name = "Arrows",
   desc = "Показывает стрелочки, указывающие на игроков",
   category = Category.RENDER
)
public class Arrows extends Function {
   private static final class_2960 obf_u0401_u221b = class_2960.method_60655("atheryx", "images/world/arrows.png");
   private static final class_2960 obf_u0405_u221b = class_2960.method_60655("atheryx", "images/particles/glow.png");
   private final NumberSetting radiusNumberSetting = new NumberSetting("Radius", 75.0D, 30.0D, 160.0D, (double)1.0F);
   private final NumberSetting sizeNumberSetting = new NumberSetting("Size", 22.0D, 8.0D, 50.0D, (double)1.0F);
   private final Map<UUID, PlayerArrowState> field_47826ddf = new HashMap<UUID, PlayerArrowState>();
   private long field_b4ade7d4;

   public Arrows() {
      this.addSettings(new Setting[]{this.getRadiusSetting(), this.getSizeSetting()});
   }

   public void onDisable() {
      this.getIterator().clear();
      this.setDelta(0L);
   }

   @EventHandler
   public void onRender2D(Render2DEvent event) {
      class_332 context = event.getDrawContext();
      if (context != null && this.mc.field_1724 != null && this.mc.field_1687 != null) {
         if (!this.mc.field_1690.field_1842 && !this.mc.method_53526().method_53536()) {
            long now = System.currentTimeMillis();
            float delta = this.getDelta() == 0L ? 0.0F : Math.min(50.0F, (float)(now - this.getDelta()));
            this.setDelta(now);
            float centerX = (float)RenderUtil.getScaledWidth() / 2.0F;
            float centerY = (float)RenderUtil.getScaledHeight() / 2.0F;
            float tickDelta = this.mc.method_61966().method_60637(false);

            for(class_1657 player : this.mc.field_1687.method_18456()) {
               if (player != this.mc.field_1724 && player.method_5805()) {
                  UUID uuid = player.method_5667();
                  PlayerArrowState state = (PlayerArrowState)this.getIterator().computeIfAbsent(uuid, (ignored) -> {
                     return new PlayerArrowState();
                  });
                  state.radiusNumberSetting = player;
                  state.sizeNumberSetting = true;
               }
            }

            Iterator<Map.Entry<UUID, PlayerArrowState>> iterator = this.getIterator().entrySet().iterator();

            while(iterator.hasNext()) {
               PlayerArrowState state = (PlayerArrowState)((Map.Entry)iterator.next()).getValue();
               state.field_47826ddf = this.animateTowards(state.field_47826ddf, state.sizeNumberSetting ? 1.0F : 0.0F, 0.018F, delta);
               if (state.radiusNumberSetting != null && state.field_47826ddf > 0.01F) {
                  this.processTarget(state.radiusNumberSetting, tickDelta, centerX, centerY, this.easeOutBack(state.field_47826ddf), state.field_47826ddf);
               }

               state.sizeNumberSetting = false;
               if (state.field_47826ddf <= 0.001F) {
                  iterator.remove();
               }
            }

         }
      }
   }

   private void processTarget(class_1657 target, float tickDelta, float centerX, float centerY, float scaleProgress, float alphaProgress) {
      class_243 targetPos = target.method_30950(tickDelta);
      class_243 selfPos = this.mc.field_1724.method_30950(tickDelta);
      double dx = targetPos.field_1352 - selfPos.field_1352;
      double dz = targetPos.field_1350 - selfPos.field_1350;
      if (!(dx * dx + dz * dz < 0.01)) {
         float worldAngle = (float)Math.atan2(dz, dx);
         float playerAngle = (float)Math.toRadians((double)this.mc.field_1724.method_36454()) + ((float)Math.PI / 2F);
         float angle = worldAngle - playerAngle;
         float r = (float)this.getRadiusSetting().getValue();
         float s = (float)this.getSizeSetting().getValue() * scaleProgress;
         float x = centerX + (float)Math.sin((double)angle) * r;
         float y = centerY - (float)Math.cos((double)angle) * r;
         this.renderModuleElement(x, y, angle, s, alphaProgress);
      }
   }

   private void renderModuleElement(float centerX, float centerY, float angle, float size, float alpha) {
      GpuTextureView texture = this.mc.method_1531().method_4619(obf_u0401_u221b).method_71659();
      GpuTextureView glowTexture = this.mc.method_1531().method_4619(obf_u0405_u221b).method_71659();
      GlStateManager._enableBlend();
      GlStateManager._blendFuncSeparate(770, 1, 1, 0);
      int red = this.calculateMovementSpeed(ThemeManager.getCurrentColor().getRed());
      int green = this.calculateMovementSpeed(ThemeManager.getCurrentColor().getGreen());
      int blue = this.calculateMovementSpeed(ThemeManager.getCurrentColor().getBlue());
      Matrix4f glowMatrix = RenderUtil.createGuiProjection();
      glowMatrix.translate(centerX, centerY, 0.0F);
      glowMatrix.rotateZ(-angle * 0.85F);
      float glowSize = size * 1.85F;
      glowMatrix.translate(-glowSize / 2.0F, -glowSize / 2.0F, 0.0F);
      Matrix4f matrix = RenderUtil.createGuiProjection();
      matrix.translate(centerX, centerY, 0.0F);
      matrix.rotateZ(angle);
      matrix.translate(-size / 2.0F, -size / 2.0F, 0.0F);
      TexturePipeline.drawSquareTexture(matrix, 0.0F, 0.0F, size, texture, this.calculateAnimationFactor(255.0F * alpha, red, green, blue), 0.0F, 0.0F);
      GlStateManager._blendFuncSeparate(770, 771, 1, 0);
   }

   private float animateTowards(float current, float target, float speed, float delta) {
      float factor = 1.0F - (float)Math.exp((double)(-speed * delta));
      float next = current + (target - current) * Math.clamp(factor, 0.0F, 1.0F);
      return Math.abs(next - target) < 0.001F ? target : next;
   }

   private float easeOutBack(float progress) {
      float c1 = 1.70158F;
      float c3 = c1 + 1.0F;
      float t = Math.clamp(progress, 0.0F, 1.0F) - 1.0F;
      return 1.0F + c3 * t * t * t + c1 * t * t;
   }

   private int calculateAnimationFactor(float alpha, int red, int green, int blue) {
      int a = Math.clamp((long)((int)alpha), 0, 255);
      return a << 24 | red << 16 | green << 8 | blue;
   }

   private int calculateMovementSpeed(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.45F)), 0, 255);
   }

   private NumberSetting getRadiusSetting() {
      return this.radiusNumberSetting;
   }

   private NumberSetting getSizeSetting() {
      return this.sizeNumberSetting;
   }

   private Map getIterator() {
      return this.field_47826ddf;
   }

   private long getDelta() {
      return this.field_b4ade7d4;
   }

   private void setDelta(long var1) {
      this.field_b4ade7d4 = var1;
   }


   private static class PlayerArrowState {
      private class_1657 radiusNumberSetting;
      private boolean sizeNumberSetting;
      private float field_47826ddf;

      private class_1657 getRadiusSetting() {
         return this.radiusNumberSetting;
      }

      private void setRadiusSetting(class_1657 var1) {
         this.radiusNumberSetting = var1;
      }

      private boolean isSizeSetting() {
         return this.sizeNumberSetting;
      }

      private void setSizeSetting(boolean var1) {
         this.sizeNumberSetting = var1;
      }

      private float getIterator() {
         return this.field_47826ddf;
      }

      private void setIterator(float var1) {
         this.field_47826ddf = var1;
      }

   }
}
