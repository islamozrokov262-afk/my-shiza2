package atheryx.module.render;

import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.render.pipeline.ShaderSkyPipeline;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ColorSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldTerrainRenderContext;
import org.joml.Quaternionf;
import org.joml.Vector3f;

@NewFunction(
   name = "ShaderSky",
   desc = "Анимированное шейдерное небо",
   category = Category.RENDER
)
public class ShaderSky extends Function {
   private final ModeSetting shaderModeSetting = new ModeSetting("Shader", new String[]{"Full", "WebShader", "Plasma", "ChamsFill", "BaseWarp", "Waves"});
   private final BooleanSetting themeColorBooleanSetting = new BooleanSetting("Theme color", true);
   private final ColorSetting colorColorSetting = new ColorSetting("Color", new Color(138, 180, 248));
   private final NumberSetting alphaNumberSetting = new NumberSetting("Alpha", (double)1.0F, 0.1, (double)1.0F, 0.05);
   private final NumberSetting speedNumberSetting = new NumberSetting("Speed", (double)1.0F, 0.1, 3.0D, 0.05);

   public ShaderSky() {
      this.addSettings(new Setting[]{this.getShaderSetting(), this.getThemeColorSetting(), this.getColorSetting(), this.getAlphaSetting(), this.getSpeedSetting()});
      this.getThemeColorSetting().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   public static void onWorldRenderStart(WorldTerrainRenderContext context) {
      ShaderSky shaderSky = (ShaderSky)FunctionManager.getFunction(ShaderSky.class);
      if (shaderSky != null && shaderSky.isEnabled()) {
         shaderSky.refreshTarget(context);
      }
   }

   private void refreshTarget(WorldTerrainRenderContext context) {
      Quaternionf orientation = context.worldState().field_63082.field_63081;
      Vector3f right = orientation.transform(new Vector3f(1.0F, 0.0F, 0.0F));
      Vector3f up = orientation.transform(new Vector3f(0.0F, 1.0F, 0.0F));
      Vector3f forward = orientation.transform(new Vector3f(0.0F, 0.0F, -1.0F));
      ShaderSkyPipeline.render(this.resolveColor(), (float)this.getAlphaSetting().getValue(), (float)this.getSpeedSetting().getValue(), this.calculateMovementSpeed(), right, up, forward);
   }

   private void updateSettingVisibility() {
      this.getColorSetting().setVisible(!this.getThemeColorSetting().isEnabled());
   }

   private Color resolveColor() {
      Color selected = this.getThemeColorSetting().isEnabled() ? ThemeManager.getCurrentColor() : this.getColorSetting().getColor();
      return !this.getThemeColorSetting().isEnabled() ? selected : new Color(brightenChannel(selected.getRed()), brightenChannel(selected.getGreen()), brightenChannel(selected.getBlue()));
   }

   private static int brightenChannel(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.35F)), 0, 255);
   }

   private int calculateMovementSpeed() {
      if (this.getShaderSetting().isSelected("Full")) {
         return 0;
      } else if (this.getShaderSetting().isSelected("WebShader")) {
         return 2;
      } else if (this.getShaderSetting().isSelected("Plasma")) {
         return 4;
      } else if (this.getShaderSetting().isSelected("ChamsFill")) {
         return 6;
      } else if (this.getShaderSetting().isSelected("BaseWarp")) {
         return 8;
      } else {
         return this.getShaderSetting().isSelected("Waves") ? 10 : 0;
      }
   }

   private ModeSetting getShaderSetting() {
      return this.shaderModeSetting;
   }

   private BooleanSetting getThemeColorSetting() {
      return this.themeColorBooleanSetting;
   }

   private ColorSetting getColorSetting() {
      return this.colorColorSetting;
   }

   private NumberSetting getAlphaSetting() {
      return this.alphaNumberSetting;
   }

   private NumberSetting getSpeedSetting() {
      return this.speedNumberSetting;
   }

}
