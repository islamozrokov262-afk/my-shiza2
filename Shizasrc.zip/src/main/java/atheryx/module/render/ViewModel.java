package atheryx.module.render;

import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import net.minecraft.class_1306;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

@NewFunction(
   name = "ViewModel",
   desc = "Кастомная позиция рук от первого лица",
   category = Category.RENDER
)
public class ViewModel extends Function {
   public static ViewModel Instance;
   private final ModeSetting rukaModeSetting = new ModeSetting("Рука", new String[]{"Правая", "Левая"});
   private final NumberSetting pravayaXNumberSetting = new NumberSetting("Правая X", (double)0.0F, -2.0D, 2.0D, 0.05);
   private final NumberSetting pravayaYNumberSetting = new NumberSetting("Правая Y", (double)0.0F, -2.0D, 2.0D, 0.05);
   private final NumberSetting pravayaZNumberSetting = new NumberSetting("Правая Z", (double)0.0F, -2.0D, 2.0D, 0.05);
   private final NumberSetting levayaXNumberSetting = new NumberSetting("Левая X", (double)0.0F, -2.0D, 2.0D, 0.05);
   private final NumberSetting levayaYNumberSetting = new NumberSetting("Левая Y", (double)0.0F, -2.0D, 2.0D, 0.05);
   private final NumberSetting levayaZNumberSetting = new NumberSetting("Левая Z", (double)0.0F, -2.0D, 2.0D, 0.05);
   private final BooleanSetting pravayaVraschenieBooleanSetting = new BooleanSetting("Правая вращение", false);
   private final ModeSetting pravayaOsVrascheniyaModeSetting = new ModeSetting("Правая ось вращения", new String[]{"X", "Y", "Z"});
   private final NumberSetting pravayaSkorostVrascheniyaNumberSetting = new NumberSetting("Правая скорость вращения", 120.0D, -720.0D, 720.0D, 5.0D);
   private final BooleanSetting levayaVraschenieBooleanSetting = new BooleanSetting("Левая вращение", false);
   private final ModeSetting levayaOsVrascheniyaModeSetting = new ModeSetting("Левая ось вращения", new String[]{"X", "Y", "Z"});
   private final NumberSetting levayaSkorostVrascheniyaNumberSetting = new NumberSetting("Левая скорость вращения", 120.0D, -720.0D, 720.0D, 5.0D);
   private final BooleanSetting statichnyeRukiBooleanSetting = new BooleanSetting("Статичные руки", false);

   public ViewModel() {
      Instance = this;
      this.addSettings(new Setting[]{this.getHandSetting(), this.getRightXSetting(), this.getRightYSetting(), this.getRightZSetting(), this.getLeftXSetting(), this.getLeftYSetting(), this.getLeftZSetting(), this.getRightRotationSetting(), this.getRightRotationAxisSetting(), this.getRightRotationSpeedSetting(), this.getLeftRotationSetting(), this.getLeftRotationAxisSetting(), this.getLeftRotationSpeedSetting(), this.getStaticHandsSetting()});
      this.getHandSetting().setChangeListener(this::updateSettingVisibility);
      this.getRightRotationSetting().setChangeListener(this::updateSettingVisibility);
      this.getLeftRotationSetting().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   public void refreshTarget(class_4587 matrices, class_1306 arm) {
      if (this.isEnabled()) {
         if (arm == class_1306.field_6183) {
            matrices.method_22904(this.getRightXSetting().getValue(), this.getRightYSetting().getValue(), this.getRightZSetting().getValue());
         } else {
            matrices.method_22904(this.getLeftXSetting().getValue(), this.getLeftYSetting().getValue(), this.getLeftZSetting().getValue());
         }

      }
   }

   public void updateRotation(class_4587 matrices, class_1306 arm) {
      if (this.isEnabled() && this.isValidArm(arm)) {
         float angle = (float)((double)System.nanoTime() / 1000000000.0D * this.calculateAnimationFactor(arm) % 360.0D);
         String var4 = this.resolveText(arm);
         byte var5 = -1;
         switch (var4.hashCode()) {
            case 89:
               if (var4.equals("Y")) {
                  var5 = 0;
               }
               break;
            case 90:
               if (var4.equals("Z")) {
                  var5 = 1;
               }
         }

         switch (var5) {
            case 0 -> matrices.method_22907(class_7833.field_40716.rotationDegrees(angle));
            case 1 -> matrices.method_22907(class_7833.field_40718.rotationDegrees(angle));
            default -> matrices.method_22907(class_7833.field_40714.rotationDegrees(arm == class_1306.field_6183 ? -angle : angle));
         }

      }
   }

   public boolean isFeatureActive() {
      return this.getStaticHandsSetting().isEnabled();
   }

   private boolean isValidArm(class_1306 arm) {
      return arm == class_1306.field_6183 ? this.getRightRotationSetting().isEnabled() : this.getLeftRotationSetting().isEnabled();
   }

   private String resolveText(class_1306 arm) {
      return arm == class_1306.field_6183 ? this.getRightRotationAxisSetting().getValue() : this.getLeftRotationAxisSetting().getValue();
   }

   private double calculateAnimationFactor(class_1306 arm) {
      return arm == class_1306.field_6183 ? this.getRightRotationSpeedSetting().getValue() : this.getLeftRotationSpeedSetting().getValue();
   }

   private void updateSettingVisibility() {
      boolean right = this.getHandSetting().isSelected("Правая");
      this.getRightXSetting().setVisible(right);
      this.getRightYSetting().setVisible(right);
      this.getRightZSetting().setVisible(right);
      this.getRightRotationSetting().setVisible(right);
      this.getRightRotationAxisSetting().setVisible(right && this.getRightRotationSetting().isEnabled());
      this.getRightRotationSpeedSetting().setVisible(right && this.getRightRotationSetting().isEnabled());
      this.getLeftXSetting().setVisible(!right);
      this.getLeftYSetting().setVisible(!right);
      this.getLeftZSetting().setVisible(!right);
      this.getLeftRotationSetting().setVisible(!right);
      this.getLeftRotationAxisSetting().setVisible(!right && this.getLeftRotationSetting().isEnabled());
      this.getLeftRotationSpeedSetting().setVisible(!right && this.getLeftRotationSetting().isEnabled());
   }

   private ModeSetting getHandSetting() {
      return this.rukaModeSetting;
   }

   private NumberSetting getRightXSetting() {
      return this.pravayaXNumberSetting;
   }

   private NumberSetting getRightYSetting() {
      return this.pravayaYNumberSetting;
   }

   private NumberSetting getRightZSetting() {
      return this.pravayaZNumberSetting;
   }

   private NumberSetting getLeftXSetting() {
      return this.levayaXNumberSetting;
   }

   private NumberSetting getLeftYSetting() {
      return this.levayaYNumberSetting;
   }

   private NumberSetting getLeftZSetting() {
      return this.levayaZNumberSetting;
   }

   private BooleanSetting getRightRotationSetting() {
      return this.pravayaVraschenieBooleanSetting;
   }

   private ModeSetting getRightRotationAxisSetting() {
      return this.pravayaOsVrascheniyaModeSetting;
   }

   private NumberSetting getRightRotationSpeedSetting() {
      return this.pravayaSkorostVrascheniyaNumberSetting;
   }

   private BooleanSetting getLeftRotationSetting() {
      return this.levayaVraschenieBooleanSetting;
   }

   private ModeSetting getLeftRotationAxisSetting() {
      return this.levayaOsVrascheniyaModeSetting;
   }

   private NumberSetting getLeftRotationSpeedSetting() {
      return this.levayaSkorostVrascheniyaNumberSetting;
   }

   private BooleanSetting getStaticHandsSetting() {
      return this.statichnyeRukiBooleanSetting;
   }

}
