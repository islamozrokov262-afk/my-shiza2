package atheryx.module.render;

import atheryx.event.EventHandler;
import atheryx.event.impl.AttackEntityEvent;
import atheryx.event.impl.EntityStatusEvent;
import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.render.Render3DUtils;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ColorSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.MultiListSetting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2960;

@NewFunction(
   name = "Particles",
   desc = "Картинки-партиклы при ударе по сущности",
   category = Category.RENDER
)
public class Particles extends Function {
   private static final class_2960 obf_u044a_u222f = class_2960.method_60655("atheryx", "images/particles/glow.png");
   private static final class_2960 obf_u00d9_u222f = class_2960.method_60655("atheryx", "images/particles/firefly.png");
   private static final class_2960 obf_u00fa_u222f = class_2960.method_60655("atheryx", "images/particles/star.png");
   private static final long obf_u03b6_u222f = 1350000000L;
   private static final double obf_u223d_u222f = -9.8000000000000007D;
   private static final double obf_u042a_u222f = 0.32000000000000001D;
   private static final double obf_u00de_u222f = 0.71999999999999997D;
   private static final float obf_u03a6_u222f = 2.3499999F;
   private static final float obf_u223c_u222f = 0.280000001F;
   private static final float obf_u03c4_u222f = 1.17999995F;
   private static final float obf_u041f_u222f = 0.720000029F;
   private static final byte obf_u041b_u222f = (byte)35;
   private static final int obf_u00f3_u222f = 30;
   private static final List<ParticleInstance> obf_u043f_u222f = new ArrayList<ParticleInstance>();
   private static final Random obf_u00da_u222f = new Random();
   public static Particles Instance;
   public final ModeSetting texture = new ModeSetting("Текстура", new String[]{"Glow", "Firefly", "Star"});
   public final MultiListSetting triggers = new MultiListSetting("Триггеры", new String[]{"При ударе", "При тотеме"});
   public final NumberSetting amount = new NumberSetting("Количество", 12.0D, (double)1.0F, 60.0D, (double)1.0F);
   public final NumberSetting speed = new NumberSetting("Скорость", (double)1.0F, 0.1, 4.0D, 0.1);
   public final NumberSetting spread = new NumberSetting("Сила разлёта", (double)1.0F, 0.1, 4.0D, 0.1);
   public final NumberSetting size = new NumberSetting("Размер", (double)1.0F, 0.3, 3.0D, 0.1);
   public final BooleanSetting themeColor = new BooleanSetting("Цвет от темы", true);
   public final ColorSetting color = new ColorSetting("Цвет", new Color(255, 255, 255));

   public Particles() {
      Instance = this;
      this.addSettings(new Setting[]{this.getTriggers(), this.getAmount(), this.getSpeed(), this.getSpread(), this.getSize(), this.getTexture(), this.getThemeColor(), this.getColor()});
      this.getThemeColor().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   public void onDisable() {
      synchronized (obf_u043f_u222f) {
         obf_u043f_u222f.clear();
      }
   }

   @EventHandler
   private void onAttackEntity(AttackEntityEvent event) {
      if (this.getTriggers().isSelected("При ударе")) {
         if (this.mc.field_1724 != null && event.getPlayer() == this.mc.field_1724) {
            this.processTarget(event.getTarget(), false);
         }
      }
   }

   @EventHandler
   private void onEntityStatus(EntityStatusEvent event) {
      if (this.getTriggers().isSelected("При тотеме")) {
         if (event.getStatusPacket().method_11470() == 35) {
            if (event.getEntity() instanceof class_1657) {
               this.processTarget(event.getEntity(), true);
            }
         }
      }
   }

   private void processTarget(class_1297 target, boolean isTotem) {
      class_243 center = target.method_73189().method_1031((double)0.0F, (double)target.method_17682() * 0.55, (double)0.0F);
      int count = isTotem ? 30 : (int)this.getAmount().getValue();
      float speedValue = (float)this.getSpeed().getValue();
      float spreadValue = (float)this.getSpread().getValue();
      float sizeValue = (float)this.getSize().getValue();
      long now = System.nanoTime();
      synchronized(obf_u043f_u222f) {
         for(int i = 0; i < count; ++i) {
            class_243 direction = this.getTargetPosition();
            double impulse = (1.15 + obf_u00da_u222f.nextDouble() * 1.55) * (double)speedValue * (double)spreadValue;
            class_243 velocity = direction.method_1021(impulse).method_1031((double)0.0F, obf_u00da_u222f.nextDouble() * (double)0.25F * (double)speedValue, (double)0.0F);
            float size = (0.13F + obf_u00da_u222f.nextFloat() * 0.08F) * sizeValue;
            float spinSpeed = -220.0F + obf_u00da_u222f.nextFloat() * 440.0F;
            boolean useGreen = isTotem && obf_u00da_u222f.nextBoolean();
            obf_u043f_u222f.add(new ParticleInstance(center, velocity, size, obf_u00da_u222f.nextFloat() * 360.0F, spinSpeed, now, useGreen));
         }

      }
   }

   private class_243 getTargetPosition() {
      double x = obf_u00da_u222f.nextDouble() * 2.0D - (double)1.0F;
      double y = obf_u00da_u222f.nextDouble() * 1.8 - (double)0.75F;
      double z = obf_u00da_u222f.nextDouble() * 2.0D - (double)1.0F;
      class_243 direction = new class_243(x, y, z);
      return direction.method_1027() < 0.001 ? new class_243((double)1.0F, (double)0.0F, (double)0.0F) : direction.method_1029();
   }

   public static void onWorldRender(WorldRenderContext context) {
      if (Instance != null && Instance.isEnabled()) {
         long now = System.nanoTime();
         List<ParticleInstance> particles;
         synchronized(obf_u043f_u222f) {
            Iterator<ParticleInstance> iterator = obf_u043f_u222f.iterator();

            while(iterator.hasNext()) {
               ParticleInstance particle = iterator.next();
               float age = (float)(now - particle.field_8f04dbbe) / 1.35e+09F;
               if (age >= 1.0F) {
                  iterator.remove();
               } else {
                  particle.refreshTarget(now);
               }
            }

            if (obf_u043f_u222f.isEmpty()) {
               return;
            }

            particles = new ArrayList<ParticleInstance>(obf_u043f_u222f);
         }

         Color selectedColor = Instance.getThemeColor().isEnabled() ? ThemeManager.getCurrentColor() : Instance.getColor().getColor();
         boolean useTheme = Instance.getThemeColor().isEnabled();
         int red = useTheme ? brightenChannel(selectedColor.getRed()) : selectedColor.getRed();
         int green = useTheme ? brightenChannel(selectedColor.getGreen()) : selectedColor.getGreen();
         int blue = useTheme ? brightenChannel(selectedColor.getBlue()) : selectedColor.getBlue();
         if (shouldProcess()) {
            class_2960 particleTexture = getParticleTexture();
            Render3DUtils.BillboardBatch batch = Render3DUtils.beginAdditiveBillboards(context, particleTexture);

            for(ParticleInstance particle : particles) {
               float age = (float)(now - particle.field_8f04dbbe) / 1.35e+09F;
               int[] colors = particle.field_695bcfa8 ? resolveCount() : resolveCount(red, green, blue);
               refreshTarget(batch, particle, age, colors[0], colors[1], colors[2]);
            }

            Render3DUtils.BillboardBatch innerGlowBatch = Render3DUtils.beginAdditiveBillboards(context, particleTexture);

            for(ParticleInstance particle : particles) {
               float age = (float)(now - particle.field_8f04dbbe) / 1.35e+09F;
               int[] colors = particle.field_695bcfa8 ? resolveCount() : resolveCount(red, green, blue);
               updateRotation(innerGlowBatch, particle, age, colors[0], colors[1], colors[2]);
            }

         } else {
            class_2960 particleTexture = getParticleTexture();
            Render3DUtils.BillboardBatch batch = Render3DUtils.beginAdditiveBillboards(context, particleTexture);

            for(ParticleInstance particle : particles) {
               float age = (float)(now - particle.field_8f04dbbe) / 1.35e+09F;
               int[] colors = particle.field_695bcfa8 ? resolveCount() : resolveCount(red, green, blue);
               advanceActionPhase(batch, particle, age, colors[0], colors[1], colors[2]);
            }

         }
      }
   }

   private static int[] resolveCount(int red, int green, int blue) {
      return new int[]{red, green, blue};
   }

   private static int[] resolveCount() {
      boolean useYellow = obf_u00da_u222f.nextBoolean();
      return useYellow ? new int[]{255, 255, 0} : new int[]{0, 255, 0};
   }

   private static class_2960 getParticleTexture() {
      if (Instance != null && Instance.getTexture().isSelected("Firefly")) {
         return obf_u00d9_u222f;
      } else {
         return Instance != null && Instance.getTexture().isSelected("Star") ? obf_u00fa_u222f : obf_u044a_u222f;
      }
   }

   private static boolean shouldProcess() {
      return Instance == null || Instance.getTexture().isSelected("Glow");
   }

   private static void refreshTarget(Render3DUtils.BillboardBatch batch, ParticleInstance particle, float age, int red, int green, int blue) {
      float alpha = calculateFadeAlpha(age);
      if (!(alpha <= 0.01F)) {
         batch.drawColoredBillboard(particle.field_6d2b79f5, calculateParticleSize(particle, age) * 2.3499999F, particle.field_b4ade7d4, red, green, blue, alpha * 0.28F);
      }
   }

   private static void updateRotation(Render3DUtils.BillboardBatch batch, ParticleInstance particle, float age, int red, int green, int blue) {
      float alpha = calculateFadeAlpha(age);
      if (!(alpha <= 0.01F)) {
         float size = calculateParticleSize(particle, age);
         batch.drawColoredBillboard(particle.field_6d2b79f5, size * 1.18F, particle.field_b4ade7d4, red, green, blue, Math.clamp(alpha * 0.72F, 0.0F, 1.0F));
         batch.drawColoredBillboard(particle.field_6d2b79f5, size, particle.field_b4ade7d4, calculateMovementSpeed(red), calculateMovementSpeed(green), calculateMovementSpeed(blue), Math.clamp(alpha * 1.25F, 0.0F, 1.0F));
      }
   }

   private static void advanceActionPhase(Render3DUtils.BillboardBatch batch, ParticleInstance particle, float age, int red, int green, int blue) {
      float alpha = calculateFadeAlpha(age);
      if (!(alpha <= 0.01F)) {
         float size = calculateParticleSize(particle, age);
         batch.drawColoredBillboard(particle.field_6d2b79f5, size * 1.18F, particle.field_b4ade7d4, red, green, blue, Math.clamp(alpha * 0.72F, 0.0F, 1.0F));
         batch.drawColoredBillboard(particle.field_6d2b79f5, size, particle.field_b4ade7d4, calculateMovementSpeed(red), calculateMovementSpeed(green), calculateMovementSpeed(blue), Math.clamp(alpha * 1.25F, 0.0F, 1.0F));
      }
   }

   private static float calculateParticleSize(ParticleInstance particle, float age) {
      float eased = 1.0F - (1.0F - age) * (1.0F - age);
      float alpha = calculateFadeAlpha(age);
      return particle.field_47826ddf * (0.65F + eased * 0.55F) * (0.18F + alpha * 0.82F);
   }

   private static float calculateFadeAlpha(float age) {
      float disappear = Math.clamp((1.0F - age) / 0.28F, 0.0F, 1.0F);
      return smoothstep(disappear);
   }

   private static float smoothstep(float value) {
      return value * value * (3.0F - 2.0F * value);
   }

   private static int brightenChannel(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.45F)), 0, 255);
   }

   private static int calculateMovementSpeed(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.72F)), 0, 255);
   }

   private void updateSettingVisibility() {
      this.getColor().setVisible(!this.getThemeColor().isEnabled());
   }

   private ModeSetting getTexture() {
      return this.texture;
   }

   private MultiListSetting getTriggers() {
      return this.triggers;
   }

   private NumberSetting getAmount() {
      return this.amount;
   }

   private NumberSetting getSpeed() {
      return this.speed;
   }

   private NumberSetting getSpread() {
      return this.spread;
   }

   private NumberSetting getSize() {
      return this.size;
   }

   private BooleanSetting getThemeColor() {
      return this.themeColor;
   }

   private ColorSetting getColor() {
      return this.color;
   }


   private static class ParticleInstance {
      private class_243 field_6d2b79f5;
      private class_243 field_da56f3ea;
      private final float field_47826ddf;
      private float field_b4ade7d4;
      private final float field_21d961c9;
      private final long field_8f04dbbe;
      private long field_fc3055b3;
      private final boolean field_695bcfa8;

      private ParticleInstance(class_243 position, class_243 velocity, float size, float rotation, float spinSpeed, long spawnedAt, boolean useGreen) {
         this.setNext(position);
         this.setVelocity(velocity);
         this.field_47826ddf = size;
         this.setRotation(rotation);
         this.field_21d961c9 = spinSpeed;
         this.field_8f04dbbe = spawnedAt;
         this.setSpawnedAt(spawnedAt);
         this.field_695bcfa8 = useGreen;
      }

      private void refreshTarget(long now) {
         if (Particles.Instance != null && Particles.Instance.mc.field_1687 != null) {
            double delta = Math.min((double)(now - this.getSpawnedAt()) / 1000000000.0D, 0.05);
            this.setSpawnedAt(now);
            this.setVelocity(this.getVelocity().method_1031((double)0.0F, -9.8000000000000007D * delta, (double)0.0F));
            class_243 next = this.getNext().method_1019(this.getVelocity().method_1021(delta));
            class_2338 floorPos = class_2338.method_49637(next.field_1352, next.field_1351 - (double)(this.getAnimationProgress() * 0.45F), next.field_1350);
            if (!Particles.Instance.mc.field_1687.method_8320(floorPos).method_26215() && this.getVelocity().field_1351 < (double)0.0F) {
               next = new class_243(next.field_1352, (double)floorPos.method_10264() + (double)1.0F + (double)(this.getAnimationProgress() * 0.45F), next.field_1350);
               this.setVelocity(new class_243(this.getVelocity().field_1352 * 0.72, Math.abs(this.getVelocity().field_1351) < 0.55 ? (double)0.0F : -this.getVelocity().field_1351 * 0.32, this.getVelocity().field_1350 * 0.72));
            }

            if (Math.abs(this.getVelocity().field_1351) < 0.02) {
               this.setVelocity(new class_243(this.getVelocity().field_1352 * 0.985, this.getVelocity().field_1351, this.getVelocity().field_1350 * 0.985));
            }

            this.setNext(next);
            this.setRotation(this.getRotation() + this.getCurrentAlpha() * (float)delta);
         }
      }

      private class_243 getNext() {
         return this.field_6d2b79f5;
      }

      private void setNext(class_243 var1) {
         this.field_6d2b79f5 = var1;
      }

      private class_243 getVelocity() {
         return this.field_da56f3ea;
      }

      private void setVelocity(class_243 var1) {
         this.field_da56f3ea = var1;
      }

      private float getAnimationProgress() {
         return this.field_47826ddf;
      }

      private float getRotation() {
         return this.field_b4ade7d4;
      }

      private void setRotation(float var1) {
         this.field_b4ade7d4 = var1;
      }

      private float getCurrentAlpha() {
         return this.field_21d961c9;
      }

      private long getLastActionTime() {
         return this.field_8f04dbbe;
      }

      private long getSpawnedAt() {
         return this.field_fc3055b3;
      }

      private void setSpawnedAt(long var1) {
         this.field_fc3055b3 = var1;
      }

      private boolean isActionPending() {
         return this.field_695bcfa8;
      }

   }
}
