package atheryx.module.render;

import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.render.pipeline.ChamsPipeline;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ColorSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.MultiListSetting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;

@NewFunction(
   name = "HandChams",
   desc = "Текстурированные чамсы для рук от первого лица",
   category = Category.RENDER
)
public class HandChams extends Function {
   public static HandChams Instance;
   private static final String obf_u223f_u222f = "Chams";
   private static final String obf_u039a_u222f = "Обводка";
   private static final String obf_u2204_u222f = "Обычная";
   private static final String obf_u0445_u222f = "Glow";
   private final MultiListSetting effektyMultiListSetting = new MultiListSetting("Эффекты", new String[]{"Chams", "Обводка"});
   private final BooleanSetting tsvetTemyBooleanSetting = new BooleanSetting("Цвет темы", true);
   private final ColorSetting tsvetColorSetting = new ColorSetting("Цвет", new Color(255, 255, 255));
   private final NumberSetting prozrachnostZalivkiNumberSetting = new NumberSetting("Прозрачность заливки", 0.65, 0.05, (double)1.0F, 0.05);
   private final ModeSetting tipZalivkiModeSetting = new ModeSetting("Тип заливки", new String[]{"Обычная", "Full", "WebShader", "Plasma", "ChamsFill", "Waves"});
   private final ModeSetting tipObvodkiModeSetting = new ModeSetting("Тип обводки", new String[]{"Обычная", "Glow"});
   private final NumberSetting shirinaObvodkiNumberSetting = new NumberSetting("Ширина обводки", 2.0D, (double)1.0F, 8.0D, (double)0.5F);
   private final NumberSetting silaSvecheniyaNumberSetting = new NumberSetting("Сила свечения", 1.15, 0.2, 3.0D, 0.05);
   private final BooleanSetting skrytTeksturuBooleanSetting = new BooleanSetting("Скрыть текстуру", false);

   public HandChams() {
      Instance = this;
      this.addSettings(new Setting[]{this.getEffectsSetting(), this.getThemeColorSetting(), this.getColorSetting(), this.getFillTransparencySetting(), this.getFillTypeSetting(), this.getOutlineTypeSetting(), this.getOutlineWidthSetting(), this.getGlowStrengthSetting(), this.getHideTextureSetting()});
      this.getEffectsSetting().setChangeListener(this::updateSettingVisibility);
      this.getThemeColorSetting().setChangeListener(this::updateSettingVisibility);
      this.getOutlineTypeSetting().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   public void refreshTarget(Runnable renderer) {
      if (this.isFeatureActive()) {
         ChamsPipeline.captureMask(renderer, false);
      }

   }

   public void applyChamsSettings() {
      if (this.isEnabled() && ChamsPipeline.hasEntityMask()) {
         Color selected = this.resolveColor();
         int outlineType = this.calculateAnimationFactor();
         if (this.getEffectsSetting().isSelected("Chams")) {
            ChamsPipeline.compositeEntityMask(selected, (float)this.getFillTransparencySetting().getValue(), this.calculateMovementSpeed(), outlineType, (float)this.getOutlineWidthSetting().getValue(), (float)this.getGlowStrengthSetting().getValue());
         } else if (outlineType != 0) {
            ChamsPipeline.compositeEntityMask(selected, 0.0F, -1, outlineType, (float)this.getOutlineWidthSetting().getValue(), (float)this.getGlowStrengthSetting().getValue());
         }
      }

   }

   public boolean isFeatureActive() {
      return this.isEnabled() && (this.getEffectsSetting().isSelected("Chams") || this.getEffectsSetting().isSelected("Обводка"));
   }

   public boolean isFeatureActivePrimary() {
      return this.isFeatureActive() && this.getHideTextureSetting().isEnabled();
   }

   private void updateSettingVisibility() {
      this.getColorSetting().setVisible(!this.getThemeColorSetting().isEnabled());
      this.getFillTransparencySetting().setVisible(this.getEffectsSetting().isSelected("Chams"));
      this.getFillTypeSetting().setVisible(this.getEffectsSetting().isSelected("Chams"));
      this.getOutlineTypeSetting().setVisible(this.getEffectsSetting().isSelected("Обводка"));
      this.getOutlineWidthSetting().setVisible(this.getEffectsSetting().isSelected("Обводка"));
      this.getGlowStrengthSetting().setVisible(this.getEffectsSetting().isSelected("Обводка") && this.getOutlineTypeSetting().isSelected("Glow"));
      this.getHideTextureSetting().setVisible(this.getEffectsSetting().isSelected("Chams") || this.getEffectsSetting().isSelected("Обводка"));
   }

   private Color resolveColor() {
      Color selected = this.getThemeColorSetting().isEnabled() ? ThemeManager.getCurrentColor() : this.getColorSetting().getColor();
      return !this.getThemeColorSetting().isEnabled() ? selected : new Color(brightenChannel(selected.getRed()), brightenChannel(selected.getGreen()), brightenChannel(selected.getBlue()));
   }

   private static int brightenChannel(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.45F)), 0, 255);
   }

   private int calculateMovementSpeed() {
      if (this.getFillTypeSetting().isSelected("Обычная")) {
         return -1;
      } else if (this.getFillTypeSetting().isSelected("Full")) {
         return 0;
      } else if (this.getFillTypeSetting().isSelected("WebShader")) {
         return 2;
      } else if (this.getFillTypeSetting().isSelected("Plasma")) {
         return 4;
      } else if (this.getFillTypeSetting().isSelected("ChamsFill")) {
         return 6;
      } else {
         return this.getFillTypeSetting().isSelected("Waves") ? 10 : -1;
      }
   }

   private int calculateAnimationFactor() {
      if (!this.getEffectsSetting().isSelected("Обводка")) {
         return 0;
      } else {
         return this.getOutlineTypeSetting().isSelected("Glow") ? 2 : 1;
      }
   }

   private MultiListSetting getEffectsSetting() {
      return this.effektyMultiListSetting;
   }

   private BooleanSetting getThemeColorSetting() {
      return this.tsvetTemyBooleanSetting;
   }

   private ColorSetting getColorSetting() {
      return this.tsvetColorSetting;
   }

   private NumberSetting getFillTransparencySetting() {
      return this.prozrachnostZalivkiNumberSetting;
   }

   private ModeSetting getFillTypeSetting() {
      return this.tipZalivkiModeSetting;
   }

   private ModeSetting getOutlineTypeSetting() {
      return this.tipObvodkiModeSetting;
   }

   private NumberSetting getOutlineWidthSetting() {
      return this.shirinaObvodkiNumberSetting;
   }

   private NumberSetting getGlowStrengthSetting() {
      return this.silaSvecheniyaNumberSetting;
   }

   private BooleanSetting getHideTextureSetting() {
      return this.skrytTeksturuBooleanSetting;
   }

}
