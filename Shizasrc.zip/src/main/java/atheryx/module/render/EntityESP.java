package atheryx.module.render;

import atheryx.gui.ThemeManager;
import atheryx.manager.FriendManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.render.pipeline.ChamsPipeline;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ColorSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.MultiSetting;
import atheryx.setting.impl.NumberSetting;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import java.awt.Color;
import java.lang.reflect.Field;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_10789;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_490;
import net.minecraft.class_572;
import net.minecraft.class_630;
import net.minecraft.class_630.class_628;
import net.minecraft.class_7833;
import net.minecraft.class_9799;
import org.joml.Matrix4f;

@NewFunction(
   name = "EntityESP",
   desc = "Текстурированные чамсы для игроков и сущностей",
   category = Category.RENDER
)
public class EntityESP extends Function {
   public static EntityESP Instance;
   public static class_4597.class_4598 skeletonConsumers;
   public static class_4597.class_4598 lineConsumers;
   public static class_4597.class_4598 chamsConsumers;
   private static final class_2960 obf_u0455_u221b;
   public static final RenderPipeline GLOW_BOX_LINES_PIPELINE;
   public static final class_1921 GLOW_BOX_LINES;
   public static final RenderPipeline GLOW_BOX_LINES_NO_DEPTH_PIPELINE;
   public static final class_1921 GLOW_BOX_LINES_NO_DEPTH;
   private static final RenderPipeline obf_u03a3_u221b;
   public static final class_1921 ENTITY_SHADER;
   private static final RenderPipeline obf_u2202_u221b;
   public static final class_1921 ENTITY_CHAMS_FILL;
   private final MultiSetting tseliMultiSetting = new MultiSetting("Цели", new String[]{"Игроки", "Сущности"});
   private final MultiSetting effektyMultiSetting = new MultiSetting("Эффекты", new String[]{"Chams", "Box", "Skeleton", "Обводка"});
   private final BooleanSetting druzyaBooleanSetting = new BooleanSetting("Друзья", false);
   private final ColorSetting tsvetDruzeyColorSetting = new ColorSetting("Цвет друзей", new Color(85, 255, 120));
   private final BooleanSetting tsvetTemyBooleanSetting = new BooleanSetting("Цвет темы", true);
   private final ColorSetting tsvetColorSetting = new ColorSetting("Цвет", new Color(255, 255, 255));
   private final NumberSetting prozrachnostZalivkiNumberSetting = new NumberSetting("Прозрачность заливки", 0.65, 0.05, (double)1.0F, 0.05);
   private final ModeSetting tipZalivkiModeSetting = new ModeSetting("Тип заливки", new String[]{"Обычная", "Full", "WebShader", "Plasma", "ChamsFill", "Waves"});
   private final BooleanSetting neVidetSkvozStenyBooleanSetting = new BooleanSetting("Не видеть сквозь стены", true);
   private final BooleanSetting obvodkaBooleanSetting = new BooleanSetting("Обводка", true);
   private final ModeSetting tipObvodkiModeSetting = new ModeSetting("Тип обводки", new String[]{"Обычная", "Glow"});
   private final NumberSetting shirinaObvodkiNumberSetting = new NumberSetting("Ширина обводки", 2.0D, (double)1.0F, 8.0D, (double)0.5F);
   private final NumberSetting silaSvecheniyaNumberSetting = new NumberSetting("Сила свечения", 1.15, 0.2, 3.0D, 0.05);
   private static Field obf_u221b_u2208;
   private static Field obf_u2208_u2208;
   private static Field obf_u222f_u2208;
   private static Field obf_u0432_u2208;
   private static Field obf_u03b2_u2208;
   private static Field obf_u220e_u2208;
   private static Field obf_u2201_u2208;
   private static Field obf_u0426_u2208;
   private static Field obf_u00c9_u2208;
   private static Field obf_u039f_u2208;
   private static Field obf_u0428_u2208;
   private static Field obf_u2216_u2208;
   private static Field obf_u2205_u2208;
   private static final DepthTestFunction obf_u00e8_u2208;

   public EntityESP() {
      Instance = this;
      this.addSettings(new Setting[]{this.getTargetsMultiSetting(), this.getEffectsMultiSetting(), this.getFriendsSetting(), this.getFriendColorSetting(), this.getThemeColorSetting(), this.getColorSetting(), this.getFillTransparencySetting(), this.getFillTypeSetting(), this.getRespectWallsSetting(), this.getOutlineSetting(), this.getOutlineTypeSetting(), this.getOutlineWidthSetting(), this.getGlowStrengthSetting()});
      this.getThemeColorSetting().setChangeListener(this::updateSettingVisibility);
      this.getFriendsSetting().setChangeListener(this::updateSettingVisibility);
      this.getEffectsMultiSetting().setChangeListener(this::updateSettingVisibility);
      this.getOutlineTypeSetting().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   public void refreshTarget(Runnable renderLiving, class_10042 state) {
      if (this.isEnabled()) {
         if (this.getEffectsMultiSetting().isSelected("Обводка") && state.field_58171 == class_1299.field_6097) {
            boolean friend = this.isValidStatePrimary(state);
            if (friend) {
               ChamsPipeline.captureFriendMask(renderLiving, this.getRespectWallsSetting().isEnabled());
            } else {
               ChamsPipeline.captureEntityMask(renderLiving, this.getRespectWallsSetting().isEnabled());
            }
         } else {
            renderLiving.run();
         }

      }
   }

   private int calculateAnimationFactor() {
      if (!this.getEffectsMultiSetting().isSelected("Обводка")) {
         return 0;
      } else {
         return this.getOutlineTypeSetting().isSelected("Glow") ? 2 : 1;
      }
   }

   public void applyChamsSettings() {
      if (this.isEnabled() && this.getEffectsMultiSetting().isSelected("Обводка")) {
         int outlineType = this.calculateAnimationFactor();
         if (outlineType != 0) {
            if (ChamsPipeline.hasEntityMask()) {
               Color selected = this.resolveColor();
               ChamsPipeline.compositeEntityMask(selected, 0.0F, -1, outlineType, (float)this.getOutlineWidthSetting().getValue(), (float)this.getGlowStrengthSetting().getValue());
            }

            if (ChamsPipeline.hasFriendMask()) {
               Color friendCol = this.getFriendColorSetting().getColor();
               ChamsPipeline.compositeFriendMask(friendCol, 0.0F, -1, outlineType, (float)this.getOutlineWidthSetting().getValue(), (float)this.getGlowStrengthSetting().getValue());
            }
         }
      }

   }

   public static void onWorldRender(WorldRenderContext context) {
      class_310 mc = class_310.method_1551();
      Matrix4f proj = mc.field_1773.method_22973(((Integer)mc.field_1690.method_41808().method_41753()).floatValue());
      Matrix4f viewProj = new Matrix4f(proj);
      viewProj.mul(context.matrices().method_23760().method_23761());
      ChamsPipeline.capturedInvViewProj = viewProj.invert();
      EntityESP esp = (EntityESP)FunctionManager.getFunction(EntityESP.class);
      if (esp != null && esp.isEnabled()) {
         if (esp.getEffectsMultiSetting().isSelected("Box")) {
            esp.renderWorldOverlay(context);
         }

         if (esp.getEffectsMultiSetting().isSelected("Обводка") && ChamsPipeline.hasCapturedMask()) {
            esp.applyChamsSettings();
         }
      }

      if (skeletonConsumers != null) {
         skeletonConsumers.method_22993();
      }

      if (lineConsumers != null) {
         lineConsumers.method_22993();
      }

      if (chamsConsumers != null) {
         chamsConsumers.method_22993();
      }

      ChamsPipeline.resetCaptureState();
   }

   public boolean matchesState(class_10042 state) {
      if (this.isEnabled() && state != null && !state.field_53333) {
         if (!this.getEffectsMultiSetting().isSelected("Chams") && !this.getEffectsMultiSetting().isSelected("Skeleton") && !this.getEffectsMultiSetting().isSelected("Обводка")) {
            return false;
         } else if (state.field_58171 == class_1299.field_6097) {
            if (this.isValidState(state)) {
               return false;
            } else {
               return this.isValidStatePrimary(state) ? this.getFriendsSetting().isEnabled() : this.getTargetsMultiSetting().isSelected("Игроки");
            }
         } else {
            return this.getTargetsMultiSetting().isSelected("Сущности");
         }
      } else {
         return false;
      }
   }

   public boolean matchesStatePrimary(class_10042 state) {
      return this.isEnabled() && this.getEffectsMultiSetting().isSelected("Chams") && this.matchesState(state);
   }

   private void renderWorldOverlay(WorldRenderContext context) {
      if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
         class_4587.class_4665 entry = context.matrices().method_23760();
         class_243 camera = context.worldState().field_63082.field_63078;
         float tickDelta = this.mc.method_61966().method_60637(false);

         for(class_1297 entity : this.mc.field_1687.method_18112()) {
            class_1309 living;
            if (entity instanceof class_1309 && this.isValidEntity(living = (class_1309)entity)) {
               class_1657 player;
               boolean friend = entity instanceof class_1657 && FriendManager.isFriend((player = (class_1657)entity).method_5477().getString());
               Color renderColor = friend ? this.getFriendColorSetting().getColor() : this.resolveColor();
               class_243 lerped = entity.method_30950(tickDelta);
               class_243 offset = lerped.method_1020(entity.method_73189());
               class_238 box = entity.method_5829().method_997(offset).method_989(-camera.field_1352, -camera.field_1351, -camera.field_1350);
               this.processPosition(context.consumers(), entry, box, renderColor, (float)this.getFillTransparencySetting().getValue());
            }
         }

      }
   }

   private void processPosition(class_4597 consumers, class_4587.class_4665 entry, class_238 box, Color color, float alpha) {
      if (!(alpha <= 0.0F)) {
         class_4588 fillBuffer = consumers.method_73477(class_12249.method_75984(obf_u0455_u221b, false));
         this.drawGeometry(fillBuffer, entry, box, this.withAlpha(color, alpha * 0.18F));
         class_4588 lineBuffer = consumers.method_73477(this.getRespectWallsSetting().isEnabled() ? GLOW_BOX_LINES : GLOW_BOX_LINES_NO_DEPTH);
         this.drawBox(lineBuffer, entry, box, this.withAlpha(color, alpha), 2.5F);
      }
   }

   private void drawGeometry(class_4588 buffer, class_4587.class_4665 entry, class_238 box, Color color) {
      this.emitVertex(buffer, entry, color, box.field_1323, box.field_1325, box.field_1324, box.field_1320, box.field_1325, box.field_1324, box.field_1320, box.field_1325, box.field_1321, box.field_1323, box.field_1325, box.field_1321);
      this.emitVertex(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1324);
      this.emitVertex(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1323, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1321, box.field_1320, box.field_1322, box.field_1321);
      this.emitVertex(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1320, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1324, box.field_1323, box.field_1322, box.field_1324);
      this.emitVertex(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1321, box.field_1323, box.field_1322, box.field_1321);
      this.emitVertex(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1324, box.field_1320, box.field_1322, box.field_1324);
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, double x1, double y1, double z1, double x2, double y2, double z2, double x3, double y3, double z3, double x4, double y4, double z4) {
      this.emitVertex(buffer, entry, color, x1, y1, z1, 0.0F, 1.0F);
      this.emitVertex(buffer, entry, color, x2, y2, z2, 1.0F, 1.0F);
      this.emitVertex(buffer, entry, color, x3, y3, z3, 1.0F, 0.0F);
      this.emitVertex(buffer, entry, color, x4, y4, z4, 0.0F, 0.0F);
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, double x, double y, double z, float u, float v) {
      buffer.method_56824(entry, (float)x, (float)y, (float)z).method_22913(u, v).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).method_22922(class_4608.field_21444).method_60803(15728880).method_60831(entry, 0.0F, 1.0F, 0.0F);
   }

   private void drawBox(class_4588 buffer, class_4587.class_4665 entry, class_238 box, Color color, float width) {
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1323, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1321, width);
      this.emitLine(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1320, box.field_1325, box.field_1324, width);
      this.emitLine(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1325, box.field_1324, width);
   }

   private void emitLine(class_4588 buffer, class_4587.class_4665 entry, Color color, double x1, double y1, double z1, double x2, double y2, double z2, float width) {
      float dx = (float)(x2 - x1);
      float dy = (float)(y2 - y1);
      float dz = (float)(z2 - z1);
      float length = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
      if (!(length <= 1.0E-4F)) {
         buffer.method_56824(entry, (float)x1, (float)y1, (float)z1).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
         buffer.method_56824(entry, (float)x2, (float)y2, (float)z2).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
      }
   }

   private Color withAlpha(Color color, float alpha) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F));
   }

   private boolean isValidEntity(class_1309 entity) {
      if (entity.method_5805() && !entity.method_5767()) {
         if (entity == this.mc.field_1724) {
            return false;
         } else if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            return FriendManager.isFriend(player.method_5477().getString()) ? this.getFriendsSetting().isEnabled() : this.getTargetsMultiSetting().isSelected("Игроки");
         } else {
            return this.getTargetsMultiSetting().isSelected("Сущности");
         }
      } else {
         return false;
      }
   }

   private boolean isValidState(class_10042 state) {
      if (!(this.mc.field_1755 instanceof class_490)) {
         return false;
      } else if (this.mc.field_1724 == null) {
         return false;
      } else if (!(state instanceof class_10055)) {
         return false;
      } else {
         class_10055 playerState = (class_10055)state;
         return playerState.field_53528 == this.mc.field_1724.method_5628();
      }
   }

   private boolean isValidEntity(class_1297 entity) {
      return this.mc.field_1755 instanceof class_490 && this.mc.field_1724 != null && entity == this.mc.field_1724;
   }

   private void updateSettingVisibility() {
      this.getColorSetting().setVisible(!this.getThemeColorSetting().isEnabled());
      this.getFriendColorSetting().setVisible(this.getFriendsSetting().isEnabled());
      this.getFillTransparencySetting().setVisible(this.getEffectsMultiSetting().isSelected("Chams"));
      this.getFillTypeSetting().setVisible(this.getEffectsMultiSetting().isSelected("Chams"));
      this.getRespectWallsSetting().setVisible(this.getEffectsMultiSetting().isSelected("Chams") || this.getEffectsMultiSetting().isSelected("Обводка"));
      this.getOutlineSetting().setVisible(this.getEffectsMultiSetting().isSelected("Chams"));
      boolean hasOutline = this.getEffectsMultiSetting().isSelected("Обводка");
      this.getOutlineTypeSetting().setVisible(hasOutline);
      this.getOutlineWidthSetting().setVisible(hasOutline);
      this.getGlowStrengthSetting().setVisible(hasOutline && this.getOutlineTypeSetting().isSelected("Glow"));
   }

   private boolean isValidStatePrimary(class_10042 state) {
      if (state instanceof class_10055 playerState) {
         if (this.mc.field_1687 != null) {
            class_1297 entity = this.mc.field_1687.method_8469(playerState.field_53528);
            if (!(entity instanceof class_1657)) {
               return false;
            }

            class_1657 player = (class_1657)entity;
            return FriendManager.isFriend(player.method_5477().getString());
         }
      }

      return false;
   }

   private Color resolveColor() {
      Color selected = this.getThemeColorSetting().isEnabled() ? ThemeManager.getCurrentColor() : this.getColorSetting().getColor();
      return !this.getThemeColorSetting().isEnabled() ? selected : new Color(brightenChannel(selected.getRed()), brightenChannel(selected.getGreen()), brightenChannel(selected.getBlue()));
   }

   private static int brightenChannel(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.45F)), 0, 255);
   }

   private int getShaderMode() {
      if (this.getFillTypeSetting().isSelected("Обычная")) {
         return 10;
      } else if (this.getFillTypeSetting().isSelected("Full")) {
         return 0;
      } else if (this.getFillTypeSetting().isSelected("WebShader")) {
         return 2;
      } else if (this.getFillTypeSetting().isSelected("Plasma")) {
         return 4;
      } else if (this.getFillTypeSetting().isSelected("ChamsFill")) {
         return 6;
      } else {
         return this.getFillTypeSetting().isSelected("Waves") ? 8 : 10;
      }
   }

   private float calculateAnimationFactor(class_630 part, Field f) {
      try {
         return f != null ? f.getFloat(part) : 0.0F;
      } catch (Exception var4) {
         return 0.0F;
      }
   }

   public boolean isFeatureActive() {
      return this.isEnabled() && this.getEffectsMultiSetting().isSelected("Chams");
   }

   public boolean isFeatureActivePrimary() {
      return this.isEnabled() && this.getEffectsMultiSetting().isSelected("Skeleton");
   }

   public boolean isFeatureActiveSecondary() {
      return this.isEnabled() && this.getEffectsMultiSetting().isSelected("Обводка");
   }

   public boolean isFeatureActiveCurrent() {
      return this.getRespectWallsSetting().isEnabled();
   }

   public void prepareInteraction(class_4587 matrices, class_4597 consumers, class_572<?> model, class_10042 state) {
      if (this.mc.field_1724 != null) {
         if (state instanceof class_10055) {
            class_10055 playerState = (class_10055)state;
            if (playerState.field_53528 == this.mc.field_1724.method_5628() && this.mc.field_1690.method_31044().method_31034()) {
               return;
            }
         }

         Color renderColor = this.isValidStatePrimary(state) ? this.getFriendColorSetting().getColor() : this.resolveColor();
         float alpha = (float)this.getFillTransparencySetting().getValue();
         if (!(alpha <= 0.0F)) {
            class_4588 buffer = consumers.method_73477(GLOW_BOX_LINES_NO_DEPTH);
            float lineW = 2.0F;
            matrices.method_22903();
            matrices.method_22905(0.0625F, 0.0625F, 0.0625F);
            class_4587.class_4665 entry = matrices.method_23760();
            this.emitLineWithAlpha(buffer, entry, renderColor, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, 12.0D, (double)0.0F, lineW, alpha);
            float rArmX = this.calculateAnimationFactor(model.field_3401, obf_u221b_u2208);
            this.calculateAnimationFactor(model.field_3401, obf_u2208_u2208);
            float rArmZ = this.calculateAnimationFactor(model.field_3401, obf_u222f_u2208);
            float lArmX = this.calculateAnimationFactor(model.field_27433, obf_u221b_u2208);
            this.calculateAnimationFactor(model.field_27433, obf_u2208_u2208);
            float lArmZ = this.calculateAnimationFactor(model.field_27433, obf_u222f_u2208);
            float shoulderY = 1.0F;
            float rShoulderX = rArmX - 1.0F;
            float lShoulderX = lArmX + 1.0F;
            this.emitLineWithAlpha(buffer, entry, renderColor, (double)rShoulderX, (double)shoulderY, (double)rArmZ, (double)lShoulderX, (double)shoulderY, (double)lArmZ, lineW, alpha);
            this.emitLineWithAlpha(buffer, entry, renderColor, (double)0.0F, 12.0D, (double)0.0F, (double)this.calculateAnimationFactor(model.field_3392, obf_u221b_u2208), (double)this.calculateAnimationFactor(model.field_3392, obf_u2208_u2208), (double)this.calculateAnimationFactor(model.field_3392, obf_u222f_u2208), lineW, alpha);
            this.emitLineWithAlpha(buffer, entry, renderColor, (double)0.0F, 12.0D, (double)0.0F, (double)this.calculateAnimationFactor(model.field_3397, obf_u221b_u2208), (double)this.calculateAnimationFactor(model.field_3397, obf_u2208_u2208), (double)this.calculateAnimationFactor(model.field_3397, obf_u222f_u2208), lineW, alpha);
            matrices.method_22903();
            this.advanceActionPhase(matrices, model.field_3398);
            this.emitLineWithAlpha(buffer, matrices.method_23760(), renderColor, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, -4.0D, (double)0.0F, lineW, alpha);
            matrices.method_22909();
            matrices.method_22903();
            this.advanceActionPhase(matrices, model.field_3401);
            this.emitLineWithAlpha(buffer, matrices.method_23760(), renderColor, (double)-1.0F, (double)-1.0F, (double)0.0F, (double)-1.0F, 10.0D, (double)0.0F, lineW, alpha);
            matrices.method_22909();
            matrices.method_22903();
            this.advanceActionPhase(matrices, model.field_27433);
            this.emitLineWithAlpha(buffer, matrices.method_23760(), renderColor, (double)1.0F, (double)-1.0F, (double)0.0F, (double)1.0F, 10.0D, (double)0.0F, lineW, alpha);
            matrices.method_22909();
            matrices.method_22903();
            this.advanceActionPhase(matrices, model.field_3392);
            this.emitLineWithAlpha(buffer, matrices.method_23760(), renderColor, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, 12.0D, (double)0.0F, lineW, alpha);
            matrices.method_22909();
            matrices.method_22903();
            this.advanceActionPhase(matrices, model.field_3397);
            this.emitLineWithAlpha(buffer, matrices.method_23760(), renderColor, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, 12.0D, (double)0.0F, lineW, alpha);
            matrices.method_22909();
            matrices.method_22909();
         }
      }
   }

   public void resetTransientState(class_4587 matrices, class_4597 consumers, class_572<?> model, class_10042 state) {
      boolean chamsFill = this.getFillTypeSetting().isSelected("ChamsFill");
      class_1921 layer;
      if (this.getRespectWallsSetting().isEnabled()) {
         layer = chamsFill ? ENTITY_CHAMS_FILL : ENTITY_SHADER;
      } else {
         layer = chamsFill ? BlockOverlay.SEE_THROUGH_CHAMS_FILL : BlockOverlay.SEE_THROUGH_SHADER;
      }

      class_4588 fillBuffer = consumers.method_73477(layer);
      if (lineConsumers == null) {
         lineConsumers = class_4597.method_22991(new class_9799(786432));
      }

      class_4588 lineBuffer = lineConsumers.method_73477(this.getRespectWallsSetting().isEnabled() ? GLOW_BOX_LINES : GLOW_BOX_LINES_NO_DEPTH);
      boolean friend = this.isValidStatePrimary(state);
      Color lineColor = friend ? this.getFriendColorSetting().getColor() : this.resolveColor();
      Color fillColor = this.resolveColor();
      float alpha = (float)this.getFillTransparencySetting().getValue();
      float modeOffset = chamsFill ? 0.0F : (float)this.getShaderMode() * 2.0F;
      matrices.method_22903();
      matrices.method_22905(0.0625F, 0.0625F, 0.0625F);
      this.emitVertex(fillBuffer, lineBuffer, matrices, model.field_3391, fillColor, lineColor, alpha, modeOffset);
      this.emitVertex(fillBuffer, lineBuffer, matrices, model.field_3398, fillColor, lineColor, alpha, modeOffset);
      this.emitVertex(fillBuffer, lineBuffer, matrices, model.field_3401, fillColor, lineColor, alpha, modeOffset);
      this.emitVertex(fillBuffer, lineBuffer, matrices, model.field_27433, fillColor, lineColor, alpha, modeOffset);
      this.emitVertex(fillBuffer, lineBuffer, matrices, model.field_3392, fillColor, lineColor, alpha, modeOffset);
      this.emitVertex(fillBuffer, lineBuffer, matrices, model.field_3397, fillColor, lineColor, alpha, modeOffset);
      matrices.method_22909();
   }

   private void emitVertex(class_4588 fillBuffer, class_4588 lineBuffer, class_4587 matrices, class_630 part, Color fillColor, Color lineColor, float alpha, float modeOffset) {
      if (obf_u2201_u2208 == null) {
         return;
      }

      try {
         @SuppressWarnings("unchecked")
         List<class_628> cuboids = (List<class_628>)obf_u2201_u2208.get(part);
         if (cuboids == null || cuboids.isEmpty()) {
            return;
         }

         matrices.method_22903();
         this.advanceActionPhase(matrices, part);
         class_4587.class_4665 entry = matrices.method_23760();

         for (class_628 cuboid : cuboids) {
            float expansion = 0.25F;
            float minX = obf_u0426_u2208.getFloat(cuboid) - expansion;
            float minY = obf_u00c9_u2208.getFloat(cuboid) - expansion;
            float minZ = obf_u039f_u2208.getFloat(cuboid) - expansion;
            float maxX = obf_u0428_u2208.getFloat(cuboid) + expansion;
            float maxY = obf_u2216_u2208.getFloat(cuboid) + expansion;
            float maxZ = obf_u2205_u2208.getFloat(cuboid) + expansion;

            this.emitVertex(fillBuffer, entry, fillColor, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ, minX, maxY, minZ, alpha, modeOffset);
            this.emitVertex(fillBuffer, entry, fillColor, minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ, minX, minY, maxZ, alpha, modeOffset);
            this.emitVertex(fillBuffer, entry, fillColor, minX, minY, minZ, minX, maxY, minZ, maxX, maxY, minZ, maxX, minY, minZ, alpha, modeOffset);
            this.emitVertex(fillBuffer, entry, fillColor, maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ, minX, minY, maxZ, alpha, modeOffset);
            this.emitVertex(fillBuffer, entry, fillColor, minX, minY, maxZ, minX, maxY, maxZ, minX, maxY, minZ, minX, minY, minZ, alpha, modeOffset);
            this.emitVertex(fillBuffer, entry, fillColor, maxX, minY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, maxX, minY, maxZ, alpha, modeOffset);

            if (this.getOutlineSetting().isEnabled()) {
               class_238 box = new class_238(minX, minY, minZ, maxX, maxY, maxZ);
               this.drawBox(lineBuffer, entry, box, lineColor, 2.0F);
            }
         }

         matrices.method_22909();
      } catch (Exception ignored) {
      }
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float x4, float y4, float z4, float alpha, float modeOffset) {
      this.emitVertex(buffer, entry, color, x1, y1, z1, 0.0F, 1.0F + modeOffset, alpha);
      this.emitVertex(buffer, entry, color, x2, y2, z2, 1.0F, 1.0F + modeOffset, alpha);
      this.emitVertex(buffer, entry, color, x3, y3, z3, 1.0F, 0.0F + modeOffset, alpha);
      this.emitVertex(buffer, entry, color, x4, y4, z4, 0.0F, 0.0F + modeOffset, alpha);
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, float x, float y, float z, float u, float v, float alpha) {
      buffer.method_56824(entry, x, y, z).method_22913(u, v).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F));
   }

   private void advanceActionPhase(class_4587 matrices, class_630 part) {
      matrices.method_46416(this.calculateAnimationFactor(part, obf_u221b_u2208), this.calculateAnimationFactor(part, obf_u2208_u2208), this.calculateAnimationFactor(part, obf_u222f_u2208));
      float r = this.calculateAnimationFactor(part, obf_u220e_u2208);
      if (r != 0.0F) {
         matrices.method_22907(class_7833.field_40718.rotation(r));
      }

      float y;
      if ((y = this.calculateAnimationFactor(part, obf_u03b2_u2208)) != 0.0F) {
         matrices.method_22907(class_7833.field_40716.rotation(y));
      }

      float p;
      if ((p = this.calculateAnimationFactor(part, obf_u0432_u2208)) != 0.0F) {
         matrices.method_22907(class_7833.field_40714.rotation(p));
      }

   }

   private void emitLineWithAlpha(class_4588 buffer, class_4587.class_4665 entry, Color color, double x1, double y1, double z1, double x2, double y2, double z2, float width, float alpha) {
      float dx = (float)(x2 - x1);
      float dy = (float)(y2 - y1);
      float dz = (float)(z2 - z1);
      float length = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
      if (!(length <= 1.0E-4F)) {
         buffer.method_56824(entry, (float)x1, (float)y1, (float)z1).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F)).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
         buffer.method_56824(entry, (float)x2, (float)y2, (float)z2).method_1336(color.getRed(), color.getGreen(), color.getBlue(), (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F)).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
      }
   }

   private static DepthTestFunction resolveDepthTestFunction() {
      return DepthTestFunction.LEQUAL_DEPTH_TEST;
   }

   static {
      obf_u00e8_u2208 = resolveDepthTestFunction();
      obf_u0455_u221b = class_2960.method_60655("minecraft", "textures/block/white_concrete.png");
      GLOW_BOX_LINES_PIPELINE = class_10799.method_67887(
         RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56859})
            .withLocation(class_2960.method_60655("atheryx", "entitychams_glow_box_lines"))
            .withBlend(BlendFunction.LIGHTNING)
            .withDepthTestFunction(obf_u00e8_u2208)
            .withDepthWrite(false)
            .build()
      );
      GLOW_BOX_LINES = class_1921.method_75940(
         "atheryx_entitychams_glow_box_lines",
         class_12247.method_75927(GLOW_BOX_LINES_PIPELINE)
            .method_75930(class_12245.field_63976)
            .method_75931(class_12246.field_63983)
            .method_75938()
      );
      GLOW_BOX_LINES_NO_DEPTH_PIPELINE = class_10799.method_67887(
         RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56859})
            .withLocation(class_2960.method_60655("atheryx", "entitychams_glow_box_lines_no_depth"))
            .withBlend(BlendFunction.LIGHTNING)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .build()
      );
      GLOW_BOX_LINES_NO_DEPTH = class_1921.method_75940(
         "atheryx_entitychams_glow_box_lines_no_depth",
         class_12247.method_75927(GLOW_BOX_LINES_NO_DEPTH_PIPELINE)
            .method_75930(class_12245.field_63976)
            .method_75931(class_12246.field_63983)
            .method_75938()
      );
      obf_u03a3_u221b = class_10799.method_67887(
         RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56864})
            .withLocation(class_2960.method_60655("atheryx", "entityesp_shader"))
            .withVertexShader(class_2960.method_60655("atheryx", "block_overlay_shader_vertex"))
            .withFragmentShader(class_2960.method_60655("atheryx", "block_overlay_shader_fragment"))
            .withUniform("Globals", class_10789.field_60031)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(obf_u00e8_u2208)
            .withDepthWrite(false)
            .withCull(false)
            .build()
      );
      ENTITY_SHADER = class_1921.method_75940(
         "atheryx_entityesp_shader",
         class_12247.method_75927(obf_u03a3_u221b)
            .method_75934("Sampler0", obf_u0455_u221b)
            .method_75937()
            .method_75931(class_12246.field_63983)
            .method_75929(1536)
            .method_75938()
      );
      obf_u2202_u221b = class_10799.method_67887(
         RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56864})
            .withLocation(class_2960.method_60655("atheryx", "entityesp_chams_fill"))
            .withVertexShader(class_2960.method_60655("atheryx", "block_overlay_shader_vertex"))
            .withFragmentShader(class_2960.method_60655("atheryx", "block_overlay_chams_fill_fragment"))
            .withUniform("Globals", class_10789.field_60031)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(obf_u00e8_u2208)
            .withDepthWrite(false)
            .withCull(false)
            .build()
      );
      ENTITY_CHAMS_FILL = class_1921.method_75940(
         "atheryx_entityesp_chams_fill",
         class_12247.method_75927(obf_u2202_u221b)
            .method_75934("Sampler0", obf_u0455_u221b)
            .method_75937()
            .method_75931(class_12246.field_63983)
            .method_75929(1536)
            .method_75938()
      );

      try {
         obf_u221b_u2208 = class_630.class.getDeclaredField("originX");
         obf_u221b_u2208.setAccessible(true);
         obf_u2208_u2208 = class_630.class.getDeclaredField("originY");
         obf_u2208_u2208.setAccessible(true);
         obf_u222f_u2208 = class_630.class.getDeclaredField("originZ");
         obf_u222f_u2208.setAccessible(true);
         obf_u0432_u2208 = class_630.class.getDeclaredField("pitch");
         obf_u0432_u2208.setAccessible(true);
         obf_u03b2_u2208 = class_630.class.getDeclaredField("yaw");
         obf_u03b2_u2208.setAccessible(true);
         obf_u220e_u2208 = class_630.class.getDeclaredField("roll");
         obf_u220e_u2208.setAccessible(true);
         obf_u2201_u2208 = class_630.class.getDeclaredField("cuboids");
         obf_u2201_u2208.setAccessible(true);

         Class<class_628> cuboidClass = class_628.class;
         obf_u0426_u2208 = cuboidClass.getDeclaredField("minX");
         obf_u0426_u2208.setAccessible(true);
         obf_u00c9_u2208 = cuboidClass.getDeclaredField("minY");
         obf_u00c9_u2208.setAccessible(true);
         obf_u039f_u2208 = cuboidClass.getDeclaredField("minZ");
         obf_u039f_u2208.setAccessible(true);
         obf_u0428_u2208 = cuboidClass.getDeclaredField("maxX");
         obf_u0428_u2208.setAccessible(true);
         obf_u2216_u2208 = cuboidClass.getDeclaredField("maxY");
         obf_u2216_u2208.setAccessible(true);
         obf_u2205_u2208 = cuboidClass.getDeclaredField("maxZ");
         obf_u2205_u2208.setAccessible(true);
      } catch (Exception ignored) {
      }
   }

   private MultiSetting getTargetsMultiSetting() {
      return this.tseliMultiSetting;
   }

   private MultiSetting getEffectsMultiSetting() {
      return this.effektyMultiSetting;
   }

   private BooleanSetting getFriendsSetting() {
      return this.druzyaBooleanSetting;
   }

   private ColorSetting getFriendColorSetting() {
      return this.tsvetDruzeyColorSetting;
   }

   private BooleanSetting getThemeColorSetting() {
      return this.tsvetTemyBooleanSetting;
   }

   private ColorSetting getColorSetting() {
      return this.tsvetColorSetting;
   }

   private NumberSetting getFillTransparencySetting() {
      return this.prozrachnostZalivkiNumberSetting;
   }

   private ModeSetting getFillTypeSetting() {
      return this.tipZalivkiModeSetting;
   }

   private BooleanSetting getRespectWallsSetting() {
      return this.neVidetSkvozStenyBooleanSetting;
   }

   private BooleanSetting getOutlineSetting() {
      return this.obvodkaBooleanSetting;
   }

   private ModeSetting getOutlineTypeSetting() {
      return this.tipObvodkiModeSetting;
   }

   private NumberSetting getOutlineWidthSetting() {
      return this.shirinaObvodkiNumberSetting;
   }

   private NumberSetting getGlowStrengthSetting() {
      return this.silaSvecheniyaNumberSetting;
   }

}
