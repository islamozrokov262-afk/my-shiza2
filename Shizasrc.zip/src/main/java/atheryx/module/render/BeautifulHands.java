package atheryx.module.render;

import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.NumberSetting;
import net.minecraft.class_1306;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

@NewFunction(
   name = "BeautifulHands",
   desc = "Shows first-person hands while holding items",
   category = Category.RENDER
)
public class BeautifulHands extends Function {
   public static BeautifulHands Instance;
   private final NumberSetting skorostAnimatsiyNumberSetting = new NumberSetting("Скорость анимаций", 30.0D, (double)1.0F, 80.0D, (double)1.0F);
   private final NumberSetting skorostVzmahaNumberSetting = new NumberSetting("Скорость взмаха", 6.0D, (double)1.0F, 20.0D, (double)1.0F);
   private final BooleanSetting animatsiyaDvizheniyaBooleanSetting = new BooleanSetting("Анимация движения", true);
   private final BooleanSetting pustayaRukaBooleanSetting = new BooleanSetting("Пустая рука", true);
   private final NumberSetting pravayaXNumberSetting = new NumberSetting("Правая X", (double)0.0F, -2.0D, 2.0D, 0.05);
   private final NumberSetting pravayaYNumberSetting = new NumberSetting("Правая Y", (double)0.0F, -2.0D, 2.0D, 0.05);
   private final NumberSetting pravayaZNumberSetting = new NumberSetting("Правая Z", (double)0.0F, -2.0D, 2.0D, 0.05);
   private final NumberSetting levayaXNumberSetting = new NumberSetting("Левая X", (double)0.0F, -2.0D, 2.0D, 0.05);
   private final NumberSetting levayaYNumberSetting = new NumberSetting("Левая Y", (double)0.0F, -2.0D, 2.0D, 0.05);
   private final NumberSetting levayaZNumberSetting = new NumberSetting("Левая Z", (double)0.0F, -2.0D, 2.0D, 0.05);
   private final NumberSetting pozitsiyaXNumberSetting = new NumberSetting("Позиция X", 0.7, -2.0D, 2.0D, 0.05);
   private final NumberSetting pozitsiyaYNumberSetting = new NumberSetting("Позиция Y", 1.3, -2.0D, 2.0D, 0.05);
   private final NumberSetting pozitsiyaZNumberSetting = new NumberSetting("Позиция Z", 0.2, -2.0D, 2.0D, 0.05);
   private final NumberSetting vraschenieXMechNumberSetting = new NumberSetting("Вращение X (Меч)", -70.0D, -180.0D, 180.0D, 5.0D);
   private final NumberSetting vraschenieYMechNumberSetting = new NumberSetting("Вращение Y (Меч)", 25.0D, -180.0D, 180.0D, 5.0D);
   private final NumberSetting vraschenieZMechNumberSetting = new NumberSetting("Вращение Z (Меч)", -15.0D, -180.0D, 180.0D, 5.0D);
   private long field_3fe31945;
   private float field_ad0e933a;
   private float field_1a3a0d2f;
   private float field_87658724;
   private float field_f4910119;
   private float field_61bc7b0e;
   private float field_cee7f503;
   private float field_3c136ef8;
   private float field_a93ee8ed;
   private boolean field_166a62e2;
   private boolean field_8395dcd7;

   public BeautifulHands() {
      this.setNow(System.nanoTime());
      Instance = this;
      this.addSettings(new Setting[]{this.getAnimationSpeedSetting(), this.getSwingSpeedSetting(), this.getMovementAnimationSetting(), this.getEmptyHandSetting(), this.getRightXSetting(), this.getRightYSetting(), this.getRightZSetting(), this.getLeftXSetting(), this.getLeftYSetting(), this.getLeftZSetting(), this.getPositionXSetting(), this.getPositionYSetting(), this.getPositionZSetting(), this.getMechanicalRotationXSetting(), this.getMechanicalRotationYSetting(), this.getMechanicalRotationZSetting()});
   }

   public void refreshTarget(class_4587 matrices, class_1306 arm) {
      if (this.isEnabled()) {
         if (arm == class_1306.field_6183) {
            matrices.method_22904(this.getRightXSetting().getValue(), this.getRightYSetting().getValue(), this.getRightZSetting().getValue());
         } else {
            matrices.method_22904(this.getLeftXSetting().getValue(), this.getLeftYSetting().getValue(), this.getLeftZSetting().getValue());
         }

      }
   }

   public float calculateAnimationFactor(float swingProgress) {
      return 0.0F;
   }

   public double calculateAnimationFactor() {
      long now = System.nanoTime();
      double delta = Math.min((double)(now - this.getNow()) / 1000000000.0D, 0.05);
      this.setNow(now);
      return delta * this.getAnimationSpeedSetting().getValue();
   }

   public boolean isFeatureActive() {
      return this.isEnabled() && this.getEmptyHandSetting().isEnabled();
   }

   public boolean isFeatureActivePrimary() {
      return this.getMovementAnimationSetting().isEnabled();
   }

   public boolean shouldProcess() {
      return false;
   }

   public int calculateAnimationFactor(int vanillaDuration) {
      return this.isEnabled() ? Math.max(1, (int)Math.round(this.getSwingSpeedSetting().getValue())) : vanillaDuration;
   }

   public boolean isValidAttackKeyPressed(boolean attackKeyPressed, float swingProgress) {
      if (attackKeyPressed && !this.isAttackKeyPressed() && swingProgress == 0.0F) {
         this.setActionPending(!this.isActionPending());
      }

      this.setAttackKeyPressed(attackKeyPressed);
      return this.isActionPending();
   }

   public float calculateMovementSpeed(float x) {
      float c1 = 1.70158F;
      float c2 = c1 * 1.525F;
      return x < 0.5F ? (float)(Math.pow((double)(2.0F * x), 2.0D) * (double)((c2 + 1.0F) * 2.0F * x - c2) / 2.0D) : (float)((Math.pow((double)(2.0F * x - 2.0F), 2.0D) * (double)((c2 + 1.0F) * (x * 2.0F - 2.0F) + c2) + 2.0D) / 2.0D);
   }

   public float calculateTargetDistance(float swingProgress) {
      return swingProgress < 0.6F ? class_3532.method_15374((double)(class_3532.method_15363(swingProgress, 0.0F, 0.12506F) * 12.5600004F)) : class_3532.method_15374((double)(class_3532.method_15363(swingProgress, 0.62532F, 0.75038F) * 12.5600004F));
   }

   public void updateRotation(class_4587 matrices, class_1306 arm, double horizontalSpeed, double verticalSpeed, float yawDelta, float pitchDelta, float swingProgress, double frameStep) {
      if (this.getMovementAnimationSetting().isEnabled()) {
         int side = arm == class_1306.field_6183 ? 1 : -1;
         this.setYawOffset(this.getYawOffset() + (float)(horizontalSpeed * 0.7 * frameStep));
         matrices.method_22904((double)((float)side * class_3532.method_15374((double)this.getYawOffset())) * horizontalSpeed * 0.05, (double)class_3532.method_15362((double)(this.getYawOffset() * 2.0F)) * horizontalSpeed * 0.045, (double)class_3532.method_15374((double)(this.getYawOffset() * 0.5F)) * horizontalSpeed * 0.025);
         this.setTargetAlpha((float)((double)this.getTargetAlpha() + (double)(yawDelta * 0.015F) * frameStep));
         this.setTargetAlpha((float)((double)this.getTargetAlpha() + (double)(swingProgress * 0.65F) * frameStep));
         this.setRenderX((float)((double)this.getRenderX() + (double)(pitchDelta * 0.015F) * frameStep));
         this.setTargetAlpha((float)((double)this.getTargetAlpha() - (double)(this.getAnimationProgress() * 0.1F) * frameStep));
         this.setRenderX((float)((double)this.getRenderX() - (double)(this.getCurrentAlpha() * 0.1F) * frameStep));
         this.setTargetAlpha(this.getTargetAlpha() * (float)Math.pow((double)0.88F, frameStep));
         this.setRenderX(this.getRenderX() * (float)Math.pow((double)0.88F, frameStep));
         this.setAnimationProgress((float)((double)this.getAnimationProgress() + (double)this.getTargetAlpha() * frameStep));
         this.setCurrentAlpha((float)((double)this.getCurrentAlpha() + (double)this.getRenderX() * frameStep));
         this.setRenderY(this.getRenderY() + (float)(((arm == class_1306.field_6183 ? -horizontalSpeed : horizontalSpeed) * 15.0D - (double)this.getRenderY()) * 0.1 * frameStep));
         matrices.method_22907(class_7833.field_40716.rotationDegrees(this.getAnimationProgress() * 0.65F));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(this.getCurrentAlpha() * 0.65F + (float)verticalSpeed * -2.0F));
         matrices.method_22907(class_7833.field_40718.rotationDegrees(this.getRenderY() * 0.25F));
      }
   }

   public void advanceActionPhase(class_4587 matrices, float swingProgress, double horizontalSpeed, double frameStep) {
      this.setCurrentScale((float)((double)this.getCurrentScale() + (double)(swingProgress * 0.03F) * frameStep));
      if (horizontalSpeed > 0.09) {
         this.setCurrentScale(this.getCurrentScale() + (float)(-0.05 * horizontalSpeed * frameStep));
      }

      this.setCurrentScale((float)((double)this.getCurrentScale() - (double)(this.getTargetScale() * 0.18F) * frameStep));
      this.setCurrentScale(this.getCurrentScale() * (float)Math.pow((double)0.82F, frameStep));
      this.setTargetScale((float)((double)this.getTargetScale() + (double)this.getCurrentScale() * frameStep));
      this.setTargetScale(class_3532.method_15363(this.getTargetScale(), -0.18F, 0.18F));
      matrices.method_22905(1.0F, 1.0F + this.getTargetScale() * -2.0F, 1.0F);
   }

   public float calculateRotationStep() {
      return (float)this.getPositionXSetting().getValue();
   }

   public float calculateRenderOffset() {
      return (float)this.getPositionYSetting().getValue();
   }

   public float calculateCooldown() {
      return (float)this.getPositionZSetting().getValue();
   }

   public float calculateInterpolation() {
      return (float)this.getMechanicalRotationXSetting().getValue();
   }

   public float calculateOpacity() {
      return (float)this.getMechanicalRotationYSetting().getValue();
   }

   public float calculateScale() {
      return (float)this.getMechanicalRotationZSetting().getValue();
   }

   private NumberSetting getAnimationSpeedSetting() {
      return this.skorostAnimatsiyNumberSetting;
   }

   private NumberSetting getSwingSpeedSetting() {
      return this.skorostVzmahaNumberSetting;
   }

   private BooleanSetting getMovementAnimationSetting() {
      return this.animatsiyaDvizheniyaBooleanSetting;
   }

   private BooleanSetting getEmptyHandSetting() {
      return this.pustayaRukaBooleanSetting;
   }

   private NumberSetting getRightXSetting() {
      return this.pravayaXNumberSetting;
   }

   private NumberSetting getRightYSetting() {
      return this.pravayaYNumberSetting;
   }

   private NumberSetting getRightZSetting() {
      return this.pravayaZNumberSetting;
   }

   private NumberSetting getLeftXSetting() {
      return this.levayaXNumberSetting;
   }

   private NumberSetting getLeftYSetting() {
      return this.levayaYNumberSetting;
   }

   private NumberSetting getLeftZSetting() {
      return this.levayaZNumberSetting;
   }

   private NumberSetting getPositionXSetting() {
      return this.pozitsiyaXNumberSetting;
   }

   private NumberSetting getPositionYSetting() {
      return this.pozitsiyaYNumberSetting;
   }

   private NumberSetting getPositionZSetting() {
      return this.pozitsiyaZNumberSetting;
   }

   private NumberSetting getMechanicalRotationXSetting() {
      return this.vraschenieXMechNumberSetting;
   }

   private NumberSetting getMechanicalRotationYSetting() {
      return this.vraschenieYMechNumberSetting;
   }

   private NumberSetting getMechanicalRotationZSetting() {
      return this.vraschenieZMechNumberSetting;
   }

   private long getNow() {
      return this.field_3fe31945;
   }

   private void setNow(long var1) {
      this.field_3fe31945 = var1;
   }

   private float getAnimationProgress() {
      return this.field_ad0e933a;
   }

   private void setAnimationProgress(float var1) {
      this.field_ad0e933a = var1;
   }

   private float getCurrentAlpha() {
      return this.field_1a3a0d2f;
   }

   private void setCurrentAlpha(float var1) {
      this.field_1a3a0d2f = var1;
   }

   private float getTargetAlpha() {
      return this.field_87658724;
   }

   private void setTargetAlpha(float var1) {
      this.field_87658724 = var1;
   }

   private float getRenderX() {
      return this.field_f4910119;
   }

   private void setRenderX(float var1) {
      this.field_f4910119 = var1;
   }

   private float getRenderY() {
      return this.field_61bc7b0e;
   }

   private void setRenderY(float var1) {
      this.field_61bc7b0e = var1;
   }

   private float getCurrentScale() {
      return this.field_cee7f503;
   }

   private void setCurrentScale(float var1) {
      this.field_cee7f503 = var1;
   }

   private float getTargetScale() {
      return this.field_3c136ef8;
   }

   private void setTargetScale(float var1) {
      this.field_3c136ef8 = var1;
   }

   private float getYawOffset() {
      return this.field_a93ee8ed;
   }

   private void setYawOffset(float var1) {
      this.field_a93ee8ed = var1;
   }

   private boolean isActionPending() {
      return this.field_166a62e2;
   }

   private void setActionPending(boolean var1) {
      this.field_166a62e2 = var1;
   }

   private boolean isAttackKeyPressed() {
      return this.field_8395dcd7;
   }

   private void setAttackKeyPressed(boolean var1) {
      this.field_8395dcd7 = var1;
   }

}
