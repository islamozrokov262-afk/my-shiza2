package atheryx.module.render;

import atheryx.render.font.Msdf;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_332;
import net.minecraft.class_5348;

public class ColoredTextRenderer {
   public static void renderHudElement(class_332 context, String text, float x, float y, float size, Color defaultColor) {
      ColoredText cs = new ColoredText(text, defaultColor.getRGB());
      Msdf.drawMulticolorText(context, cs.plainText, x, y, size, cs.colors);
   }

   public static void renderHudElementPrimary(class_332 context, String text, float centerX, float y, float size, Color defaultColor) {
      ColoredText cs = new ColoredText(text, defaultColor.getRGB());
      float width = Msdf.getTextWidth(cs.plainText, size);
      Msdf.drawMulticolorText(context, cs.plainText, centerX - width / 2.0F, y, size, cs.colors);
   }

   public static void renderHudElementSecondary(class_332 context, String text, float rightX, float y, float size, Color defaultColor) {
      ColoredText cs = new ColoredText(text, defaultColor.getRGB());
      float width = Msdf.getTextWidth(cs.plainText, size);
      Msdf.drawMulticolorText(context, cs.plainText, rightX - width, y, size, cs.colors);
   }


   public static class ColoredText {
      public final String plainText;
      public final int[] colors;

      public ColoredText(String text, int[] colors) {
         this.plainText = text;
         this.colors = colors;
      }

      public ColoredText(String text, int defaultColor) {
         StringBuilder builder = new StringBuilder();
         int[] tempColors = new int[text.length()];
         int currentColor = defaultColor;
         int idx = 0;

         for(int i = 0; i < text.length(); ++i) {
            char c = text.charAt(i);
            if (c == 167 && i + 1 < text.length()) {
               ++i;
               char code = text.charAt(i);
               class_124 format = class_124.method_544(code);
               if (format != null) {
                  if (format.method_532() != null) {
                     currentColor = format.method_532() | -16777216;
                  } else if (format == class_124.field_1070) {
                     currentColor = defaultColor;
                  }
               }
            } else {
               builder.append(c);
               tempColors[idx++] = currentColor;
            }
         }

         this.plainText = builder.toString();
         this.colors = new int[idx];
         System.arraycopy(tempColors, 0, this.getBuilder(), 0, idx);
      }

      public static ColoredText fromText(class_2561 text, final int defaultColor) {
         final StringBuilder builder = new StringBuilder();
         final ArrayList colorList = new ArrayList();
         text.method_27658(new class_5348.class_5246<Void>() {
            public Optional<Void> accept(class_2583 style, String string) {
               int color = this.getDefaultColor();
               if (style != null && style.method_10973() != null) {
                  color = style.method_10973().method_27716() | -16777216;
               }

               int currentColor = color;

               for(int i = 0; i < string.length(); ++i) {
                  char c = string.charAt(i);
                  if (c == 167 && i + 1 < string.length()) {
                     ++i;
                     char code = string.charAt(i);
                     class_124 format = class_124.method_544(code);
                     if (format != null) {
                        if (format.method_532() != null) {
                           currentColor = format.method_532() | -16777216;
                        } else if (format == class_124.field_1070) {
                           currentColor = color;
                        }
                     }
                  } else {
                     this.getBuilder().append(c);
                     this.getColorList().add(currentColor);
                  }
               }

               return Optional.<Void>empty();
            }

            private int getDefaultColor() {
               return defaultColor;
            }

            private StringBuilder getBuilder() {
               return builder;
            }

            private List getColorList() {
               return colorList;
            }

         }, class_2583.field_24360);
         int[] colors = new int[colorList.size()];

         for(int i = 0; i < colorList.size(); ++i) {
            colors[i] = (Integer)colorList.get(i);
         }

         return new ColoredText(builder.toString(), colors);
      }

      private String getDefaultColor() {
         return this.plainText;
      }

      private int[] getBuilder() {
         return this.colors;
      }

   }
}
