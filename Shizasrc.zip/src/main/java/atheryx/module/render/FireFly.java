package atheryx.module.render;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.gui.ThemeManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.render.Render3DUtils;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ColorSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3532;

@NewFunction(
   name = "Fire Fly",
   desc = "Летающие снежные частицы вокруг игрока",
   category = Category.RENDER
)
public class FireFly extends Function {
   private static final class_2960 obf_u03af_u2208 = class_2960.method_60655("atheryx", "images/particles/glow.png");
   private static final class_2960 obf_u2222_u2208 = class_2960.method_60655("atheryx", "images/particles/firefly.png");
   private static final class_2960 obf_u2207_u2208 = class_2960.method_60655("atheryx", "images/particles/star.png");
   private static final double obf_u00e4_u2208 = 3.0D;
   private static final double obf_u223e_u2208 = 28.0D;
   private static final double obf_u0448_u2208 = 11.0D;
   private static final long obf_u00fc_u2208 = 8000L;
   private static final float obf_u223f_u2208 = 2.3499999F;
   private static final float obf_u039a_u2208 = 0.280000001F;
   private static final float obf_u2204_u2208 = 1.17999995F;
   private static final float obf_u0445_u2208 = 0.720000029F;
   public static FireFly Instance;
   public final ModeSetting texture = new ModeSetting("Текстура", new String[]{"Glow", "Firefly", "Star"});
   public final NumberSetting count = new NumberSetting("Количество", 55.0D, 10.0D, 120.0D, (double)1.0F);
   public final NumberSetting size = new NumberSetting("Размер", (double)1.0F, 0.4, 3.0D, 0.1);
   public final BooleanSetting themeColor = new BooleanSetting("Цвет от темы", true);
   public final ColorSetting color = new ColorSetting("Цвет", new Color(245, 248, 255));
   private final List<FireflyParticle> field_8f04dbbe = new ArrayList<FireflyParticle>();
   private final Random field_fc3055b3 = new Random();

   public FireFly() {
      Instance = this;
      this.addSettings(new Setting[]{this.getCount(), this.getSize(), this.getTexture(), this.getThemeColor(), this.getColor()});
      this.getThemeColor().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   public void onDisable() {
      this.getIterator().clear();
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         class_243 playerPos = this.mc.field_1724.method_73189();
         Iterator iterator = this.getIterator().iterator();

         while(iterator.hasNext()) {
            FireflyParticle particle = (FireflyParticle)iterator.next();
            particle.update();
            if (particle.isValidPlayerPos(playerPos)) {
               iterator.remove();
            }
         }

         int targetCount = (int)this.getCount().getValue();

         while(this.getIterator().size() > targetCount) {
            this.getIterator().remove(this.getIterator().size() - 1);
         }

         while(this.getIterator().size() < targetCount) {
            this.processPosition(playerPos);
         }

      }
   }

   public static void onWorldRender(WorldRenderContext context) {
      if (Instance != null && Instance.isEnabled()) {
         Instance.renderWorldOverlay(context);
      }
   }

   private void processPosition(class_243 playerPos) {
      double angle = Math.toRadians(this.getRandom().nextDouble() * 360.0D);
      double distance = 3.0D + this.getRandom().nextDouble() * 25.0D;
      double height = (double)1.0F + this.getRandom().nextDouble() * 11.0D;
      class_243 position = playerPos.method_1031(Math.cos(angle) * distance, (double)0.0F, Math.sin(angle) * distance).method_1031((double)0.0F, height, (double)0.0F);
      class_243 velocity = new class_243((this.getRandom().nextDouble() - (double)0.5F) * 0.055, -0.035 - this.getRandom().nextDouble() * 0.055, (this.getRandom().nextDouble() - (double)0.5F) * 0.055);
      this.getIterator().add(new FireflyParticle(position, velocity, 0.055F + this.getRandom().nextFloat() * 0.075F, this.getRandom().nextFloat() * 360.0F, -1.4F + this.getRandom().nextFloat() * 2.79999995F, 0.55F + this.getRandom().nextFloat() * 0.35F));
   }

   private void renderWorldOverlay(WorldRenderContext context) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null && !this.getIterator().isEmpty()) {
         Color selectedColor = this.getThemeColor().isEnabled() ? ThemeManager.getCurrentColor() : this.getColor().getColor();
         boolean useTheme = this.getThemeColor().isEnabled();
         int red = useTheme ? brightenChannel(selectedColor.getRed()) : selectedColor.getRed();
         int green = useTheme ? brightenChannel(selectedColor.getGreen()) : selectedColor.getGreen();
         int blue = useTheme ? brightenChannel(selectedColor.getBlue()) : selectedColor.getBlue();
         float sizeMultiplier = (float)this.getSize().getValue();
         float tickDelta = this.mc.method_61966().method_60637(false);
         class_2960 particleTexture = this.getParticleTexture();
         Render3DUtils.BillboardBatch outerGlowBatch = Render3DUtils.beginAdditiveBillboards(context, particleTexture);

         for(FireflyParticle particle : this.getIterator()) {
            float alpha = particle.calculateAnimationFactor();
            if (!(alpha <= 0.01F)) {
               class_243 position = particle.getTargetPosition(tickDelta);
               float particleSize = particle.field_695bcfa8 * sizeMultiplier;
               outerGlowBatch.drawColoredBillboard(position, particleSize * 2.3499999F, particle.field_d687499d, red, green, blue, alpha * 0.28F);
            }
         }

         Render3DUtils.BillboardBatch innerGlowBatch = Render3DUtils.beginAdditiveBillboards(context, particleTexture);

         for(FireflyParticle particle : this.getIterator()) {
            float alpha = particle.calculateAnimationFactor();
            if (!(alpha <= 0.01F)) {
               class_243 position = particle.getTargetPosition(tickDelta);
               float particleSize = particle.field_695bcfa8 * sizeMultiplier;
               innerGlowBatch.drawColoredBillboard(position, particleSize * 1.18F, particle.field_d687499d, red, green, blue, alpha * 0.72F);
               innerGlowBatch.drawColoredBillboard(position, particleSize, particle.field_d687499d, 255, 255, 255, alpha);
            }
         }

      }
   }

   private class_2960 getParticleTexture() {
      if (this.getTexture().isSelected("Firefly")) {
         return obf_u2222_u2208;
      } else {
         return this.getTexture().isSelected("Star") ? obf_u2207_u2208 : obf_u03af_u2208;
      }
   }

   private static int brightenChannel(int value) {
      return Math.clamp((long)((int)((float)value + (float)(255 - value) * 0.58F)), 0, 255);
   }

   private void updateSettingVisibility() {
      this.getColor().setVisible(!this.getThemeColor().isEnabled());
   }

   private ModeSetting getTexture() {
      return this.texture;
   }

   private NumberSetting getCount() {
      return this.count;
   }

   private NumberSetting getSize() {
      return this.size;
   }

   private BooleanSetting getThemeColor() {
      return this.themeColor;
   }

   private ColorSetting getColor() {
      return this.color;
   }

   private List<FireflyParticle> getIterator() {
      return this.field_8f04dbbe;
   }

   private Random getRandom() {
      return this.field_fc3055b3;
   }


   private static class FireflyParticle {
      private double field_6d2b79f5;
      private double field_da56f3ea;
      private double field_47826ddf;
      private double field_b4ade7d4;
      private double field_21d961c9;
      private double field_8f04dbbe;
      private final class_243 field_fc3055b3;
      private final float field_695bcfa8;
      private float field_d687499d;
      private final float field_43b2c392;
      private final float field_b0de3d87;
      private final float field_1e09b77c;
      private final long field_8b353171;

      private FireflyParticle(class_243 position, class_243 velocity, float size, float rotation, float spinSpeed, float maxAlpha) {
         this.setDx(position.field_1352);
         this.setDy(position.field_1351);
         this.setDz(position.field_1350);
         this.setSelectedColor(position.field_1352);
         this.setDistance(position.field_1351);
         this.setIterator(position.field_1350);
         this.field_fc3055b3 = velocity;
         this.field_695bcfa8 = size;
         this.setRotation(rotation);
         this.field_43b2c392 = spinSpeed;
         this.field_b0de3d87 = maxAlpha;
         this.field_1e09b77c = (float)(Math.random() * 3.1415926535897931D * 2.0D);
         this.field_8b353171 = System.currentTimeMillis();
      }

      private void update() {
         this.setSelectedColor(this.getDx());
         this.setDistance(this.getDy());
         this.setIterator(this.getDz());
         long age = System.currentTimeMillis() - this.getLastActionTime();
         double wobble = Math.sin((double)age / 420.0D + (double)this.getRenderX()) * 0.018;
         this.setDx(this.getDx() + this.getCurrentPosition().field_1352 + wobble);
         this.setDy(this.getDy() + this.getCurrentPosition().field_1351);
         this.setDz(this.getDz() + this.getCurrentPosition().field_1350 + Math.cos((double)age / 510.0D + (double)this.getRenderX()) * 0.018);
         this.setRotation(this.getRotation() + this.getCurrentAlpha());
      }

      private boolean isValidPlayerPos(class_243 playerPos) {
         long age = System.currentTimeMillis() - this.getLastActionTime();
         if (age <= 8000L && !(this.getDy() < playerPos.field_1351 - 3.5D)) {
            double dx = this.getDx() - playerPos.field_1352;
            double dy = this.getDy() - playerPos.field_1351;
            double dz = this.getDz() - playerPos.field_1350;
            return dx * dx + dy * dy + dz * dz > 2025.0D;
         } else {
            return true;
         }
      }

      private class_243 getTargetPosition(float tickDelta) {
         return new class_243(class_3532.method_16436((double)tickDelta, this.getSelectedColor(), this.getDx()), class_3532.method_16436((double)tickDelta, this.getDistance(), this.getDy()), class_3532.method_16436((double)tickDelta, this.getIterator(), this.getDz()));
      }

      private float calculateAnimationFactor() {
         long age = System.currentTimeMillis() - this.getLastActionTime();
         float fadeIn = Math.clamp((float)age / 650.0F, 0.0F, 1.0F);
         float fadeOut = Math.clamp((float)(8000L - age) / 1300.0F, 0.0F, 1.0F);
         return this.smoothstep(Math.min(fadeIn, fadeOut)) * this.getTargetAlpha();
      }

      private float smoothstep(float value) {
         value = Math.clamp(value, 0.0F, 1.0F);
         return value * value * (3.0F - 2.0F * value);
      }

      private double getDx() {
         return this.field_6d2b79f5;
      }

      private void setDx(double var1) {
         this.field_6d2b79f5 = var1;
      }

      private double getDy() {
         return this.field_da56f3ea;
      }

      private void setDy(double var1) {
         this.field_da56f3ea = var1;
      }

      private double getDz() {
         return this.field_47826ddf;
      }

      private void setDz(double var1) {
         this.field_47826ddf = var1;
      }

      private double getSelectedColor() {
         return this.field_b4ade7d4;
      }

      private void setSelectedColor(double var1) {
         this.field_b4ade7d4 = var1;
      }

      private double getDistance() {
         return this.field_21d961c9;
      }

      private void setDistance(double var1) {
         this.field_21d961c9 = var1;
      }

      private double getIterator() {
         return this.field_8f04dbbe;
      }

      private void setIterator(double var1) {
         this.field_8f04dbbe = var1;
      }

      private class_243 getCurrentPosition() {
         return this.field_fc3055b3;
      }

      private float getAnimationProgress() {
         return this.field_695bcfa8;
      }

      private float getRotation() {
         return this.field_d687499d;
      }

      private void setRotation(float var1) {
         this.field_d687499d = var1;
      }

      private float getCurrentAlpha() {
         return this.field_43b2c392;
      }

      private float getTargetAlpha() {
         return this.field_b0de3d87;
      }

      private float getRenderX() {
         return this.field_1e09b77c;
      }

      private long getLastActionTime() {
         return this.field_8b353171;
      }

   }
}
