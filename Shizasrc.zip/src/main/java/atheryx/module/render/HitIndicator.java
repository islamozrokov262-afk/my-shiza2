package atheryx.module.render;

import atheryx.event.EventHandler;
import atheryx.event.impl.Render2DEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.render.RenderUtil;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_3532;

@NewFunction(
   name = "HitIndicator",
   desc = "Показывает красную дугу со стороны, откуда пришел урон",
   category = Category.RENDER
)
public class HitIndicator extends Function {
   private final NumberSetting radiusNumberSetting = new NumberSetting("Радиус", 125.0D, 60.0D, 260.0D, 5.0D);
   private final NumberSetting dlinaDugiNumberSetting = new NumberSetting("Длина дуги", 76.0D, 30.0D, 150.0D, (double)1.0F);
   private final NumberSetting tolschinaNumberSetting = new NumberSetting("Толщина", 2.3999999999999999D, (double)1.0F, 7.0D, 0.1);
   private final NumberSetting vremyaPokazaNumberSetting = new NumberSetting("Время показа", 700.0D, 250.0D, 1600.0D, 25.0D);
   private final NumberSetting prozrachnostNumberSetting = new NumberSetting("Прозрачность", 0.9, 0.2, (double)1.0F, 0.05);
   private final NumberSetting distantsiyaIstochnikaNumberSetting = new NumberSetting("Дистанция источника", 32.0D, 6.0D, 64.0D, (double)1.0F);
   private final BooleanSetting svechenieBooleanSetting = new BooleanSetting("Свечение", true);
   private final List<DamageIndicator> field_695bcfa8 = new ArrayList<DamageIndicator>();
   private float field_d687499d;

   public HitIndicator() {
      this.setCurrentHealth(-1.0F);
      this.addSettings(new Setting[]{this.getRadiusSetting(), this.getArcLengthSetting(), this.getThicknessSetting(), this.getDisplayDurationSetting(), this.getTransparencySetting(), this.getSourceDistanceSetting(), this.getGlowSetting()});
   }

   public void onEnable() {
      super.onEnable();
      this.setCurrentHealth(this.calculateAnimationFactor());
      this.getIterator().clear();
   }

   public void onDisable() {
      this.getIterator().clear();
      this.setCurrentHealth(-1.0F);
      super.onDisable();
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         float currentHealth = this.calculateAnimationFactor();
         if (this.getCurrentHealth() < 0.0F) {
            this.setCurrentHealth(currentHealth);
         } else {
            if (currentHealth + 0.01F < this.getCurrentHealth()) {
               Float yaw = this.resolveFloat();
               if (yaw != null) {
                  this.updateTimedState(yaw);
               }
            }

            this.setCurrentHealth(currentHealth);
         }
      } else {
         this.setCurrentHealth(-1.0F);
         this.getIterator().clear();
      }
   }

   @EventHandler
   public void onRender2D(Render2DEvent event) {
      if (event.getDrawContext() != null && this.mc.field_1724 != null && this.mc.field_1687 != null && !this.getIterator().isEmpty()) {
         if (!this.mc.field_1690.field_1842 && !this.mc.method_53526().method_53536()) {
            long now = System.currentTimeMillis();
            float width = (float)RenderUtil.getScaledWidth();
            float height = (float)RenderUtil.getScaledHeight();
            float centerX = width / 2.0F;
            float centerY = height / 2.0F;
            float maxRadius = Math.max(24.0F, Math.min(centerX, centerY) - 8.0F);
            float drawRadius = Math.min((float)this.getRadiusSetting().getValue(), maxRadius);
            float cameraYaw = this.mc.field_1773.method_19418().method_19330();
            float length = (float)this.getArcLengthSetting().getValue();
            float arcProgress = Math.clamp(length / 360.0F, 0.0F, 1.0F);
            Iterator iterator = this.getIterator().iterator();

            while(iterator.hasNext()) {
               DamageIndicator indicator = (DamageIndicator)iterator.next();
               float age = (float)(now - indicator.dlinaDugiNumberSetting);
               float lifetime = (float)this.getDisplayDurationSetting().getValue();
               if (age >= lifetime) {
                  iterator.remove();
               } else {
                  float progress = class_3532.method_15363(age / lifetime, 0.0F, 1.0F);
                  float fadeIn = class_3532.method_15363(age / 90.0F, 0.0F, 1.0F);
                  float alpha = (float)this.getTransparencySetting().getValue() * fadeIn * (1.0F - progress * progress);
                  if (!(alpha <= 0.02F)) {
                     float relativeYaw = class_3532.method_15393(indicator.radiusNumberSetting - cameraYaw);
                     float startAngle = relativeYaw - length / 2.0F - 90.0F;
                     int baseAlpha = class_3532.method_15340((int)(alpha * 255.0F), 0, 255);
                     if (this.getGlowSetting().isEnabled()) {
                        RenderUtil.drawArc(centerX, centerY, drawRadius, (float)this.getThicknessSetting().getValue() + 3.20000005F, startAngle, arcProgress, new Color(255, 35, 45, class_3532.method_15340((int)(alpha * 0.22F * 255.0F), 0, 255)));
                     }

                     RenderUtil.drawArc(centerX, centerY, drawRadius, (float)this.getThicknessSetting().getValue(), startAngle, arcProgress, new Color(255, 35, 45, baseAlpha));
                  }
               }
            }

         }
      }
   }

   private float calculateAnimationFactor() {
      return this.mc.field_1724 == null ? -1.0F : this.mc.field_1724.method_6032() + this.mc.field_1724.method_6067();
   }

   private void updateTimedState(float worldYaw) {
      this.getIterator().add(new DamageIndicator(worldYaw, System.currentTimeMillis()));

      while(this.getIterator().size() > 8) {
         this.getIterator().remove(0);
      }

   }

   private Float resolveFloat() {
      class_1297 source = this.findTarget();
      if (!this.isEntityInRange(source)) {
         source = this.findTargetPrimary();
      }

      if (!this.isEntityInRange(source)) {
         return null;
      } else {
         double dx = source.method_23317() - this.mc.field_1724.method_23317();
         double dz = source.method_23321() - this.mc.field_1724.method_23321();
         return dx * dx + dz * dz < 1.0E-4 ? null : (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0D);
      }
   }

   private class_1297 findTarget() {
      class_1282 damageSource = this.mc.field_1724.method_6081();
      class_1297 source = null;
      if (damageSource != null) {
         source = damageSource.method_5529();
         if (!this.isEntityInRange(source)) {
            source = damageSource.method_5526();
         }
      }

      if (!this.isEntityInRange(source)) {
         source = this.mc.field_1724.method_6052();
      }

      if (!this.isEntityInRange(source)) {
         source = this.mc.field_1724.method_6065();
      }

      return source;
   }

   private class_1297 findTargetPrimary() {
      class_1297 nearest = null;
      class_1297 nearestSwinging = null;
      double bestDistance = this.getSourceDistanceSetting().getValue() * this.getSourceDistanceSetting().getValue();
      double bestSwingingDistance = bestDistance;

      for(class_1297 entity : this.mc.field_1687.method_18112()) {
         if (entity instanceof class_1309 living) {
            if (this.isEntityInRange(entity)) {
               double distance = this.mc.field_1724.method_5858(entity);
               if (living.field_6252 && distance < bestSwingingDistance) {
                  bestSwingingDistance = distance;
                  nearestSwinging = entity;
               }

               if (distance < bestDistance) {
                  bestDistance = distance;
                  nearest = entity;
               }
            }
         }
      }

      return nearestSwinging != null ? nearestSwinging : nearest;
   }

   private boolean isEntityInRange(class_1297 entity) {
      return entity != null && entity != this.mc.field_1724 && entity.method_5805() && this.mc.field_1724 != null && this.mc.field_1724.method_5858(entity) <= this.getSourceDistanceSetting().getValue() * this.getSourceDistanceSetting().getValue();
   }

   private NumberSetting getRadiusSetting() {
      return this.radiusNumberSetting;
   }

   private NumberSetting getArcLengthSetting() {
      return this.dlinaDugiNumberSetting;
   }

   private NumberSetting getThicknessSetting() {
      return this.tolschinaNumberSetting;
   }

   private NumberSetting getDisplayDurationSetting() {
      return this.vremyaPokazaNumberSetting;
   }

   private NumberSetting getTransparencySetting() {
      return this.prozrachnostNumberSetting;
   }

   private NumberSetting getSourceDistanceSetting() {
      return this.distantsiyaIstochnikaNumberSetting;
   }

   private BooleanSetting getGlowSetting() {
      return this.svechenieBooleanSetting;
   }

   private List getIterator() {
      return this.field_695bcfa8;
   }

   private float getCurrentHealth() {
      return this.field_d687499d;
   }

   private void setCurrentHealth(float var1) {
      this.field_d687499d = var1;
   }


   private static class DamageIndicator {
      private final float radiusNumberSetting;
      private final long dlinaDugiNumberSetting;

      private DamageIndicator(float worldYaw, long spawnTime) {
         this.radiusNumberSetting = worldYaw;
         this.dlinaDugiNumberSetting = spawnTime;
      }

      private float getRadiusSetting() {
         return this.radiusNumberSetting;
      }

      private long getArcLengthSetting() {
         return this.dlinaDugiNumberSetting;
      }

   }
}
