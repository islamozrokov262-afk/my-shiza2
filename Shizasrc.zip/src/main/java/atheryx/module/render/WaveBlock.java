package atheryx.module.render;

import net.minecraft.class_2338;
import net.minecraft.class_238;

final class WaveBlock {
   final class_2338 pos;
   final class_238 box;
   final float distance;

   WaveBlock(class_2338 pos, class_238 box, float distance) {
      this.pos = pos;
      this.box = box;
      this.distance = distance;
   }
}
