package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.PacketSendEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.module.combat.AttackAura;
import atheryx.module.combat.TriggerBot;
import net.minecraft.class_2596;
import net.minecraft.class_2848;
import net.minecraft.class_2848.class_2849;

@NewFunction(
   name = "Sprint",
   desc = "Автоматически удерживает состояние бега",
   category = Category.MOVEMENT
)
public class Sprint extends Function {
   private boolean field_6d2b79f5;

   public void onEnable() {
      this.setActionPending(this.mc.field_1724 != null && this.mc.field_1724.method_5624());
   }

   public void onDisable() {
      this.setActionPending(false);
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerMissing()) {
         AttackAura aura = (AttackAura)FunctionManager.getFunction(AttackAura.class);
         TriggerBot bot = (TriggerBot)FunctionManager.getFunction(TriggerBot.class);
         if ((aura == null || !aura.shouldPreventSprintReset()) && (bot == null || !bot.shouldPreventSprintReset())) {
            if (this.mc.field_1724.method_5624()) {
               if (!this.shouldProcess()) {
                  this.mc.field_1724.method_5728(false);
               }
            } else if (this.shouldProcess()) {
               this.mc.field_1724.method_5728(true);
            }

         }
      }
   }

   private boolean shouldProcess() {
      return !this.mc.field_1724.method_74025() && (!this.mc.field_1724.method_5765() || this.mc.field_1724.method_48155()) && this.mc.field_1724.field_3913.method_20622() && this.mc.field_1724.method_7344().method_75882();
   }

   @EventHandler
   public void onPacketSend(PacketSendEvent event) {
      class_2596 var3 = event.getPacket();
      if (var3 instanceof class_2848 packet) {
         if (packet.method_12365() == class_2849.field_12981) {
            if (this.isActionPending()) {
               event.cancel();
               return;
            }

            this.setActionPending(true);
         } else if (packet.method_12365() == class_2849.field_12985) {
            if (!this.isActionPending()) {
               event.cancel();
               return;
            }

            this.setActionPending(false);
         }

      }
   }

   private boolean isActionPending() {
      return this.field_6d2b79f5;
   }

   private void setActionPending(boolean var1) {
      this.field_6d2b79f5 = var1;
   }

}
