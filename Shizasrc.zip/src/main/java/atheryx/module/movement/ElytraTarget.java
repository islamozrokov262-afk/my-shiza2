package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.manager.RotationManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.NumberSetting;
import net.minecraft.class_1657;
import net.minecraft.class_243;

@NewFunction(
   name = "ElytraTarget",
   desc = "Таргетит игроков на элитре и летит за ними",
   category = Category.MOVEMENT
)
public class ElytraTarget extends Function {
   private final NumberSetting distantsiyaNumberSetting = new NumberSetting("Дистанция", 50.0D, 5.0D, 200.0D, (double)1.0F);
   private class_1657 field_da56f3ea;

   public ElytraTarget() {
      this.setTargetPos((class_1657)null);
      this.addSettings(new Setting[]{this.getDistanceSetting()});
   }

   public double calculateAnimationFactor() {
      return this.getDistanceSetting().getValue();
   }

   public void onDisable() {
      this.setTargetPos((class_1657)null);
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing() && this.mc.field_1724 != null && this.mc.field_1687 != null) {
         this.setTargetPos((class_1657)null);
         double closestDistSq = this.getDistanceSetting().getValue() * this.getDistanceSetting().getValue();

         for(class_1657 player : this.mc.field_1687.method_18456()) {
            if (player != this.mc.field_1724 && player.method_5805() && player.method_6128()) {
               double distSq = this.mc.field_1724.method_5858(player);
               if (distSq <= closestDistSq) {
                  closestDistSq = distSq;
                  this.setTargetPos(player);
               }
            }
         }

         if (this.getTargetPos() != null && this.mc.field_1724.method_6128()) {
            class_243 targetPos = this.getTargetPos().method_5829().method_1005();
            class_243 motion = this.getTargetPos().method_18798();
            if (motion.method_1027() > 0.001) {
               targetPos = targetPos.method_1019(motion.method_1021((double)1.5F));
            }

            RotationManager.Rotation targetRot = RotationManager.rotationTo(targetPos);
            RotationManager.requestRotation(targetRot, RotationManager.MoveCorrection.SILENT, 180.0F, 180.0F, 180.0F);
            class_243 diff = targetPos.method_1020(this.mc.field_1724.method_33571());
            double dist = Math.sqrt(this.mc.field_1724.method_5707(targetPos));
            class_243 direction = diff.method_1029();
            if (dist < 3.0D) {
               this.mc.field_1724.method_18799(this.getTargetPos().method_18798().method_1019(direction.method_1021(0.2)));
            } else {
               double speed = Math.min(this.mc.field_1724.method_18798().method_1033(), 3.0D);
               this.mc.field_1724.method_18799(direction.method_1021(speed));
            }
         }

      }
   }

   private NumberSetting getDistanceSetting() {
      return this.distantsiyaNumberSetting;
   }

   private class_1657 getTargetPos() {
      return this.field_da56f3ea;
   }

   private void setTargetPos(class_1657 var1) {
      this.field_da56f3ea = var1;
   }

}
