package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.NoSlowEvent;
import atheryx.event.impl.PacketSendEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.ModeSetting;
import atheryx.util.NetworkUtils;
import java.util.ArrayList;
import java.util.List;
import lombok.Generated;
import net.minecraft.class_1268;
import net.minecraft.class_1839;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2596;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_471;
import net.minecraft.class_476;
import net.minecraft.class_490;
import net.minecraft.class_498;

@NewFunction(
   name = "NoSlow",
   desc = "Убирает замедления от использования предметов и инвентаря",
   category = Category.MOVEMENT
)
public class NoSlow extends Function {
   private static NoSlow obf_u0441_u221c;
   public static final ModeSetting mode = new ModeSetting("Режим", new String[]{"Vanilla", "Grim", "ReallyWorld"});
   private int field_6d2b79f5;
   private int field_da56f3ea;
   private boolean field_47826ddf;
   private boolean field_b4ade7d4;
   private boolean field_21d961c9;
   private static final long obf_u00fd_u221c = 15L;
   private static final long obf_u222b_u221c = 90L;
   private static final long obf_u00d4_u221c = 40L;
   private static final long obf_u03a7_u221c = 10L;
   private static final float obf_u00fe_u221c = 0.0900000036F;
   private static final float obf_u0456_u221c = 0.0399999991F;
   private static final float obf_u2234_u221c = 20.0F;
   private static final float obf_u03b1_u221c = 1000.0F;
   private final List<class_2596<?>> field_8f04dbbe;
   private int field_fc3055b3;
   private long field_695bcfa8;
   private long field_d687499d;
   public boolean slow;

   public NoSlow() {
      this.setCooldownTicks(0);
      this.setRetryCount(0);
      this.setActionPending(false);
      this.field_8f04dbbe = new ArrayList<class_2596<?>>();
      this.addSettings(new Setting[]{mode});
      obf_u0441_u221c = this;
   }

   private class_304[] getMovementKeys() {
      return this.mc.field_1690 == null ? new class_304[0] : new class_304[]{this.mc.field_1690.field_1894, this.mc.field_1690.field_1881, this.mc.field_1690.field_1913, this.mc.field_1690.field_1849, this.mc.field_1690.field_1903, this.mc.field_1690.field_1867};
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         class_304[] keys = this.getMovementKeys();
         if (this.shouldProcessSecondary()) {
            this.advanceActionPhase(keys);
            if (this.getSelectedSlot() > 0) {
               this.setSelectedSlot(this.getSelectedSlot() - 1);
            }
         } else if (System.currentTimeMillis() < this.getNextActionTime()) {
            this.advanceActionPhase(keys);
         } else if (!(this.mc.field_1755 instanceof class_408) && !(this.mc.field_1755 instanceof class_498) && !(this.mc.field_1755 instanceof class_471)) {
            if (mode.isSelected("Grim") && this.mc.field_1755 instanceof class_476) {
               this.advanceActionPhase(keys);
            } else if (this.mc.field_1755 instanceof class_490 && this.isGrimMode()) {
               this.updateRotation(keys);
            }
         } else {
            this.advanceActionPhase(keys);
         }

         if (!mode.isSelected("Grim") && !mode.isSelected("ReallyWorld")) {
            if (this.mc.field_1724.method_6058() != class_1268.field_5808 && this.mc.field_1724.method_6058() != class_1268.field_5810) {
               this.setCooldownTicks(0);
            } else if (this.mc.field_1724.method_6115()) {
               this.setCooldownTicks(this.getCooldownTicks() + 1);
            } else {
               this.setCooldownTicks(0);
            }

            this.updateAnimation();
         } else {
            if (!this.mc.field_1724.method_6123()) {
               if (this.mc.field_1724.method_6115()) {
                  this.setCooldownTicks(this.getCooldownTicks() + 1);
               } else {
                  this.setCooldownTicks(0);
                  this.setRetryCount(0);
               }
            }

            this.resetTransientState();
         }

      }
   }

   @EventHandler
   public void onPacketSend(PacketSendEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         if (!NetworkUtils.silentSending) {
            class_2596<?> packet = event.getPacket();
            if (packet instanceof class_2813 && this.hasMovementInput() && this.mc.field_1755 instanceof class_490 && this.isGrimMode()) {
               this.getTrackedItems().add(packet);
               event.cancel();
            } else if (packet instanceof class_2815 && this.mc.field_1755 instanceof class_490 && this.hasMovementInput() && !this.getTrackedItems().isEmpty() && this.isGrimMode()) {
               this.setSlow(true);
               (new Thread(this::refreshTarget, "NoSlow packet replay")).start();
               event.cancel();
            }

         }
      }
   }

   @EventHandler
   public void onNoSlow(NoSlowEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         if (mode.isSelected("Vanilla")) {
            event.setCancelled(true);
         } else if (mode.isSelected("Grim") || mode.isSelected("ReallyWorld")) {
            int[] thresholds = new int[]{2, 2, 3};
            int threshold = thresholds[this.getRetryCount() % 2];
            if (this.getCooldownTicks() >= threshold) {
               event.setCancelled(true);
               this.setCooldownTicks(0);
               this.setRetryCount(this.getRetryCount() + 1);
            }
         }

      }
   }

   private boolean isGrimMode() {
      return mode.isSelected("Grim") || mode.isSelected("ReallyWorld");
   }

   private boolean hasMovementInput() {
      return this.mc.field_1724 != null && this.mc.field_1724.field_3913 != null && this.mc.field_1724.field_3913.method_3128().method_35587() > 1.0E-7F;
   }

   private void refreshTarget() {
      this.setNextActionTime(System.currentTimeMillis() + 15L);
      updateTimedState(mode.isSelected("ReallyWorld") ? 0.09F : 0.04F);

      try {
         Thread.sleep(mode.isSelected("ReallyWorld") ? 90L : 40L);
      } catch (InterruptedException ignored) {
         Thread.currentThread().interrupt();
      }

      for (class_2596<?> packet : this.getTrackedItems()) {
         if (this.mc.field_1724 != null) {
            NetworkUtils.sendPacketSilently(packet);

            try {
               Thread.sleep(10L);
            } catch (InterruptedException ignored) {
               Thread.currentThread().interrupt();
               break;
            }
         }
      }

      this.getTrackedItems().clear();
      this.setSlow(false);
      if (this.mc.field_1724 != null && this.mc.field_1724.field_7512 != null) {
         NetworkUtils.sendPacketSilently(new class_2815(this.mc.field_1724.field_7512.field_7763));
      }
   }

   private void updateRotation(class_304[] keys) {
      if (this.mc.method_22683() != null) {
         for(class_304 key : keys) {
            int keyCode = key.method_1429().method_1444();
            boolean pressed = keyCode != class_3675.field_16237.method_1444() && class_3675.method_15987(this.mc.method_22683(), keyCode);
            key.method_23481(pressed);
         }

      }
   }

   private void advanceActionPhase(class_304[] keys) {
      for(class_304 key : keys) {
         key.method_23481(false);
      }

   }

   private boolean shouldProcessSecondary() {
      return this.getSelectedSlot() > 0 || System.currentTimeMillis() < this.getLastActionTime();
   }

   public static void updateTimedState(float seconds) {
      NoSlow noSlow = obf_u0441_u221c;
      if (noSlow != null && noSlow.isEnabled()) {
         int ticks = Math.max(1, (int)Math.ceil((double)(seconds * 20.0F)));
         noSlow.setSelectedSlot(Math.max(noSlow.getSelectedSlot(), ticks));
         noSlow.setLastActionTime(Math.max(noSlow.getLastActionTime(), System.currentTimeMillis() + (long)(seconds * 1000.0F)));
         noSlow.advanceActionPhase(noSlow.getMovementKeys());
      } else {
         prepareInteraction();
      }
   }

   public static void prepareInteraction() {
      NoSlow noSlow = obf_u0441_u221c;
      if (noSlow != null && noSlow.mc != null && noSlow.mc.field_1690 != null) {
         class_304[] keys = new class_304[]{noSlow.mc.field_1690.field_1894, noSlow.mc.field_1690.field_1881, noSlow.mc.field_1690.field_1913, noSlow.mc.field_1690.field_1849, noSlow.mc.field_1690.field_1903, noSlow.mc.field_1690.field_1867, noSlow.mc.field_1690.field_1832};

         for(class_304 key : keys) {
            key.method_23481(false);
         }

      }
   }

   private boolean shouldProcessCurrent() {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         class_2338 playerPos = this.mc.field_1724.method_24515();
         class_2248 block = this.mc.field_1687.method_8320(playerPos).method_26204();
         return block == class_2246.field_10477 || block == class_2246.field_10466 || block == class_2246.field_9977 || block == class_2246.field_10482 || block == class_2246.field_10290 || block == class_2246.field_10512 || block == class_2246.field_10040 || block == class_2246.field_10393 || block == class_2246.field_10591 || block == class_2246.field_10209 || block == class_2246.field_10433 || block == class_2246.field_10510 || block == class_2246.field_10043 || block == class_2246.field_10473 || block == class_2246.field_10338 || block == class_2246.field_10536 || block == class_2246.field_10106;
      } else {
         return false;
      }
   }

   private void resetTransientState() {
      if (this.mc.field_1724 != null && this.mc.field_1690 != null) {
         boolean eating = this.mc.field_1724.method_6115() && this.mc.field_1724.method_6030().method_7976() == class_1839.field_8950;
         if (eating) {
            if (!this.isInputCaptured()) {
               this.setRestoreRequired(this.mc.field_1690.field_1867.method_1434());
               this.setInputCaptured(true);
            }

            this.mc.field_1690.field_1867.method_23481(true);
            this.mc.field_1724.method_5728(true);
         } else {
            this.updateAnimation();
         }
      }
   }

   private void updateAnimation() {
      if (this.isInputCaptured() && this.mc.field_1690 != null) {
         if (!this.isRestoreRequired()) {
            this.mc.field_1690.field_1867.method_23481(false);
         }

         this.setInputCaptured(false);
         this.setRestoreRequired(false);
      }
   }

   public void onDisable() {
      super.onDisable();
      this.updateAnimation();
      this.setCooldownTicks(0);
      this.setRetryCount(0);
      this.setActionPending(false);
      this.getTrackedItems().clear();
      this.setSlow(false);
      this.setSelectedSlot(0);
      this.setLastActionTime(0L);
      this.setNextActionTime(0L);
      if (this.mc.field_1690 != null) {
         this.advanceActionPhase(this.getMovementKeys());
      }

   }

   @Generated
   public static NoSlow resolveNoSlow() {
      return obf_u0441_u221c;
   }

   private int getCooldownTicks() {
      return this.field_6d2b79f5;
   }

   private void setCooldownTicks(int var1) {
      this.field_6d2b79f5 = var1;
   }

   private int getRetryCount() {
      return this.field_da56f3ea;
   }

   private void setRetryCount(int var1) {
      this.field_da56f3ea = var1;
   }

   private boolean isActionPending() {
      return this.field_47826ddf;
   }

   private void setActionPending(boolean var1) {
      this.field_47826ddf = var1;
   }

   private boolean isInputCaptured() {
      return this.field_b4ade7d4;
   }

   private void setInputCaptured(boolean var1) {
      this.field_b4ade7d4 = var1;
   }

   private boolean isRestoreRequired() {
      return this.field_21d961c9;
   }

   private void setRestoreRequired(boolean var1) {
      this.field_21d961c9 = var1;
   }

   private List<class_2596<?>> getTrackedItems() {
      return this.field_8f04dbbe;
   }

   private int getSelectedSlot() {
      return this.field_fc3055b3;
   }

   private void setSelectedSlot(int var1) {
      this.field_fc3055b3 = var1;
   }

   private long getLastActionTime() {
      return this.field_695bcfa8;
   }

   private void setLastActionTime(long var1) {
      this.field_695bcfa8 = var1;
   }

   private long getNextActionTime() {
      return this.field_d687499d;
   }

   private void setNextActionTime(long var1) {
      this.field_d687499d = var1;
   }

   private boolean isSlow() {
      return this.slow;
   }

   private void setSlow(boolean var1) {
      this.slow = var1;
   }

}
