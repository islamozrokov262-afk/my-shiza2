package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_243;

@NewFunction(
   name = "GrimGlide",
   category = Category.MOVEMENT,
   desc = "Ускорение на элитре без фееров"
)
public class GrimGlide extends Function {
   private long field_6d2b79f5;
   private int field_da56f3ea;

   public GrimGlide() {
      this.setLastActionTime(0L);
      this.setCooldownTicks(0);
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerMissing() && this.mc.field_1724.method_6128()) {
         this.setCooldownTicks(this.getCooldownTicks() + 1);
         class_243 pos = this.mc.field_1724.method_73189();
         float yaw = this.mc.field_1724.method_36454();
         double forward = this.mc.field_1724.field_6012 % 2 == 0 ? 0.087 : 0.09;
         double dx = -Math.sin(Math.toRadians((double)yaw)) * forward;
         double dz = Math.cos(Math.toRadians((double)yaw)) * forward;
         if (System.currentTimeMillis() - this.getLastActionTime() >= 40L) {
            this.mc.field_1724.method_5814(pos.method_10216() + dx, pos.method_10214(), pos.method_10215() + dz);
            this.setLastActionTime(System.currentTimeMillis());
         }

         if (this.getCooldownTicks() % 40 == 0) {
            this.mc.field_1724.method_18800(dx * (double)ThreadLocalRandom.current().nextFloat(1.001F, 1.0021F), this.mc.field_1724.method_18798().field_1351 + 0.00600000075995922, dz * (double)ThreadLocalRandom.current().nextFloat(1.001F, 1.0021F));
         }

      }
   }

   public void onEnable() {
      super.onEnable();
      this.setCooldownTicks(0);
      this.setLastActionTime(System.currentTimeMillis());
   }

   public void onDisable() {
      this.setCooldownTicks(0);
      super.onDisable();
   }

   private long getLastActionTime() {
      return this.field_6d2b79f5;
   }

   private void setLastActionTime(long var1) {
      this.field_6d2b79f5 = var1;
   }

   private int getCooldownTicks() {
      return this.field_da56f3ea;
   }

   private void setCooldownTicks(int var1) {
      this.field_da56f3ea = var1;
   }

}
