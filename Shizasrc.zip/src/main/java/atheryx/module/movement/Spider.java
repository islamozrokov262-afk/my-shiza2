package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.ListSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1802;

@NewFunction(
   name = "Spider",
   desc = "Позволяет ползать по стенам",
   category = Category.MOVEMENT
)
public class Spider extends Function {
   private final ListSetting modListSetting = new ListSetting("Мод", new String[]{"Vanilla", "РВ вода"});

   public Spider() {
      this.addSettings(new Setting[]{this.getModeSetting()});
   }

   public void onEnable() {
      super.onEnable();
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         if (this.mc.field_1724.field_5976) {
            if (this.getModeSetting().isSelected("Vanilla")) {
               this.mc.field_1724.method_18800(this.mc.field_1724.method_18798().field_1352, 0.2, this.mc.field_1724.method_18798().field_1350);
            } else if (this.getModeSetting().isSelected("РВ вода") && this.mc.field_1724.field_6012 % 3 == 0) {
               int waterSlot = this.calculateAnimationFactor();
               if (waterSlot != -1) {
                  int oldSlot = this.mc.field_1724.method_31548().method_67532();
                  this.mc.field_1724.method_31548().method_61496(waterSlot);
                  float oldPitch = this.mc.field_1724.method_36455();
                  this.mc.field_1724.method_36457(90.0F);
                  this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
                  this.mc.field_1724.method_6104(class_1268.field_5808);
                  this.mc.field_1724.method_36457(oldPitch);
                  this.mc.field_1724.method_31548().method_61496(oldSlot);
                  this.mc.field_1724.method_18800(this.mc.field_1724.method_18798().field_1352, 0.4, this.mc.field_1724.method_18798().field_1350);
               }
            }
         }

      }
   }

   private int calculateAnimationFactor() {
      for(int i = 0; i < 9; ++i) {
         if (this.mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8705) {
            return i;
         }
      }

      return -1;
   }

   private ListSetting getModeSetting() {
      return this.modListSetting;
   }

}
