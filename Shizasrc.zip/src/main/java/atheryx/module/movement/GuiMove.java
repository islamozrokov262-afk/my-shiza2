package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.PacketSendEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.ModeSetting;
import atheryx.util.NetworkUtils;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_2596;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_471;
import net.minecraft.class_490;
import net.minecraft.class_498;

@NewFunction(
   name = "GuiMove",
   desc = "Позволяет двигаться с открытым инвентарём",
   category = Category.MOVEMENT
)
public class GuiMove extends Function {
   private final ModeSetting modeModeSetting = new ModeSetting("Mode", new String[]{"Packet", "Grim full"});
   private final List<class_2596<?>> field_da56f3ea = new CopyOnWriteArrayList<class_2596<?>>();
   private final Queue<Runnable> field_47826ddf = new LinkedList<Runnable>();
   private boolean field_b4ade7d4;
   private boolean field_21d961c9;

   public GuiMove() {
      this.setActionPending(false);
      this.setInputCaptured(false);
      this.addSettings(new Setting[]{this.getModeSetting()});
   }

   @EventHandler
   public void onUpdate(UpdateEvent e) {
      if (this.mc.field_1724 == null) {
         this.resetStatePrimary();
      } else {
         if (!this.getCurrentValue().isEmpty()) {
            Runnable task = (Runnable)this.getCurrentValue().poll();
            if (task != null) {
               task.run();
            }
         }

         if (!this.isInputCaptured()) {
            if (this.mc.field_1755 != null && !(this.mc.field_1755 instanceof class_408) && !(this.mc.field_1755 instanceof class_498) && !(this.mc.field_1755 instanceof class_471)) {
               for(class_304 binding : new class_304[]{this.mc.field_1690.field_1894, this.mc.field_1690.field_1881, this.mc.field_1690.field_1849, this.mc.field_1690.field_1913, this.mc.field_1690.field_1903, this.mc.field_1690.field_1867}) {
                  if (class_3675.method_15987(this.mc.method_22683(), binding.method_1429().method_1444())) {
                     binding.method_23481(true);
                  }
               }

            }
         } else {
            for(class_304 binding : new class_304[]{this.mc.field_1690.field_1894, this.mc.field_1690.field_1881, this.mc.field_1690.field_1849, this.mc.field_1690.field_1913, this.mc.field_1690.field_1903, this.mc.field_1690.field_1867}) {
               binding.method_23481(false);
            }

         }
      }
   }

   @EventHandler
   public void onPacketSend(PacketSendEvent e) {
      if (this.mc.field_1724 != null && !this.getModeSetting().isSelected("Packet")) {
         if (!NetworkUtils.silentSending) {
            class_2596 var4 = e.getPacket();
            if (var4 instanceof class_2813) {
               class_2813 clickPacket = (class_2813)var4;
               if (this.mc.field_1755 instanceof class_490 && this.hasMovementInput() && this.shouldProcessPrimary()) {
                  this.getTrackedItems().add(clickPacket);
                  e.cancel();
                  return;
               }
            }

            var4 = e.getPacket();
            if (var4 instanceof class_2815) {
               class_2815 closePacket = (class_2815)var4;
               if (closePacket.method_36168() == 0 && !this.getTrackedItems().isEmpty() && !this.isActionPending()) {
                  this.getTrackedItems().add(closePacket);
                  e.cancel();
                  this.resetState();
               }
            }

         }
      }
   }

   private void resetState() {
      this.setActionPending(true);
      if (this.getModeSetting().isSelected("Grim full")) {
         this.getCurrentValue().add((Runnable)() -> {
            this.setInputCaptured(true);
         });
         this.getCurrentValue().add((Runnable)() -> {
            for(class_2596<?> p : this.getTrackedItems()) {
               NetworkUtils.sendPacketSilently(p);
            }

            this.getTrackedItems().clear();
            this.setActionPending(false);
            this.setInputCaptured(false);
            this.refreshTarget();
         });
      }

   }

   private void refreshTarget() {
      if (this.mc.method_22683() != null) {
         for(class_304 binding : new class_304[]{this.mc.field_1690.field_1894, this.mc.field_1690.field_1881, this.mc.field_1690.field_1849, this.mc.field_1690.field_1913, this.mc.field_1690.field_1903, this.mc.field_1690.field_1867}) {
            binding.method_23481(class_3675.method_15987(this.mc.method_22683(), binding.method_1429().method_1444()));
         }

      }
   }

   private boolean hasMovementInput() {
      return this.mc.field_1724 != null && this.mc.field_1724.field_3913 != null && this.mc.field_1724.field_3913.method_3128().method_35587() > 1.0E-7F;
   }

   private boolean shouldProcessPrimary() {
      return this.mc.field_1724 != null && this.mc.field_1724.field_7512 != null && this.mc.field_1724.field_7512.field_7761.size() >= 27;
   }

   private void resetStatePrimary() {
      this.getTrackedItems().clear();
      this.getCurrentValue().clear();
      this.setActionPending(false);
      this.setInputCaptured(false);
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
      this.resetStatePrimary();
   }

   private ModeSetting getModeSetting() {
      return this.modeModeSetting;
   }

   private List<class_2596<?>> getTrackedItems() {
      return this.field_da56f3ea;
   }

   private Queue getCurrentValue() {
      return this.field_47826ddf;
   }

   private boolean isActionPending() {
      return this.field_b4ade7d4;
   }

   private void setActionPending(boolean var1) {
      this.field_b4ade7d4 = var1;
   }

   private boolean isInputCaptured() {
      return this.field_21d961c9;
   }

   private void setInputCaptured(boolean var1) {
      this.field_21d961c9 = var1;
   }

}
