package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.PacketSendEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import net.minecraft.class_243;
import net.minecraft.class_2828;

@NewFunction(
   name = "AirStuck",
   desc = "Замораживает игрока, отменяя пакеты перемещения",
   category = Category.MOVEMENT
)
public class AirStuck extends Function {
   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         this.mc.field_1724.method_18799(class_243.field_1353);
         this.mc.field_1724.field_6017 = (double)0.0F;
         if (this.mc.field_1724.method_31549() != null) {
            this.mc.field_1724.method_31549().field_7479 = false;
         }

      }
   }

   @EventHandler
   public void onPacketSend(PacketSendEvent event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         if (event.getPacket() instanceof class_2828) {
            event.cancel();
         }

      }
   }

   public void onDisable() {
      if (this.mc.field_1724 != null) {
         this.mc.field_1724.method_18799(class_243.field_1353);
         this.mc.field_1724.field_6017 = (double)0.0F;
      }

   }

}
