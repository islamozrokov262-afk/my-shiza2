package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.manager.RotationManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ListSetting;
import atheryx.setting.impl.NumberSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3965;

@NewFunction(
   name = "Scaffold",
   desc = "Строит под вами блоки без пакетов (Сайлент ротация)",
   category = Category.MOVEMENT
)
public class Scaffold extends Function {
   private final BooleanSetting sohranyatVysotuBooleanSetting = new BooleanSetting("Сохранять высоту", false);
   private final BooleanSetting tellyBooleanSetting = new BooleanSetting("Telly", false);
   private final ListSetting korrektsiyaListSetting = new ListSetting("Коррекция", new String[]{"Silent", "None"});
   private final NumberSetting skorostRotatsiiNumberSetting = new NumberSetting("Скорость ротации", 90.0D, 10.0D, 180.0D, 5.0D);
   private int field_21d961c9;
   private class_2338 field_8f04dbbe;
   private class_2350 field_fc3055b3;
   private boolean field_695bcfa8;

   public Scaffold() {
      this.addSettings(new Setting[]{this.getMaintainHeightSetting(), this.getTellySetting(), this.getCorrectionSetting(), this.getRotationSpeedSetting()});
   }

   public void onEnable() {
      if (this.mc.field_1724 != null) {
         this.setCooldownTicks((int)Math.floor(this.mc.field_1724.method_23318()));
      }

      this.setAdjacent((class_2338)null);
      this.setPlacementFace((class_2350)null);
      this.setActionPending(false);
      super.onEnable();
   }

   public void onDisable() {
      if (this.isActionPending()) {
         RotationManager.reset();
         this.setActionPending(false);
      }

      super.onDisable();
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         int selectedSlot = -1;

         for(int i = 0; i < 9; ++i) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() instanceof class_1747) {
               selectedSlot = i;
               break;
            }
         }

         if (selectedSlot == -1) {
            if (this.isActionPending()) {
               RotationManager.reset();
               this.setActionPending(false);
            }

         } else {
            if (this.getMaintainHeightSetting().isEnabled() && this.mc.field_1690.field_1903.method_1434()) {
               this.setCooldownTicks((int)Math.floor(this.mc.field_1724.method_23318()));
            }

            boolean shouldPlace = true;
            if (this.getTellySetting().isEnabled()) {
               boolean falling = !this.mc.field_1724.method_24828() && this.mc.field_1724.method_18798().field_1351 < (double)0.0F;
               if (!falling) {
                  shouldPlace = false;
               }
            }

            double yPos = this.getMaintainHeightSetting().isEnabled() ? (double)(this.getCooldownTicks() - 1) : this.mc.field_1724.method_23318() - (double)1.0F;
            class_2338 posUnder = new class_2338((int)Math.floor(this.mc.field_1724.method_23317()), (int)Math.floor(yPos), (int)Math.floor(this.mc.field_1724.method_23321()));
            if (this.mc.field_1687.method_8320(posUnder).method_45474() && shouldPlace) {
               this.processPosition(posUnder);
            } else {
               this.setAdjacent((class_2338)null);
               this.setPlacementFace((class_2350)null);
            }

            if (this.getAdjacent() != null && this.getPlacementFace() != null) {
               class_243 hitVec = new class_243((double)this.getAdjacent().method_10263() + (double)0.5F + (double)this.getPlacementFace().method_10148() * (double)0.5F, (double)this.getAdjacent().method_10264() + (double)0.5F + (double)this.getPlacementFace().method_10164() * (double)0.5F, (double)this.getAdjacent().method_10260() + (double)0.5F + (double)this.getPlacementFace().method_10165() * (double)0.5F);
               RotationManager.Rotation targetRot = RotationManager.rotationTo(hitVec);
               float rotSpeed = (float)this.getRotationSpeedSetting().getValue();
               RotationManager.MoveCorrection correction = RotationManager.MoveCorrection.NONE;
               if (this.getCorrectionSetting().isSelected("Silent")) {
                  correction = RotationManager.MoveCorrection.SILENT;
               }

               RotationManager.requestRotation(targetRot, correction, rotSpeed, rotSpeed, rotSpeed);
               this.setActionPending(true);
               RotationManager.Rotation current = RotationManager.getCurrentRotation();
               if (this.isValidExact(targetRot, current)) {
                  int oldSlot = this.mc.field_1724.method_31548().method_67532();
                  this.mc.field_1724.method_31548().method_61496(selectedSlot);
                  class_3965 hitResult = new class_3965(hitVec, this.getPlacementFace(), this.getAdjacent(), false);
                  this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, hitResult);
                  this.mc.field_1724.method_6104(class_1268.field_5808);
                  this.mc.field_1724.method_31548().method_61496(oldSlot);
                  this.setAdjacent((class_2338)null);
                  this.setPlacementFace((class_2350)null);
               }
            } else if (this.isActionPending()) {
               RotationManager.reset();
               this.setActionPending(false);
            }

         }
      }
   }

   private void processPosition(class_2338 posUnder) {
      if (this.mc.field_1687.method_8320(posUnder).method_45474()) {
         List<class_2338> offsets = new ArrayList<class_2338>();
         offsets.add(new class_2338(0, -1, 0));
         offsets.add(new class_2338(1, 0, 0));
         offsets.add(new class_2338(-1, 0, 0));
         offsets.add(new class_2338(0, 0, 1));
         offsets.add(new class_2338(0, 0, -1));

         for(class_2338 offset : offsets) {
            class_2338 adjacent = posUnder.method_10081(offset);
            class_2680 state = this.mc.field_1687.method_8320(adjacent);
            if (!state.method_45474() && !state.method_26215()) {
               this.setAdjacent(adjacent);
               this.setPlacementFace(this.findPlacementDirection(offset).method_10153());
               return;
            }
         }

      }
   }

   private class_2350 findPlacementDirection(class_2338 offset) {
      if (offset.method_10263() > 0) {
         return class_2350.field_11034;
      } else if (offset.method_10263() < 0) {
         return class_2350.field_11039;
      } else if (offset.method_10264() > 0) {
         return class_2350.field_11036;
      } else if (offset.method_10264() < 0) {
         return class_2350.field_11033;
      } else if (offset.method_10260() > 0) {
         return class_2350.field_11035;
      } else {
         return offset.method_10260() < 0 ? class_2350.field_11043 : class_2350.field_11033;
      }
   }

   private boolean isValidExact(RotationManager.Rotation exact, RotationManager.Rotation current) {
      float yawDelta = Math.abs(class_3532.method_15393(exact.yaw() - current.yaw()));
      float pitchDelta = Math.abs(exact.pitch() - current.pitch());
      return yawDelta < 15.0F && pitchDelta < 15.0F;
   }

   private BooleanSetting getMaintainHeightSetting() {
      return this.sohranyatVysotuBooleanSetting;
   }

   private BooleanSetting getTellySetting() {
      return this.tellyBooleanSetting;
   }

   private ListSetting getCorrectionSetting() {
      return this.korrektsiyaListSetting;
   }

   private NumberSetting getRotationSpeedSetting() {
      return this.skorostRotatsiiNumberSetting;
   }

   private int getCooldownTicks() {
      return this.field_21d961c9;
   }

   private void setCooldownTicks(int var1) {
      this.field_21d961c9 = var1;
   }

   private class_2338 getAdjacent() {
      return this.field_8f04dbbe;
   }

   private void setAdjacent(class_2338 var1) {
      this.field_8f04dbbe = var1;
   }

   private class_2350 getPlacementFace() {
      return this.field_fc3055b3;
   }

   private void setPlacementFace(class_2350 var1) {
      this.field_fc3055b3 = var1;
   }

   private boolean isActionPending() {
      return this.field_695bcfa8;
   }

   private void setActionPending(boolean var1) {
      this.field_695bcfa8 = var1;
   }

}
