package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.ModeSetting;
import net.minecraft.class_12125;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_3489;
import net.minecraft.class_9334;

@NewFunction(
   name = "Fly",
   desc = "Свапает на копье и делает выпад",
   category = Category.MOVEMENT
)
public class Fly extends Function {
   private static final long obf_u00f3_u221c = 200L;
   private final ModeSetting rezhimModeSetting = new ModeSetting("Режим", new String[]{"Полёт на копье"});
   private int field_da56f3ea;
   private long field_47826ddf;

   public Fly() {
      this.setCooldownTicks(-1);
      this.addSettings(new Setting[]{this.getModeSetting()});
   }

   public void onEnable() {
      this.setCooldownTicks(this.mc.field_1724 != null ? this.mc.field_1724.method_31548().method_67532() : -1);
      this.setLastActionTime(0L);
   }

   public void onDisable() {
      if (this.mc.field_1724 != null && this.getCooldownTicks() >= 0 && this.getCooldownTicks() < 9) {
         this.mc.field_1724.method_31548().method_61496(this.getCooldownTicks());
      }

      this.setCooldownTicks(-1);
      this.setLastActionTime(0L);
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing() && this.mc.field_1761 != null && this.mc.field_1755 == null) {
         if (this.getModeSetting().isSelected("Полёт на копье") && !this.mc.field_1724.method_6115()) {
            if (System.currentTimeMillis() - this.getLastActionTime() >= 200L) {
               int spearSlot = this.calculateAnimationFactor();
               if (spearSlot != -1) {
                  class_1799 spearStack = this.mc.field_1724.method_31548().method_5438(spearSlot);
                  class_12125 piercingWeapon = (class_12125)spearStack.method_58694(class_9334.field_63631);
                  if (piercingWeapon != null) {
                     int currentSlot = this.mc.field_1724.method_31548().method_67532();
                     this.mc.field_1724.method_31548().method_61496(spearSlot);
                     this.mc.field_1761.method_75407(piercingWeapon);
                     this.mc.field_1724.method_6104(class_1268.field_5808);
                     if (currentSlot != spearSlot) {
                        this.mc.field_1724.method_31548().method_61496(currentSlot);
                     }

                     this.setLastActionTime(System.currentTimeMillis());
                  }
               }
            }
         }
      }
   }

   private int calculateAnimationFactor() {
      for(int slot = 0; slot < 9; ++slot) {
         class_1799 stack = this.mc.field_1724.method_31548().method_5438(slot);
         if (stack.method_31573(class_3489.field_63257)) {
            return slot;
         }
      }

      return -1;
   }

   private ModeSetting getModeSetting() {
      return this.rezhimModeSetting;
   }

   private int getCooldownTicks() {
      return this.field_da56f3ea;
   }

   private void setCooldownTicks(int var1) {
      this.field_da56f3ea = var1;
   }

   private long getLastActionTime() {
      return this.field_47826ddf;
   }

   private void setLastActionTime(long var1) {
      this.field_47826ddf = var1;
   }

}
