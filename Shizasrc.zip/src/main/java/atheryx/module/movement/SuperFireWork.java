package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import net.minecraft.class_1657;
import net.minecraft.class_243;

@NewFunction(
   name = "SuperFireWork",
   desc = "Даёт больше буста от фейерверк",
   category = Category.MOVEMENT
)
public class SuperFireWork extends Function {
   public ModeSetting mode;
   public final NumberSetting speed;
   public final BooleanSetting nearBoost;
   public float speedXZ;
   public float speedY;
   public float diag1;
   public float diag2;
   public float diag3;
   public float diag4;
   public float diag5;
   public float diag6;
   public float diag7;
   public float diag8;
   public float diag9;
   public float diag10;
   public float speedD_1;
   public float speedD_2;
   public float speedD_3;
   public float speedD_4;
   public float speedD_5;
   public float speedD_6;
   public float speedD_7;
   public float speedD_8;
   public float speedD_9;
   public float speedPitch;
   public float speedPitchY;
   public float speedNXZ;
   public float speedNY;
   private int field_5decd0c1;

   public SuperFireWork() {
      this.setMode(new ModeSetting("Мод", new String[]{"BravoHvH", "ReallyWorld", "PulseHVH", "Custom"}));
      this.speed = new NumberSetting("Скорость", 1.7, (double)1.5F, 8.0D, 0.01);
      this.nearBoost = new BooleanSetting("Ускорение если рядом игрок", false);
      this.setSpeedXZ(1.5F);
      this.setSpeedY(1.5F);
      this.setFirstStageThreshold(5.0F);
      this.setSecondStageThreshold(5.0F);
      this.setThirdStageThreshold(5.0F);
      this.setFourthStageThreshold(5.0F);
      this.setFifthStageThreshold(5.0F);
      this.setSixthStageThreshold(5.0F);
      this.setSeventhStageThreshold(5.0F);
      this.setEighthStageThreshold(5.0F);
      this.setNinthStageThreshold(5.0F);
      this.setTenthStageThreshold(5.0F);
      this.setFirstStageSpeed(1.5F);
      this.setSecondStageSpeed(1.5F);
      this.setThirdStageSpeed(1.5F);
      this.setFourthStageSpeed(1.5F);
      this.setFifthStageSpeed(1.5F);
      this.setSixthStageSpeed(1.5F);
      this.setSeventhStageSpeed(1.5F);
      this.setEighthStageSpeed(1.5F);
      this.setNinthStageSpeed(1.5F);
      this.setSpeedPitch(1.5F);
      this.setSpeedPitchY(1.5F);
      this.setSpeedNXZ(1.5F);
      this.setSpeedNY(1.5F);
      this.setFlightTicks(0);
      this.addSettings(new Setting[]{this.getMode(), this.getSpeed(), this.getNearBoost()});
      this.getMode().setChangeListener(() -> {
         this.getSpeed().setVisible(this.getMode().isSelected("Custom"));
      });
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      this.setSpeedXZ(1.61F);
      this.setSpeedY(1.61F);
      this.setFirstStageThreshold(4.0F);
      this.setSecondStageThreshold(8.0F);
      this.setThirdStageThreshold(12.0F);
      this.setFourthStageThreshold(16.0F);
      this.setFifthStageThreshold(20.0F);
      this.setSixthStageThreshold(24.0F);
      this.setSeventhStageThreshold(28.0F);
      this.setEighthStageThreshold(32.0F);
      this.setNinthStageThreshold(36.0F);
      this.setTenthStageThreshold(40.0F);
      this.setSpeedPitch(2.5F);
      this.setSpeedPitchY(2.5F);
      this.setFirstStageSpeed(2.20000005F);
      this.setSecondStageSpeed(2.05999994F);
      this.setThirdStageSpeed(1.98F);
      this.setFourthStageSpeed(1.87F);
      this.setFifthStageSpeed(1.8F);
      this.setSixthStageSpeed(1.74F);
      this.setSeventhStageSpeed(1.7F);
      this.setEighthStageSpeed(1.65F);
      this.setNinthStageSpeed(1.63F);
      this.setSpeedNXZ(1.66F);
      this.setSpeedNY(1.66F);
      if (this.nullCheck.isPlayerOrWorldMissing()) {
         this.setFlightTicks(0);
      } else {
         if (this.mc.field_1724.method_6128()) {
            this.setFlightTicks(this.getFlightTicks() + 1);
            double sXZ = this.getSpeed().getValue();
            double sY = this.getSpeed().getValue();
            String var6 = this.getMode().getValue();
            byte var7 = -1;
            switch (var6.hashCode()) {
               case 46952496:
                  if (var6.equals("BravoHvH")) {
                     var7 = 0;
                  }
                  break;
               case 935423623:
                  if (var6.equals("ReallyWorld")) {
                     var7 = 1;
                  }
                  break;
               case 1650855649:
                  if (var6.equals("PulseHVH")) {
                     var7 = 2;
                  }
                  break;
               case 2029746065:
                  if (var6.equals("Custom")) {
                     var7 = 3;
                  }
            }

            switch (var7) {
               case 0:
                  if ((float)this.getFlightTicks() <= this.getFirstStageThreshold()) {
                     sXZ = (double)this.getFirstStageSpeed();
                     sY = (double)this.getFirstStageSpeed();
                  } else if ((float)this.getFlightTicks() <= this.getSecondStageThreshold()) {
                     sXZ = (double)this.getSecondStageSpeed();
                     sY = (double)this.getSecondStageSpeed();
                  } else if ((float)this.getFlightTicks() <= this.getThirdStageThreshold()) {
                     sXZ = (double)this.getThirdStageSpeed();
                     sY = (double)this.getThirdStageSpeed();
                  } else if ((float)this.getFlightTicks() <= this.getFourthStageThreshold()) {
                     sXZ = (double)this.getFourthStageSpeed();
                     sY = (double)this.getFourthStageSpeed();
                  } else if ((float)this.getFlightTicks() <= this.getFifthStageThreshold()) {
                     sXZ = (double)this.getFifthStageSpeed();
                     sY = (double)this.getFifthStageSpeed();
                  } else if ((float)this.getFlightTicks() <= this.getSixthStageThreshold()) {
                     sXZ = (double)this.getSixthStageSpeed();
                     sY = (double)this.getSixthStageSpeed();
                  } else if ((float)this.getFlightTicks() <= this.getSeventhStageThreshold()) {
                     sXZ = (double)this.getSeventhStageSpeed();
                     sY = (double)this.getSeventhStageSpeed();
                  } else if ((float)this.getFlightTicks() <= this.getEighthStageThreshold()) {
                     sXZ = (double)this.getEighthStageSpeed();
                     sY = (double)this.getEighthStageSpeed();
                  } else if ((float)this.getFlightTicks() <= this.getNinthStageThreshold()) {
                     sXZ = (double)this.getNinthStageSpeed();
                     sY = (double)this.getNinthStageSpeed();
                  } else if ((float)this.getFlightTicks() <= this.getTenthStageThreshold()) {
                     sXZ = (double)this.getSpeedXZ();
                     sY = (double)this.getSpeedY();
                  } else {
                     this.setFlightTicks(0);
                     sXZ = (double)this.getSpeedXZ();
                     sY = (double)this.getSpeedY();
                  }
                  break;
               case 1:
                  sXZ = (double)this.getSpeedNXZ();
                  sY = (double)this.getSpeedNY();
                  break;
               case 2:
                  sXZ = (double)this.getSpeedPitch();
                  sY = (double)this.getSpeedPitchY();
                  break;
               case 3:
               default:
                  sXZ = this.getSpeed().getValue();
                  sY = this.getSpeed().getValue();
            }

            if (this.getNearBoost().isEnabled()) {
               boolean hasPlayersNear = false;

               for(class_1657 p : this.mc.field_1687.method_18456()) {
                  if (p != this.mc.field_1724 && this.mc.field_1724.method_5739(p) < 15.0F) {
                     hasPlayersNear = true;
                     break;
                  }
               }

               if (hasPlayersNear) {
                  sXZ += 0.2;
                  sY += 0.2;
               }
            }

            class_243 look = this.mc.field_1724.method_5720();
            class_243 currentVel = this.mc.field_1724.method_18798();
            double boostX = look.field_1352 * 0.1 + (look.field_1352 * sXZ - currentVel.field_1352) * (double)0.5F;
            double boostY = look.field_1351 * 0.1 + (look.field_1351 * sY - currentVel.field_1351) * (double)0.5F;
            double boostZ = look.field_1350 * 0.1 + (look.field_1350 * sXZ - currentVel.field_1350) * (double)0.5F;
            this.mc.field_1724.method_5762(boostX, boostY, boostZ);
         } else {
            this.setFlightTicks(0);
         }

      }
   }

   private ModeSetting getMode() {
      return this.mode;
   }

   private void setMode(ModeSetting var1) {
      this.mode = var1;
   }

   private NumberSetting getSpeed() {
      return this.speed;
   }

   private BooleanSetting getNearBoost() {
      return this.nearBoost;
   }

   private float getSpeedXZ() {
      return this.speedXZ;
   }

   private void setSpeedXZ(float var1) {
      this.speedXZ = var1;
   }

   private float getSpeedY() {
      return this.speedY;
   }

   private void setSpeedY(float var1) {
      this.speedY = var1;
   }

   private float getFirstStageThreshold() {
      return this.diag1;
   }

   private void setFirstStageThreshold(float var1) {
      this.diag1 = var1;
   }

   private float getSecondStageThreshold() {
      return this.diag2;
   }

   private void setSecondStageThreshold(float var1) {
      this.diag2 = var1;
   }

   private float getThirdStageThreshold() {
      return this.diag3;
   }

   private void setThirdStageThreshold(float var1) {
      this.diag3 = var1;
   }

   private float getFourthStageThreshold() {
      return this.diag4;
   }

   private void setFourthStageThreshold(float var1) {
      this.diag4 = var1;
   }

   private float getFifthStageThreshold() {
      return this.diag5;
   }

   private void setFifthStageThreshold(float var1) {
      this.diag5 = var1;
   }

   private float getSixthStageThreshold() {
      return this.diag6;
   }

   private void setSixthStageThreshold(float var1) {
      this.diag6 = var1;
   }

   private float getSeventhStageThreshold() {
      return this.diag7;
   }

   private void setSeventhStageThreshold(float var1) {
      this.diag7 = var1;
   }

   private float getEighthStageThreshold() {
      return this.diag8;
   }

   private void setEighthStageThreshold(float var1) {
      this.diag8 = var1;
   }

   private float getNinthStageThreshold() {
      return this.diag9;
   }

   private void setNinthStageThreshold(float var1) {
      this.diag9 = var1;
   }

   private float getTenthStageThreshold() {
      return this.diag10;
   }

   private void setTenthStageThreshold(float var1) {
      this.diag10 = var1;
   }

   private float getFirstStageSpeed() {
      return this.speedD_1;
   }

   private void setFirstStageSpeed(float var1) {
      this.speedD_1 = var1;
   }

   private float getSecondStageSpeed() {
      return this.speedD_2;
   }

   private void setSecondStageSpeed(float var1) {
      this.speedD_2 = var1;
   }

   private float getThirdStageSpeed() {
      return this.speedD_3;
   }

   private void setThirdStageSpeed(float var1) {
      this.speedD_3 = var1;
   }

   private float getFourthStageSpeed() {
      return this.speedD_4;
   }

   private void setFourthStageSpeed(float var1) {
      this.speedD_4 = var1;
   }

   private float getFifthStageSpeed() {
      return this.speedD_5;
   }

   private void setFifthStageSpeed(float var1) {
      this.speedD_5 = var1;
   }

   private float getSixthStageSpeed() {
      return this.speedD_6;
   }

   private void setSixthStageSpeed(float var1) {
      this.speedD_6 = var1;
   }

   private float getSeventhStageSpeed() {
      return this.speedD_7;
   }

   private void setSeventhStageSpeed(float var1) {
      this.speedD_7 = var1;
   }

   private float getEighthStageSpeed() {
      return this.speedD_8;
   }

   private void setEighthStageSpeed(float var1) {
      this.speedD_8 = var1;
   }

   private float getNinthStageSpeed() {
      return this.speedD_9;
   }

   private void setNinthStageSpeed(float var1) {
      this.speedD_9 = var1;
   }

   private float getSpeedPitch() {
      return this.speedPitch;
   }

   private void setSpeedPitch(float var1) {
      this.speedPitch = var1;
   }

   private float getSpeedPitchY() {
      return this.speedPitchY;
   }

   private void setSpeedPitchY(float var1) {
      this.speedPitchY = var1;
   }

   private float getSpeedNXZ() {
      return this.speedNXZ;
   }

   private void setSpeedNXZ(float var1) {
      this.speedNXZ = var1;
   }

   private float getSpeedNY() {
      return this.speedNY;
   }

   private void setSpeedNY(float var1) {
      this.speedNY = var1;
   }

   private int getFlightTicks() {
      return this.field_5decd0c1;
   }

   private void setFlightTicks(int var1) {
      this.field_5decd0c1 = var1;
   }

}
