package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.InputEvent;
import atheryx.event.impl.PacketReceiveEvent;
import atheryx.event.impl.PacketSendEvent;
import atheryx.event.impl.Render2DEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.manager.TimerManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.util.MoveUtil;
import atheryx.util.NetworkUtils;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_6374;

@NewFunction(
   name = "Timer",
   desc = "Замедляется, накапливает инерцию и резко выбрасывает её в ускорение",
   category = Category.MOVEMENT
)
public class Timer extends Function {
   private static final float obf_u2216_u221b = 0.0500000007F;
   private static final float obf_u2205_u221b = 1.70000005F;
   private static final long obf_u00e8_u221b = 1250000000L;
   private static final long obf_u00e6_u221b = 2400000000L;
   private static final int obf_u2218_u221b = 4;
   private TimerPhase field_6d2b79f5;
   private boolean field_da56f3ea;
   private boolean field_47826ddf;
   private int field_b4ade7d4;
   private int field_21d961c9;
   private long field_8f04dbbe;
   private final Queue<class_6374> field_fc3055b3;

   public Timer() {
      this.setPhase(Timer.TimerPhase.CHARGING);
      this.field_fc3055b3 = new ConcurrentLinkedQueue<class_6374>();
   }

   public void onEnable() {
      this.prepareInteraction();
   }

   public void onDisable() {
      this.prepareInteraction();
   }

   @EventHandler
   public void onRender2D(Render2DEvent event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         if (!MoveUtil.isMoving()) {
            this.prepareInteraction();
         } else {
            long now = System.nanoTime();
            if (!this.isActionPending()) {
               this.setActionPending(true);
               this.refreshTarget();
            } else {
               if (this.getPhase() == Timer.TimerPhase.CHARGING && now - this.getLastFrameTime() >= 1250000000L) {
                  this.updateRotation();
               } else if (this.getPhase() == Timer.TimerPhase.BOOSTING && now - this.getLastFrameTime() >= 2400000000L) {
                  this.advanceActionPhase();
               }

            }
         }
      } else {
         this.prepareInteraction();
      }
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         if (this.isActionPending() && this.getPhase() == Timer.TimerPhase.BOOSTING) {
            if (this.mc.field_1724.field_5992) {
               if (this.isInputCaptured()) {
                  this.setInputCaptured(false);
                  this.setCooldownTicks(this.getCooldownTicks() + 1);
               }
            } else {
               this.setInputCaptured(true);
               if (this.getCooldownTicks() >= 4 && this.mc.field_1724.method_18798().field_1351 <= (double)0.0F) {
                  this.advanceActionPhase();
               }
            }

         }
      } else {
         this.prepareInteraction();
      }
   }

   @EventHandler
   public void onInput(InputEvent event) {
      if (this.mc.field_1724 != null && this.getPhase() == Timer.TimerPhase.BOOSTING && MoveUtil.isMoving()) {
         this.setRetryCount(this.mc.field_1724.field_5992 ? this.getRetryCount() + 1 : 0);
         event.setSprinting(true);
         if (this.getRetryCount() > 0) {
            event.setJumping(true);
         }

      } else {
         this.setRetryCount(0);
      }
   }

   @EventHandler
   public void onPacketSend(PacketSendEvent event) {
      if (this.isActionPending()) {
         class_2596 var3 = event.getPacket();
         if (var3 instanceof class_6374) {
            class_6374 packet = (class_6374)var3;
            this.getCurrentValue().add(packet);
            event.cancel();
         }
      }

   }

   @EventHandler
   public void onPacketReceive(PacketReceiveEvent event) {
      if (this.isActionPending() && this.getPhase() == Timer.TimerPhase.BOOSTING && event.getPacket() instanceof class_2708) {
         this.advanceActionPhase();
      }

   }

   private void refreshTarget() {
      this.resetTransientState();
      this.setPhase(Timer.TimerPhase.CHARGING);
      this.setInputCaptured(false);
      this.setCooldownTicks(0);
      this.setRetryCount(0);
      this.setLastFrameTime(System.nanoTime());
      TimerManager.setTimerSpeed(0.05F);
   }

   private void updateRotation() {
      this.setPhase(Timer.TimerPhase.BOOSTING);
      this.setInputCaptured(false);
      this.setCooldownTicks(0);
      this.setRetryCount(0);
      this.setLastFrameTime(System.nanoTime());
      TimerManager.setTimerSpeed(1.7F);
   }

   private void advanceActionPhase() {
      this.toggle();
      this.toggle();
   }

   private void prepareInteraction() {
      this.resetTransientState();
      this.setActionPending(false);
      this.setPhase(Timer.TimerPhase.CHARGING);
      this.setInputCaptured(false);
      this.setCooldownTicks(0);
      this.setRetryCount(0);
      this.setLastFrameTime(0L);
      TimerManager.reset();
   }

   private void resetTransientState() {
      class_6374 packet;
      while((packet = (class_6374)this.getCurrentValue().poll()) != null) {
         NetworkUtils.sendPacketSilently(packet);
      }

   }

   private TimerPhase getPhase() {
      return this.field_6d2b79f5;
   }

   private void setPhase(TimerPhase var1) {
      this.field_6d2b79f5 = var1;
   }

   private boolean isActionPending() {
      return this.field_da56f3ea;
   }

   private void setActionPending(boolean var1) {
      this.field_da56f3ea = var1;
   }

   private boolean isInputCaptured() {
      return this.field_47826ddf;
   }

   private void setInputCaptured(boolean var1) {
      this.field_47826ddf = var1;
   }

   private int getCooldownTicks() {
      return this.field_b4ade7d4;
   }

   private void setCooldownTicks(int var1) {
      this.field_b4ade7d4 = var1;
   }

   private int getRetryCount() {
      return this.field_21d961c9;
   }

   private void setRetryCount(int var1) {
      this.field_21d961c9 = var1;
   }

   private long getLastFrameTime() {
      return this.field_8f04dbbe;
   }

   private void setLastFrameTime(long var1) {
      this.field_8f04dbbe = var1;
   }

   private Queue getCurrentValue() {
      return this.field_fc3055b3;
   }


   private static enum TimerPhase {
      CHARGING,
      BOOSTING;

   }
}
