package atheryx.module.movement;

import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;

@NewFunction(
   name = "NoPush",
   desc = "Отключает отталкивание от сущностей и воды",
   category = Category.MOVEMENT
)
public class NoPush extends Function {
   public static NoPush Instance;
   public static BooleanSetting players = new BooleanSetting("Сущности", true);
   public static BooleanSetting water = new BooleanSetting("Вода", true);

   public NoPush() {
      Instance = this;
      this.addSettings(new Setting[]{players, water});
   }

}
