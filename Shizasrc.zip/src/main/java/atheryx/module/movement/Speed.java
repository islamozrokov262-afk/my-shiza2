package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.NumberSetting;
import atheryx.util.MoveUtil;
import java.util.Locale;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_238;

@NewFunction(
   name = "Speed",
   desc = "Ускоряет игрока при столкновении с сущностями",
   category = Category.MOVEMENT
)
public class Speed extends Function {
   private final ModeSetting rezhimModeSetting = new ModeSetting("Режим", new String[]{"Grim", "MetaHVH", "Grim", "HolyWorld"});
   private final NumberSetting skorostNumberSetting = new NumberSetting("Скорость", (double)1.5F, (double)1.0F, 5.0D, 0.1);

   public Speed() {
      this.getModeSetting().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
      this.addSettings(new Setting[]{this.getModeSetting(), this.getSpeedSetting()});
   }

   private void updateSettingVisibility() {
      this.getSpeedSetting().setVisible(this.getModeSetting().isSelected("MetaHVH"));
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         if (MoveUtil.isMoving()) {
            if (this.getModeSetting().isSelected("MetaHVH")) {
               this.updateRotation();
            } else if (this.getModeSetting().isSelected("Grim")) {
               this.advanceActionPhase();
            } else if (this.getModeSetting().isSelected("HolyWorld")) {
               this.prepareInteraction();
            }

         }
      }
   }

   private void updateRotation() {
      double speedMult = this.getSpeedSetting().getValue() / 3.0D;
      MoveUtil.setHorizontalSpeed(speedMult);
   }

   private void advanceActionPhase() {
      int collisions = 0;

      for(class_1297 entity : this.mc.field_1687.method_18112()) {
         if (this.isValidEntity(entity) && this.isValidEntity(entity, (double)0.5F)) {
            ++collisions;
         }
      }

      if (collisions > 0) {
         double boost = 0.07 * (double)collisions;
         double[] dir = MoveUtil.getMotionForSpeed(boost);
         this.mc.field_1724.method_5762(dir[0], (double)0.0F, dir[1]);
      }

   }

   private void prepareInteraction() {
      int collisions = 0;

      for(class_1297 entity : this.mc.field_1687.method_18112()) {
         if (this.isValidEntity(entity) && this.isValidEntity(entity, 0.35)) {
            ++collisions;
         }
      }

      if (collisions > 0) {
         double boost = 0.0205 * (double)collisions;
         double[] dir = MoveUtil.getMotionForSpeed(boost);
         this.mc.field_1724.method_5762(dir[0], (double)0.0F, dir[1]);
      }

   }

   private boolean isValidEntity(class_1297 entity) {
      if (entity != null && entity != this.mc.field_1724 && !(entity instanceof class_1531)) {
         return entity instanceof class_1309 || entity.method_5864().toString().toLowerCase(Locale.ROOT).contains("boat");
      } else {
         return false;
      }
   }

   private boolean isValidEntity(class_1297 entity, double inflate) {
      class_238 playerBox = this.mc.field_1724.method_5829().method_1014(inflate);
      class_238 entityBox = entity.method_5829();
      return playerBox.method_994(entityBox);
   }

   private ModeSetting getModeSetting() {
      return this.rezhimModeSetting;
   }

   private NumberSetting getSpeedSetting() {
      return this.skorostNumberSetting;
   }

}
