package atheryx.module.movement;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.util.MoveUtil;
import atheryx.util.PlayerInteractionHelper;
import net.minecraft.class_2246;

@NewFunction(
   name = "NoWeb",
   desc = "Позволяет быстро перемещаться в паутине",
   category = Category.MOVEMENT
)
public class NoWeb extends Function {
   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         if (PlayerInteractionHelper.isPlayerInsideBlock(class_2246.field_10343)) {
            MoveUtil.setSpeedAndVerticalVelocity(0.64, (double)0.0F);
            if (this.mc.field_1690.field_1903.method_1434()) {
               MoveUtil.setSpeedAndVerticalVelocity(0.64, 0.95);
            }

            if (this.mc.field_1690.field_1832.method_1434()) {
               MoveUtil.setSpeedAndVerticalVelocity(0.64, -0.95);
            }
         }

      }
   }

}
