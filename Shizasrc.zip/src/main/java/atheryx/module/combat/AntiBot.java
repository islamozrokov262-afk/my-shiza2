package atheryx.module.combat;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.ModeSetting;
import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_640;
import net.minecraft.class_1297.class_5529;

@NewFunction(
   name = "AntiBot",
   desc = "Обнаруживает ботов по паттернам брони и инвентаря",
   category = Category.COMBAT
)
public class AntiBot extends Function {
   private final ModeSetting rezhimModeSetting = new ModeSetting("Режим", new String[]{"Matrix/Rw", "CakeWorld"});
   private final List<class_1657> field_da56f3ea = new ArrayList<class_1657>();
   private final Pattern field_47826ddf = Pattern.compile("^\\w{3,16}$");

   public AntiBot() {
      this.addSettings(new Setting[]{this.getModeSetting()});
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         for(class_1657 player : this.mc.field_1687.method_18456()) {
            if (player != this.mc.field_1724) {
               boolean isBot = false;
               if (this.getModeSetting().getValue().equals("Matrix/Rw")) {
                  isBot = this.isValidPlayer(player);
               } else if (this.getModeSetting().getValue().equals("CakeWorld")) {
                  isBot = this.matchesPlayerPrimary(player);
               }

               if (isBot) {
                  if (!this.getKnownBotNames().contains(player)) {
                     this.getKnownBotNames().add(player);
                  }

                  if (this.getModeSetting().getValue().equals("CakeWorld")) {
                     this.mc.field_1687.method_2945(player.method_5628(), class_5529.field_26999);
                  }
               } else {
                  this.getKnownBotNames().remove(player);
               }
            }
         }

         this.getKnownBotNames().removeIf((playerx) -> {
            return playerx == null || !playerx.method_5805() || !this.mc.field_1687.method_18456().contains(playerx);
         });
      }
   }

   public void onDisable() {
      super.onDisable();
      this.getKnownBotNames().clear();
   }

   public boolean matchesPlayer(class_1657 player) {
      return this.getKnownBotNames().contains(player);
   }

   private boolean isValidPlayer(class_1657 player) {
      for(class_1304 slot : new class_1304[]{class_1304.field_6166, class_1304.field_6172, class_1304.field_6174, class_1304.field_6169}) {
         class_1799 armorPiece = player.method_6118(slot);
         if (!armorPiece.method_7960() && armorPiece.method_7923() && !armorPiece.method_7986() && this.isValidPlayerPrimary(player) && !player.method_6047().method_7960() && player.method_6079().method_7960() && player.method_7344().method_7586() == 20) {
            return true;
         }
      }

      return false;
   }

   private boolean isValidPlayerPrimary(class_1657 player) {
      return player.method_6118(class_1304.field_6166).method_7909() == class_1802.field_8370 || player.method_6118(class_1304.field_6172).method_7909() == class_1802.field_8570 || player.method_6118(class_1304.field_6174).method_7909() == class_1802.field_8577 || player.method_6118(class_1304.field_6169).method_7909() == class_1802.field_8267 || player.method_6118(class_1304.field_6166).method_7909() == class_1802.field_8660 || player.method_6118(class_1304.field_6172).method_7909() == class_1802.field_8396 || player.method_6118(class_1304.field_6174).method_7909() == class_1802.field_8523 || player.method_6118(class_1304.field_6169).method_7909() == class_1802.field_8743;
   }

   private boolean matchesPlayerPrimary(class_1657 player) {
      if (this.mc.field_1724 != null && this.mc.field_1724.field_3944 != null) {
         class_640 entry = this.mc.field_1724.field_3944.method_2871(player.method_5667());
         if (entry == null) {
            return true;
         } else {
            String name = player.method_7334().name();
            if (name == null) {
               return true;
            } else {
               return !this.collectItems().contains(name);
            }
         }
      } else {
         return false;
      }
   }

   private List<String> collectItems() {
      return (List<String>)(this.mc.field_1724 != null && this.mc.field_1724.field_3944 != null ? (List)this.mc.field_1724.field_3944.method_2880().stream().map(class_640::method_2966).map(GameProfile::name).filter((name) -> {
         return this.getBotNamePattern().matcher(name).matches();
      }).collect(Collectors.toList()) : new ArrayList());
   }

   private ModeSetting getModeSetting() {
      return this.rezhimModeSetting;
   }

   private List<class_1657> getKnownBotNames() {
      return this.field_da56f3ea;
   }

   private Pattern getBotNamePattern() {
      return this.field_47826ddf;
   }

}
