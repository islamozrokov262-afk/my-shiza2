package atheryx.module.combat;

import atheryx.event.EventHandler;
import atheryx.event.impl.InputEvent;
import atheryx.event.impl.Render2DEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.gui.ThemeManager;
import atheryx.manager.RotationManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.module.player.ElytraHelper;
import atheryx.render.RenderUtil;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ListSetting;
import atheryx.setting.impl.MultiListSetting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1839;
import net.minecraft.class_243;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_490;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@NewFunction(
   name = "AttackAura",
   desc = "Плавный сайлент-аим и атака ближайших сущностей",
   category = Category.COMBAT
)
public class AttackAura extends Function {
   private static final float obf_u0437 = 0.5F;
   private static final float obf_u00d1 = 0.920000017F;
   private static final float obf_u0394 = 30.0F;
   private static final float obf_u044c = 60.0F;
   private static final float obf_u2213 = 2.0F;
   private static final float obf_u041c = 8.0F;
   private static final int obf_u0409 = 50;
   private static final long obf_u044a = 200L;
   private static final float obf_u00d9 = 0.0500000007F;
   private static final double obf_u00fa = -0.029999999999999999D;
   private static final double obf_u03b6 = 0.029999999999999999D;
   private static final int obf_u223d = 3;
   private final NumberSetting radiusNumberSetting = new NumberSetting("Радиус", 3.0D, (double)1.0F, 6.0D, 0.1);
   private final NumberSetting radiusAimaNumberSetting = new NumberSetting("Радиус аима", 3.0D, (double)1.0F, 6.0D, 0.1);
   private final ListSetting rotatsiyaListSetting = new ListSetting("Ротация", new String[]{"Grim", "ReallyWorld", "HvH", "Sloth", "SpookyTime", "SpookyDuels", "Legit", "FunTime"});
   private final NumberSetting fovLegitNumberSetting = new NumberSetting("FOV (Legit)", 90.0D, 10.0D, 360.0D, (double)1.0F);
   private final NumberSetting skorostLegitNumberSetting = new NumberSetting("Скорость (Legit)", 30.0D, (double)1.0F, 100.0D, (double)1.0F);
   private final NumberSetting dzhitterLegitNumberSetting = new NumberSetting("Джиттер (Legit)", (double)0.0F, (double)0.0F, 5.0D, 0.1);
   private final ListSetting korrektsiyaListSetting = new ListSetting("Коррекция", new String[]{"Свободная", "Сфокусированная", "Нету"});
   private final ListSetting sortirovkaListSetting = new ListSetting("Сортировка", new String[]{"Дистанция", "Здоровье", "Поле зрения"});
   private final MultiListSetting tseliMultiListSetting = new MultiListSetting("Цели", new String[]{"Игроки", "Животные", "Мобы", "Невидимые"});
   private final MultiListSetting neBitEsliMultiListSetting = new MultiListSetting("Не бить если", new String[]{"Если ешь", "Если открыт инвентарь"});
   private final BooleanSetting bitCherezStenyBooleanSetting = new BooleanSetting("Бить через стены", true);
   private final BooleanSetting umnyeKrityBooleanSetting = new BooleanSetting("Умные криты", false);
   private final ListSetting otvodkaListSetting = new ListSetting("Отводка", new String[]{"Silent", "ClientLook", "Нету"});
   private final ListSetting sbrosSprintaListSetting = new ListSetting("Сброс спринта", new String[]{"Быстрый", "Легитный"});
   private float field_658c255b;
   private float field_d2b79f50;
   private class_1309 field_3fe31945;
   private long field_ad0e933a;
   private int field_1a3a0d2f;
   private int field_87658724;
   private int field_f4910119;
   private boolean field_61bc7b0e;
   private boolean field_cee7f503;
   private long field_3c136ef8;
   private boolean field_a93ee8ed;
   private int field_166a62e2;
   private final Random field_8395dcd7 = new Random();
   private int field_f0c156cc;
   private int field_5decd0c1;
   private long field_cb184ab6;
   private long field_3843c4ab;
   private float field_a56f3ea0;
   private float field_129ab895;
   private float field_7fc6328a;
   private int field_ecf1ac7f;
   private int field_5a1d2674;
   private float field_c748a069;
   private float field_34741a5e;
   private long field_a19f9453;
   private boolean field_ecb0e48;
   private static final float obf_u042d = 25.5F;
   private static final float obf_u00e1 = 44.5F;
   private static final float obf_u0408 = 74.0F;
   private static final float obf_u03c6 = 32.3339996F;
   private static final float obf_u0416 = 1.03298342F;
   private static final float obf_u0404 = 0.00100000005F;
   private static final float obf_u0438 = 25.5F;
   private static final float obf_u045e = 44.5F;
   private static final float obf_u0441 = 2.20000005F;
   private static final float obf_u03bd = 0.319999993F;
   private static final float obf_u0427 = 74.0F;
   private static final float obf_u0442 = 32.3339996F;
   private static final float obf_u00ca = 1.03298342F;
   private static final float obf_u223b = 0.00100000005F;
   private static final float obf_u00fd = 50.0F;
   private static final float obf_u222b = 25.0F;
   private static final float obf_u00d4 = 30.0F;
   private long field_7bf6883d;

   public AttackAura() {
      this.setPreviousSlot(-1);
      this.setCurrentFrame(0L);
      this.setYawS(0.0F);
      this.setPitchS(0.0F);
      this.setAimSlowdown(0.0F);
      this.setVisibleTargetTicks(0);
      this.setReactionTicks(0);
      this.setYawJitter(0.0F);
      this.setPitchJitter(0.0F);
      this.setNowPrimary(0L);
      this.setAimInitialized(false);
      this.setLastActionTime(0L);
      this.addSettings(new Setting[]{this.getRotationSetting(), this.getFovLegitSetting(), this.getLegitSpeedSetting(), this.getLegitJitterSetting(), this.getCorrectionSetting(), this.getSortingSetting(), this.getTargetsSetting(), this.getRadiusSetting(), this.getAimRadiusSetting(), this.getDoNotAttackWhenSetting(), this.getAttackThroughWallsSetting(), this.getSmartCriticalsSetting(), this.getRotationApplicationSetting(), this.getSprintResetSetting()});
   }

   public void onEnable() {
      if (this.mc.field_1724 != null) {
         this.setRotationYaw(this.mc.field_1724.method_36454());
         this.setRotationPitch(this.mc.field_1724.method_36455());
      }

      this.setNow(0L);
      this.setLastTargetEntityId(-1);
      this.setPreviousSlot(-1);
      this.setAttackCount(0);
      this.setAttackPauseDeadline(0L);
      this.setCurrentFrame(0L);
      this.setAimInitialized(false);
      this.updateRotation();
      this.setJumpInputTicks(0);
      this.setRetryCount(0);
      this.setAttackQueued(false);
      RotationManager.reset();
   }

   public void onDisable() {
      this.setTarget((class_1309)null);
      this.setPreviousSlot(-1);
      this.setLastTargetEntityId(-1);
      this.setAttackPauseDeadline(0L);
      this.setAimInitialized(false);
      RotationManager.reset();
      this.updateRotation();
      super.onDisable();
      this.setJumpInputTicks(0);
      this.setAttackQueued(false);
      if (RotationManager.isRotating()) {
         if (this.getRotationApplicationSetting().isSelected("Silent")) {
            RotationManager.beginReturn(180.0F);
         } else if (this.getRotationApplicationSetting().isSelected("ClientLook")) {
            this.updateRotationForTarget();
         } else {
            RotationManager.reset();
         }
      } else {
         RotationManager.reset();
      }

   }

   @EventHandler
   public void onRender2D(Render2DEvent event) {
      if (this.getRotationSetting().isSelected("FunTime")) {
         this.renderModuleElement();
         this.setCurrentFrame(0L);
      } else if (!this.getRotationSetting().isSelected("Legit")) {
         this.setCurrentFrame(0L);
      } else if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         long currentFrame = System.nanoTime();
         if (this.getCurrentFrame() == 0L) {
            this.setCurrentFrame(currentFrame);
         } else {
            float dt = (float)(currentFrame - this.getCurrentFrame()) / 1e+09F;
            this.setCurrentFrame(currentFrame);
            if (dt > 0.1F) {
               dt = 0.1F;
            }

            if (this.mc.field_1755 == null) {
               if (this.getTarget() != null) {
                  class_243 aimPoint = this.getTargetPosition(this.getTarget());
                  double dX = aimPoint.field_1352 - this.mc.field_1724.method_23317();
                  double dZ = aimPoint.field_1350 - this.mc.field_1724.method_23321();
                  double dY = aimPoint.field_1351 - this.mc.field_1724.method_23320();
                  double dist = Math.sqrt(dX * dX + dZ * dZ);
                  float targetYaw = (float)Math.toDegrees(Math.atan2(dZ, dX)) - 90.0F;
                  float targetPitch = (float)(-Math.toDegrees(Math.atan2(dY, dist)));
                  float yawDiff = class_3532.method_15393(targetYaw - this.mc.field_1724.method_36454());
                  float pitchDiff = class_3532.method_15393(targetPitch - this.mc.field_1724.method_36455());
                  float factor = (float)this.getLegitSpeedSetting().getValue() * 0.2F;
                  float stepYaw = yawDiff * factor * dt;
                  float stepPitch = pitchDiff * factor * dt;
                  if (Math.abs(stepYaw) > Math.abs(yawDiff)) {
                     stepYaw = yawDiff;
                  }

                  if (Math.abs(stepPitch) > Math.abs(pitchDiff)) {
                     stepPitch = pitchDiff;
                  }

                  float jitterValue = (float)this.getLegitJitterSetting().getValue();
                  float jitterYaw = jitterValue > 0.0F ? (float)((Math.random() - (double)0.5F) * (double)jitterValue) : 0.0F;
                  float jitterPitch = jitterValue > 0.0F ? (float)((Math.random() - (double)0.5F) * (double)jitterValue) : 0.0F;
                  this.mc.field_1724.method_36456(this.mc.field_1724.method_36454() + stepYaw + jitterYaw);
                  this.mc.field_1724.method_36457(this.mc.field_1724.method_36455() + stepPitch + jitterPitch);
               }
            }
         }
      }
   }

   private void renderModuleElement() {
      int centerX = RenderUtil.getScaledWidth() / 2;
      int centerY = RenderUtil.getScaledHeight() / 2;
      float radius = 90.0F;
      RenderUtil.drawCircle((float)centerX, (float)centerY, radius, 1.3F, ThemeManager.getCurrentColor());
      RenderUtil.drawCircle((float)centerX, (float)centerY, radius + 2.0F, 0.8F, new Color(ThemeManager.getCurrentColor().getRed(), ThemeManager.getCurrentColor().getGreen(), ThemeManager.getCurrentColor().getBlue(), 70));
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.nullCheck.isPlayerOrWorldMissing()) {
         this.setTarget((class_1309)null);
         this.setLastTargetEntityId(-1);
         this.setAttackPauseDeadline(0L);
         this.updateRotation();
         this.setJumpInputTicks(0);
         RotationManager.reset();
      } else {
         this.refreshTarget();
         this.setTarget(this.selectTarget());
         if (this.getTarget() == null) {
            this.setLastTargetEntityId(-1);
            this.setPreviousSlot(-1);
            this.setAttackPauseDeadline(0L);
            this.setAimInitialized(false);
            this.updateRotation();
            this.setRotationYaw(this.mc.field_1724.method_36454());
            this.setRotationPitch(this.mc.field_1724.method_36455());
            if (RotationManager.isRotating()) {
               if (this.getRotationApplicationSetting().isSelected("Silent")) {
                  RotationManager.beginReturn(180.0F);
               } else if (this.getRotationApplicationSetting().isSelected("ClientLook")) {
                  this.updateRotationForTarget();
               } else {
                  RotationManager.reset();
               }
            } else {
               RotationManager.reset();
            }

         } else {
            if (this.shouldProcessVariantP()) {
               this.updateRotation();
            }

            boolean preparedSprintDropThisTick = false;
            if (this.shouldProcessVariantN()) {
               this.mc.field_1724.method_5728(false);
               this.setSprintResetTicks(3);
               preparedSprintDropThisTick = true;
            }

            if (this.shouldProcessVariantO()) {
               this.setWasSprinting(true);
               this.mc.field_1724.method_5728(false);
               this.setSprintResetPending(true);
               this.setSprintRestoreDeadline(System.currentTimeMillis() + 90L);
               preparedSprintDropThisTick = true;
            }

            RotationManager.Rotation rotation = this.calculateTargetRotation(this.getTarget());
            RotationSpeeds speed = this.getRotationSpeedProfile(rotation);
            boolean isGrim = this.getRotationSetting().isSelected("Grim");
            float maxStep = (float)(isGrim ? 30.0F : 360.0F);
            RotationManager.requestRotation(rotation, this.getRotationApplicationMode(), speed.yaw(), speed.pitch(), speed.returnSpeed(), false, maxStep);
            this.setRotationYaw(RotationManager.getCurrentRotation().yaw());
            this.setRotationPitch(RotationManager.getCurrentRotation().pitch());
            if (this.getTarget() != null && this.mc.field_1761 != null && !preparedSprintDropThisTick && this.isValidRotationPrimary(rotation)) {
               this.updateTimedState();
            }

         }
      }
   }

   private class_1309 selectTarget() {
      double maxDistance = this.calculateRotationStep();
      class_1309 bestTarget = null;
      double bestScore = 1.7976931348623157e+308D;

      for(class_1297 entity : this.mc.field_1687.method_18112()) {
         if (this.isValidEntity(entity, maxDistance)) {
            class_1309 living = (class_1309)entity;
            double score = this.calculateAnimationFactor(living);
            if (score < bestScore) {
               bestScore = score;
               bestTarget = living;
            }
         }
      }

      return bestTarget;
   }

   private double calculateAnimationFactor(class_1309 entity) {
      if (this.getSortingSetting().isSelected("Здоровье")) {
         return (double)(entity.method_6032() + entity.method_6067());
      } else {
         return this.getSortingSetting().isSelected("Поле зрения") ? this.calculateMovementSpeed(entity) : this.mc.field_1724.method_5858(entity);
      }
   }

   private double calculateMovementSpeed(class_1309 entity) {
      RotationManager.Rotation rotation = RotationManager.rotationTo(this.getTargetPosition(entity));
      float yawDelta = Math.abs(class_3532.method_15393(rotation.yaw() - this.mc.field_1724.method_36454()));
      float pitchDelta = Math.abs(class_3532.method_15393(rotation.pitch() - this.mc.field_1724.method_36455()));
      return Math.hypot((double)yawDelta, (double)pitchDelta);
   }

   private boolean isValidEntity(class_1297 entity, double maxDistance) {
      if (entity != this.mc.field_1724 && entity instanceof class_1309 living) {
         if (entity instanceof class_1531) {
            return false;
         } else if (entity.method_5805() && entity.method_5732()) {
            if (entity.method_5767() && !this.getTargetsSetting().isSelected("Невидимые")) {
               return false;
            } else {
               if (entity instanceof class_1657) {
                  class_1657 player = (class_1657)entity;
                  AntiBot antiBot = (AntiBot)FunctionManager.getFunction(AntiBot.class);
                  if (antiBot != null && antiBot.isEnabled() && antiBot.matchesPlayer(player)) {
                     return false;
                  }

                  if (NoFriendDamage.isValidPlayer(player)) {
                     return false;
                  }

                  if (!this.getTargetsSetting().isSelected("Игроки")) {
                     return false;
                  }
               }

               if (entity instanceof class_1429 && !this.getTargetsSetting().isSelected("Животные")) {
                  return false;
               } else if (entity instanceof class_1308 && !this.getTargetsSetting().isSelected("Мобы")) {
                  return false;
               } else {
                  if (this.getRotationSetting().isSelected("Legit")) {
                     RotationManager.Rotation rotation = RotationManager.rotationTo(this.getTargetPosition(living));
                     float yawDiff = Math.abs(class_3532.method_15393(rotation.yaw() - this.mc.field_1724.method_36454()));
                     float pitchDiff = Math.abs(class_3532.method_15393(rotation.pitch() - this.mc.field_1724.method_36455()));
                     if (Math.hypot((double)yawDiff, (double)pitchDiff) > this.getFovLegitSetting().getValue()) {
                        return false;
                     }
                  }

                  if (this.getRotationSetting().isSelected("FunTime")) {
                     if (!this.matchesEntity(living)) {
                        return false;
                     } else {
                        return this.mc.field_1724.method_5858(entity) <= maxDistance * maxDistance;
                     }
                  } else {
                     return this.mc.field_1724.method_5858(entity) <= maxDistance * maxDistance;
                  }
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private RotationManager.Rotation calculateTargetRotation(class_1309 entity) {
      if (this.getRotationSetting().isSelected("Legit")) {
         return new RotationManager.Rotation(this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455());
      } else if (this.getRotationSetting().isSelected("ReallyWorld")) {
         return this.calculateReallyWorldRotation(entity);
      } else if (this.getRotationSetting().isSelected("HvH")) {
         return this.calculateHvhRotation(entity);
      } else if (this.getRotationSetting().isSelected("Sloth")) {
         return this.calculateSlothRotation(entity);
      } else if (this.getRotationSetting().isSelected("SpookyTime")) {
         return this.calculateSpookyTimeRotation(entity);
      } else if (this.getRotationSetting().isSelected("SpookyDuels")) {
         return this.calculateSpookyDuelsRotation(entity);
      } else {
         return this.getRotationSetting().isSelected("FunTime") ? this.calculateFunTimeRotation(entity) : RotationManager.rotationTo(this.getTargetPosition(entity));
      }
   }

   private class_243 getTargetPosition(class_1309 entity) {
      class_243 nearest = RotationManager.closestPointToEyes(entity);
      return new class_243(nearest.field_1352, class_3532.method_15350(this.lerp(this.mc.field_1724.method_23318(), entity.method_23320(), (double)0.5F), entity.method_5829().field_1322, entity.method_5829().field_1325), nearest.field_1350);
   }

   private RotationManager.Rotation getCurrentRotation() {
      return RotationManager.isRotating() ? RotationManager.getCurrentRotation() : new RotationManager.Rotation(this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455());
   }

   private RotationManager.Rotation calculateReallyWorldRotation(class_1309 entity) {
      RotationManager.Rotation current = this.getCurrentRotation();
      if (entity == null) {
         return current;
      } else {
         long now = System.currentTimeMillis();
         if (now < this.getAttackPauseDeadline()) {
            return new RotationManager.Rotation(current.yaw(), (float)this.lerp((double)current.pitch(), (double)(current.pitch() - 90.0F), 0.55));
         } else {
            RotationManager.Rotation targetRot = RotationManager.rotationTo(this.getTargetPosition(entity));
            float yawDelta = class_3532.method_15393(targetRot.yaw() - current.yaw());
            float pitchDelta = targetRot.pitch() - current.pitch();
            double total = Math.max(Math.hypot((double)yawDelta, (double)pitchDelta), 0.001);
            float yawCap = (float)(Math.abs((double)yawDelta / total) * 180.0D);
            float pitchCap = (float)(Math.abs((double)pitchDelta / total) * 180.0D);
            float clampedYaw = class_3532.method_15363(yawDelta, -yawCap, yawCap);
            float clampedPitch = class_3532.method_15363(pitchDelta, -pitchCap, pitchCap);
            float speed = this.calculateTargetDistance(this.getRandom(), 1.0F, 1.2F);
            float nextYaw = (float)this.lerp((double)current.yaw(), (double)(current.yaw() + clampedYaw), (double)speed);
            float nextPitch = (float)this.lerp((double)current.pitch(), (double)(current.pitch() + clampedPitch), (double)speed);
            if (!this.isValidEntity(entity)) {
               nextYaw += -6.0F * (float)Math.cos((double)now / 90.0D);
               nextPitch += 6.0F * (float)Math.sin((double)now / 90.0D);
            }

            return new RotationManager.Rotation(nextYaw, class_3532.method_15363(nextPitch, -90.0F, 90.0F));
         }
      }
   }

   private RotationManager.Rotation calculateHvhRotation(class_1309 entity) {
      RotationManager.Rotation current = this.getCurrentRotation();
      if (entity == null) {
         return current;
      } else {
         RotationManager.Rotation targetRot = RotationManager.rotationTo(this.getTargetPosition(entity));
         float yawDelta = class_3532.method_15393(targetRot.yaw() - current.yaw());
         float pitchDelta = targetRot.pitch() - current.pitch();
         float nextYaw = current.yaw() + yawDelta;
         float nextPitch = current.pitch() + pitchDelta;
         if (!this.isValidEntity(entity)) {
            long ms = System.currentTimeMillis();
            nextYaw += 5.0F * (float)Math.sin((double)ms / 45.0D);
            nextPitch += 5.0F * (float)Math.sin((double)ms / 45.0D);
         }

         return new RotationManager.Rotation(nextYaw, class_3532.method_15363(nextPitch, -90.0F, 90.0F));
      }
   }

   private RotationManager.Rotation calculateSlothRotation(class_1309 entity) {
      RotationManager.Rotation current = this.getCurrentRotation();
      if (entity == null) {
         this.setAimInitialized(false);
         return current;
      } else {
         long now = System.currentTimeMillis();
         ThreadLocalRandom r = ThreadLocalRandom.current();
         if (!this.isAimInitialized() && this.mc.field_1724 != null) {
            this.setAimInitialized(true);
         }

         RotationManager.Rotation targetAngle = RotationManager.rotationTo(this.getTargetPosition(entity));
         float targetYaw = targetAngle.yaw();
         float targetPitch = targetAngle.pitch();
         float deltaYaw = class_3532.method_15393(targetYaw - current.yaw());
         float deltaPitch = targetPitch - current.pitch();
         float f = current.pitch() * ((float)Math.PI / 180F);
         float g = -current.yaw() * ((float)Math.PI / 180F);
         float h = class_3532.method_15362((double)g);
         float i = class_3532.method_15374((double)g);
         float j = class_3532.method_15362((double)f);
         float k = class_3532.method_15374((double)f);
         class_243 lookVec = new class_243((double)(i * j), (double)(-k), (double)(h * j));
         class_243 eyePos = this.mc.field_1724.method_33571();
         class_243 endPos = eyePos.method_1019(lookVec.method_1021(999.0D));
         boolean hasTrace = entity.method_5829().method_1014(0.1).method_992(eyePos, endPos).isPresent();
         boolean isElytra = this.mc.field_1724.method_6128();
         float angularDist = (float)Math.hypot((double)deltaYaw, (double)deltaPitch);
         if (now - this.getNowPrimary() > (long)r.nextInt(30, 80)) {
            this.setYawJitter((r.nextFloat() - 0.5F) * 0.12F);
            this.setPitchJitter((r.nextFloat() - 0.5F) * 0.08F);
            this.setNowPrimary(now);
         }

         if (!hasTrace) {
            int reactionThreshold = 2 + Math.min(this.getVisibleTargetTicks() / 3, 5) + r.nextInt(2);
            if (this.getReactionTicks() < reactionThreshold) {
               this.setReactionTicks(this.getReactionTicks() + 1);
               deltaYaw += (r.nextFloat() - 0.5F) * 1.2F;
               deltaPitch += (r.nextFloat() - 0.5F) * 0.6F;
            } else {
               float targetSpeed = angularDist > 12.0F ? 0.72F : 0.35F;
               this.setYawS(class_3532.method_16439(0.035F, this.getYawS(), targetSpeed));
               this.setPitchS(class_3532.method_16439(0.035F, this.getPitchS(), targetSpeed));
            }

            this.setVisibleTargetTicks(0);
         } else {
            this.setReactionTicks(0);
            this.setYawS(class_3532.method_16439(0.55F, this.getYawS(), 0.0F));
            this.setPitchS(class_3532.method_16439(0.55F, this.getPitchS(), 0.0F));
            this.setVisibleTargetTicks(this.getVisibleTargetTicks() + 1);
         }

         this.setAimSlowdown(class_3532.method_15363(this.getAimSlowdown() + angularDist * 8.0E-5F, 0.0F, 0.32F));
         if (hasTrace) {
            this.setAimSlowdown(this.getAimSlowdown() * 0.97F);
         }

         float baseYawSpeed = r.nextFloat(8.0F, 14.0F) / (isElytra ? 2.20000005F : 1.0F);
         float basePitchSpeed = r.nextFloat(4.0F, 8.0F) / (isElytra ? 2.20000005F : 1.0F);
         float yawS = this.getYawS() * this.getYawS() * (3.0F - 2.0F * this.getYawS());
         float pitchS = this.getPitchS() * this.getPitchS() * (3.0F - 2.0F * this.getPitchS());
         float yawSpeed = baseYawSpeed * yawS * (1.0F - this.getAimSlowdown());
         float pitchSpeed = basePitchSpeed * pitchS * (1.0F - this.getAimSlowdown());
         if (!this.mc.field_1724.method_24828()) {
            deltaPitch *= 0.12F;
            deltaYaw *= 0.85F;
         }

         if (hasTrace && this.getVisibleTargetTicks() > 3 && r.nextFloat() < 0.15F) {
            deltaYaw += (r.nextFloat() - 0.5F) * 2.0F;
            deltaPitch += (r.nextFloat() - 0.5F) * 1.0F;
         }

         float clampedYaw = class_3532.method_15363(deltaYaw, -yawSpeed, yawSpeed);
         float clampedPitch = class_3532.method_15363(deltaPitch, -pitchSpeed, pitchSpeed);
         if (hasTrace && Math.abs(clampedYaw) < 0.35F) {
            clampedYaw = 0.0F;
         }

         if (hasTrace && Math.abs(clampedPitch) < 0.18F) {
            clampedPitch = 0.0F;
         }

         float newYaw = current.yaw() + clampedYaw + this.getYawJitter();
         float newPitch = current.pitch() + clampedPitch + this.getPitchJitter();
         newPitch = class_3532.method_15363(newPitch, -90.0F, 90.0F);
         return new RotationManager.Rotation(newYaw, newPitch);
      }
   }

   private RotationManager.Rotation calculateSpookyTimeRotation(class_1309 entity) {
      RotationManager.Rotation current = this.getCurrentRotation();
      if (entity == null) {
         return current;
      } else {
         RotationManager.Rotation targetRot = RotationManager.rotationTo(this.getTargetPosition(entity));
         float yawDelta = class_3532.method_15393(targetRot.yaw() - current.yaw());
         float pitchDelta = class_3532.method_15393(targetRot.pitch() - current.pitch());
         float length = (float)Math.hypot((double)yawDelta, (double)pitchDelta);
         float angleLimitYaw = (float)Math.min((double)Math.abs(yawDelta), 74.0D + Math.random() * (double)1.0329834F);
         float angleLimitPitch = Math.min(Math.abs(pitchDelta), 32.3339996F);
         float newYaw = current.yaw();
         float newPitch = current.pitch();
         if (length > 0.001F) {
            boolean pitchLimitReached = Math.abs(pitchDelta) >= angleLimitPitch;
            float maxStep = (float)(pitchLimitReached ? 44.5F : 25.5F);
            float step = Math.min(length, maxStep);
            float scale = step / length;
            if (!pitchLimitReached) {
               scale = this.calculateMovementSpeed(scale);
            }

            newPitch = class_3532.method_15363(current.pitch() + pitchDelta * scale, -89.0F, 90.0F);
         }

         if (length > 0.001F) {
            boolean yawLimitReached = Math.abs(yawDelta) >= angleLimitYaw;
            float maxStep = (float)(yawLimitReached ? 44.5F : 25.5F);
            float step = Math.min(length, maxStep);
            float var18 = step / length;
            if (!yawLimitReached) {
               var18 = this.calculateMovementSpeed(var18);
            }

            newYaw = current.yaw() + yawDelta * var18;
         }

         return new RotationManager.Rotation(newYaw, newPitch);
      }
   }

   private RotationManager.Rotation calculateSpookyDuelsRotation(class_1309 entity) {
      RotationManager.Rotation current = this.getCurrentRotation();
      if (entity == null) {
         return current;
      } else {
         RotationManager.Rotation targetRot = RotationManager.rotationTo(this.getTargetPosition(entity));
         float yawDelta = class_3532.method_15393(targetRot.yaw() - current.yaw());
         float pitchDelta = class_3532.method_15393(targetRot.pitch() - current.pitch());
         float length = (float)Math.hypot((double)yawDelta, (double)pitchDelta);
         float angleLimitYaw = (float)Math.min((double)Math.abs(yawDelta), 74.0D + Math.random() * (double)1.0329834F);
         float angleLimitPitch = Math.min(Math.abs(pitchDelta), 32.3339996F);
         float newYaw = current.yaw();
         float newPitch = current.pitch();
         if (length > 0.001F) {
            boolean pitchLimitReached = Math.abs(pitchDelta) >= angleLimitPitch;
            float maxStep = (float)(pitchLimitReached ? 44.5F : 25.5F);
            float step = Math.min(length, maxStep);
            float scale = step / length;
            if (!pitchLimitReached) {
               scale = this.calculateMovementSpeed(scale);
            }

            newPitch = class_3532.method_15363(current.pitch() + pitchDelta * scale, -89.0F, 90.0F);
         }

         if (length > 0.001F) {
            boolean yawLimitReached = Math.abs(yawDelta) >= angleLimitYaw;
            float maxStep = (float)(yawLimitReached ? 44.5F : 25.5F);
            float step = Math.min(length, maxStep);
            float var21 = step / length;
            if (!yawLimitReached) {
               var21 = this.calculateMovementSpeed(var21);
            }

            newYaw = current.yaw() + yawDelta * var21;
         }

         if (!this.isValidEntity(entity)) {
            float time = (float)(System.currentTimeMillis() % 12000L) / 1200.0F;
            float swayPhase = time * 0.32F * 6.28318548F;
            float swayYaw = class_3532.method_15374((double)swayPhase) * 2.20000005F;
            newYaw += swayYaw;
         }

         return new RotationManager.Rotation(newYaw, newPitch);
      }
   }

   private RotationManager.Rotation calculateFunTimeRotation(class_1309 entity) {
      RotationManager.Rotation current = this.getCurrentRotation();
      if (entity == null) {
         return current;
      } else if (!this.isValidEntity(entity)) {
         return new RotationManager.Rotation(this.stepAngleToward(current.yaw(), this.mc.field_1724.method_36454(), 30.0F), class_3532.method_15363(this.stepAngleToward(current.pitch(), this.mc.field_1724.method_36455(), 30.0F), -90.0F, 90.0F));
      } else {
         RotationManager.Rotation targetRot = RotationManager.rotationTo(this.getTargetPositionPrimary(entity));
         return new RotationManager.Rotation(this.stepAngleToward(current.yaw(), targetRot.yaw(), 25.0F), class_3532.method_15363(this.stepAngleToward(current.pitch(), targetRot.pitch(), 25.0F), -90.0F, 90.0F));
      }
   }

   private float stepAngleToward(float current, float target, float speed) {
      float diff = class_3532.method_15393(target - current);
      return Math.abs(diff) <= speed ? target : current + Math.signum(diff) * speed;
   }

   private float calculateMovementSpeed(float value) {
      return value * (0.5F + 0.5F * value);
   }

   private RotationSpeeds getRotationSpeedProfile(RotationManager.Rotation rotation) {
      if (this.getRotationSetting().isSelected("FunTime")) {
         return new RotationSpeeds(360.0F, 360.0F, 180.0F);
      } else if (!this.getRotationSetting().isSelected("SpookyTime") && !this.getRotationSetting().isSelected("SpookyDuels")) {
         return this.getRotationSetting().isSelected("Grim") ? new RotationSpeeds(30.0F, 30.0F, 30.0F) : new RotationSpeeds(360.0F, 360.0F, 180.0F);
      } else {
         return new RotationSpeeds(360.0F, 360.0F, 180.0F);
      }
   }

   private class_243 getTargetPositionPrimary(class_1309 entity) {
      return this.getTargetPosition(entity);
   }

   private boolean prepareAttackRotation() {
      if (this.getTarget() == null) {
         return false;
      } else if (this.getRotationSetting().isSelected("Legit")) {
         return true;
      } else if (this.getRotationSetting().isSelected("FunTime")) {
         return this.shouldProcessPrimary();
      } else {
         RotationManager.Rotation exact = RotationManager.rotationTo(this.getTargetPositionPrimary(this.getTarget()));
         RotationManager.Rotation current = RotationManager.isRotating() ? RotationManager.getCurrentRotation() : new RotationManager.Rotation(this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455());
         float yawDelta = class_3532.method_15393(exact.yaw() - current.yaw());
         float pitchDelta = exact.pitch() - current.pitch();
         boolean var5 = this.shouldProcessPending();
         float stepLimit = (float)(var5 ? 60.0F : 30.0F);
         if (!(Math.abs(yawDelta) > stepLimit) && !(Math.abs(pitchDelta) > stepLimit)) {
            RotationManager.requestRotation(exact, this.getRotationApplicationMode(), stepLimit, stepLimit, 30.0F);
            this.setRotationYaw(RotationManager.getCurrentRotation().yaw());
            this.setRotationPitch(RotationManager.getCurrentRotation().pitch());
            return this.shouldProcessPrimary();
         } else {
            return false;
         }
      }
   }

   private boolean shouldProcessPrimary() {
      if (this.getRotationSetting().isSelected("Legit")) {
         if (this.mc.field_1765 != null && this.mc.field_1765.method_17783() == class_240.field_1331) {
            class_3966 entityHit = (class_3966)this.mc.field_1765;
            if (entityHit.method_17782() == this.getTarget()) {
               return true;
            }
         }

         RotationManager.Rotation exact = RotationManager.rotationTo(this.getTargetPositionPrimary(this.getTarget()));
         float yawDelta = Math.abs(class_3532.method_15393(exact.yaw() - this.mc.field_1724.method_36454()));
         float pitchDelta = Math.abs(exact.pitch() - this.mc.field_1724.method_36455());
         float tolerance = this.shouldProcessPending() ? 8.0F : 2.0F;
         return yawDelta <= tolerance && pitchDelta <= tolerance;
      } else {
         RotationManager.Rotation exact = RotationManager.rotationTo(this.getTargetPositionPrimary(this.getTarget()));
         RotationManager.Rotation current = RotationManager.isRotating() ? RotationManager.getCurrentRotation() : new RotationManager.Rotation(this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455());
         float yawDelta = Math.abs(class_3532.method_15393(exact.yaw() - current.yaw()));
         float pitchDelta = Math.abs(exact.pitch() - current.pitch());
         float tolerance = this.shouldProcessPending() ? 8.0F : 2.0F;
         return yawDelta <= tolerance && pitchDelta <= tolerance;
      }
   }

   private boolean isValidRotation(RotationManager.Rotation rotation) {
      return this.isValidRotation(rotation, 18.0F, 18.0F);
   }

   private boolean isValidRotation(RotationManager.Rotation rotation, float yawTolerance, float pitchTolerance) {
      float yawDelta = Math.abs(class_3532.method_15393(rotation.yaw() - this.getRotationYaw()));
      float pitchDelta = Math.abs(class_3532.method_15393(rotation.pitch() - this.getRotationPitch()));
      return yawDelta <= yawTolerance && pitchDelta <= pitchTolerance;
   }

   private boolean isValidEntity(class_1309 entity) {
      if (entity == null) {
         return false;
      } else if (this.shouldProcessPrevious()) {
         return false;
      } else if (!this.matchesEntity(entity)) {
         return false;
      } else if (!this.isEntityInRange(entity)) {
         return false;
      } else {
         return !this.shouldProcessTarget() ? false : this.shouldProcessSecondary();
      }
   }

   private boolean isValidRotationPrimary(RotationManager.Rotation rotation) {
      if (this.shouldProcessPrevious()) {
         return false;
      } else if (!this.matchesEntity(this.getTarget())) {
         return false;
      } else if (!this.isEntityInRange(this.getTarget())) {
         return false;
      } else if (!this.shouldProcessTarget()) {
         return false;
      } else if (!this.shouldProcessSecondary()) {
         return false;
      } else if (!this.prepareAttackRotation()) {
         return false;
      } else {
         return this.shouldProcessPrimary();
      }
   }

   private boolean shouldProcessSecondary() {
      if (this.mc.field_1724 != null && this.mc.field_1724.method_6128()) {
         return true;
      } else {
         return this.getSprintResetSetting().isSelected("Легитный") ? this.shouldProcessVariantM() : this.shouldProcessAnimated();
      }
   }

   private boolean shouldProcessCurrent() {
      if (this.mc.field_1724 == null) {
         return false;
      } else {
         for(class_1268 hand : class_1268.values()) {
            class_1799 stack = this.mc.field_1724.method_5998(hand);
            if (stack != null && !stack.method_7960()) {
               String name = stack.method_7964().getString().toLowerCase();
               if (name.contains("аирстак") || name.contains("airstack")) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private boolean shouldProcessPrevious() {
      if (this.getDoNotAttackWhenSetting().isSelected("Если ешь") && this.mc.field_1724.method_6115() && this.mc.field_1724.method_6030().method_7976() == class_1839.field_8950) {
         return true;
      } else if (this.getDoNotAttackWhenSetting().isSelected("Если открыт инвентарь") && this.mc.field_1755 instanceof class_490) {
         return true;
      } else {
         ElytraHelper elytraHelper = (ElytraHelper)FunctionManager.getFunction(ElytraHelper.class);
         if (elytraHelper != null && elytraHelper.shouldProcess()) {
            this.setLastActionTime(System.currentTimeMillis());
            return true;
         } else if (!this.mc.field_1690.field_1904.method_1434() || !this.mc.field_1724.method_6047().method_31574(class_1802.field_8639) && !this.mc.field_1724.method_6079().method_31574(class_1802.field_8639)) {
            return false;
         } else {
            this.setLastActionTime(System.currentTimeMillis());
            return true;
         }
      }
   }

   private boolean isEntityInRange(class_1309 entity) {
      if (this.getAttackThroughWallsSetting().isEnabled()) {
         return true;
      } else if (this.mc.field_1724.method_5858(entity) > this.getAimRadiusSetting().getValue() * this.getAimRadiusSetting().getValue()) {
         return true;
      } else {
         return this.isValidPoint(entity.method_33571()) || this.isValidPoint(entity.method_5829().method_1005()) || this.isValidPoint(this.getTargetPosition(entity));
      }
   }

   private boolean isValidPoint(class_243 point) {
      class_3965 result = this.mc.field_1687.method_17742(new class_3959(this.mc.field_1724.method_33571(), point, class_3960.field_17558, class_242.field_1348, this.mc.field_1724));
      return result.method_17783() == class_240.field_1333;
   }

   private double calculateTargetDistance() {
      return this.shouldProcessCurrent() ? 6.0D : this.getRadiusSetting().getValue();
   }

   private boolean matchesEntity(class_1309 entity) {
      if (this.getRotationSetting().isSelected("FunTime")) {
         if (this.mc.field_1724.method_5858(entity) > this.calculateTargetDistance() * this.calculateTargetDistance()) {
            return false;
         } else {
            RotationManager.Rotation rotation = RotationManager.rotationTo(this.getTargetPosition(entity));
            float yawDiff = Math.abs(class_3532.method_15393(rotation.yaw() - this.mc.field_1724.method_36454()));
            float pitchDiff = Math.abs(class_3532.method_15393(rotation.pitch() - this.mc.field_1724.method_36455()));
            return Math.hypot((double)yawDiff, (double)pitchDiff) <= 50.0D;
         }
      } else {
         return this.mc.field_1724.method_5858(entity) <= this.calculateTargetDistance() * this.calculateTargetDistance();
      }
   }

   private double calculateRotationStep() {
      return this.shouldProcessCurrent() ? Math.max(6.0D, this.getAimRadiusSetting().getValue()) : this.getAimRadiusSetting().getValue();
   }

   private boolean shouldProcessTarget() {
      if (this.shouldProcessCurrent()) {
         return true;
      } else {
         float threshold = this.shouldProcessPending() ? 0.82F : 0.92F;
         return this.mc.field_1724.method_7261(0.5F) >= threshold;
      }
   }

   private void refreshTarget() {
      if (this.mc.field_1690.field_1903.method_1434()) {
         this.setJumpInputTicks(4);
      } else if (this.getJumpInputTicks() > 0) {
         this.setJumpInputTicks(this.getJumpInputTicks() - 1);
      }

   }

   private boolean shouldProcessCached() {
      double effectiveJumpHeight = (double)this.mc.field_1724.method_49476();
      class_243 jumpVec = new class_243((double)0.0F, effectiveJumpHeight, (double)0.0F);
      class_243 allowedMovement = class_1297.method_20736(this.mc.field_1724, jumpVec, this.mc.field_1724.method_5829(), this.mc.field_1687, List.of());
      return this.mc.field_1724.method_5771() || this.mc.field_1724.method_6101() || this.mc.field_1724.method_5777(class_3486.field_15517) || this.mc.field_1724.method_6059(class_1294.field_5902) || this.mc.field_1724.method_6059(class_1294.field_5906) || this.mc.field_1724.method_6059(class_1294.field_5919) || this.mc.field_1724.method_5765() || this.mc.field_1724.method_31549().field_7479 || allowedMovement.field_1351 < (double)this.mc.field_1724.method_49476() - (double)0.5F && this.mc.field_1724.method_24828() || this.mc.field_1724.method_18798().field_1351 == -0.005 && this.mc.field_1724.method_5869();
   }

   private boolean shouldProcessAnimated() {
      return this.shouldProcessPending();
   }

   private boolean shouldProcessRendered() {
      return this.mc.field_1724.field_6017 > (double)0.05F || this.mc.field_1724.method_18798().field_1351 <= -0.03;
   }

   private boolean shouldProcessPending() {
      return !this.shouldProcessCurrent() && !this.shouldProcessCached() && !this.mc.field_1724.method_24828() && (this.shouldProcessRendered() || this.mc.field_1724.method_6128());
   }

   private boolean shouldProcessFallback() {
      return !this.mc.field_1724.method_24828() && this.mc.field_1724.method_18798().field_1351 > (double)0.0F;
   }

   private boolean isFeatureActive() {
      return this.getSmartCriticalsSetting().isEnabled() && this.mc.field_1724.method_24828() && !this.shouldProcessAlternate();
   }

   private boolean shouldProcessAlternate() {
      return this.mc.field_1690.field_1903.method_1434() || this.getJumpInputTicks() > 0;
   }

   private boolean shouldProcessFinal() {
      return !this.shouldProcessCurrent() && !this.shouldProcessCached() && !this.mc.field_1724.method_24828() && (this.shouldProcessRendered() || this.mc.field_1724.method_18798().field_1351 < (double)0.0F || this.mc.field_1724.method_6128());
   }

   private boolean shouldProcessVariantM() {
      return this.shouldProcessPending();
   }

   private boolean shouldProcessVariantN() {
      if (!this.getSprintResetSetting().isSelected("Быстрый")) {
         return false;
      } else if (this.getSprintResetTicks() > 0) {
         return false;
      } else if (this.getTarget() == null) {
         return false;
      } else if (!this.mc.field_1724.method_5624()) {
         return false;
      } else if (!this.shouldProcessFinal()) {
         return false;
      } else if (this.shouldProcessPrevious()) {
         return false;
      } else if (!this.matchesEntity(this.getTarget())) {
         return false;
      } else if (!this.isEntityInRange(this.getTarget())) {
         return false;
      } else {
         return this.mc.field_1724.method_7261(0.5F) >= 0.78F;
      }
   }

   private boolean shouldProcessVariantO() {
      if (!this.getSprintResetSetting().isSelected("Легитный")) {
         return false;
      } else if (!this.isSprintResetPending() && !this.shouldProcessVariantR()) {
         if (this.getTarget() == null) {
            return false;
         } else if (!this.mc.field_1724.method_5624() && !this.mc.field_1690.field_1867.method_1434()) {
            return false;
         } else if (!this.shouldProcessFinal()) {
            return false;
         } else if (this.shouldProcessPrevious()) {
            return false;
         } else if (!this.matchesEntity(this.getTarget())) {
            return false;
         } else if (!this.isEntityInRange(this.getTarget())) {
            return false;
         } else {
            return this.mc.field_1724.method_7261(0.5F) >= 0.82F;
         }
      } else {
         return false;
      }
   }

   private boolean shouldProcessVariantP() {
      if (!this.isSprintResetPending()) {
         return false;
      } else if (!this.getSprintResetSetting().isSelected("Легитный")) {
         return true;
      } else if (this.getTarget() == null) {
         return true;
      } else if (this.shouldProcessPrevious()) {
         return true;
      } else if (!this.shouldProcessFinal() && !this.shouldProcessPending()) {
         return true;
      } else if (!this.matchesEntity(this.getTarget())) {
         return true;
      } else {
         return !this.isEntityInRange(this.getTarget());
      }
   }

   private RotationManager.MoveCorrection getRotationApplicationMode() {
      if (this.getCorrectionSetting().isSelected("Свободная")) {
         return RotationManager.MoveCorrection.SILENT;
      } else {
         return this.getCorrectionSetting().isSelected("Сфокусированная") ? RotationManager.MoveCorrection.DIRECT : RotationManager.MoveCorrection.NONE;
      }
   }

   private void updateTimedState() {
      boolean criticalHitReady = this.shouldProcessPending();
      boolean sprintIntent = this.mc.field_1724.method_5624() || this.mc.field_1690.field_1867.method_1434() || this.wasSprinting();
      boolean legitMode = this.getSprintResetSetting().isSelected("Легитный");
      boolean preResetSprint = criticalHitReady && !legitMode;
      if (preResetSprint && this.mc.field_1724.method_5624()) {
         this.mc.field_1724.method_5728(false);
      }

      PacketCriticals packetCriticals = (PacketCriticals)FunctionManager.getFunction(PacketCriticals.class);
      if (packetCriticals != null && packetCriticals.isEnabled()) {
         packetCriticals.updateTimedState();
      }

      if (this.mc.field_1724.method_6128() && System.currentTimeMillis() - this.getLastActionTime() > 2000L) {
         this.mc.field_1724.method_18800((double)0.0F, (double)0.0F, (double)0.0F);
      }

      this.mc.field_1761.method_2918(this.mc.field_1724, this.getTarget());
      this.mc.field_1724.method_6104(class_1268.field_5808);
      if (criticalHitReady && sprintIntent) {
         if (!preResetSprint && this.mc.field_1724.method_5624()) {
            this.mc.field_1724.method_5728(false);
         }

         if (legitMode) {
            this.setSprintResetPending(false);
            this.setWasSprinting(false);
            this.setSprintRestoreDeadline(System.currentTimeMillis() + 110L);
         } else {
            this.setSprintResetTicks(2);
         }
      }

      long now = System.currentTimeMillis();
      if (this.getRotationSetting().isSelected("ReallyWorld")) {
         this.setAttackCount(this.getAttackCount() + 1);
         if (this.getAttackCount() % 50 == 0) {
            this.setAttackPauseDeadline(now + 200L);
         }
      }

      this.setNow(now);
      this.setLastTargetEntityId(this.getTarget().method_5628());
   }

   @EventHandler
   public void onInput(InputEvent event) {
      if (this.shouldPreventSprintReset()) {
         event.setSprinting(false);
         if (this.getSprintResetTicks() > 0) {
            this.setSprintResetTicks(this.getSprintResetTicks() - 1);
         }

      }
   }

   public boolean shouldPreventSprintReset() {
      return this.getSprintResetTicks() > 0 || this.shouldProcessVariantR();
   }

   private boolean shouldProcessVariantR() {
      return this.getSprintResetSetting().isSelected("Легитный") && (this.isSprintResetPending() || this.getSprintRestoreDeadline() > System.currentTimeMillis());
   }

   private void updateRotation() {
      this.setSprintResetTicks(0);
      this.setSprintResetPending(false);
      this.setWasSprinting(false);
      this.setSprintRestoreDeadline(0L);
   }

   private void updateRotationForTarget() {
      RotationManager.beginReturn(30.0F);
   }

   public class_1309 findTarget() {
      return this.isEnabled() ? this.getTarget() : null;
   }

   public boolean isFeatureActivePrimary() {
      if (this.isEnabled() && this.getTarget() != null) {
         if (this.shouldProcessPrevious()) {
            return false;
         } else if (!this.matchesEntity(this.getTarget())) {
            return false;
         } else if (!this.isEntityInRange(this.getTarget())) {
            return false;
         } else {
            return !this.shouldProcessTarget() ? false : this.shouldProcessSecondary();
         }
      } else {
         return false;
      }
   }

   private float calculateTargetDistance(Random random, float min, float max) {
      return min + random.nextFloat() * (max - min);
   }

   private double calculateRenderOffset(double scale) {
      return class_3532.method_15350(this.getRandom().nextGaussian() * scale, -scale * 2.0D, scale * 2.0D);
   }

   private double lerp(double from, double to, double delta) {
      return from + (to - from) * delta;
   }

   private NumberSetting getRadiusSetting() {
      return this.radiusNumberSetting;
   }

   private NumberSetting getAimRadiusSetting() {
      return this.radiusAimaNumberSetting;
   }

   private ListSetting getRotationSetting() {
      return this.rotatsiyaListSetting;
   }

   private NumberSetting getFovLegitSetting() {
      return this.fovLegitNumberSetting;
   }

   private NumberSetting getLegitSpeedSetting() {
      return this.skorostLegitNumberSetting;
   }

   private NumberSetting getLegitJitterSetting() {
      return this.dzhitterLegitNumberSetting;
   }

   private ListSetting getCorrectionSetting() {
      return this.korrektsiyaListSetting;
   }

   private ListSetting getSortingSetting() {
      return this.sortirovkaListSetting;
   }

   private MultiListSetting getTargetsSetting() {
      return this.tseliMultiListSetting;
   }

   private MultiListSetting getDoNotAttackWhenSetting() {
      return this.neBitEsliMultiListSetting;
   }

   private BooleanSetting getAttackThroughWallsSetting() {
      return this.bitCherezStenyBooleanSetting;
   }

   private BooleanSetting getSmartCriticalsSetting() {
      return this.umnyeKrityBooleanSetting;
   }

   private ListSetting getRotationApplicationSetting() {
      return this.otvodkaListSetting;
   }

   private ListSetting getSprintResetSetting() {
      return this.sbrosSprintaListSetting;
   }

   private float getRotationYaw() {
      return this.field_658c255b;
   }

   private void setRotationYaw(float var1) {
      this.field_658c255b = var1;
   }

   private float getRotationPitch() {
      return this.field_d2b79f50;
   }

   private void setRotationPitch(float var1) {
      this.field_d2b79f50 = var1;
   }

   private class_1309 getTarget() {
      return this.field_3fe31945;
   }

   private void setTarget(class_1309 var1) {
      this.field_3fe31945 = var1;
   }

   private long getNow() {
      return this.field_ad0e933a;
   }

   private void setNow(long var1) {
      this.field_ad0e933a = var1;
   }

   private int getLastTargetEntityId() {
      return this.field_1a3a0d2f;
   }

   private void setLastTargetEntityId(int var1) {
      this.field_1a3a0d2f = var1;
   }

   private int getSprintResetTicks() {
      return this.field_87658724;
   }

   private void setSprintResetTicks(int var1) {
      this.field_87658724 = var1;
   }

   private int getJumpInputTicks() {
      return this.field_f4910119;
   }

   private void setJumpInputTicks(int var1) {
      this.field_f4910119 = var1;
   }

   private boolean isSprintResetPending() {
      return this.field_61bc7b0e;
   }

   private void setSprintResetPending(boolean var1) {
      this.field_61bc7b0e = var1;
   }

   private boolean wasSprinting() {
      return this.field_cee7f503;
   }

   private void setWasSprinting(boolean var1) {
      this.field_cee7f503 = var1;
   }

   private long getSprintRestoreDeadline() {
      return this.field_3c136ef8;
   }

   private void setSprintRestoreDeadline(long var1) {
      this.field_3c136ef8 = var1;
   }

   private boolean isAttackQueued() {
      return this.field_a93ee8ed;
   }

   private void setAttackQueued(boolean var1) {
      this.field_a93ee8ed = var1;
   }

   private int getRetryCount() {
      return this.field_166a62e2;
   }

   private void setRetryCount(int var1) {
      this.field_166a62e2 = var1;
   }

   private Random getRandom() {
      return this.field_8395dcd7;
   }

   private int getPreviousSlot() {
      return this.field_f0c156cc;
   }

   private void setPreviousSlot(int var1) {
      this.field_f0c156cc = var1;
   }

   private int getAttackCount() {
      return this.field_5decd0c1;
   }

   private void setAttackCount(int var1) {
      this.field_5decd0c1 = var1;
   }

   private long getAttackPauseDeadline() {
      return this.field_cb184ab6;
   }

   private void setAttackPauseDeadline(long var1) {
      this.field_cb184ab6 = var1;
   }

   private long getCurrentFrame() {
      return this.field_3843c4ab;
   }

   private void setCurrentFrame(long var1) {
      this.field_3843c4ab = var1;
   }

   private float getYawS() {
      return this.field_a56f3ea0;
   }

   private void setYawS(float var1) {
      this.field_a56f3ea0 = var1;
   }

   private float getPitchS() {
      return this.field_129ab895;
   }

   private void setPitchS(float var1) {
      this.field_129ab895 = var1;
   }

   private float getAimSlowdown() {
      return this.field_7fc6328a;
   }

   private void setAimSlowdown(float var1) {
      this.field_7fc6328a = var1;
   }

   private int getVisibleTargetTicks() {
      return this.field_ecf1ac7f;
   }

   private void setVisibleTargetTicks(int var1) {
      this.field_ecf1ac7f = var1;
   }

   private int getReactionTicks() {
      return this.field_5a1d2674;
   }

   private void setReactionTicks(int var1) {
      this.field_5a1d2674 = var1;
   }

   private float getYawJitter() {
      return this.field_c748a069;
   }

   private void setYawJitter(float var1) {
      this.field_c748a069 = var1;
   }

   private float getPitchJitter() {
      return this.field_34741a5e;
   }

   private void setPitchJitter(float var1) {
      this.field_34741a5e = var1;
   }

   private long getNowPrimary() {
      return this.field_a19f9453;
   }

   private void setNowPrimary(long var1) {
      this.field_a19f9453 = var1;
   }

   private boolean isAimInitialized() {
      return this.field_ecb0e48;
   }

   private void setAimInitialized(boolean var1) {
      this.field_ecb0e48 = var1;
   }

   private long getLastActionTime() {
      return this.field_7bf6883d;
   }

   private void setLastActionTime(long var1) {
      this.field_7bf6883d = var1;
   }


   private static record RotationSpeeds(float yaw, float pitch, float returnSpeed) {
      public float yaw() {
         return this.getYaw();
      }

      public float pitch() {
         return this.getPitch();
      }

      public float returnSpeed() {
         return this.getReturnSpeed();
      }

      private float getYaw() {
         return this.yaw;
      }

      private float getPitch() {
         return this.pitch;
      }

      private float getReturnSpeed() {
         return this.returnSpeed;
      }

   }
}
