package atheryx.module.combat;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.KeybindSetting;
import atheryx.setting.impl.ModeSetting;
import net.minecraft.class_1041;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

@NewFunction(
   name = "AutoSwap",
   desc = "Авто свап предметов в оффхенд с режимами Default и Legit",
   category = Category.COMBAT
)
public class AutoSwap extends Function {
   private final ModeSetting rezhimModeSetting = new ModeSetting("Режим", new String[]{"Packet", "Legit"});
   private final ModeSetting pervyyPredmetModeSetting = new ModeSetting("Первый предмет", new String[]{"Щит", "Геплы", "Тотем", "Шар"});
   private final ModeSetting vtoroyPredmetModeSetting = new ModeSetting("Второй предмет", new String[]{"Щит", "Геплы", "Тотем", "Шар"});
   private final KeybindSetting knopkaKeybindSetting = new KeybindSetting("Кнопка", -1);
   private SwapState field_21d961c9;
   private boolean field_8f04dbbe;
   private int field_fc3055b3;
   private boolean field_695bcfa8;
   private boolean field_d687499d;
   private boolean field_43b2c392;
   private boolean field_b0de3d87;
   private boolean field_1e09b77c;
   private boolean field_8b353171;

   public AutoSwap() {
      this.setActionPhase(AutoSwap.SwapState.READY);
      this.setPressed(false);
      this.setSlotToSwap(-1);
      this.setRestoreMovementInput(false);
      this.addSettings(new Setting[]{this.getModeSetting(), this.getFirstItemSetting(), this.getSecondItemSetting(), this.getActionKeybindSetting()});
   }

   public void onEnable() {
      this.processInput();
      this.setPressed(false);
   }

   public void onDisable() {
      this.processInput();
      this.setPressed(false);
      this.resetTransientState();
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing() && this.mc.field_1761 != null && this.mc.field_1755 == null) {
         this.refreshTarget();
         if (this.getModeSetting().getValue().equals("Legit") && this.getActionPhase() != AutoSwap.SwapState.READY) {
            this.advanceActionPhase();
         }

      } else {
         this.processInput();
      }
   }

   private void refreshTarget() {
      int key = this.getActionKeybindSetting().getKeybind();
      if (key > 0) {
         boolean pressed = KeybindSetting.isMouseBinding(key) ? this.getActionKeybindSetting().consumeMouseClick(this.mc.method_22683().method_4490()) : GLFW.glfwGetKey(this.mc.method_22683().method_4490(), key) == 1;
         if (pressed && (!this.isPressed() || KeybindSetting.isMouseBinding(key)) && this.getActionPhase() == AutoSwap.SwapState.READY) {
            this.setSlotToSwap(this.calculateAnimationFactor());
            if (this.getSlotToSwap() == -1) {
               this.setPressed(pressed);
               return;
            }

            if (this.getModeSetting().getValue().equals("Packet")) {
               this.prepareInteraction(this.getSlotToSwap());
               this.processInput();
            } else {
               this.updateRotation(this.getSlotToSwap());
            }
         }

         this.setPressed(pressed);
      }
   }

   private void updateRotation(int slotToSwap) {
      this.setSlotToSwap(slotToSwap);
      class_1041 window = this.mc.method_22683();
      this.setSlotChanged(class_3675.method_15987(window, this.mc.field_1690.field_1894.method_1429().method_1444()));
      this.setSwapPending(class_3675.method_15987(window, this.mc.field_1690.field_1881.method_1429().method_1444()));
      this.setWasLeftPressed(class_3675.method_15987(window, this.mc.field_1690.field_1913.method_1429().method_1444()));
      this.setWasRightPressed(class_3675.method_15987(window, this.mc.field_1690.field_1849.method_1429().method_1444()));
      this.setWasJumpPressed(class_3675.method_15987(window, this.mc.field_1690.field_1903.method_1429().method_1444()));
      this.setRestoreMovementInput(false);
      this.setActionPhase(AutoSwap.SwapState.SLOWING_DOWN);
   }

   private void advanceActionPhase() {
      switch (this.getActionPhase().ordinal()) {
         case 0:
         default:
            break;
         case 1:
            this.prepareInteraction();
            this.setRestoreMovementInput(true);
            if (this.mc.field_1724.method_5624()) {
               this.mc.field_1724.method_5728(false);
            }

            this.setActionPhase(AutoSwap.SwapState.PICKUP_ITEM);
            break;
         case 2:
            this.resetTransientState(this.getSlotToSwap());
            this.setActionPhase(AutoSwap.SwapState.PICKUP_OFFHAND);
            break;
         case 3:
            this.resetTransientState(45);
            this.setActionPhase(AutoSwap.SwapState.RETURN_ITEM);
            break;
         case 4:
            this.resetTransientState(this.getSlotToSwap());
            this.setActionPhase(AutoSwap.SwapState.SPEEDING_UP);
            this.resetTransientState();
            break;
         case 5:
            this.resetTransientState();
            this.setActionPhase(AutoSwap.SwapState.FINISHED);
            break;
         case 6:
            this.processInput();
      }

   }

   private void prepareInteraction(int slot) {
      this.resetTransientState(slot);
      this.resetTransientState(45);
      this.resetTransientState(slot);
   }

   private void resetTransientState(int slot) {
      if (slot != -1 && this.mc.field_1724 != null && this.mc.field_1761 != null) {
         this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, slot, 0, class_1713.field_7790, this.mc.field_1724);
      }
   }

   private int calculateAnimationFactor() {
      class_1792 firstItem = this.resolveSwapItem(this.getFirstItemSetting().getValue());
      class_1792 secondItem = this.resolveSwapItem(this.getSecondItemSetting().getValue());
      class_1792 offhandItem = this.mc.field_1724.method_6079().method_7909();
      if (offhandItem == firstItem) {
         int slot = this.calculateMovementSpeed(secondItem);
         if (slot != -1) {
            return this.calculateTargetDistance(slot);
         }
      }

      if (offhandItem == secondItem) {
         int slot = this.calculateMovementSpeed(firstItem);
         if (slot != -1) {
            return this.calculateTargetDistance(slot);
         }
      }

      if (offhandItem != firstItem && offhandItem != secondItem) {
         int slot = this.calculateMovementSpeed(firstItem);
         if (slot != -1) {
            return this.calculateTargetDistance(slot);
         }

         slot = this.calculateMovementSpeed(secondItem);
         if (slot != -1) {
            return this.calculateTargetDistance(slot);
         }
      }

      return -1;
   }

   private int calculateMovementSpeed(class_1792 item) {
      if (item == class_1802.field_8162) {
         return -1;
      } else {
         for(int i = 35; i >= 0; --i) {
            class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_31574(item)) {
               return i;
            }
         }

         return -1;
      }
   }

   private int calculateTargetDistance(int inventorySlot) {
      return inventorySlot < 9 ? inventorySlot + 36 : inventorySlot;
   }

   private void prepareInteraction() {
      this.mc.field_1690.field_1894.method_23481(false);
      this.mc.field_1690.field_1881.method_23481(false);
      this.mc.field_1690.field_1913.method_23481(false);
      this.mc.field_1690.field_1849.method_23481(false);
      this.mc.field_1690.field_1903.method_23481(false);
   }

   private void resetTransientState() {
      if (this.isRestoreMovementInput() && this.mc.method_22683() != null) {
         class_1041 window = this.mc.method_22683();
         boolean currentForward = class_3675.method_15987(window, this.mc.field_1690.field_1894.method_1429().method_1444());
         boolean currentBack = class_3675.method_15987(window, this.mc.field_1690.field_1881.method_1429().method_1444());
         boolean currentLeft = class_3675.method_15987(window, this.mc.field_1690.field_1913.method_1429().method_1444());
         boolean currentRight = class_3675.method_15987(window, this.mc.field_1690.field_1849.method_1429().method_1444());
         boolean currentJump = class_3675.method_15987(window, this.mc.field_1690.field_1903.method_1429().method_1444());
         this.mc.field_1690.field_1894.method_23481(this.isSlotChanged() && currentForward);
         this.mc.field_1690.field_1881.method_23481(this.isSwapPending() && currentBack);
         this.mc.field_1690.field_1913.method_23481(this.wasLeftPressed() && currentLeft);
         this.mc.field_1690.field_1849.method_23481(this.wasRightPressed() && currentRight);
         this.mc.field_1690.field_1903.method_23481(this.wasJumpPressed() && currentJump);
         this.setRestoreMovementInput(false);
      }
   }

   private void processInput() {
      if (this.isRestoreMovementInput()) {
         this.resetTransientState();
      }

      this.setActionPhase(AutoSwap.SwapState.READY);
      this.setSlotToSwap(-1);
      this.setRestoreMovementInput(false);
   }

   private class_1792 resolveSwapItem(String type) {
      byte var3 = -1;
      switch (type.hashCode()) {
         case 1056824:
            if (type.equals("Шар")) {
               var3 = 3;
            }
            break;
         case 1058035:
            if (type.equals("Щит")) {
               var3 = 0;
            }
            break;
         case 996396589:
            if (type.equals("Геплы")) {
               var3 = 2;
            }
            break;
         case 1010520205:
            if (type.equals("Тотем")) {
               var3 = 1;
            }
      }

      class_1792 var4;
      switch (var3) {
         case 0 -> var4 = class_1802.field_8255;
         case 1 -> var4 = class_1802.field_8288;
         case 2 -> var4 = class_1802.field_8463;
         case 3 -> var4 = class_1802.field_8575;
         default -> var4 = class_1802.field_8162;
      }

      return var4;
   }

   private ModeSetting getModeSetting() {
      return this.rezhimModeSetting;
   }

   private ModeSetting getFirstItemSetting() {
      return this.pervyyPredmetModeSetting;
   }

   private ModeSetting getSecondItemSetting() {
      return this.vtoroyPredmetModeSetting;
   }

   private KeybindSetting getActionKeybindSetting() {
      return this.knopkaKeybindSetting;
   }

   private SwapState getActionPhase() {
      return this.field_21d961c9;
   }

   private void setActionPhase(SwapState var1) {
      this.field_21d961c9 = var1;
   }

   private boolean isPressed() {
      return this.field_8f04dbbe;
   }

   private void setPressed(boolean var1) {
      this.field_8f04dbbe = var1;
   }

   private int getSlotToSwap() {
      return this.field_fc3055b3;
   }

   private void setSlotToSwap(int var1) {
      this.field_fc3055b3 = var1;
   }

   private boolean isSlotChanged() {
      return this.field_695bcfa8;
   }

   private void setSlotChanged(boolean var1) {
      this.field_695bcfa8 = var1;
   }

   private boolean isSwapPending() {
      return this.field_d687499d;
   }

   private void setSwapPending(boolean var1) {
      this.field_d687499d = var1;
   }

   private boolean wasLeftPressed() {
      return this.field_43b2c392;
   }

   private void setWasLeftPressed(boolean var1) {
      this.field_43b2c392 = var1;
   }

   private boolean wasRightPressed() {
      return this.field_b0de3d87;
   }

   private void setWasRightPressed(boolean var1) {
      this.field_b0de3d87 = var1;
   }

   private boolean wasJumpPressed() {
      return this.field_1e09b77c;
   }

   private void setWasJumpPressed(boolean var1) {
      this.field_1e09b77c = var1;
   }

   private boolean isRestoreMovementInput() {
      return this.field_8b353171;
   }

   private void setRestoreMovementInput(boolean var1) {
      this.field_8b353171 = var1;
   }


   private static enum SwapState {
      READY,
      SLOWING_DOWN,
      PICKUP_ITEM,
      PICKUP_OFFHAND,
      RETURN_ITEM,
      SPEEDING_UP,
      FINISHED;

   }
}
