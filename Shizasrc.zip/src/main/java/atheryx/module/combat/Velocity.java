package atheryx.module.combat;

import atheryx.event.EventHandler;
import atheryx.event.impl.PacketReceiveEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.ModeSetting;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2664;
import net.minecraft.class_2708;
import net.minecraft.class_2743;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_6373;
import net.minecraft.class_2846.class_2847;

@NewFunction(
   name = "Velocity",
   category = Category.COMBAT,
   desc = "Полностью убирает откидывание"
)
public class Velocity extends Function {
   private final ModeSetting rezhimModeSetting = new ModeSetting("Режим", new String[]{"Пакетный", "New Grim", "Old Grim", "Matrix", "Normal"});
   private boolean field_da56f3ea;
   private int field_47826ddf;
   private int field_b4ade7d4;
   private class_243 field_21d961c9;

   public Velocity() {
      this.addSettings(new Setting[]{this.getModeSetting()});
   }

   public void onEnable() {
      this.setCooldownTicks(0);
      this.setActionPending(false);
      this.setRetryCount(0);
      this.setCurrentPosition((class_243)null);
      super.onEnable();
   }

   public void onDisable() {
      this.setCurrentPosition((class_243)null);
      super.onDisable();
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         if (!this.mc.field_1724.method_5799() && !this.mc.field_1724.method_5869()) {
            if (this.getModeSetting().isSelected("Matrix")) {
               this.updateRotation();
            }

            if (this.getModeSetting().isSelected("New Grim") && this.isActionPending()) {
               this.advanceActionPhase();
            }

            if (this.getCooldownTicks() > 0) {
               this.setCooldownTicks(this.getCooldownTicks() - 1);
            }

         }
      }
   }

   @EventHandler
   public void onPacketReceive(PacketReceiveEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         if (!this.mc.field_1724.method_5799() && !this.mc.field_1724.method_5869() && !this.mc.field_1724.method_5771()) {
            if (this.getRetryCount() > 0) {
               this.setRetryCount(this.getRetryCount() - 1);
            } else {
               class_2596 var3 = event.getPacket();
               if (var3 instanceof class_2743) {
                  class_2743 packet = (class_2743)var3;
                  if (packet.method_11818() == this.mc.field_1724.method_5628()) {
                     this.refreshTarget(event, packet);
                  }
               }

               if (event.getPacket() instanceof class_2664 && (this.getModeSetting().isSelected("Пакетный") || this.getModeSetting().isSelected("Normal"))) {
                  event.cancel();
               }

               if (this.getModeSetting().isSelected("Old Grim") && event.getPacket() instanceof class_6373 && this.getCooldownTicks() > 0) {
                  event.cancel();
                  this.setCooldownTicks(this.getCooldownTicks() - 1);
               }

               if (event.getPacket() instanceof class_2708 && this.getModeSetting().isSelected("New Grim")) {
                  this.setRetryCount(5);
               }

            }
         }
      }
   }

   private void refreshTarget(PacketReceiveEvent event, class_2743 packet) {
      class_243 velocity = packet.method_73085();
      if (this.getModeSetting().isSelected("Matrix")) {
         if (!this.isActionPending()) {
            event.cancel();
            this.setActionPending(true);
         } else {
            this.setActionPending(false);
            event.cancel();
            this.setCurrentPosition(new class_243(velocity.field_1352 * -0.1, velocity.field_1351, velocity.field_1350 * -0.1));
         }
      } else if (!this.getModeSetting().isSelected("Normal") && !this.getModeSetting().isSelected("Пакетный")) {
         if (this.getModeSetting().isSelected("Old Grim")) {
            event.cancel();
            this.setCooldownTicks(6);
         } else if (this.getModeSetting().isSelected("New Grim")) {
            event.cancel();
            this.setActionPending(true);
         }
      } else {
         event.cancel();
      }

   }

   private void updateRotation() {
      if (this.getCurrentPosition() != null) {
         this.mc.field_1724.method_18799(this.getCurrentPosition());
         this.setCurrentPosition((class_243)null);
      }

      if (this.mc.field_1724.field_6235 > 0 && !this.mc.field_1724.method_24828()) {
         double yaw = (double)(this.mc.field_1724.method_36454() * ((float)Math.PI / 180F));
         double speed = Math.hypot(this.mc.field_1724.method_18798().field_1352, this.mc.field_1724.method_18798().field_1350);
         this.mc.field_1724.method_18800(-Math.sin(yaw) * speed, this.mc.field_1724.method_18798().field_1351, Math.cos(yaw) * speed);
         this.mc.field_1724.method_5728(this.mc.field_1724.field_6012 % 2 != 0);
      }

   }

   private void advanceActionPhase() {
      if (this.getRetryCount() <= 0) {
         this.mc.field_1724.field_3944.method_52787(new class_2828.class_2830(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321(), this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455(), this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
         this.mc.field_1724.field_3944.method_52787(new class_2846(class_2847.field_12971, this.mc.field_1724.method_24515(), class_2350.field_11033));
      }

      this.setActionPending(false);
   }

   private ModeSetting getModeSetting() {
      return this.rezhimModeSetting;
   }

   private boolean isActionPending() {
      return this.field_da56f3ea;
   }

   private void setActionPending(boolean var1) {
      this.field_da56f3ea = var1;
   }

   private int getCooldownTicks() {
      return this.field_47826ddf;
   }

   private void setCooldownTicks(int var1) {
      this.field_47826ddf = var1;
   }

   private int getRetryCount() {
      return this.field_b4ade7d4;
   }

   private void setRetryCount(int var1) {
      this.field_b4ade7d4 = var1;
   }

   private class_243 getCurrentPosition() {
      return this.field_21d961c9;
   }

   private void setCurrentPosition(class_243 var1) {
      this.field_21d961c9 = var1;
   }

}
