package atheryx.module.combat;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.KeybindSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_2848;
import net.minecraft.class_3966;
import net.minecraft.class_2848.class_2849;

@NewFunction(
   name = "TriggerBot",
   desc = "Бьёт сущностей при наводке",
   category = Category.COMBAT
)
public class TriggerBot extends Function {
   private final BooleanSetting tolkoKrityBooleanSetting = new BooleanSetting("Только криты", true);
   private final KeybindSetting bindKeybindSetting = new KeybindSetting("Бинд", 0);
   private long field_47826ddf;

   public TriggerBot() {
      this.setLastActionTime(0L);
      this.addSettings(new Setting[]{this.getCriticalHitsOnlySetting(), this.getKeybindSetting()});
   }

   public void setKeybind(int keybind) {
      super.setKeybind(keybind);
      if (this.getKeybindSetting() != null) {
         this.getKeybindSetting().setKeybind(keybind);
      }

   }

   @EventHandler
   public void onUpdate(UpdateEvent e) {
      if (this.getKeybindSetting().getKeybind() != super.getKeybind()) {
         super.setKeybind(this.getKeybindSetting().getKeybind());
      }

      class_239 hitResult = this.mc.field_1765;
      if (System.currentTimeMillis() - this.getLastActionTime() >= 450L) {
         if (hitResult instanceof class_3966) {
            class_3966 entityHitResult = (class_3966)hitResult;
            if (!(entityHitResult.method_17782() instanceof class_1657)) {
               return;
            }

            float cooled = this.mc.field_1724.method_7261(1.5F);
            if (cooled < 0.92F) {
               return;
            }

            if (this.getCriticalHitsOnlySetting().isEnabled() && this.mc.field_1724.field_6017 < (double)0.2F) {
               return;
            }

            boolean sprinting = this.mc.field_1724.method_5624();
            if (sprinting) {
               this.mc.field_1724.method_5728(false);
               this.mc.field_1724.field_3944.method_52787(new class_2848(this.mc.field_1724, class_2849.field_12985));
            }

            this.setLastActionTime(System.currentTimeMillis());
            this.mc.field_1761.method_2918(this.mc.field_1724, entityHitResult.method_17782());
            this.mc.field_1724.method_6104(class_1268.field_5808);
            if (sprinting) {
               this.mc.field_1724.method_5728(true);
               this.mc.field_1724.field_3944.method_52787(new class_2848(this.mc.field_1724, class_2849.field_12981));
            }
         }

      }
   }

   public boolean shouldPreventSprintReset() {
      return false;
   }

   public class_1309 findTarget() {
      class_239 var3 = this.mc.field_1765;
      if (var3 instanceof class_3966 entityHitResult) {
         class_1297 var4 = entityHitResult.method_17782();
         if (var4 instanceof class_1657 player) {
            return player;
         }
      }

      return null;
   }

   private BooleanSetting getCriticalHitsOnlySetting() {
      return this.tolkoKrityBooleanSetting;
   }

   private KeybindSetting getKeybindSetting() {
      return this.bindKeybindSetting;
   }

   private long getLastActionTime() {
      return this.field_47826ddf;
   }

   private void setLastActionTime(long var1) {
      this.field_47826ddf = var1;
   }

}
