package atheryx.module.combat;

import atheryx.event.EventHandler;
import atheryx.event.EventPriority;
import atheryx.event.impl.InputEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.manager.RotationManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.module.movement.Speed;
import atheryx.module.player.ElytraHelper;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ListSetting;
import atheryx.setting.impl.NumberSetting;
import atheryx.util.MoveUtil;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_243;

@NewFunction(
   name = "TargetStrafe",
   desc = "Стрейф вокруг цели AttackAura",
   category = Category.COMBAT
)
public class TargetStrafe extends Function {
   private static final float obf_u00ed_u221c = 180.0F;
   private final NumberSetting strafePowerNumberSetting = new NumberSetting("Strafe Power", (double)0.0F, (double)0.0F, (double)1.0F, 0.05);
   private final ListSetting directionListSetting = new ListSetting("Direction", new String[]{"Auto", "Left", "Right"});
   private final BooleanSetting onlyWithSpeedBooleanSetting = new BooleanSetting("Only With Speed", true);
   private final BooleanSetting autoJumpBooleanSetting = new BooleanSetting("Auto Jump", true);
   private final BooleanSetting collisionSwitchBooleanSetting = new BooleanSetting("Collision Switch", true);
   private class_1309 field_8f04dbbe;
   private int field_fc3055b3;

   public TargetStrafe() {
      this.setCooldownTicks(1);
      this.addSettings(new Setting[]{this.getStrafePowerSetting(), this.getDirectionSetting(), this.getOnlyWithSpeedSetting(), this.getAutoJumpSetting(), this.getCollisionSwitchSetting()});
   }

   public void onEnable() {
      this.setTarget((class_1309)null);
      this.setCooldownTicks(1);
   }

   public void onDisable() {
      this.setTarget((class_1309)null);
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onUpdate(UpdateEvent event) {
      this.setTarget(this.selectStrafeTarget());
      if (!this.isFeatureActive()) {
         this.setTarget((class_1309)null);
      } else {
         this.refreshTarget();
         this.updateRotation();
         Speed speedFunc = (Speed)FunctionManager.getFunction(Speed.class);
         if (speedFunc == null || !speedFunc.isEnabled()) {
            double currentSpeed = Math.sqrt(this.mc.field_1724.method_18798().field_1352 * this.mc.field_1724.method_18798().field_1352 + this.mc.field_1724.method_18798().field_1350 * this.mc.field_1724.method_18798().field_1350);
            if (currentSpeed < 0.22) {
               currentSpeed = 0.22;
               if (this.mc.field_1724.method_6059(class_1294.field_5904)) {
                  currentSpeed *= (double)1.0F + 0.2 * (double)(this.mc.field_1724.method_6112(class_1294.field_5904).method_5578() + 1);
               }
            }

            MoveUtil.setHorizontalSpeed(currentSpeed);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onInput(InputEvent event) {
      if (this.isFeatureActive()) {
         ElytraHelper helper = (ElytraHelper)FunctionManager.getFunction(ElytraHelper.class);
         if (helper == null || !helper.shouldProcess()) {
            event.setForward(1.0F);
            event.setStrafe((float)((double)this.getCooldownTicks() * this.getStrafePowerSetting().getValue()));
            if (this.getAutoJumpSetting().isEnabled() && this.mc.field_1724.method_24828() && !event.isSneaking()) {
               event.setJumping(true);
            }

         }
      }
   }

   private class_1309 selectStrafeTarget() {
      AttackAura aura = (AttackAura)FunctionManager.getFunction(AttackAura.class);
      return aura != null && aura.isEnabled() ? aura.findTarget() : null;
   }

   private boolean isFeatureActive() {
      if (!this.nullCheck.isPlayerOrWorldMissing() && this.getTarget() != null && this.getTarget().method_5805()) {
         if (!this.mc.field_1724.method_5715() && !this.mc.field_1724.method_5765()) {
            if (!this.getOnlyWithSpeedSetting().isEnabled()) {
               return true;
            } else {
               Speed speed = (Speed)FunctionManager.getFunction(Speed.class);
               return speed != null && speed.isEnabled();
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void refreshTarget() {
      if (this.getDirectionSetting().isSelected("Left")) {
         this.setCooldownTicks(1);
      } else if (this.getDirectionSetting().isSelected("Right")) {
         this.setCooldownTicks(-1);
      } else {
         if (this.mc.field_1690.field_1913.method_1434()) {
            this.setCooldownTicks(1);
         } else if (this.mc.field_1690.field_1849.method_1434()) {
            this.setCooldownTicks(-1);
         } else if (this.getCollisionSwitchSetting().isEnabled() && this.mc.field_1724.field_5976) {
            this.setCooldownTicks(-this.getCooldownTicks());
         }

      }
   }

   private void updateRotation() {
      AttackAura aura = (AttackAura)FunctionManager.getFunction(AttackAura.class);
      if (aura == null || !aura.isFeatureActivePrimary()) {
         RotationManager.Rotation rotation = RotationManager.rotationTo(this.getTargetPosition());
         RotationManager.requestRotation(rotation, RotationManager.MoveCorrection.SILENT, 180.0F, 180.0F, 180.0F);
      }
   }

   private class_243 getTargetPosition() {
      return this.getTarget().method_5829().method_1005();
   }

   public class_1309 findTarget() {
      return this.getTarget();
   }

   public int calculateAnimationFactor() {
      return this.getCooldownTicks();
   }

   public double calculateAnimationFactorForTarget() {
      return this.getStrafePowerSetting().getValue();
   }

   private NumberSetting getStrafePowerSetting() {
      return this.strafePowerNumberSetting;
   }

   private ListSetting getDirectionSetting() {
      return this.directionListSetting;
   }

   private BooleanSetting getOnlyWithSpeedSetting() {
      return this.onlyWithSpeedBooleanSetting;
   }

   private BooleanSetting getAutoJumpSetting() {
      return this.autoJumpBooleanSetting;
   }

   private BooleanSetting getCollisionSwitchSetting() {
      return this.collisionSwitchBooleanSetting;
   }

   private class_1309 getTarget() {
      return this.field_8f04dbbe;
   }

   private void setTarget(class_1309 var1) {
      this.field_8f04dbbe = var1;
   }

   private int getCooldownTicks() {
      return this.field_fc3055b3;
   }

   private void setCooldownTicks(int var1) {
      this.field_fc3055b3 = var1;
   }

}
