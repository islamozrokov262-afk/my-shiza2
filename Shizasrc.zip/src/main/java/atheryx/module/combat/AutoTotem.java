package atheryx.module.combat;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.NumberSetting;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1041;
import net.minecraft.class_1304;
import net.minecraft.class_1511;
import net.minecraft.class_1541;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_3675;

@NewFunction(
   name = "AutoTotem",
   desc = "Moves a totem to offhand when dangerous",
   category = Category.COMBAT
)
public class AutoTotem extends Function {
   private final NumberSetting porogZdorovyaNumberSetting = new NumberSetting("Порог здоровья", 4.0D, 2.0D, 8.0D, 0.1);
   private final BooleanSetting kristallyBooleanSetting = new BooleanSetting("Кристаллы", true);
   private final BooleanSetting tntBooleanSetting = new BooleanSetting("TNT", true);
   private final NumberSetting distantsiyaDoTntNumberSetting = new NumberSetting("Дистанция до TNT", 8.0D, (double)0.0F, 50.0D, 0.1);
   private long field_21d961c9;
   private TotemSwapState field_8f04dbbe;
   private boolean field_fc3055b3;
   private boolean field_695bcfa8;
   private boolean field_d687499d;
   private boolean field_43b2c392;
   private boolean field_b0de3d87;
   private boolean field_1e09b77c;
   private int field_8b353171;

   public AutoTotem() {
      this.setActionPhase(AutoTotem.TotemSwapState.READY);
      this.setRestoreMovementInput(false);
      this.setTotemSlot(-1);
      this.addSettings(new Setting[]{this.getHealthThresholdSetting(), this.getCrystalsSetting(), this.getTntSetting(), this.getTntDistanceSetting()});
      this.getTntSetting().setChangeListener(this::updateSettingVisibility);
      this.updateSettingVisibility();
   }

   public void onEnable() {
      this.processInput();
      this.setLastActionTime(0L);
   }

   public void onDisable() {
      this.processInput();
      this.setLastActionTime(0L);
      this.resetTransientState();
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      this.updateSettingVisibility();
      if (!this.nullCheck.isPlayerOrWorldMissing() && this.mc.field_1761 != null && this.mc.field_1687 != null) {
         if (this.mc.field_1755 != null) {
            this.processInput();
         } else {
            if (this.getActionPhase() == AutoTotem.TotemSwapState.READY) {
               if (!this.mc.field_1724.field_7512.method_34255().method_7960()) {
                  return;
               }

               if (!this.isFeatureActive()) {
                  return;
               }

               class_1799 offhand = this.mc.field_1724.method_6079();
               int totemSlot = this.calculateAnimationFactor();
               if (totemSlot == -1) {
                  return;
               }

               class_1799 totemStack = this.mc.field_1724.method_31548().method_5438(totemSlot);
               boolean needSwap = !offhand.method_31574(class_1802.field_8288) || offhand.method_7942() && !totemStack.method_7942();
               if (needSwap && this.shouldProcessSecondary()) {
                  this.advanceActionPhase();
                  this.setTotemSlot(totemSlot);
                  this.setActionPhase(AutoTotem.TotemSwapState.SLOWING_DOWN);
               }
            } else {
               this.updateTimedState();
            }

         }
      } else {
         this.processInput();
      }
   }

   private void updateSettingVisibility() {
      this.getTntDistanceSetting().setVisible(this.getTntSetting().isEnabled());
   }

   private boolean isFeatureActive() {
      if (this.mc.field_1724.method_7357().method_7904(class_1802.field_8288.method_7854())) {
         return false;
      } else {
         float elytraBonus = this.mc.field_1724.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833) ? 4.0F : 0.0F;
         float currentHealth = this.mc.field_1724.method_6032() + this.mc.field_1724.method_6067();
         if ((double)currentHealth < this.getHealthThresholdSetting().getValue() + (double)elytraBonus) {
            return true;
         } else if (this.getCrystalsSetting().isEnabled() && this.shouldProcess()) {
            return true;
         } else {
            return this.getTntSetting().isEnabled() && this.shouldProcessPrimary();
         }
      }
   }

   private boolean shouldProcess() {
      class_238 box = this.mc.field_1724.method_5829().method_1014(5.0D);
      List<class_1511> crystals = this.mc.field_1687.method_8390(class_1511.class, box, (crystal) -> {
         return this.mc.field_1724.method_5739(crystal) < 5.0F && crystal.method_23318() > this.mc.field_1724.method_23320();
      });
      return !crystals.isEmpty();
   }

   private boolean shouldProcessPrimary() {
      class_238 box = this.mc.field_1724.method_5829().method_1014(this.getTntDistanceSetting().getValue());
      List var2 = this.mc.field_1687.method_8390(class_1541.class, box, (tnt) -> {
         return (double)this.mc.field_1724.method_5739(tnt) < this.getTntDistanceSetting().getValue();
      });
      return !var2.isEmpty();
   }

   private int calculateAnimationFactor() {
      return (Integer)this.mc.field_1724.method_31548().method_67533().stream().filter((stack) -> {
         return stack.method_31574(class_1802.field_8288);
      }).min(Comparator.comparing(class_1799::method_7942)).map((stack) -> {
         return this.mc.field_1724.method_31548().method_67533().indexOf(stack);
      }).orElse(-1);
   }

   private void updateRotation(int inventorySlot) {
      int slotIndex = this.calculateMovementSpeed(inventorySlot);
      this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, slotIndex, 40, class_1713.field_7791, this.mc.field_1724);
   }

   private int calculateMovementSpeed(int slot) {
      return slot < 9 ? slot + 36 : slot;
   }

   private boolean shouldProcessSecondary() {
      return System.currentTimeMillis() - this.getLastActionTime() >= 200L;
   }

   private void updateTimedState() {
      switch (this.getActionPhase().ordinal()) {
         case 0:
         default:
            break;
         case 1:
            this.prepareInteraction();
            this.setRestoreMovementInput(true);
            if (this.mc.field_1724.method_5624()) {
               this.mc.field_1724.method_5728(false);
            }

            this.setActionPhase(AutoTotem.TotemSwapState.SWAPPING);
            break;
         case 2:
            this.updateRotation(this.getTotemSlot());
            this.setLastActionTime(System.currentTimeMillis());
            this.setActionPhase(AutoTotem.TotemSwapState.SPEEDING_UP);
            break;
         case 3:
            this.resetTransientState();
            this.setActionPhase(AutoTotem.TotemSwapState.FINISHED);
            break;
         case 4:
            this.processInput();
      }

   }

   private void advanceActionPhase() {
      class_1041 window = this.mc.method_22683();
      this.setSlotChanged(class_3675.method_15987(window, this.mc.field_1690.field_1894.method_1429().method_1444()));
      this.setSwapPending(class_3675.method_15987(window, this.mc.field_1690.field_1881.method_1429().method_1444()));
      this.setInteractionPending(class_3675.method_15987(window, this.mc.field_1690.field_1913.method_1429().method_1444()));
      this.setWasRightPressed(class_3675.method_15987(window, this.mc.field_1690.field_1849.method_1429().method_1444()));
      this.setWasJumpPressed(class_3675.method_15987(window, this.mc.field_1690.field_1903.method_1429().method_1444()));
      this.setRestoreMovementInput(false);
   }

   private void prepareInteraction() {
      this.mc.field_1690.field_1894.method_23481(false);
      this.mc.field_1690.field_1881.method_23481(false);
      this.mc.field_1690.field_1913.method_23481(false);
      this.mc.field_1690.field_1849.method_23481(false);
      this.mc.field_1690.field_1903.method_23481(false);
   }

   private void resetTransientState() {
      if (this.isRestoreMovementInput() && this.mc.method_22683() != null) {
         class_1041 window = this.mc.method_22683();
         boolean currentForward = class_3675.method_15987(window, this.mc.field_1690.field_1894.method_1429().method_1444());
         boolean currentBack = class_3675.method_15987(window, this.mc.field_1690.field_1881.method_1429().method_1444());
         boolean currentLeft = class_3675.method_15987(window, this.mc.field_1690.field_1913.method_1429().method_1444());
         boolean currentRight = class_3675.method_15987(window, this.mc.field_1690.field_1849.method_1429().method_1444());
         boolean currentJump = class_3675.method_15987(window, this.mc.field_1690.field_1903.method_1429().method_1444());
         this.mc.field_1690.field_1894.method_23481(this.isSlotChanged() && currentForward);
         this.mc.field_1690.field_1881.method_23481(this.isSwapPending() && currentBack);
         this.mc.field_1690.field_1913.method_23481(this.isInteractionPending() && currentLeft);
         this.mc.field_1690.field_1849.method_23481(this.wasRightPressed() && currentRight);
         this.mc.field_1690.field_1903.method_23481(this.wasJumpPressed() && currentJump);
         this.setRestoreMovementInput(false);
      }
   }

   private void processInput() {
      if (this.isRestoreMovementInput()) {
         this.resetTransientState();
      }

      this.setActionPhase(AutoTotem.TotemSwapState.READY);
      this.setTotemSlot(-1);
      this.setRestoreMovementInput(false);
   }

   private NumberSetting getHealthThresholdSetting() {
      return this.porogZdorovyaNumberSetting;
   }

   private BooleanSetting getCrystalsSetting() {
      return this.kristallyBooleanSetting;
   }

   private BooleanSetting getTntSetting() {
      return this.tntBooleanSetting;
   }

   private NumberSetting getTntDistanceSetting() {
      return this.distantsiyaDoTntNumberSetting;
   }

   private long getLastActionTime() {
      return this.field_21d961c9;
   }

   private void setLastActionTime(long var1) {
      this.field_21d961c9 = var1;
   }

   private TotemSwapState getActionPhase() {
      return this.field_8f04dbbe;
   }

   private void setActionPhase(TotemSwapState var1) {
      this.field_8f04dbbe = var1;
   }

   private boolean isSlotChanged() {
      return this.field_fc3055b3;
   }

   private void setSlotChanged(boolean var1) {
      this.field_fc3055b3 = var1;
   }

   private boolean isSwapPending() {
      return this.field_695bcfa8;
   }

   private void setSwapPending(boolean var1) {
      this.field_695bcfa8 = var1;
   }

   private boolean isInteractionPending() {
      return this.field_d687499d;
   }

   private void setInteractionPending(boolean var1) {
      this.field_d687499d = var1;
   }

   private boolean wasRightPressed() {
      return this.field_43b2c392;
   }

   private void setWasRightPressed(boolean var1) {
      this.field_43b2c392 = var1;
   }

   private boolean wasJumpPressed() {
      return this.field_b0de3d87;
   }

   private void setWasJumpPressed(boolean var1) {
      this.field_b0de3d87 = var1;
   }

   private boolean isRestoreMovementInput() {
      return this.field_1e09b77c;
   }

   private void setRestoreMovementInput(boolean var1) {
      this.field_1e09b77c = var1;
   }

   private int getTotemSlot() {
      return this.field_8b353171;
   }

   private void setTotemSlot(int var1) {
      this.field_8b353171 = var1;
   }


   private static enum TotemSwapState {
      READY,
      SLOWING_DOWN,
      SWAPPING,
      SPEEDING_UP,
      FINISHED;

   }
}
