package atheryx.module.combat;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.manager.RotationManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.NumberSetting;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;

@NewFunction(
   name = "AutoExplosion",
   desc = "Автоматически ставит и взрывает кристалл",
   category = Category.COMBAT
)
public class AutoExplosion extends Function {
   private final NumberSetting radiusNumberSetting = new NumberSetting("Радиус", 5.0D, 3.0D, 6.0D, 0.1);
   private final NumberSetting zaderzhkaNumberSetting = new NumberSetting("Задержка", 80.0D, (double)0.0F, 500.0D, 10.0D);
   private final Set<class_2338> field_47826ddf = new HashSet<class_2338>();
   private final Set<class_2338> field_b4ade7d4 = new HashSet<class_2338>();
   private class_2338 field_21d961c9;
   private int field_8f04dbbe;
   private int field_fc3055b3;
   private boolean field_695bcfa8;
   private ExplosionState field_d687499d;
   private long field_43b2c392;
   private int field_b0de3d87;

   public AutoExplosion() {
      this.setSlot(-1);
      this.setPreviousSlot(-1);
      this.setActionPhase(AutoExplosion.ExplosionState.IDLE);
      this.addSettings(new Setting[]{this.getRadiusSetting(), this.getDelaySetting()});
   }

   public void onEnable() {
      this.setCrystalPos((class_2338)null);
      this.setSlot(-1);
      this.setPreviousSlot(-1);
      this.setSlotChanged(false);
      this.setActionPhase(AutoExplosion.ExplosionState.IDLE);
      this.setLastActionTime(0L);
      this.setCrystalWaitTicks(0);
      this.getCandidatePositions().clear();
      this.getProcessedPositions().clear();
      this.refreshTarget();
   }

   public void onDisable() {
      this.restoreSelectedSlotPrimary();
      this.setCrystalPos((class_2338)null);
      this.setSlot(-1);
      this.setPreviousSlot(-1);
      this.setSlotChanged(false);
      this.setActionPhase(AutoExplosion.ExplosionState.IDLE);
      this.setCrystalWaitTicks(0);
      this.getCandidatePositions().clear();
      this.getProcessedPositions().clear();
      RotationManager.reset();
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing() && this.mc.field_1724 != null && this.mc.field_1687 != null && this.mc.field_1761 != null) {
         long now = System.currentTimeMillis();
         if (!((double)(now - this.getLastActionTime()) < this.getDelaySetting().getValue())) {
            switch (this.getActionPhase().ordinal()) {
               case 0:
                  this.updateTimedState();
                  break;
               case 1:
                  this.updateRotation();
                  break;
               case 2:
                  this.restoreSelectedSlot();
                  break;
               case 3:
                  this.updateTimedStatePrimary();
                  break;
               case 4:
                  this.updateRotationPrimary();
                  break;
               case 5:
                  this.restoreSelectedSlotPrimary();
                  this.reset();
            }

         }
      } else {
         this.reset();
      }
   }

   private void refreshTarget() {
      class_2338 playerPos = this.mc.field_1724.method_24515();
      int r = (int)this.getRadiusSetting().getValue();
      double rangeSq = this.getRadiusSetting().getValue() * this.getRadiusSetting().getValue();

      for(int x = -r; x <= r; ++x) {
         for(int y = -r; y <= r; ++y) {
            for(int z = -r; z <= r; ++z) {
               class_2338 pos = playerPos.method_10069(x, y, z).method_10062();
               if (!(this.mc.field_1724.method_5707(class_243.method_24953(pos)) > rangeSq)) {
                  class_2248 block = this.mc.field_1687.method_8320(pos).method_26204();
                  if (block == class_2246.field_10540 || block == class_2246.field_9987) {
                     this.getCandidatePositions().add(pos);
                  }
               }
            }
         }
      }

   }

   private void updateTimedState() {
      class_2338 playerPos = this.mc.field_1724.method_24515();
      int r = (int)this.getRadiusSetting().getValue();
      double rangeSq = this.getRadiusSetting().getValue() * this.getRadiusSetting().getValue();

      for(int x = -r; x <= r; ++x) {
         for(int y = -r; y <= r; ++y) {
            for(int z = -r; z <= r; ++z) {
               class_2338 pos = playerPos.method_10069(x, y, z).method_10062();
               if (!(this.mc.field_1724.method_5707(class_243.method_24953(pos)) > rangeSq)) {
                  class_2248 block = this.mc.field_1687.method_8320(pos).method_26204();
                  if (block != class_2246.field_10540 && block != class_2246.field_9987) {
                     this.getCandidatePositions().remove(pos);
                     this.getProcessedPositions().remove(pos);
                  } else if (!this.getCandidatePositions().contains(pos) && !this.getProcessedPositions().contains(pos)) {
                     if (!this.isValidObsidianPos(pos)) {
                        this.getCandidatePositions().add(pos);
                     } else {
                        int slot = this.calculateAnimationFactor();
                        if (slot != -1) {
                           this.setCrystalPos(pos);
                           this.setSlot(slot);
                           this.getCandidatePositions().add(pos);
                           this.getProcessedPositions().add(pos);
                           this.setActionPhase(AutoExplosion.ExplosionState.ROTATE_PLACE);
                           this.setCrystalWaitTicks(0);
                           this.setLastActionTime(System.currentTimeMillis());
                           return;
                        }

                        this.getCandidatePositions().add(pos);
                     }
                  }
               }
            }
         }
      }

   }

   private void updateRotation() {
      if (this.getCrystalPos() != null && this.isValidObsidianPos(this.getCrystalPos())) {
         class_243 eyeVec = this.mc.field_1724.method_33571();
         class_243 hitVec = this.calculatePosition(eyeVec, this.getCrystalPos());
         RotationManager.Rotation var3 = RotationManager.rotationTo(hitVec);
         RotationManager.requestRotation(var3, RotationManager.MoveCorrection.SILENT, 180.0F, 180.0F, 180.0F);
         this.setActionPhase(AutoExplosion.ExplosionState.PLACE);
         this.setLastActionTime(System.currentTimeMillis());
      } else {
         this.reset();
      }
   }

   private void restoreSelectedSlot() {
      if (this.getCrystalPos() != null && this.isValidObsidianPos(this.getCrystalPos())) {
         this.setPreviousSlot(this.mc.field_1724.method_31548().method_67532());
         if (this.getSlot() != this.getPreviousSlot()) {
            this.mc.field_1724.method_31548().method_61496(this.getSlot());
            this.setSlotChanged(true);
         }

         class_243 eyeVec = this.mc.field_1724.method_33571();
         class_243 hitVec = this.calculatePosition(eyeVec, this.getCrystalPos());
         class_243 offset = eyeVec.method_1020(hitVec);
         class_2350 direction = class_2350.method_10142(offset.field_1352, offset.field_1351, offset.field_1350);
         class_3965 hitResult = new class_3965(hitVec, direction, this.getCrystalPos(), false);
         this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, hitResult);
         this.mc.field_1724.method_6104(class_1268.field_5808);
         this.setActionPhase(AutoExplosion.ExplosionState.WAIT_CRYSTAL);
         this.setCrystalWaitTicks(0);
         this.setLastActionTime(System.currentTimeMillis());
      } else {
         this.reset();
      }
   }

   private void updateTimedStatePrimary() {
      if (this.getCrystalPos() == null) {
         this.reset();
      } else {
         class_1511 crystal = this.findPlacedCrystal();
         if (crystal != null) {
            this.setActionPhase(AutoExplosion.ExplosionState.ATTACK);
            this.setLastActionTime(System.currentTimeMillis());
         } else {
            this.setCrystalWaitTicks(this.getCrystalWaitTicks() + 1);
            if (this.getCrystalWaitTicks() > 8) {
               this.setActionPhase(AutoExplosion.ExplosionState.RESTORE);
            }

            this.setLastActionTime(System.currentTimeMillis());
         }
      }
   }

   private void updateRotationPrimary() {
      if (this.getCrystalPos() == null) {
         this.reset();
      } else {
         class_1511 crystal = this.findPlacedCrystal();
         if (crystal == null) {
            this.setActionPhase(AutoExplosion.ExplosionState.RESTORE);
         } else {
            if (!crystal.method_5829().method_1006(this.mc.field_1724.method_33571())) {
               class_243 lookVec = crystal.method_5829().method_1005();
               RotationManager.Rotation rotation = RotationManager.rotationTo(lookVec);
               RotationManager.requestRotation(rotation, RotationManager.MoveCorrection.SILENT, 180.0F, 180.0F, 180.0F);
            }

            this.mc.field_1761.method_2918(this.mc.field_1724, crystal);
            this.mc.field_1724.method_6104(class_1268.field_5808);
            this.setActionPhase(AutoExplosion.ExplosionState.RESTORE);
            this.setLastActionTime(System.currentTimeMillis());
         }
      }
   }

   private boolean isValidObsidianPos(class_2338 obsidianPos) {
      class_2248 block = this.mc.field_1687.method_8320(obsidianPos).method_26204();
      if (block != class_2246.field_10540 && block != class_2246.field_9987) {
         return false;
      } else {
         class_2338 crystalPos = obsidianPos.method_10084();
         if (!this.mc.field_1687.method_8320(crystalPos).method_26215()) {
            return false;
         } else if (!this.mc.field_1687.method_8320(crystalPos.method_10084()).method_26215()) {
            return false;
         } else {
            for(class_1297 entity : this.mc.field_1687.method_18112()) {
               if (!(entity instanceof class_1511) && entity.method_5829().method_1003((double)crystalPos.method_10263(), (double)crystalPos.method_10264(), (double)crystalPos.method_10260(), (double)crystalPos.method_10263() + (double)1.0F, (double)crystalPos.method_10264() + 2.0D, (double)crystalPos.method_10260() + (double)1.0F)) {
                  return false;
               }
            }

            return true;
         }
      }
   }

   private class_1511 findPlacedCrystal() {
      if (this.getCrystalPos() == null) {
         return null;
      } else {
         class_2338 crystalPos = this.getCrystalPos().method_10084();

         for(class_1297 entity : this.mc.field_1687.method_18112()) {
            if (entity instanceof class_1511) {
               class_1511 crystal = (class_1511)entity;
               if (crystal.method_5829().method_1003((double)crystalPos.method_10263() - 0.1, (double)crystalPos.method_10264() - 0.1, (double)crystalPos.method_10260() - 0.1, (double)crystalPos.method_10263() + 1.1, (double)crystalPos.method_10264() + 1.1, (double)crystalPos.method_10260() + 1.1)) {
                  return crystal;
               }
            }
         }

         return null;
      }
   }

   private class_243 calculatePosition(class_243 eyeVec, class_2338 pos) {
      double x = this.clamp(eyeVec.field_1352, (double)pos.method_10263(), (double)pos.method_10263() + (double)1.0F);
      double y = this.clamp(eyeVec.field_1351, (double)pos.method_10264(), (double)pos.method_10264() + (double)1.0F);
      double z = this.clamp(eyeVec.field_1350, (double)pos.method_10260(), (double)pos.method_10260() + (double)1.0F);
      return new class_243(x, y, z);
   }

   private double clamp(double value, double min, double max) {
      return Math.max(min, Math.min(max, value));
   }

   private int calculateAnimationFactor() {
      for(int i = 0; i < 9; ++i) {
         if (this.mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8301) {
            return i;
         }
      }

      return -1;
   }

   private void restoreSelectedSlotPrimary() {
      if (this.isSlotChanged() && this.getPreviousSlot() >= 0 && this.getPreviousSlot() < 9) {
         this.mc.field_1724.method_31548().method_61496(this.getPreviousSlot());
      }

      this.setSlotChanged(false);
      this.setPreviousSlot(-1);
   }

   private void reset() {
      this.setCrystalPos((class_2338)null);
      this.setSlot(-1);
      this.setCrystalWaitTicks(0);
      this.setActionPhase(AutoExplosion.ExplosionState.IDLE);
      this.setLastActionTime(System.currentTimeMillis());
   }

   private NumberSetting getRadiusSetting() {
      return this.radiusNumberSetting;
   }

   private NumberSetting getDelaySetting() {
      return this.zaderzhkaNumberSetting;
   }

   private Set getCandidatePositions() {
      return this.field_47826ddf;
   }

   private Set getProcessedPositions() {
      return this.field_b4ade7d4;
   }

   private class_2338 getCrystalPos() {
      return this.field_21d961c9;
   }

   private void setCrystalPos(class_2338 var1) {
      this.field_21d961c9 = var1;
   }

   private int getSlot() {
      return this.field_8f04dbbe;
   }

   private void setSlot(int var1) {
      this.field_8f04dbbe = var1;
   }

   private int getPreviousSlot() {
      return this.field_fc3055b3;
   }

   private void setPreviousSlot(int var1) {
      this.field_fc3055b3 = var1;
   }

   private boolean isSlotChanged() {
      return this.field_695bcfa8;
   }

   private void setSlotChanged(boolean var1) {
      this.field_695bcfa8 = var1;
   }

   private ExplosionState getActionPhase() {
      return this.field_d687499d;
   }

   private void setActionPhase(ExplosionState var1) {
      this.field_d687499d = var1;
   }

   private long getLastActionTime() {
      return this.field_43b2c392;
   }

   private void setLastActionTime(long var1) {
      this.field_43b2c392 = var1;
   }

   private int getCrystalWaitTicks() {
      return this.field_b0de3d87;
   }

   private void setCrystalWaitTicks(int var1) {
      this.field_b0de3d87 = var1;
   }


   private static enum ExplosionState {
      IDLE,
      ROTATE_PLACE,
      PLACE,
      WAIT_CRYSTAL,
      ATTACK,
      RESTORE;

   }
}
