package atheryx.module.combat;

import atheryx.event.EventHandler;
import atheryx.event.impl.AttackEntityEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import net.minecraft.class_1294;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2828;
import net.minecraft.class_3532;

@NewFunction(
   name = "PacketCriticals",
   desc = "Бьёт критами под плавном падении и в паутине RW",
   category = Category.COMBAT
)
public class PacketCriticals extends Function {
   private long field_6d2b79f5;

   @EventHandler
   public void onAttackEntity(AttackEntityEvent event) {
      this.updateTimedState();
   }

   public boolean shouldProcess() {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         return this.shouldProcessPrimary() || this.mc.field_1724.method_6059(class_1294.field_5906);
      } else {
         return false;
      }
   }

   public void updateTimedState() {
      if (this.shouldProcess()) {
         long now = System.currentTimeMillis();
         if (now - this.getNow() >= 80L) {
            this.setNow(now);
            double x = this.mc.field_1724.method_23317();
            double y = this.mc.field_1724.method_23318();
            double z = this.mc.field_1724.method_23321();
            this.mc.field_1724.field_3944.method_52787(new class_2828.class_2829(x, y + (double)0.0625F, z, false, false));
            this.mc.field_1724.field_3944.method_52787(new class_2828.class_2829(x, y + 0.0015, z, false, false));
            this.mc.field_1724.field_3944.method_52787(new class_2828.class_2829(x, y, z, false, false));
         }
      }
   }

   private boolean shouldProcessPrimary() {
      class_238 box = this.mc.field_1724.method_5829();

      for(int x = class_3532.method_15357(box.field_1323); x <= class_3532.method_15357(box.field_1320); ++x) {
         for(int y = class_3532.method_15357(box.field_1322); y <= class_3532.method_15357(box.field_1325); ++y) {
            for(int z = class_3532.method_15357(box.field_1321); z <= class_3532.method_15357(box.field_1324); ++z) {
               class_2338 blockPos = new class_2338(x, y, z);
               if (this.mc.field_1687.method_8320(blockPos).method_27852(class_2246.field_10343) && (new class_238(blockPos)).method_994(box)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private long getNow() {
      return this.field_6d2b79f5;
   }

   private void setNow(long var1) {
      this.field_6d2b79f5 = var1;
   }

}
