package atheryx.module.combat;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.gui.ThemeManager;
import atheryx.manager.RotationManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import atheryx.module.render.EntityESP;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ColorSetting;
import atheryx.setting.impl.MultiListSetting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_12249;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;

@NewFunction(
   name = "HitBox",
   desc = "Увеличивает визуальный хитбокс с сайлент-атакой",
   category = Category.COMBAT
)
public class HitBox extends Function {
   private final NumberSetting razmerNumberSetting = new NumberSetting("Размер", (double)0.5F, 0.1, 3.0D, 0.1);
   private final BooleanSetting tsvetTemyBooleanSetting = new BooleanSetting("Цвет темы", true);
   private final BooleanSetting zalivkaBooleanSetting = new BooleanSetting("Заливка", true);
   private final NumberSetting alfaZalivkiNumberSetting = new NumberSetting("Альфа заливки", 50.0D, (double)0.0F, 255.0D, (double)1.0F);
   private final BooleanSetting obvodkaBooleanSetting = new BooleanSetting("Обводка", true);
   private final ColorSetting tsvetColorSetting = new ColorSetting("Цвет", new Color(255, 255, 255, 100));
   private final NumberSetting alfaPriUdareNumberSetting = new NumberSetting("Альфа при ударе", 200.0D, (double)0.0F, 255.0D, (double)1.0F);
   private final NumberSetting skorostAnimatsiiNumberSetting = new NumberSetting("Скорость анимации", 10.0D, (double)1.0F, 30.0D, (double)1.0F);
   private final NumberSetting skorostRotatsiiNumberSetting = new NumberSetting("Скорость ротации", 45.0D, 10.0D, 180.0D, 5.0D);
   private final MultiListSetting tseliMultiListSetting = new MultiListSetting("Цели", new String[]{"Игроки", "Животные", "Мобы", "Невидимые"});
   private final Map<Integer, Double> field_b0de3d87 = new HashMap<Integer, Double>();
   private long field_1e09b77c;
   private class_1297 field_8b353171;
   private boolean field_f860ab66;
   private boolean field_658c255b;
   private final Random field_d2b79f50;
   private boolean field_3fe31945;
   private double field_ad0e933a;
   private double field_1a3a0d2f;
   private double field_87658724;

   public HitBox() {
      this.setDelta(0L);
      this.setBox((class_1297)null);
      this.setActionPending(false);
      this.setInputCaptured(false);
      this.field_d2b79f50 = new Random();
      this.setIsPressed(false);
      this.setDistance((double)0.5F);
      this.setTargetDistance(0.8);
      this.setCurrentValue((double)0.5F);
      this.addSettings(new Setting[]{this.getTargetsSetting(), this.getSizeSetting(), this.getThemeColorSetting(), this.getFillSetting(), this.getFillAlphaSetting(), this.getOutlineSetting(), this.getColorSetting(), this.getHitAlphaSetting(), this.getAnimationSpeedSetting(), this.getRotationSpeedSetting()});
      WorldRenderEvents.AFTER_ENTITIES.register(this::renderWorldOverlay);
      AttackBlockCallback.EVENT.register((AttackBlockCallback)(player, world, hand, pos, direction) -> {
         if (this.isActionPending()) {
            return class_1269.field_5814;
         } else {
            return (class_1269)(this.isEnabled() && player == this.mc.field_1724 && this.shouldProcess() ? class_1269.field_5814 : class_1269.field_5811);
         }
      });
      AttackEntityCallback.EVENT.register((AttackEntityCallback)(player, world, hand, entity, hitResult) -> {
         if (this.isInputCaptured()) {
            return class_1269.field_5811;
         } else if (this.isActionPending()) {
            return class_1269.field_5814;
         } else {
            return (class_1269)(this.isEnabled() && player == this.mc.field_1724 && this.shouldProcess() ? class_1269.field_5814 : class_1269.field_5811);
         }
      });
   }

   public void onEnable() {
      this.getTrackedEntries().clear();
      this.setDelta(System.nanoTime());
      this.setBox((class_1297)null);
      this.setActionPending(false);
      this.setIsPressed(false);
   }

   public void onDisable() {
      if (this.isActionPending()) {
         RotationManager.reset();
      }

      this.setBox((class_1297)null);
      this.setActionPending(false);
      this.setInputCaptured(false);
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (!this.nullCheck.isPlayerOrWorldMissing()) {
         boolean isPressed = this.mc.field_1690.field_1886.method_1434();
         if (this.isActionPending() && this.getBox() != null) {
            float rotSpeed = (float)this.getRotationSpeedSetting().getValue();
            class_238 box = this.getBox().method_5829();
            double targetX = box.field_1323 + (box.field_1320 - box.field_1323) * this.getDistance();
            double targetY = box.field_1322 + (box.field_1325 - box.field_1322) * this.getTargetDistance();
            double targetZ = box.field_1321 + (box.field_1324 - box.field_1321) * this.getCurrentValue();
            RotationManager.Rotation exactTargetRot = RotationManager.rotationTo(new class_243(targetX, targetY, targetZ));
            RotationManager.requestRotation(exactTargetRot, RotationManager.MoveCorrection.SILENT, rotSpeed, rotSpeed, rotSpeed);
            RotationManager.Rotation var12 = RotationManager.getCurrentRotation();
            if (this.isValidExact(exactTargetRot, var12)) {
               if (!this.mc.field_1724.method_24828() && this.mc.field_1724.method_18798().field_1351 >= (double)0.0F) {
                  return;
               }

               this.setInputCaptured(true);
               this.mc.field_1761.method_2918(this.mc.field_1724, this.getBox());
               this.setInputCaptured(false);
               this.mc.field_1724.method_6104(class_1268.field_5808);
               this.getTrackedEntries().put(this.getBox().method_5628(), (double)1.0F);
               RotationManager.beginReturn(rotSpeed);
               this.setActionPending(false);
               this.setBox((class_1297)null);
            }

            this.setIsPressed(isPressed);
         } else {
            if (isPressed && !this.isPressed()) {
               this.shouldProcess();
            }

            this.setIsPressed(isPressed);
         }
      }
   }

   private boolean shouldProcess() {
      if (this.isActionPending()) {
         return false;
      } else {
         class_243 start = this.mc.field_1724.method_5836(1.0F);
         class_243 direction = this.mc.field_1724.method_5828(1.0F);
         class_243 end = start.method_1019(direction.method_1021(4.5D));
      double minExpandedDistanceSq = 1.7976931348623157e+308D;
         class_1297 expandedHitEntity = null;
         class_1297 normalHitEntity = null;

         for(class_1297 entity : this.mc.field_1687.method_18112()) {
            if (this.isValidEntity(entity)) {
               class_238 normalBox = entity.method_5829();
               Optional<class_243> normalRaycast = normalBox.method_992(start, end);
               if (normalRaycast.isPresent()) {
                  normalHitEntity = entity;
               }

               class_238 expandedBox = normalBox.method_1009(this.getSizeSetting().getValue(), (double)0.0F, this.getSizeSetting().getValue());
               Optional<class_243> expandedRaycast = expandedBox.method_992(start, end);
               if (expandedRaycast.isPresent()) {
                  double distSq = start.method_1025(expandedRaycast.get());
                  if (distSq < minExpandedDistanceSq) {
                     minExpandedDistanceSq = distSq;
                     expandedHitEntity = entity;
                  }
               }
            }
         }

         if (normalHitEntity != null) {
            return false;
         } else if (expandedHitEntity != null) {
            this.setActionPending(true);
            this.setBox(expandedHitEntity);
            this.setDistance(this.getRandom().nextDouble());
            this.setTargetDistance(0.3 + this.getRandom().nextDouble() * 0.7);
            this.setCurrentValue(this.getRandom().nextDouble());
            this.mc.field_1690.field_1886.method_23481(false);
            return true;
         } else {
            return false;
         }
      }
   }

   private RotationManager.Rotation calculateTargetRotation(class_1297 entity) {
      class_238 box = entity.method_5829();
      double targetX = box.field_1323 + (box.field_1320 - box.field_1323) * this.getRandom().nextDouble();
      double targetY = box.field_1322 + (box.field_1325 - box.field_1322) * (0.3 + this.getRandom().nextDouble() * 0.7);
      double targetZ = box.field_1321 + (box.field_1324 - box.field_1321) * this.getRandom().nextDouble();
      return RotationManager.rotationTo(new class_243(targetX, targetY, targetZ));
   }

   private boolean isValidExact(RotationManager.Rotation exact, RotationManager.Rotation current) {
      float yawDelta = Math.abs(class_3532.method_15393(exact.yaw() - current.yaw()));
      float pitchDelta = Math.abs(exact.pitch() - current.pitch());
      return yawDelta < 6.0F && pitchDelta < 6.0F;
   }

   private boolean isValidEntity(class_1297 entity) {
      if (entity != this.mc.field_1724 && entity instanceof class_1309) {
         if (entity.method_5805() && entity.method_5732()) {
            if (entity.method_5767() && !this.getTargetsSetting().isSelected("Невидимые")) {
               return false;
            } else {
               if (entity instanceof class_1657) {
                  AntiBot antiBot = (AntiBot)FunctionManager.getFunction(AntiBot.class);
                  if (antiBot != null && antiBot.isEnabled() && antiBot.matchesPlayer((class_1657)entity)) {
                     return false;
                  }

                  if (NoFriendDamage.isValidPlayer((class_1657)entity)) {
                     return false;
                  }

                  if (!this.getTargetsSetting().isSelected("Игроки")) {
                     return false;
                  }
               } else {
                  if (entity instanceof class_1429 && !this.getTargetsSetting().isSelected("Животные")) {
                     return false;
                  }

                  if (entity instanceof class_1308 && !this.getTargetsSetting().isSelected("Мобы")) {
                     return false;
                  }
               }

               return true;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void renderWorldOverlay(WorldRenderContext context) {
      if (this.isEnabled() && this.mc.field_1687 != null && this.mc.field_1724 != null) {
         long now = System.nanoTime();
         double delta = this.getDelta() == 0L ? (double)0.0F : Math.min((double)(now - this.getDelta()) / 1000000000.0D, 0.05);
         this.setDelta(now);
         class_243 camera = context.worldState().field_63082.field_63078;
         class_4587 matrices = context.matrices();
         Color baseColor = this.getThemeColorSetting().isEnabled() ? ThemeManager.getCurrentColor() : this.getColorSetting().getColor();
         double expSize = this.getSizeSetting().getValue();
         double animSpeed = this.getAnimationSpeedSetting().getValue();
         float tickDelta = this.mc.method_61966().method_60637(false);

         for(class_1297 entity : this.mc.field_1687.method_18112()) {
            if (this.isValidEntity(entity)) {
               int id = entity.method_5628();
               double progress = (Double)this.getTrackedEntries().getOrDefault(id, (double)0.0F);
               if (progress > (double)0.0F) {
                  progress -= delta * animSpeed;
                  if (progress <= (double)0.0F) {
                     progress = (double)0.0F;
                     this.getTrackedEntries().remove(id);
                  } else {
                     this.getTrackedEntries().put(id, progress);
                  }
               }

               double easedProgress = (double)1.0F - Math.pow((double)1.0F - progress, 3.0D);
               int r = baseColor.getRed();
               int g = baseColor.getGreen();
               int b = baseColor.getBlue();
               int baseA = baseColor.getAlpha();
               int targetA = (int)this.getHitAlphaSetting().getValue();
               int a = (int)((double)baseA + (double)(targetA - baseA) * easedProgress);
               int baseFA = (int)this.getFillAlphaSetting().getValue();
               int fA = (int)((double)baseFA + (double)(targetA - baseFA) * easedProgress);
               Color renderColor = new Color(Math.clamp((long)r, 0, 255), Math.clamp((long)g, 0, 255), Math.clamp((long)b, 0, 255), Math.clamp((long)a, 0, 255));
               Color fillRenderColor = new Color(Math.clamp((long)r, 0, 255), Math.clamp((long)g, 0, 255), Math.clamp((long)b, 0, 255), Math.clamp((long)fA, 0, 255));
               class_243 var31 = entity.method_30950(tickDelta);
               class_243 offset = var31.method_1020(entity.method_73189());
               class_238 var33 = entity.method_5829().method_1009(expSize, (double)0.0F, expSize).method_997(offset);
               class_238 renderBox = var33.method_989(-camera.field_1352, -camera.field_1351, -camera.field_1350);
               if (this.getFillSetting().isEnabled()) {
                  class_4588 fillBuffer = context.consumers().method_73477(class_12249.method_75984(class_2960.method_60655("minecraft", "textures/block/white_concrete.png"), false));
                  this.drawBoxFaces(fillBuffer, matrices.method_23760(), renderBox, fillRenderColor);
               }

               if (this.getOutlineSetting().isEnabled()) {
                  class_4588 lineBuffer = context.consumers().method_73477(EntityESP.GLOW_BOX_LINES_NO_DEPTH);
                  this.drawBoxLines(lineBuffer, matrices.method_23760(), renderBox, renderColor);
               }
            }
         }

      }
   }

   private void drawBoxLines(class_4588 buffer, class_4587.class_4665 entry, class_238 box, Color color) {
      float width = 2.0F;
      double minX = box.field_1323;
      double minY = box.field_1322;
      double minZ = box.field_1321;
      double maxX = box.field_1320;
      double maxY = box.field_1325;
      double maxZ = box.field_1324;
      this.emitLine(buffer, entry, color, minX, minY, minZ, maxX, minY, minZ, width);
      this.emitLine(buffer, entry, color, maxX, minY, minZ, maxX, minY, maxZ, width);
      this.emitLine(buffer, entry, color, maxX, minY, maxZ, minX, minY, maxZ, width);
      this.emitLine(buffer, entry, color, minX, minY, maxZ, minX, minY, minZ, width);
      this.emitLine(buffer, entry, color, minX, maxY, minZ, maxX, maxY, minZ, width);
      this.emitLine(buffer, entry, color, maxX, maxY, minZ, maxX, maxY, maxZ, width);
      this.emitLine(buffer, entry, color, maxX, maxY, maxZ, minX, maxY, maxZ, width);
      this.emitLine(buffer, entry, color, minX, maxY, maxZ, minX, maxY, minZ, width);
      this.emitLine(buffer, entry, color, minX, minY, minZ, minX, maxY, minZ, width);
      this.emitLine(buffer, entry, color, maxX, minY, minZ, maxX, maxY, minZ, width);
      this.emitLine(buffer, entry, color, maxX, minY, maxZ, maxX, maxY, maxZ, width);
      this.emitLine(buffer, entry, color, minX, minY, maxZ, minX, maxY, maxZ, width);
   }

   private void drawBoxFaces(class_4588 buffer, class_4587.class_4665 entry, class_238 box, Color color) {
      this.emitVertex(buffer, entry, color, box.field_1323, box.field_1325, box.field_1324, box.field_1320, box.field_1325, box.field_1324, box.field_1320, box.field_1325, box.field_1321, box.field_1323, box.field_1325, box.field_1321);
      this.emitVertex(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1324, box.field_1323, box.field_1322, box.field_1324);
      this.emitVertex(buffer, entry, color, box.field_1323, box.field_1322, box.field_1321, box.field_1323, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1321, box.field_1320, box.field_1322, box.field_1321);
      this.emitVertex(buffer, entry, color, box.field_1320, box.field_1322, box.field_1324, box.field_1320, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1324, box.field_1323, box.field_1322, box.field_1324);
      this.emitVertex(buffer, entry, color, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1325, box.field_1324, box.field_1323, box.field_1325, box.field_1321, box.field_1323, box.field_1322, box.field_1321);
      this.emitVertex(buffer, entry, color, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1324, box.field_1320, box.field_1322, box.field_1324);
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, double x1, double y1, double z1, double x2, double y2, double z2, double x3, double y3, double z3, double x4, double y4, double z4) {
      this.emitVertex(buffer, entry, color, x1, y1, z1, 0.0F, 1.0F);
      this.emitVertex(buffer, entry, color, x2, y2, z2, 1.0F, 1.0F);
      this.emitVertex(buffer, entry, color, x3, y3, z3, 1.0F, 0.0F);
      this.emitVertex(buffer, entry, color, x4, y4, z4, 0.0F, 0.0F);
   }

   private void emitVertex(class_4588 buffer, class_4587.class_4665 entry, Color color, double x, double y, double z, float u, float v) {
      buffer.method_56824(entry, (float)x, (float)y, (float)z).method_22913(u, v).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).method_22922(class_4608.field_21444).method_60803(15728880).method_60831(entry, 0.0F, 1.0F, 0.0F);
   }

   private void emitLine(class_4588 buffer, class_4587.class_4665 entry, Color color, double x1, double y1, double z1, double x2, double y2, double z2, float width) {
      float dx = (float)(x2 - x1);
      float dy = (float)(y2 - y1);
      float dz = (float)(z2 - z1);
      float length = (float)Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
      if (!(length <= 1.0E-4F)) {
         buffer.method_56824(entry, (float)x1, (float)y1, (float)z1).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
         buffer.method_56824(entry, (float)x2, (float)y2, (float)z2).method_1336(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha()).method_60831(entry, dx / length, dy / length, dz / length).method_75298(width);
      }
   }

   private NumberSetting getSizeSetting() {
      return this.razmerNumberSetting;
   }

   private BooleanSetting getThemeColorSetting() {
      return this.tsvetTemyBooleanSetting;
   }

   private BooleanSetting getFillSetting() {
      return this.zalivkaBooleanSetting;
   }

   private NumberSetting getFillAlphaSetting() {
      return this.alfaZalivkiNumberSetting;
   }

   private BooleanSetting getOutlineSetting() {
      return this.obvodkaBooleanSetting;
   }

   private ColorSetting getColorSetting() {
      return this.tsvetColorSetting;
   }

   private NumberSetting getHitAlphaSetting() {
      return this.alfaPriUdareNumberSetting;
   }

   private NumberSetting getAnimationSpeedSetting() {
      return this.skorostAnimatsiiNumberSetting;
   }

   private NumberSetting getRotationSpeedSetting() {
      return this.skorostRotatsiiNumberSetting;
   }

   private MultiListSetting getTargetsSetting() {
      return this.tseliMultiListSetting;
   }

   private Map getTrackedEntries() {
      return this.field_b0de3d87;
   }

   private long getDelta() {
      return this.field_1e09b77c;
   }

   private void setDelta(long var1) {
      this.field_1e09b77c = var1;
   }

   private class_1297 getBox() {
      return this.field_8b353171;
   }

   private void setBox(class_1297 var1) {
      this.field_8b353171 = var1;
   }

   private boolean isActionPending() {
      return this.field_f860ab66;
   }

   private void setActionPending(boolean var1) {
      this.field_f860ab66 = var1;
   }

   private boolean isInputCaptured() {
      return this.field_658c255b;
   }

   private void setInputCaptured(boolean var1) {
      this.field_658c255b = var1;
   }

   private Random getRandom() {
      return this.field_d2b79f50;
   }

   private boolean isPressed() {
      return this.field_3fe31945;
   }

   private void setIsPressed(boolean var1) {
      this.field_3fe31945 = var1;
   }

   private double getDistance() {
      return this.field_ad0e933a;
   }

   private void setDistance(double var1) {
      this.field_ad0e933a = var1;
   }

   private double getTargetDistance() {
      return this.field_1a3a0d2f;
   }

   private void setTargetDistance(double var1) {
      this.field_1a3a0d2f = var1;
   }

   private double getCurrentValue() {
      return this.field_87658724;
   }

   private void setCurrentValue(double var1) {
      this.field_87658724 = var1;
   }

}
