package atheryx.module.combat;

import atheryx.manager.FriendManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.module.NewFunction;
import net.minecraft.class_1657;

@NewFunction(
   name = "NoFriendDamage",
   desc = "Запрещает AttackAura бить друзей",
   category = Category.COMBAT
)
public class NoFriendDamage extends Function {
   public static boolean isValidPlayer(class_1657 player) {
      NoFriendDamage function = (NoFriendDamage)FunctionManager.getFunction(NoFriendDamage.class);
      return function != null && function.isEnabled() && FriendManager.isFriend(player.method_7334().name());
   }

}
