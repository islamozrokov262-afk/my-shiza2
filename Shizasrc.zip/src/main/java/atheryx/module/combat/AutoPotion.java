package atheryx.module.combat;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.manager.RotationManager;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import atheryx.setting.Setting;
import atheryx.setting.impl.MultiListSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

@NewFunction(
   name = "AutoPotion",
   desc = "Кидает взрывные зелья под себя",
   category = Category.COMBAT
)
public class AutoPotion extends Function {
   private final MultiListSetting bafatMultiListSetting = new MultiListSetting("Бафать", new String[]{"Силу", "Скорость", "Огнестойкость"});
   private final List<Integer> field_da56f3ea = new ArrayList<Integer>();
   private final List<class_6880<class_1291>> field_47826ddf = new ArrayList<class_6880<class_1291>>();
   private boolean field_b4ade7d4;
   private long field_21d961c9;
   private long field_8f04dbbe;

   public AutoPotion() {
      this.setActionPending(false);
      this.setLastActionTime(0L);
      this.setLastActionTimePrimary(0L);
      this.addSettings(new Setting[]{this.getApplyBuffsSetting()});
   }

   public void onDisable() {
      this.getTrackedItems().clear();
      this.getCandidateItems().clear();
      this.setActionPending(false);
      RotationManager.reset();
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         if (this.mc.field_1755 != null) {
            String screenName = this.mc.field_1755.getClass().getSimpleName();
            if (screenName.contains("Downloading") || screenName.contains("Receiving") || screenName.contains("class_434")) {
               return;
            }
         }

         if (!this.mc.field_1724.method_6128() && (!this.mc.field_1724.method_6115() || this.mc.field_1724.method_6030().method_7909() == class_1802.field_8255)) {
            if (this.getTrackedItems().isEmpty() && !this.isActionPending()) {
               if (System.currentTimeMillis() - this.getLastActionTimePrimary() < 1000L) {
                  return;
               }

               for(PotionType type : AutoPotion.PotionType.values()) {
                  if (this.matchesType(type)) {
                     int slot = this.calculateAnimationFactor(type.getEffect());
                     if (slot != -1 && !this.getTrackedItems().contains(slot)) {
                        this.getTrackedItems().add(slot);
                        this.getCandidateItems().add(type.getEffect());
                     }
                  }
               }
            }

            if (!this.getTrackedItems().isEmpty()) {
               float targetYaw = RotationManager.getServerYaw(this.mc.field_1724.method_36454());
               if (RotationManager.getServerPitch(this.mc.field_1724.method_36455()) >= 85.0F) {
                  int slot = (Integer)this.getTrackedItems().remove(0);
                  int oldItem = this.mc.field_1724.method_31548().method_67532();
                  float oldPitch = this.mc.field_1724.method_36455();
                  float oldYaw = this.mc.field_1724.method_36454();
                  this.mc.field_1724.method_31548().method_61496(slot);
                  this.mc.field_1724.method_36457(90.0F);
                  this.mc.field_1724.method_36456(targetYaw);
                  this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
                  this.mc.field_1724.method_6104(class_1268.field_5808);
                  this.mc.field_1724.method_31548().method_61496(oldItem);
                  this.mc.field_1724.method_36457(oldPitch);
                  this.mc.field_1724.method_36456(oldYaw);
                  if (this.getTrackedItems().isEmpty()) {
                     this.setActionPending(true);
                     this.setLastActionTime(System.currentTimeMillis());
                  }
               }

               RotationManager.requestRotation(new RotationManager.Rotation(targetYaw, 90.0F), RotationManager.MoveCorrection.SILENT, 360.0F, 360.0F, 360.0F);
            } else {
               if (this.isActionPending()) {
                  float targetYaw = RotationManager.getServerYaw(this.mc.field_1724.method_36454());
                  RotationManager.requestRotation(new RotationManager.Rotation(targetYaw, 90.0F), RotationManager.MoveCorrection.SILENT, 360.0F, 360.0F, 360.0F);
                  boolean hasAllEffects = true;

                  for(class_6880<class_1291> effect : this.getCandidateItems()) {
                     if (!this.mc.field_1724.method_6059(effect)) {
                        hasAllEffects = false;
                        break;
                     }
                  }

                  if (hasAllEffects || System.currentTimeMillis() - this.getLastActionTime() > 1000L) {
                     this.setActionPending(false);
                     this.getCandidateItems().clear();
                     this.setLastActionTimePrimary(System.currentTimeMillis());
                     RotationManager.reset();
                  }
               }

            }
         }
      }
   }

   private boolean matchesType(PotionType type) {
      return this.getApplyBuffsSetting().isSelected(type.getName()) && !this.mc.field_1724.method_6059(type.getEffect());
   }

   private int calculateAnimationFactor(class_6880<class_1291> effect) {
      for(int i = 0; i < 9; ++i) {
         class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
         if (stack.method_7909() == class_1802.field_8436) {
            class_1844 contents = (class_1844)stack.method_58694(class_9334.field_49651);
            if (contents != null) {
               for(class_1293 inst : contents.method_57397()) {
                  if (inst.method_5579() == effect) {
                     return i;
                  }
               }
            }
         }
      }

      return -1;
   }

   private MultiListSetting getApplyBuffsSetting() {
      return this.bafatMultiListSetting;
   }

   private List<Integer> getTrackedItems() {
      return this.field_da56f3ea;
   }

   private List<class_6880<class_1291>> getCandidateItems() {
      return this.field_47826ddf;
   }

   private boolean isActionPending() {
      return this.field_b4ade7d4;
   }

   private void setActionPending(boolean var1) {
      this.field_b4ade7d4 = var1;
   }

   private long getLastActionTime() {
      return this.field_21d961c9;
   }

   private void setLastActionTime(long var1) {
      this.field_21d961c9 = var1;
   }

   private long getLastActionTimePrimary() {
      return this.field_8f04dbbe;
   }

   private void setLastActionTimePrimary(long var1) {
      this.field_8f04dbbe = var1;
   }


   private static enum PotionType {
      STRENGTH(class_1294.field_5910, "Силу"),
      SPEED(class_1294.field_5904, "Скорость"),
      FIRE_RESISTANCE(class_1294.field_5918, "Огнестойкость");

      private final class_6880<class_1291> bafatMultiListSetting;
      private final String field_da56f3ea;

      private PotionType(class_6880<class_1291> effect, String name) {
         this.bafatMultiListSetting = effect;
         this.field_da56f3ea = name;
      }

      public class_6880<class_1291> getEffect() {
         return this.getApplyBuffsSetting();
      }

      public String getName() {
         return this.getDisplayName();
      }

      private class_6880 getApplyBuffsSetting() {
         return this.bafatMultiListSetting;
      }

      private String getDisplayName() {
         return this.field_da56f3ea;
      }

   }
}
