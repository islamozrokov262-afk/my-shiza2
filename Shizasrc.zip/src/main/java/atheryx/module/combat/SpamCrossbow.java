package atheryx.module.combat;

import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import atheryx.module.Category;
import atheryx.module.Function;
import atheryx.module.NewFunction;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2886;

@NewFunction(
   name = "SpamCrossbow",
   desc = "Спамит стрелами из арбалета",
   category = Category.COMBAT
)
public class SpamCrossbow extends Function {
   @EventHandler
   public void onUpdate(UpdateEvent event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         boolean inMainHand = this.mc.field_1724.method_6047().method_7909() == class_1802.field_8399;
         boolean inOffHand = this.mc.field_1724.method_6079().method_7909() == class_1802.field_8399;
         if (inMainHand || inOffHand) {
            class_1268 hand = inMainHand ? class_1268.field_5808 : class_1268.field_5810;
            this.mc.field_1724.field_3944.method_52787(new class_2886(hand, 0, this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455()));
         }

      }
   }

}
