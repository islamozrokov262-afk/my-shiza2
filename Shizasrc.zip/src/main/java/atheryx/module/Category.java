package atheryx.module;

import lombok.Generated;

public enum Category {
   COMBAT("Combat", ""),
   MOVEMENT("Movement", "C"),
   RENDER("Render", "X"),
   PLAYER("Player", ""),
   MISC("Misc", "M"),
   MENU("Menu", "V"),
   CONFIG("Config", "G");

   private final String field_6d2b79f5;
   private final String field_da56f3ea;

   private Category(String name, String icon) {
      this.field_6d2b79f5 = name;
      this.field_da56f3ea = icon;
   }

   @Generated
   public String getName() {
      return this.getDisplayName();
   }

   @Generated
   public String getIcon() {
      return this.getDescription();
   }

   private String getDisplayName() {
      return this.field_6d2b79f5;
   }

   private String getDescription() {
      return this.field_da56f3ea;
   }

}
