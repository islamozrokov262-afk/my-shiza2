package atheryx.module;

import atheryx.event.EventBus;
import atheryx.module.misc.Sounds;
import atheryx.setting.Setting;
import atheryx.util.NullCheck;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.Generated;
import net.minecraft.class_310;

public abstract class Function {
   protected final class_310 mc = class_310.method_1551();
   protected final NullCheck nullCheck = new NullCheck();
   private final String name;
   private final String description;
   private final Category category;
   private int keybind;
   private boolean enabled;
   private final List<Setting> settings = new ArrayList<Setting>();

   public Function() {
      if (this.getClass().isAnnotationPresent(NewFunction.class)) {
         NewFunction annotation = (NewFunction)this.getClass().getAnnotation(NewFunction.class);
         this.name = annotation.name();
         this.description = annotation.desc();
         this.category = annotation.category();
         this.writeEnabled(false);
      } else {
         throw new RuntimeException("Error " + String.valueOf(this.getClass().getSimpleName()));
      }
   }

   public void addSettings(Setting... setting) {
      this.readSettings().addAll(Arrays.asList(setting));
   }

   public void toggle() {
      boolean wasEnabled = this.readEnabled();
      this.writeEnabled(!this.readEnabled());
      this.playModuleToggleSound(wasEnabled);
      if (this.readEnabled()) {
         this.onEnable();
         EventBus.register(this);
      } else {
         this.onDisable();
         EventBus.unregister(this);
      }

   }

   private void playModuleToggleSound(boolean wasEnabled) {
      Sounds sounds = (Sounds)FunctionManager.getFunction(Sounds.class);
      boolean soundsModuleToggle = this instanceof Sounds && (wasEnabled || this.readEnabled());
      if (sounds != null && sounds.isEnabled() || soundsModuleToggle) {
         Sounds.playModuleToggleSound(this.readEnabled());
      }

   }

   public void onEnable() {
   }

   public void onDisable() {
   }

   @Generated
   public String getName() {
      return this.readName();
   }

   @Generated
   public String getDescription() {
      return this.readDescription();
   }

   @Generated
   public Category getCategory() {
      return this.readCategory();
   }

   @Generated
   public int getKeybind() {
      return this.readKeybind();
   }

   @Generated
   public void setKeybind(int keybind) {
      this.writeKeybind(keybind);
   }

   @Generated
   public boolean isEnabled() {
      return this.readEnabled();
   }

   @Generated
   public void setEnabled(boolean enabled) {
      this.writeEnabled(enabled);
   }

   @Generated
   public List<Setting> getSettings() {
      return this.readSettings();
   }

   private class_310 getMinecraftClient() {
      return this.mc;
   }

   private NullCheck getNullCheck() {
      return this.nullCheck;
   }

   private String readName() {
      return this.name;
   }

   private String readDescription() {
      return this.description;
   }

   private Category readCategory() {
      return this.category;
   }

   private int readKeybind() {
      return this.keybind;
   }

   private void writeKeybind(int var1) {
      this.keybind = var1;
   }

   private boolean readEnabled() {
      return this.enabled;
   }

   private void writeEnabled(boolean var1) {
      this.enabled = var1;
   }

   private List readSettings() {
      return this.settings;
   }

}
