package atheryx.util;

import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_310;

public final class PlayerInteractionHelper {
   private static final class_310 obf_u0435_u220e = class_310.method_1551();

   private PlayerInteractionHelper() {
   }

   public static boolean isPlayerInsideBlock(class_2248 block) {
      return obf_u0435_u220e.field_1724 != null && obf_u0435_u220e.field_1687 != null ? containsBlock(obf_u0435_u220e.field_1724.method_5829().method_1011(0.001), block) : false;
   }

   public static boolean containsBlock(class_238 box, class_2248 block) {
      return anyBlockMatches(box, (pos) -> {
         return obf_u0435_u220e.field_1687.method_8320(pos).method_27852(block);
      });
   }

   public static boolean anyBlockMatches(class_238 box, Predicate<class_2338> predicate) {
      return streamBlockPositions(box).anyMatch(predicate);
   }

   private static Stream<class_2338> streamBlockPositions(class_238 box) {
      int minX = (int)Math.floor(box.field_1323);
      int minY = (int)Math.floor(box.field_1322);
      int minZ = (int)Math.floor(box.field_1321);
      int maxX = (int)Math.floor(box.field_1320);
      int maxY = (int)Math.floor(box.field_1325);
      int maxZ = (int)Math.floor(box.field_1324);
      Iterable var7 = () -> {
         return class_2338.method_10094(minX, minY, minZ, maxX, maxY, maxZ).iterator();
      };
      return StreamSupport.<class_2338>stream(var7.spliterator(), false);
   }

}
