package atheryx.util;

import net.minecraft.class_310;

public interface IMinecraft {
   class_310 mc = class_310.method_1551();
}
