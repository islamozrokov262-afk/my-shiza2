package atheryx.util.math;

public class Easings {
   public static float easeOutBack(float x) {
      float c1 = 1.70158F;
      float c3 = c1 + 1.0F;
      return (float)((double)1.0F + (double)c3 * Math.pow((double)x - (double)1.0F, 3.0D) + (double)c1 * Math.pow((double)x - (double)1.0F, 2.0D));
   }

   public static float easeOutCubic(float x) {
      return (float)((double)1.0F - Math.pow((double)1.0F - (double)x, 3.0D));
   }

}
