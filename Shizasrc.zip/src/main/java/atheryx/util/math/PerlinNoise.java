package atheryx.util.math;

import java.util.Random;

public class PerlinNoise {
   private final int[] field_6d2b79f5;

   public PerlinNoise() {
      this(System.currentTimeMillis());
   }

   public PerlinNoise(long seed) {
      this.field_6d2b79f5 = new int[512];
      Random random = new Random(seed);
      int[] permutation = new int[256];

      for(int i = 0; i < 256; permutation[i] = i++) {
      }

      for(int i = 0; i < 256; ++i) {
         int j = random.nextInt(256 - i) + i;
         int temp = permutation[i];
         permutation[i] = permutation[j];
         permutation[j] = temp;
      }

      for(int i = 0; i < 256; ++i) {
         this.getPermutationInternal()[i] = this.getPermutationInternal()[i + 256] = permutation[i];
      }

   }

   public double noiseOneDimensional(double x) {
      return this.noiseThreeDimensional(x, (double)0.0F, (double)0.0F);
   }

   public double noiseTwoDimensional(double x, double y) {
      return this.noiseThreeDimensional(x, y, (double)0.0F);
   }

   public double noiseThreeDimensional(double x, double y, double z) {
      int xIndex = (int)Math.floor(x) & 255;
      int yIndex = (int)Math.floor(y) & 255;
      int zIndex = (int)Math.floor(z) & 255;
      x -= Math.floor(x);
      y -= Math.floor(y);
      z -= Math.floor(z);
      double u = fade(x);
      double v = fade(y);
      double w = fade(z);
      int a = this.getPermutationInternal()[xIndex] + yIndex;
      int aa = this.getPermutationInternal()[a] + zIndex;
      int ab = this.getPermutationInternal()[a + 1] + zIndex;
      int b = this.getPermutationInternal()[xIndex + 1] + yIndex;
      int ba = this.getPermutationInternal()[b] + zIndex;
      int bb = this.getPermutationInternal()[b + 1] + zIndex;
      return lerp(w, lerp(v, lerp(u, gradient(this.getPermutationInternal()[aa], x, y, z), gradient(this.getPermutationInternal()[ba], x - (double)1.0F, y, z)), lerp(u, gradient(this.getPermutationInternal()[ab], x, y - (double)1.0F, z), gradient(this.getPermutationInternal()[bb], x - (double)1.0F, y - (double)1.0F, z))), lerp(v, lerp(u, gradient(this.getPermutationInternal()[aa + 1], x, y, z - (double)1.0F), gradient(this.getPermutationInternal()[ba + 1], x - (double)1.0F, y, z - (double)1.0F)), lerp(u, gradient(this.getPermutationInternal()[ab + 1], x, y - (double)1.0F, z - (double)1.0F), gradient(this.getPermutationInternal()[bb + 1], x - (double)1.0F, y - (double)1.0F, z - (double)1.0F))));
   }

   private static double fade(double t) {
      return t * t * t * (t * (t * 6.0D - 15.0D) + 10.0D);
   }

   private static double lerp(double t, double a, double b) {
      return a + t * (b - a);
   }

   private static double gradient(int hash, double x, double y, double z) {
      int h = hash & 15;
      double u = h < 8 ? x : y;
      double v = h < 4 ? y : (h != 12 && h != 14 ? z : x);
      return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v);
   }

   private int[] getPermutationInternal() {
      return this.field_6d2b79f5;
   }

}
