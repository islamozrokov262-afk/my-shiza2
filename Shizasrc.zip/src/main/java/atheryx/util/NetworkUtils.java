package atheryx.util;

import net.minecraft.class_2596;
import net.minecraft.class_310;

public class NetworkUtils {
   public static boolean silentSending;

   public static void sendPacketSilently(class_2596<?> packet) {
      if (class_310.method_1551().method_1562() != null) {
         silentSending = true;
         class_310.method_1551().method_1562().method_52787(packet);
         silentSending = false;
      }

   }

}
