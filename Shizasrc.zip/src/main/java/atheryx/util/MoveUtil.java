package atheryx.util;

import atheryx.manager.RotationManager;
import atheryx.module.FunctionManager;
import atheryx.module.combat.TargetStrafe;
import net.minecraft.class_241;
import net.minecraft.class_310;

public class MoveUtil {
   public static boolean isMoving() {
      class_310 mc = class_310.method_1551();
      return mc.field_1724 != null && mc.field_1724.field_3913.method_3128().method_35587() > 1.0E-7F;
   }

   public static double[] getMotionForSpeed(double speed) {
      class_310 mc = class_310.method_1551();
      if (mc.field_1724 == null) {
         return new double[]{(double)0.0F, (double)0.0F};
      } else {
         class_241 input = mc.field_1724.field_3913.method_3128();
         float strafe = input.field_1343;
         float forward = input.field_1342;
         float yaw = mc.field_1724.method_36454();
         TargetStrafe targetStrafe = (TargetStrafe)FunctionManager.getFunction(TargetStrafe.class);
         if (targetStrafe != null && targetStrafe.isEnabled() && targetStrafe.findTarget() != null) {
            yaw = RotationManager.rotationTo(targetStrafe.findTarget().method_5829().method_1005()).yaw();
            forward = 1.0F;
            strafe = (float)((double)targetStrafe.calculateAnimationFactor() * targetStrafe.calculateAnimationFactorForTarget());
         }

         if (forward != 0.0F) {
            if (strafe > 0.0F) {
               yaw += forward > 0.0F ? -45.0F : 45.0F;
            } else if (strafe < 0.0F) {
               yaw += forward > 0.0F ? 45.0F : -45.0F;
            }

            strafe = 0.0F;
            forward = forward > 0.0F ? 1.0F : -1.0F;
         }

         double sin = Math.sin(Math.toRadians((double)(yaw + 90.0F)));
         double cos = Math.cos(Math.toRadians((double)(yaw + 90.0F)));
         double motionX = (double)forward * speed * cos + (double)strafe * speed * sin;
         double motionZ = (double)forward * speed * sin - (double)strafe * speed * cos;
         return new double[]{motionX, motionZ};
      }
   }

   public static void setHorizontalSpeed(double speed) {
      class_310 mc = class_310.method_1551();
      if (mc.field_1724 != null && isMoving()) {
         double[] dir = getMotionForSpeed(speed);
         mc.field_1724.method_18800(dir[0], mc.field_1724.method_18798().field_1351, dir[1]);
      }
   }

   public static void setSpeedAndVerticalVelocity(double speed, double y) {
      class_310 mc = class_310.method_1551();
      if (mc.field_1724 != null && isMoving()) {
         double[] dir = getMotionForSpeed(speed);
         mc.field_1724.method_18800(dir[0], y, dir[1]);
      }
   }

   public static void setVerticalVelocity(double y) {
      class_310 mc = class_310.method_1551();
      if (mc.field_1724 != null) {
         mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, y, mc.field_1724.method_18798().field_1350);
      }
   }

}
