package atheryx.util;

import atheryx.module.FunctionManager;
import atheryx.module.movement.Sprint;
import net.minecraft.class_10185;
import net.minecraft.class_2815;
import net.minecraft.class_2848;
import net.minecraft.class_2851;
import net.minecraft.class_310;
import net.minecraft.class_2848.class_2849;

public class InventoryUtil {
   public static final InventoryUtil instance = new InventoryUtil();
   private static final class_310 obf_u2225_u220e = class_310.method_1551();

   public static InventoryUtil getInstance() {
      return instance;
   }

   public static void runWithoutMovementInput(Runnable runnable) {
      if (obf_u2225_u220e.field_1724 != null && obf_u2225_u220e.method_1562() != null) {
         try {
            obf_u2225_u220e.method_1562().method_52787(new class_2851(new class_10185(false, false, false, false, false, false, false)));
            if (obf_u2225_u220e.field_1724.method_5624()) {
               obf_u2225_u220e.field_1724.method_5728(false);
               obf_u2225_u220e.method_1562().method_52787(new class_2848(obf_u2225_u220e.field_1724, class_2849.field_12985));
               Sprint sprint = (Sprint)FunctionManager.getFunction(Sprint.class);
               if (sprint == null || !sprint.isEnabled()) {
                  obf_u2225_u220e.field_1690.field_1867.method_23481(false);
               }
            }

            runnable.run();
            NetworkUtils.sendPacketSilently(new class_2815(0));
            obf_u2225_u220e.method_1562().method_52787(new class_2851(obf_u2225_u220e.field_1724.field_3913.field_54155));
         } catch (Exception e) {
            e.printStackTrace();
         }

      }
   }

}
