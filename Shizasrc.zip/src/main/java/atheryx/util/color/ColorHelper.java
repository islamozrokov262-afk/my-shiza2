package atheryx.util.color;

import java.awt.Color;

public class ColorHelper {
   public static int[] toArgbArray(Color... colors) {
      int[] RGB = new int[colors.length];

      for(int i = 0; i < colors.length; ++i) {
         RGB[i] = colors[i].getRGB();
      }

      return RGB;
   }

   public static int toArgb(Color color) {
      return color.getRGB();
   }

   public static int lerpArgb(int c1, int c2, float t) {
      int a1 = c1 >> 24 & 255;
      int r1 = c1 >> 16 & 255;
      int g1 = c1 >> 8 & 255;
      int b1 = c1 & 255;
      int a2 = c2 >> 24 & 255;
      int r2 = c2 >> 16 & 255;
      int g2 = c2 >> 8 & 255;
      int b2 = c2 & 255;
      return (int)((float)a1 + (float)(a2 - a1) * t) << 24 | (int)((float)r1 + (float)(r2 - r1) * t) << 16 | (int)((float)g1 + (float)(g2 - g1) * t) << 8 | (int)((float)b1 + (float)(b2 - b1) * t);
   }

}
