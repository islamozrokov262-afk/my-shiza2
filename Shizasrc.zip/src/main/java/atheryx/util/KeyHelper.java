package atheryx.util;

import atheryx.setting.impl.KeybindSetting;
import org.lwjgl.glfw.GLFW;

public class KeyHelper {
   public static String getKeyName(int key) {
      if (key <= 0) {
         return "None";
      } else if (KeybindSetting.isMouseBinding(key)) {
         String var3;
         switch (KeybindSetting.keyToMouseButton(key)) {
            case 2 -> var3 = "M.Mouse";
            case 3 -> var3 = "Mouse 4";
            case 4 -> var3 = "Mouse 5";
            default -> var3 = "Mouse " + String.valueOf(KeybindSetting.keyToMouseButton(key));
         }

         return var3;
      } else if (key >= 65 && key <= 90) {
         return String.valueOf((char)key);
      } else if (key >= 48 && key <= 57) {
         return String.valueOf((char)key);
      } else {
         String var2;
         switch (key) {
            case 32:
               var2 = "Space";
               break;
            case 39:
               var2 = "'";
               break;
            case 44:
               var2 = ",";
               break;
            case 45:
               var2 = "-";
               break;
            case 46:
               var2 = ".";
               break;
            case 47:
               var2 = "/";
               break;
            case 59:
               var2 = ";";
               break;
            case 61:
               var2 = "=";
               break;
            case 91:
               var2 = "[";
               break;
            case 92:
               var2 = "\\";
               break;
            case 93:
               var2 = "]";
               break;
            case 96:
               var2 = "`";
               break;
            case 256:
               var2 = "Esc";
               break;
            case 257:
               var2 = "Enter";
               break;
            case 258:
               var2 = "Tab";
               break;
            case 259:
               var2 = "Backspace";
               break;
            case 262:
               var2 = "Right";
               break;
            case 263:
               var2 = "Left";
               break;
            case 264:
               var2 = "Down";
               break;
            case 265:
               var2 = "Up";
               break;
            case 280:
               var2 = "Caps";
               break;
            case 290:
               var2 = "F1";
               break;
            case 291:
               var2 = "F2";
               break;
            case 292:
               var2 = "F3";
               break;
            case 293:
               var2 = "F4";
               break;
            case 294:
               var2 = "F5";
               break;
            case 295:
               var2 = "F6";
               break;
            case 296:
               var2 = "F7";
               break;
            case 297:
               var2 = "F8";
               break;
            case 298:
               var2 = "F9";
               break;
            case 299:
               var2 = "F10";
               break;
            case 300:
               var2 = "F11";
               break;
            case 301:
               var2 = "F12";
               break;
            case 340:
               var2 = "L.Shift";
               break;
            case 341:
               var2 = "L.Ctrl";
               break;
            case 342:
               var2 = "L.Alt";
               break;
            case 344:
               var2 = "R.Shift";
               break;
            case 345:
               var2 = "R.Ctrl";
               break;
            case 346:
               var2 = "R.Alt";
               break;
            default:
               String name = GLFW.glfwGetKeyName(key, 0);
               var2 = name == null ? "Key " + String.valueOf(key) : name.toUpperCase();
         }

         return var2;
      }
   }

}
