package atheryx.util;

import net.minecraft.class_310;

public class NullCheck {
   class_310 mc;

   public NullCheck() {
      this.setClientInternal(class_310.method_1551());
   }

   public boolean isPlayerMissing() {
      return this.getClientInternal().field_1724 == null;
   }

   public boolean isPlayerOrWorldMissing() {
      return this.getClientInternal().field_1724 == null || this.getClientInternal().field_1687 == null;
   }

   public boolean isWorldMissing() {
      return this.getClientInternal().field_1687 == null;
   }

   private class_310 getClientInternal() {
      return this.mc;
   }

   private void setClientInternal(class_310 var1) {
      this.mc = var1;
   }

}
