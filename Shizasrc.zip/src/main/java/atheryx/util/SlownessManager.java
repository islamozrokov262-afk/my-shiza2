package atheryx.util;

import atheryx.event.EventBus;
import atheryx.event.EventHandler;
import atheryx.event.impl.UpdateEvent;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class SlownessManager {
   private static final List<DelayedTask> obf_u03c3_u220e = new CopyOnWriteArrayList<DelayedTask>();

   public static void schedule(DelayedTask task) {
      obf_u03c3_u220e.add(task);
   }

   public static boolean isEmpty() {
      return obf_u03c3_u220e.isEmpty();
   }

   @EventHandler
   public void onUpdate(UpdateEvent event) {
      for(DelayedTask task : obf_u03c3_u220e) {
         --task.delay;
         if (task.delay <= 0L) {
            if (task.runnable != null) {
               task.runnable.run();
            }

            obf_u03c3_u220e.remove(task);
         }
      }

   }

   static {
      EventBus.register(new SlownessManager());
   }


   public static class DelayedTask {
      public long delay;
      public Runnable runnable;
      public double slowness;

      public DelayedTask(long delay, Runnable runnable) {
         this.setDelayInternal(delay);
         this.setRunnableInternal(runnable);
         this.setSlownessInternal((double)0.0F);
      }

      public DelayedTask(long delay, double slowness, Runnable runnable) {
         this.setDelayInternal(delay);
         this.setSlownessInternal(slowness);
         this.setRunnableInternal(runnable);
      }

      private long getDelayInternal() {
         return this.delay;
      }

      private void setDelayInternal(long var1) {
         this.delay = var1;
      }

      private Runnable getRunnableInternal() {
         return this.runnable;
      }

      private void setRunnableInternal(Runnable var1) {
         this.runnable = var1;
      }

      private double getSlownessInternal() {
         return this.slowness;
      }

      private void setSlownessInternal(double var1) {
         this.slowness = var1;
      }

   }
}
