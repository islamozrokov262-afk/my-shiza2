package atheryx.manager;

import atheryx.gui.ThemeManager;
import atheryx.module.Function;
import atheryx.module.FunctionManager;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import atheryx.setting.impl.ColorSetting;
import atheryx.setting.impl.KeybindSetting;
import atheryx.setting.impl.ModeSetting;
import atheryx.setting.impl.MultiSetting;
import atheryx.setting.impl.NumberSetting;
import atheryx.setting.impl.TextSetting;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_156;

public final class ConfigManager {
   private static final String DEFAULT_CONFIG_FILE = "config.properties";
   private static final Properties defaultProperties = new Properties();
   private static Path configDirectory;
   private static Path defaultConfigPath;

   private ConfigManager() {
   }

   public static void init() {
      ensurePathsInitialized();
      captureDefaultProperties();
      load(null);
   }

   public static boolean save() {
      return save(null);
   }

   public static boolean save(String name) {
      ensurePathsInitialized();
      Properties properties = new Properties();
      writeCurrentState(properties);

      try {
         Files.createDirectories(configDirectory);
         try (BufferedWriter writer = Files.newBufferedWriter(resolveConfigPath(name))) {
            properties.store(writer, "Minar config");
         }
         return true;
      } catch (IOException ignored) {
         return false;
      }
   }

   public static boolean load() {
      return load(null);
   }

   public static boolean load(String name) {
      ensurePathsInitialized();
      Path path = resolveConfigPath(name);
      if (!Files.exists(path)) {
         if (name == null) {
            save();
         }
         return false;
      }

      Properties properties = new Properties();
      try (BufferedReader reader = Files.newBufferedReader(path)) {
         properties.load(reader);
         applyProperties(properties);
         return true;
      } catch (IOException ignored) {
         return false;
      }
   }

   public static void reset() {
      ensurePathsInitialized();
      applyProperties(defaultProperties);
      save();
   }

   public static boolean openConfigDirectory() {
      ensurePathsInitialized();
      try {
         Files.createDirectories(configDirectory);
         class_156.method_668().method_60932(configDirectory);
         return true;
      } catch (Exception ignored) {
         return false;
      }
   }

   public static boolean isValidConfigName(String name) {
      return name != null && name.matches("[A-Za-z0-9_-]{1,32}");
   }

   public static List<String> getConfigNames() {
      ensurePathsInitialized();
      try {
         Files.createDirectories(configDirectory);
         try (Stream<Path> paths = Files.list(configDirectory)) {
            return paths
               .filter(Files::isRegularFile)
               .map(path -> path.getFileName().toString())
               .filter(fileName -> fileName.endsWith(".properties"))
               .filter(fileName -> !DEFAULT_CONFIG_FILE.equalsIgnoreCase(fileName))
               .map(fileName -> fileName.substring(0, fileName.length() - ".properties".length()))
               .filter(ConfigManager::isValidConfigName)
               .sorted(String.CASE_INSENSITIVE_ORDER)
               .toList();
         }
      } catch (IOException ignored) {
         return List.of();
      }
   }

   private static void captureDefaultProperties() {
      defaultProperties.clear();
      writeCurrentState(defaultProperties);
      defaultProperties.setProperty("theme.selected", colorToHex(ThemeManager.PASTEL_PURPLE));
      defaultProperties.setProperty("theme.selected2", colorToHex(ThemeManager.PASTEL_BLUE));
      defaultProperties.setProperty("theme.twoColors", "false");
      defaultProperties.setProperty("theme.custom.count", "0");
      defaultProperties.setProperty("friends.count", "0");
   }

   private static void writeCurrentState(Properties properties) {
      for (Function function : FunctionManager.getFunctions()) {
         String functionKey = functionKey(function);
         properties.setProperty(functionKey + ".enabled", String.valueOf(function.isEnabled()));
         properties.setProperty(functionKey + ".keybind", String.valueOf(function.getKeybind()));

         for (Setting setting : function.getSettings()) {
            writeSetting(properties, functionKey + ".setting." + settingKey(setting), setting);
         }
      }

      properties.setProperty("theme.selected", colorToHex(ThemeManager.Theme_Color));
      properties.setProperty("theme.selected2", colorToHex(ThemeManager.Theme_Color2));
      properties.setProperty("theme.twoColors", String.valueOf(ThemeManager.twoColors));
      properties.setProperty("theme.custom.count", String.valueOf(ThemeManager.CUSTOM_THEMES.size()));
      for (int index = 0; index < ThemeManager.CUSTOM_THEMES.size(); index++) {
         properties.setProperty("theme.custom." + index, colorToHex(ThemeManager.CUSTOM_THEMES.get(index)));
      }

      List<String> friends = new ArrayList<>(FriendManager.getFriends().values());
      properties.setProperty("friends.count", String.valueOf(friends.size()));
      for (int index = 0; index < friends.size(); index++) {
         properties.setProperty("friends." + index, friends.get(index));
      }
   }

   private static void applyProperties(Properties properties) {
      for (Function function : FunctionManager.getFunctions()) {
         String functionKey = functionKey(function);
         function.setEnabled(Boolean.parseBoolean(properties.getProperty(
            functionKey + ".enabled", String.valueOf(function.isEnabled())
         )));
         function.setKeybind(parseInt(properties.getProperty(functionKey + ".keybind"), function.getKeybind()));

         for (Setting setting : function.getSettings()) {
            readSetting(properties, functionKey + ".setting." + settingKey(setting), setting);
         }
      }

      ThemeManager.Theme_Color = parseColor(properties.getProperty("theme.selected"), ThemeManager.Theme_Color);
      ThemeManager.Theme_Color2 = parseColor(properties.getProperty("theme.selected2"), ThemeManager.Theme_Color2);
      ThemeManager.twoColors = Boolean.parseBoolean(properties.getProperty("theme.twoColors", "false"));
      ThemeManager.CUSTOM_THEMES.clear();
      int themeCount = parseInt(properties.getProperty("theme.custom.count"), 0);
      for (int index = 0; index < themeCount; index++) {
         ThemeManager.CUSTOM_THEMES.add(parseColor(properties.getProperty("theme.custom." + index), ThemeManager.PASTEL_PURPLE));
      }

      int friendCount = parseInt(properties.getProperty("friends.count"), 0);
      Map<String, String> friends = new java.util.LinkedHashMap<>();
      for (int index = 0; index < friendCount; index++) {
         String friend = properties.getProperty("friends." + index);
         if (friend != null && friend.matches("[A-Za-z0-9_]{1,16}")) {
            friends.put(friend.toLowerCase(java.util.Locale.ROOT), friend);
         }
      }
      FriendManager.setFriends(friends);
   }

   private static void writeSetting(Properties properties, String key, Setting setting) {
      if (setting instanceof BooleanSetting booleanSetting) {
         properties.setProperty(key, String.valueOf(booleanSetting.isEnabled()));
      } else if (setting instanceof NumberSetting numberSetting) {
         properties.setProperty(key, String.valueOf(numberSetting.getValue()));
      } else if (setting instanceof ModeSetting modeSetting) {
         properties.setProperty(key, modeSetting.getValue());
      } else if (setting instanceof MultiSetting multiSetting) {
         properties.setProperty(key, String.join(",", multiSetting.getSelectedOptions()));
      } else if (setting instanceof KeybindSetting keybindSetting) {
         properties.setProperty(key, String.valueOf(keybindSetting.getKeybind()));
      } else if (setting instanceof ColorSetting colorSetting) {
         properties.setProperty(key, colorToHex(colorSetting.getColor()));
      } else if (setting instanceof TextSetting textSetting) {
         properties.setProperty(key, textSetting.getText());
      }
   }

   private static void readSetting(Properties properties, String key, Setting setting) {
      String value = properties.getProperty(key);
      if (value == null) {
         return;
      }

      if (setting instanceof BooleanSetting booleanSetting) {
         booleanSetting.setEnabled(Boolean.parseBoolean(value));
      } else if (setting instanceof NumberSetting numberSetting) {
         numberSetting.setValue(parseDouble(value, numberSetting.getValue()));
      } else if (setting instanceof ModeSetting modeSetting) {
         modeSetting.setValue(value);
      } else if (setting instanceof MultiSetting multiSetting) {
         Set<String> selected = value.isEmpty() ? Set.of() : new HashSet<>(List.of(value.split(",")));
         multiSetting.setSelectedOptions(selected);
      } else if (setting instanceof KeybindSetting keybindSetting) {
         keybindSetting.setKeybind(parseInt(value, keybindSetting.getKeybind()));
      } else if (setting instanceof ColorSetting colorSetting) {
         colorSetting.setColor(parseColor(value, colorSetting.getColor()));
      } else if (setting instanceof TextSetting textSetting) {
         textSetting.setText(value);
      }
   }

   private static void ensurePathsInitialized() {
      if (configDirectory == null || defaultConfigPath == null) {
         configDirectory = FabricLoader.getInstance().getGameDir().resolve("Minar");
         defaultConfigPath = configDirectory.resolve(DEFAULT_CONFIG_FILE);
      }
   }

   private static Path resolveConfigPath(String name) {
      return name == null ? defaultConfigPath : configDirectory.resolve(name + ".properties");
   }

   private static String functionKey(Function function) {
      return "function." + sanitizeKey(function.getName());
   }

   private static String settingKey(Setting setting) {
      return sanitizeKey(setting.getName());
   }

   private static String sanitizeKey(String value) {
      return value.replace('.', '_').replace(' ', '_');
   }

   private static String colorToHex(Color color) {
      return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
   }

   private static Color parseColor(String value, Color fallback) {
      if (value == null || value.length() != 7 || value.charAt(0) != '#') {
         return fallback;
      }
      try {
         return new Color(Integer.parseInt(value.substring(1), 16));
      } catch (NumberFormatException ignored) {
         return fallback;
      }
   }

   private static int parseInt(String value, int fallback) {
      try {
         return Integer.parseInt(value);
      } catch (NumberFormatException ignored) {
         return fallback;
      }
   }

   private static double parseDouble(String value, double fallback) {
      try {
         return Double.parseDouble(value);
      } catch (NumberFormatException ignored) {
         return fallback;
      }
   }
}
