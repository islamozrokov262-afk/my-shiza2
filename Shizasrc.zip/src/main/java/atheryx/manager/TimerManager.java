package atheryx.manager;

public class TimerManager {
   private static float obf_u03b6_u0432 = 1.0F;

   public static void setTimerSpeed(float timer) {
      obf_u03b6_u0432 = Math.max(0.05F, timer);
   }

   public static float getTimerSpeed() {
      return obf_u03b6_u0432;
   }

   public static void reset() {
      obf_u03b6_u0432 = 1.0F;
   }

}
