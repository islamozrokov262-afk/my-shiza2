package atheryx.manager;

import net.minecraft.class_1309;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class RotationManager {
   private static final class_310 obf_u03c2_u0432 = class_310.method_1551();
   private static final long obf_u00c6_u0432 = 120L;
   private static final float obf_u0439_u0432 = 30.0F;
   private static Rotation obf_u03a8_u0432;
   private static Rotation obf_u2212_u0432;
   private static Rotation obf_u0425_u0432;
   private static Rotation obf_u0437_u0432;
   private static float obf_u00d1_u0432;
   private static float obf_u0394_u0432;
   private static float obf_u044c_u0432;
   private static MoveCorrection obf_u2213_u0432;
   private static long obf_u041c_u0432;
   private static RotationState obf_u0409_u0432;
   private static boolean obf_u044a_u0432;

   public static void update() {
      obf_u2212_u0432 = obf_u03a8_u0432;
      if (obf_u03c2_u0432.field_1724 == null) {
         reset();
      } else if (obf_u0437_u0432 == null) {
         obf_u03a8_u0432 = getPlayerRotation();
         obf_u0409_u0432 = RotationManager.RotationState.IDLE;
      } else if (System.currentTimeMillis() - obf_u041c_u0432 > 120L) {
         Rotation playerRotation = getPlayerRotation();
         if (obf_u03a8_u0432.differenceValue(playerRotation) < 1.0F) {
            obf_u0437_u0432 = null;
            obf_u03a8_u0432 = playerRotation;
            obf_u0409_u0432 = RotationManager.RotationState.IDLE;
         } else {
            obf_u0409_u0432 = RotationManager.RotationState.ROTATING_BACK;
            float yawDiff = angleDifference(obf_u03a8_u0432.yaw(), playerRotation.yaw());
            float pitchDiff = angleDifference(obf_u03a8_u0432.pitch(), playerRotation.pitch());
            float yawStep = Math.max(4.0F, Math.abs(yawDiff) * 0.55F);
            float pitchStep = Math.max(4.0F, Math.abs(pitchDiff) * 0.55F);
            yawStep = Math.min(yawStep, obf_u044c_u0432);
            pitchStep = Math.min(pitchStep, obf_u044c_u0432);
            Rotation backStep = new Rotation(stepAngleToward(obf_u03a8_u0432.yaw(), playerRotation.yaw(), yawStep), stepAngleToward(obf_u03a8_u0432.pitch(), playerRotation.pitch(), pitchStep));
            obf_u03a8_u0432 = obf_u044a_u0432 ? backStep : applySensitivityGcd(backStep);
         }
      } else {
         obf_u0409_u0432 = RotationManager.RotationState.ROTATING;
         Rotation fwdStep = new Rotation(stepAngleToward(obf_u03a8_u0432.yaw(), obf_u0437_u0432.yaw(), obf_u00d1_u0432), stepAngleToward(obf_u03a8_u0432.pitch(), obf_u0437_u0432.pitch(), obf_u0394_u0432));
         obf_u03a8_u0432 = obf_u044a_u0432 ? fwdStep : applySensitivityGcd(fwdStep);
      }
   }

   public static void updateRenderRotation(float tickDelta) {
      float yaw = lerpAngle(obf_u2212_u0432.yaw(), obf_u03a8_u0432.yaw(), tickDelta);
      float pitch = class_3532.method_16439(tickDelta, obf_u2212_u0432.pitch(), obf_u03a8_u0432.pitch());
      obf_u0425_u0432 = new Rotation(yaw, pitch <= -85.0F ? 0.0F : pitch);
   }

   public static void requestRotation(Rotation rotation, MoveCorrection moveCorrection, float yawSpeed, float pitchSpeed, float returnSpeed) {
      requestRotation(rotation, moveCorrection, yawSpeed, pitchSpeed, returnSpeed, false);
   }

   public static void requestRotation(Rotation rotation, MoveCorrection moveCorrection, float yawSpeed, float pitchSpeed, float returnSpeed, boolean skipGcd) {
      requestRotation(rotation, moveCorrection, yawSpeed, pitchSpeed, returnSpeed, skipGcd, 30.0F);
   }

   public static void requestRotation(Rotation rotation, MoveCorrection moveCorrection, float yawSpeed, float pitchSpeed, float returnSpeed, boolean skipGcd, float maxStep) {
      if (obf_u03c2_u0432.field_1724 != null) {
         float adjustedYaw = unwrapAngleToward(obf_u0437_u0432 == null ? getPlayerRotation().yaw() : obf_u0437_u0432.yaw(), rotation.yaw());
         obf_u0437_u0432 = new Rotation(adjustedYaw, class_3532.method_15363(rotation.pitch(), -90.0F, 90.0F));
         obf_u00d1_u0432 = clampRotationSpeed(yawSpeed, maxStep);
         obf_u0394_u0432 = clampRotationSpeed(pitchSpeed, maxStep);
         obf_u044c_u0432 = clampRotationSpeed(returnSpeed, maxStep);
         obf_u2213_u0432 = moveCorrection;
         obf_u044a_u0432 = skipGcd;
         obf_u041c_u0432 = System.currentTimeMillis();
         obf_u0409_u0432 = RotationManager.RotationState.ROTATING;
         Rotation stepped = new Rotation(stepAngleToward(obf_u03a8_u0432.yaw(), obf_u0437_u0432.yaw(), obf_u00d1_u0432), stepAngleToward(obf_u03a8_u0432.pitch(), obf_u0437_u0432.pitch(), obf_u0394_u0432));
         obf_u03a8_u0432 = skipGcd ? stepped : applySensitivityGcd(stepped);
      }
   }

   public static void requestRotation(Rotation rotation, float yawSpeed, float pitchSpeed, float returnSpeed) {
      requestRotation(rotation, RotationManager.MoveCorrection.NONE, yawSpeed, pitchSpeed, returnSpeed, false);
   }

   public static void reset() {
      obf_u0437_u0432 = null;
      obf_u0409_u0432 = RotationManager.RotationState.IDLE;
      obf_u2213_u0432 = RotationManager.MoveCorrection.NONE;
      obf_u044a_u0432 = false;
      if (obf_u03c2_u0432.field_1724 != null) {
         obf_u03a8_u0432 = getPlayerRotation();
         obf_u2212_u0432 = obf_u03a8_u0432;
         obf_u0425_u0432 = obf_u03a8_u0432;
      }

   }

   public static void beginReturn(float speed) {
      if (obf_u03c2_u0432.field_1724 != null && obf_u0437_u0432 != null) {
         obf_u044c_u0432 = clampRotationSpeed(speed);
         obf_u041c_u0432 = 0L;
      } else {
         reset();
      }
   }

   public static boolean isRotating() {
      return obf_u03c2_u0432.field_1724 != null && obf_u0409_u0432 != RotationManager.RotationState.IDLE;
   }

   public static float getServerYaw(float fallback) {
      return isRotating() ? obf_u03a8_u0432.yaw() : fallback;
   }

   public static float getServerPitch(float fallback) {
      return isRotating() ? obf_u03a8_u0432.pitch() : fallback;
   }

   public static float getRenderYaw(float fallback) {
      return isRotating() ? obf_u0425_u0432.yaw() : fallback;
   }

   public static float getRenderPitch(float fallback) {
      return isRotating() ? obf_u0425_u0432.pitch() : fallback;
   }

   public static Rotation getCurrentRotation() {
      return obf_u03a8_u0432;
   }

   public static boolean hasMoveCorrection() {
      return isRotating() && obf_u2213_u0432 != RotationManager.MoveCorrection.NONE;
   }

   public static boolean usesSilentMoveCorrection() {
      return isRotating() && obf_u2213_u0432 == RotationManager.MoveCorrection.SILENT;
   }

   public static class_241 correctMovementInput(float forward, float strafe) {
      if (obf_u03c2_u0432.field_1724 != null && usesSilentMoveCorrection() && (forward != 0.0F || strafe != 0.0F)) {
         double angle = class_3532.method_15338(Math.toDegrees(movementDirectionRadians(obf_u03c2_u0432.field_1724.method_36454(), forward, strafe)));
         float closestForward = forward;
         float closestStrafe = strafe;
         float closestDifference = 3.40282347e+38F;

         for(float predictedForward = -1.0F; predictedForward <= 1.0F; ++predictedForward) {
            for(float predictedStrafe = -1.0F; predictedStrafe <= 1.0F; ++predictedStrafe) {
               if (predictedForward != 0.0F || predictedStrafe != 0.0F) {
                  double predictedAngle = class_3532.method_15338(Math.toDegrees(movementDirectionRadians(obf_u03a8_u0432.yaw(), predictedForward, predictedStrafe)));
                  float difference = (float)Math.abs(class_3532.method_15338(angle - predictedAngle));
                  if (difference < closestDifference) {
                     closestDifference = difference;
                     closestForward = predictedForward;
                     closestStrafe = predictedStrafe;
                  }
               }
            }
         }

         return new class_241(closestStrafe, closestForward);
      } else {
         return new class_241(strafe, forward);
      }
   }

   public static Rotation rotationTo(class_243 pos) {
      class_243 eyes = obf_u03c2_u0432.field_1724.method_33571();
      double deltaX = pos.field_1352 - eyes.field_1352;
      double deltaY = pos.field_1351 - eyes.field_1351;
      double deltaZ = pos.field_1350 - eyes.field_1350;
      double horizontal = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
      float yaw = (float)Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0F;
      float pitch = (float)(-Math.toDegrees(Math.atan2(deltaY, horizontal)));
      return new Rotation(yaw, pitch);
   }

   public static class_243 closestPointToEyes(class_1309 entity) {
      class_243 eyes = obf_u03c2_u0432.field_1724.method_33571();
      return new class_243(class_3532.method_15350(eyes.field_1352, entity.method_5829().field_1323, entity.method_5829().field_1320), class_3532.method_15350(eyes.field_1351, entity.method_5829().field_1322, entity.method_5829().field_1325), class_3532.method_15350(eyes.field_1350, entity.method_5829().field_1321, entity.method_5829().field_1324));
   }

   private static Rotation getPlayerRotation() {
      return obf_u03c2_u0432.field_1724 == null ? RotationManager.Rotation.ZERO : new Rotation(obf_u03c2_u0432.field_1724.method_36454(), obf_u03c2_u0432.field_1724.method_36455());
   }

   private static Rotation applySensitivityGcd(Rotation rotation) {
      double gcd = getSensitivityGcd();
      float yaw = (float)((double)rotation.yaw() - (double)rotation.yaw() % gcd);
      float pitch = (float)((double)rotation.pitch() - (double)rotation.pitch() % gcd);
      return new Rotation(yaw, pitch);
   }

   public static double getSensitivityGcd() {
      double sensitivity = (Double)obf_u03c2_u0432.field_1690.method_42495().method_41753() * (double)0.6F + (double)0.2F;
      return sensitivity * sensitivity * sensitivity * 8.0D * (double)0.15F;
   }

   private static float clampRotationSpeed(float speed) {
      return clampRotationSpeed(speed, 30.0F);
   }

   private static float clampRotationSpeed(float speed, float maxStep) {
      return class_3532.method_15363(speed, 0.0F, Math.max(0.0F, maxStep));
   }

   private static float stepAngleToward(float current, float target, float speed) {
      float difference = angleDifference(current, target);
      return Math.abs(difference) <= speed ? target : current + Math.signum(difference) * speed;
   }

   private static float angleDifference(float current, float target) {
      return class_3532.method_15393(target - current);
   }

   private static float unwrapAngleToward(float currentAngle, float targetAngle) {
      float normalizedCurrent = currentAngle % 360.0F;
      if (normalizedCurrent < 0.0F) {
         normalizedCurrent += 360.0F;
      }

      float normalizedTarget = targetAngle % 360.0F;
      if (normalizedTarget < 0.0F) {
         normalizedTarget += 360.0F;
      }

      int revolutions = (int)(currentAngle / 360.0F);
      if (currentAngle < 0.0F && currentAngle % 360.0F != 0.0F) {
         --revolutions;
      }

      float adjustedTarget = normalizedTarget + (float)revolutions * 360.0F;
      float difference = adjustedTarget - currentAngle;
      if (difference > 180.0F) {
         adjustedTarget -= 360.0F;
      }

      if (difference < -180.0F) {
         adjustedTarget += 360.0F;
      }

      return adjustedTarget;
   }

   private static float lerpAngle(float start, float end, float delta) {
      return start + class_3532.method_15393(end - start) * delta;
   }

   private static double movementDirectionRadians(float yaw, float forward, float strafe) {
      if (forward < 0.0F) {
         yaw += 180.0F;
      }

      float factor = 1.0F;
      if (forward < 0.0F) {
         factor = -0.5F;
      } else if (forward > 0.0F) {
         factor = 0.5F;
      }

      if (strafe > 0.0F) {
         yaw -= 90.0F * factor;
      }

      if (strafe < 0.0F) {
         yaw += 90.0F * factor;
      }

      return Math.toRadians((double)yaw);
   }

   static {
      obf_u03a8_u0432 = RotationManager.Rotation.ZERO;
      obf_u2212_u0432 = RotationManager.Rotation.ZERO;
      obf_u0425_u0432 = RotationManager.Rotation.ZERO;
      obf_u2213_u0432 = RotationManager.MoveCorrection.NONE;
      obf_u0409_u0432 = RotationManager.RotationState.IDLE;
   }


   private static enum RotationState {
      IDLE,
      ROTATING,
      ROTATING_BACK;

   }

   public static enum MoveCorrection {
      NONE,
      DIRECT,
      SILENT;

   }

   public static record Rotation(float yaw, float pitch) {
      public static final Rotation ZERO = new Rotation(0.0F, 0.0F);

      public float differenceValue(Rotation other) {
         return Math.abs(class_3532.method_15393(other.getYawInternal() - this.getYawInternal())) + Math.abs(class_3532.method_15393(other.getPitchInternal() - this.getPitchInternal()));
      }

      public float yaw() {
         return this.getYawInternal();
      }

      public float pitch() {
         return this.getPitchInternal();
      }

      private float getYawInternal() {
         return this.yaw;
      }

      private float getPitchInternal() {
         return this.pitch;
      }

   }
}
