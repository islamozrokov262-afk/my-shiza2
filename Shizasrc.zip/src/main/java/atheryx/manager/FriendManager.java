package atheryx.manager;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public final class FriendManager {
   private static final Map<String, String> obf_u0411_u0432 = new LinkedHashMap<String, String>();

   private FriendManager() {
   }

   public static boolean addFriend(String name) {
      return obf_u0411_u0432.putIfAbsent(normalizeName(name), name) == null;
   }

   public static boolean removeBot(String name) {
      return obf_u0411_u0432.remove(normalizeName(name)) != null;
   }

   public static int clearFriends() {
      int size = obf_u0411_u0432.size();
      obf_u0411_u0432.clear();
      return size;
   }

   public static Map<String, String> getFriends() {
      return new LinkedHashMap<String, String>(obf_u0411_u0432);
   }

   public static void setFriends(Map<String, String> friends) {
      obf_u0411_u0432.clear();
      obf_u0411_u0432.putAll(friends);
   }

   public static boolean isFriend(String name) {
      return name != null && obf_u0411_u0432.containsKey(normalizeName(name));
   }

   private static String normalizeName(String name) {
      return name.toLowerCase(Locale.ROOT);
   }

}
