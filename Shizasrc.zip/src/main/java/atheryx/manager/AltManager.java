package atheryx.manager;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;

public class AltManager {
   private static final List<AltAccount> obf_u03bb_u0432 = new ArrayList<AltAccount>();
   private static Path obf_u220d_u0432;
   private static Path obf_u00e5_u0432;

   public static void init() {
      obf_u220d_u0432 = FabricLoader.getInstance().getGameDir().resolve("Minar");
      obf_u00e5_u0432 = obf_u220d_u0432.resolve("alts.txt");
      load();
   }

   public static List<AltAccount> getAccounts() {
      return new ArrayList<AltAccount>(obf_u03bb_u0432);
   }

   public static void addAccount(String name) {
      if (obf_u03bb_u0432.stream().noneMatch((a) -> {
         return a.name.equalsIgnoreCase(name);
      })) {
         obf_u03bb_u0432.add(new AltAccount(name, false));
         sortAndSave();
      }

   }

   public static void removeAccount(String name) {
      if (obf_u03bb_u0432.removeIf((a) -> {
         return a.name.equalsIgnoreCase(name);
      })) {
         sortAndSave();
      }

   }

   public static void toggleFavorite(String name) {
      for(AltAccount alt : obf_u03bb_u0432) {
         if (alt.name.equalsIgnoreCase(name)) {
            alt.isFavorite = !alt.isFavorite;
            sortAndSave();
            break;
         }
      }

   }

   public static void renameAccount(String oldName, String newName) {
      for(AltAccount alt : obf_u03bb_u0432) {
         if (alt.name.equalsIgnoreCase(oldName)) {
            alt.name = newName;
            sortAndSave();
            break;
         }
      }

   }

   private static void sortAndSave() {
      obf_u03bb_u0432.sort((a, b) -> {
         if (a.isFavorite && !b.isFavorite) {
            return -1;
         } else {
            return !a.isFavorite && b.isFavorite ? 1 : a.name.compareToIgnoreCase(b.name);
         }
      });
      save();
   }

   public static void load() {
      if (Files.exists(obf_u00e5_u0432)) {
         try {
            List<String> lines = Files.readAllLines(obf_u00e5_u0432);
            obf_u03bb_u0432.clear();

            for(String line : lines) {
               line = line.trim();
               if (!line.isEmpty()) {
                  if (line.contains(":")) {
                     String[] parts = line.split(":", 2);
                     obf_u03bb_u0432.add(new AltAccount(parts[0], Boolean.parseBoolean(parts[1])));
                  } else {
                     obf_u03bb_u0432.add(new AltAccount(line, false));
                  }
               }
            }

            obf_u03bb_u0432.sort((a, b) -> {
               if (a.isFavorite && !b.isFavorite) {
                  return -1;
               } else {
                  return !a.isFavorite && b.isFavorite ? 1 : a.name.compareToIgnoreCase(b.name);
               }
            });
         } catch (IOException e) {
            e.printStackTrace();
         }

      }
   }

   public static void save() {
      try {
         Files.createDirectories(obf_u220d_u0432);
         List<String> lines = new ArrayList<String>();

         for(AltAccount alt : obf_u03bb_u0432) {
            lines.add(alt.name + alt.isFavorite);
         }

         Files.write(obf_u00e5_u0432, (Iterable)lines);
      } catch (IOException e) {
         e.printStackTrace();
      }

   }


   public static class AltAccount {
      public String name;
      public boolean isFavorite;

      public AltAccount(String name, boolean isFavorite) {
         this.setNameInternal(name);
         this.setFavoriteInternal(isFavorite);
      }

      private String getNameInternal() {
         return this.name;
      }

      private void setNameInternal(String var1) {
         this.name = var1;
      }

      private boolean getFavoriteInternal() {
         return this.isFavorite;
      }

      private void setFavoriteInternal(boolean var1) {
         this.isFavorite = var1;
      }

   }
}
