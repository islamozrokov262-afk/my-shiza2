package atheryx.neuro;

import atheryx.command.CommandFeedback;
import atheryx.gui.ThemeManager;
import atheryx.render.RenderUtil;
import atheryx.render.font.Msdf;
import atheryx.render.scissor.Scissor;
import atheryx.util.math.Easings;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_11909;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;

public class NeuroTrainingScreen extends class_437 {
   private static final int obf_u040f_u220e = 16;
   private static final float obf_u0420_u220e = 12.0F;
   private static final float obf_u0458_u220e = 62.0F;
   private static final float obf_u042f_u220e = 22.0F;
   private static final float obf_u2237_u220e = 115.0F;
   private static final float obf_u0429_u220e = 7.0F;
   private static final float obf_u040a_u220e = 330.0F;
   private static final float obf_u041a_u220e = 220.0F;
   private static final float obf_u0417_u220e = 16.0F;
   private static final float obf_u00cf_u220e = 34.0F;
   private static final float obf_u2200_u220e = 36.0F;
   private static final long obf_u223a_u220e = 420L;
   private static final long obf_u03b8_u220e = 260L;
   private final String field_6d2b79f5;
   private final Random field_da56f3ea = new Random();
   private final List<NeuroManager.AimFrame> field_47826ddf = new ArrayList<NeuroManager.AimFrame>();
   private float field_b4ade7d4;
   private float field_21d961c9;
   private float field_8f04dbbe;
   private float field_fc3055b3;
   private float field_695bcfa8;
   private float field_d687499d;
   private boolean field_43b2c392;
   private long field_b0de3d87;
   private long field_1e09b77c;
   private long field_8b353171;
   private long field_f860ab66;

   public NeuroTrainingScreen(String modelName) {
      super(class_2561.method_43470("Neuro Record"));
      this.field_6d2b79f5 = modelName;
   }

   protected void init() {
      super.method_25426();
      this.setRecordingStartTimeInternal(System.currentTimeMillis());
      this.setHitEffectTimeInternal(0L);
      this.setStopClickTimeInternal(0L);
      this.spawnTarget();
   }

   public void renderScreenContent(class_332 context, int mouseX, int mouseY, float deltaTicks) {
   }

   public void renderScreen(class_332 context, int mouseX, int mouseY, float delta) {
      int width = RenderUtil.getScaledWidth();
      int height = RenderUtil.getScaledHeight();
      float mx = RenderUtil.toScaledX((float)mouseX);
      float my = RenderUtil.toScaledY((float)mouseY);
      long now = System.currentTimeMillis();
      float openProgress = class_3532.method_15363((float)(now - this.getRecordingStartTimeInternal()) / 420.0F, 0.0F, 1.0F);
      float open = Easings.easeOutBack(openProgress);
      float alpha = class_3532.method_15363(openProgress * 1.6F, 0.0F, 1.0F);
      int alphaInt = Math.round(alpha * 255.0F);
      float panelW = Math.min(330.0F, (float)width - 28.0F);
      float panelH = Math.min(220.0F, (float)height - 28.0F);
      float panelX = ((float)width - panelW) / 2.0F;
      float panelY = ((float)height - panelH) / 2.0F + (1.0F - open) * 34.0F;
      float panelScale = 0.94F + open * 0.06F;
      float drawPanelW = panelW * panelScale;
      float drawPanelH = panelH * panelScale;
      float drawPanelX = panelX + (panelW - drawPanelW) / 2.0F;
      float drawPanelY = panelY + (panelH - drawPanelH) / 2.0F;
      this.recordMouseMovement(mx, my, panelX, panelY, panelW, panelH);
      RenderUtil.drawRoundedRect(0.0F, 0.0F, (float)width, (float)height, 0.0F, new Color(4, 6, 10, Math.round(132.0F * alpha)));
      RenderUtil.drawShadow(drawPanelX, drawPanelY + 2.0F, drawPanelW, drawPanelH, 10.0F, 18.0F, 0.35F * alpha, 2.20000005F, new Color(0, 0, 0, 190));
      RenderUtil.drawHudBlur(drawPanelX, drawPanelY, drawPanelW, drawPanelH, 10.0F, 18.0F, alpha, new Color(28, 32, 42, 70));
      RenderUtil.drawRoundedRect(drawPanelX, drawPanelY, drawPanelW, drawPanelH, 10.0F, new Color(255, 255, 255, Math.round(16.0F * alpha)));
      RenderUtil.drawRoundedOutline(drawPanelX, drawPanelY, drawPanelW, drawPanelH, 10.0F, 0.8F, new Color(255, 255, 255, Math.round(42.0F * alpha)));
      float trainX = panelX + 16.0F;
      float trainY = panelY + 34.0F;
      float trainW = panelW - 32.0F;
      float trainH = panelH - 34.0F - 36.0F;
      RenderUtil.drawHudBlur(trainX, trainY, trainW, trainH, 8.0F, 12.0F, alpha, new Color(95, 120, 150, 24));
      RenderUtil.drawRoundedRect(trainX, trainY, trainW, trainH, 8.0F, new Color(8, 10, 16, Math.round(118.0F * alpha)));
      RenderUtil.drawRoundedOutline(trainX, trainY, trainW, trainH, 8.0F, 0.7F, new Color(255, 255, 255, Math.round(28.0F * alpha)));
      RenderUtil.drawText(context, Msdf.SF_BOLD, panelX + 16.0F, panelY + 12.0F, "Neuro Record", 13.0F, new Color(245, 247, 250, alphaInt));
      float var10001 = panelX + panelW - 16.0F;
      float var10002 = panelY + 14.0F;
      String var10003 = this.getModelNameInternal();
      RenderUtil.drawAlignedText(context, var10001, var10002, var10003 + this.getRecordedFramesInternal().size(), 8.5F, new Color(188, 196, 210, Math.round(220.0F * alpha)), "right");
      Scissor.push((double)trainX, (double)trainY, (double)trainW, (double)trainH);
      this.renderHitEffect();
      this.renderTarget(now);
      Scissor.popTertiary();
      float stopX = this.getStopButtonX(panelX, panelW);
      float stopY = this.getStopButtonY(panelY, panelH);
      boolean var30 = this.isPointInside(mx, my, stopX, stopY, 62.0F, 22.0F);
      float stopClick = this.getClickAnimation(this.getStopClickTimeInternal(), 170L);
      float stopScale = 1.0F + (var30 ? 0.035F : 0.0F) - stopClick * 0.08F;
      float stopDrawW = 62.0F * stopScale;
      float stopDrawH = 22.0F * stopScale;
      float stopDrawX = stopX + (62.0F - stopDrawW) / 2.0F;
      float stopDrawY = stopY + (22.0F - stopDrawH) / 2.0F;
      RenderUtil.drawHudBlur(stopDrawX, stopDrawY, stopDrawW, stopDrawH, 6.0F, 8.0F, alpha, new Color(155, 48, 58, 180));
      RenderUtil.drawAlignedText(context, stopDrawX + stopDrawW / 2.0F, stopDrawY + 6.19999981F * stopScale, "Stop", 8.80000019F * stopScale, Color.WHITE, "center");
      super.method_25394(context, mouseX, mouseY, delta);
   }

   public boolean mouseClicked(class_11909 click, boolean doubled) {
      float mx = RenderUtil.toScaledX((float)click.comp_4798());
      float my = RenderUtil.toScaledY((float)click.comp_4799());
      int width = RenderUtil.getScaledWidth();
      int height = RenderUtil.getScaledHeight();
      float panelW = Math.min(330.0F, (float)width - 28.0F);
      float panelH = Math.min(220.0F, (float)height - 28.0F);
      float panelX = ((float)width - panelW) / 2.0F;
      float panelY = ((float)height - panelH) / 2.0F;
      float trainX = panelX + 16.0F;
      float trainY = panelY + 34.0F;
      float trainW = panelW - 32.0F;
      float trainH = panelH - 34.0F - 36.0F;
      float stopX = this.getStopButtonX(panelX, panelW);
      float var16 = this.getStopButtonY(panelY, panelH);
      if (this.isPointInside(mx, my, stopX, var16, 62.0F, 22.0F)) {
         this.setStopClickTimeInternal(System.currentTimeMillis());
         this.finishRecording();
         return true;
      } else if (!this.isPointInside(mx, my, trainX, trainY, trainW, trainH)) {
         this.setTrackingMouseInternal(false);
         return true;
      } else {
         float dx = mx - this.getTargetXInternal();
         float dy = my - this.getTargetYInternal();
         if (dx * dx + dy * dy <= 361.0F) {
            this.getRecordedFramesInternal().add(new NeuroManager.AimFrame(dx * 0.22F, dy * 0.22F));
            this.setLastHitXInternal(this.getTargetXInternal());
            this.setLastHitYInternal(this.getTargetYInternal());
            this.setHitEffectTimeInternal(System.currentTimeMillis());
            this.spawnTarget();
            return true;
         } else {
            return super.method_25402(click, doubled);
         }
      }
   }

   public boolean shouldPause() {
      return false;
   }

   public void close() {
      if (this.field_22787 != null) {
         this.field_22787.method_1507((class_437)null);
      }

   }

   private void recordMouseMovement(float mouseX, float mouseY, float panelX, float panelY, float panelW, float panelH) {
      float trainX = panelX + 16.0F;
      float trainY = panelY + 34.0F;
      float trainW = panelW - 32.0F;
      float trainH = panelH - 34.0F - 36.0F;
      if (!this.isPointInside(mouseX, mouseY, trainX, trainY, trainW, trainH)) {
         this.setTrackingMouseInternal(false);
      } else if (!this.getTrackingMouseInternal()) {
         this.setLastMouseXInternal(mouseX);
         this.setLastMouseYInternal(mouseY);
         this.setTrackingMouseInternal(true);
      } else {
         float dx = mouseX - this.getLastMouseXInternal();
         float dy = mouseY - this.getLastMouseYInternal();
         this.setLastMouseXInternal(mouseX);
         this.setLastMouseYInternal(mouseY);
         if (!(Math.abs(dx) < 0.05F) || !(Math.abs(dy) < 0.05F)) {
            float yawDelta = class_3532.method_15363(dx * 0.42F, -35.0F, 35.0F);
            float pitchDelta = class_3532.method_15363(dy * 0.36F, -25.0F, 25.0F);
            this.getRecordedFramesInternal().add(new NeuroManager.AimFrame(yawDelta, pitchDelta));
         }
      }
   }

   private void spawnTarget() {
      int width = RenderUtil.getScaledWidth();
      int height = RenderUtil.getScaledHeight();
      float panelW = Math.min(330.0F, (float)width - 28.0F);
      float panelH = Math.min(220.0F, (float)height - 28.0F);
      float panelX = ((float)width - panelW) / 2.0F;
      float panelY = ((float)height - panelH) / 2.0F;
      float trainX = panelX + 16.0F;
      float trainY = panelY + 34.0F;
      float trainW = panelW - 32.0F;
      float trainH = panelH - 34.0F - 36.0F;
      float margin = 22.0F;
      this.setTargetXInternal(trainX + margin + this.getRandomInternal().nextFloat() * Math.max(1.0F, trainW - margin * 2.0F));
      this.setTargetYInternal(trainY + margin + this.getRandomInternal().nextFloat() * Math.max(1.0F, trainH - margin * 2.0F));
      this.setTargetSpawnTimeInternal(System.currentTimeMillis());
   }

   private void renderTarget(long now) {
      float spawnProgress = class_3532.method_15363((float)(now - this.getTargetSpawnTimeInternal()) / 260.0F, 0.0F, 1.0F);
      float spawnBounce = Easings.easeOutBack(spawnProgress);
      float scale = 0.72F + spawnBounce * 0.28F;
      float radius = 12.0F * scale;
      RenderUtil.drawCircle(this.getTargetXInternal(), this.getTargetYInternal(), radius + 5.0F, 1.3F, ThemeManager.getCurrentColor());
   }

   private void renderHitEffect() {
      if (this.getHitEffectTimeInternal() != 0L) {
         float progress = class_3532.method_15363((float)(System.currentTimeMillis() - this.getHitEffectTimeInternal()) / 300.0F, 0.0F, 1.0F);
         if (!(progress >= 1.0F)) {
            float bounce = Easings.easeOutBack(progress);
            int alpha = Math.round((1.0F - progress) * 150.0F);
            RenderUtil.drawCircle(this.getLastHitXInternal(), this.getLastHitYInternal(), 17.0F + bounce * 15.0F, 1.6F, new Color(ThemeManager.getCurrentColor().getRed(), ThemeManager.getCurrentColor().getGreen(), ThemeManager.getCurrentColor().getBlue(), alpha));
         }
      }
   }

   private float getClickAnimation(long start, long duration) {
      if (start == 0L) {
         return 0.0F;
      } else {
         float progress = class_3532.method_15363((float)(System.currentTimeMillis() - start) / (float)duration, 0.0F, 1.0F);
         return progress >= 1.0F ? 0.0F : 1.0F - Easings.easeOutCubic(progress);
      }
   }

   private void finishRecording() {
      if (this.field_22787 != null && this.field_22787.field_1755 == this) {
         if (this.getRecordedFramesInternal().isEmpty() && System.currentTimeMillis() - this.getRecordingStartTimeInternal() > 350L) {
            CommandFeedback.sendFeedback("No neuro movement recorded. Move the mouse or click circles before stopping.", class_124.field_1054);
         } else {
            if (NeuroManager.saveModel(this.getModelNameInternal(), this.getRecordedFramesInternal())) {
               NeuroManager.load(this.getModelNameInternal());
               CommandFeedback.sendFeedback(this.getModelNameInternal() + this.getRecordedFramesInternal().size(), class_124.field_1060);
               if (this.getRecordedFramesInternal().size() < 16) {
                  CommandFeedback.sendFeedback("Neuro model is short; record more frames for smoother rotation.", class_124.field_1054);
               }
            } else {
               CommandFeedback.sendFeedback("Could not save neuro model: " + String.valueOf(this.getModelNameInternal()), class_124.field_1061);
            }

            this.field_22787.method_1507((class_437)null);
         }
      }
   }

   private boolean isPointInside(float mouseX, float mouseY, float x, float y, float width, float height) {
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
   }

   private float getStopButtonX(float panelX, float panelW) {
      return panelX + panelW - 16.0F - 62.0F - 115.0F;
   }

   private float getStopButtonY(float panelY, float panelH) {
      return panelY + panelH - 16.0F - 22.0F + 7.0F;
   }

   private String getModelNameInternal() {
      return this.field_6d2b79f5;
   }

   private Random getRandomInternal() {
      return this.field_da56f3ea;
   }

   private List getRecordedFramesInternal() {
      return this.field_47826ddf;
   }

   private float getTargetXInternal() {
      return this.field_b4ade7d4;
   }

   private void setTargetXInternal(float var1) {
      this.field_b4ade7d4 = var1;
   }

   private float getTargetYInternal() {
      return this.field_21d961c9;
   }

   private void setTargetYInternal(float var1) {
      this.field_21d961c9 = var1;
   }

   private float getLastMouseXInternal() {
      return this.field_8f04dbbe;
   }

   private void setLastMouseXInternal(float var1) {
      this.field_8f04dbbe = var1;
   }

   private float getLastMouseYInternal() {
      return this.field_fc3055b3;
   }

   private void setLastMouseYInternal(float var1) {
      this.field_fc3055b3 = var1;
   }

   private float getLastHitXInternal() {
      return this.field_695bcfa8;
   }

   private void setLastHitXInternal(float var1) {
      this.field_695bcfa8 = var1;
   }

   private float getLastHitYInternal() {
      return this.field_d687499d;
   }

   private void setLastHitYInternal(float var1) {
      this.field_d687499d = var1;
   }

   private boolean getTrackingMouseInternal() {
      return this.field_43b2c392;
   }

   private void setTrackingMouseInternal(boolean var1) {
      this.field_43b2c392 = var1;
   }

   private long getRecordingStartTimeInternal() {
      return this.field_b0de3d87;
   }

   private void setRecordingStartTimeInternal(long var1) {
      this.field_b0de3d87 = var1;
   }

   private long getTargetSpawnTimeInternal() {
      return this.field_1e09b77c;
   }

   private void setTargetSpawnTimeInternal(long var1) {
      this.field_1e09b77c = var1;
   }

   private long getHitEffectTimeInternal() {
      return this.field_8b353171;
   }

   private void setHitEffectTimeInternal(long var1) {
      this.field_8b353171 = var1;
   }

   private long getStopClickTimeInternal() {
      return this.field_f860ab66;
   }

   private void setStopClickTimeInternal(long var1) {
      this.field_f860ab66 = var1;
   }

}
