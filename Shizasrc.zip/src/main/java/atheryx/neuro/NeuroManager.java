package atheryx.neuro;

import atheryx.manager.RotationManager;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Random;
import java.util.stream.Stream;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class NeuroManager {
   private static final Path obf_u00c2_u03b2;
   private static final String obf_u03a1_u03b2 = "[A-Za-z0-9_-]{1,32}";
   private static final int obf_u00c1_u03b2 = 220;
   private static final long obf_u00f6_u03b2 = 2200L;
   private static final List<AimFrame> obf_u2229_u03b2;
   private static final List<AimTrailPoint> obf_u039c_u03b2;
   private static final Random obf_u040c_u03b2;
   private static String obf_u0446_u03b2;
   private static int obf_u0457_u03b2;
   private static RotationManager.Rotation obf_u045d_u03b2;
   private static RotationSpeeds obf_u2223_u03b2;
   private static float obf_u03c8_u03b2;
   private static float obf_u221c_u220e;
   private static float obf_u221b_u220e;
   private static float obf_u2208_u220e;
   private static float obf_u222f_u220e;
   private static float obf_u0432_u220e;
   private static float obf_u03b2_u220e;
   private static float obf_u220e_u220e;
   private static float obf_u2201_u220e;
   private static float obf_u0426_u220e;
   private static float obf_u00c9_u220e;
   private static boolean obf_u039f_u220e;
   private static boolean obf_u0428_u220e;
   private static long obf_u2216_u220e;
   private static long obf_u2205_u220e;

   private NeuroManager() {
   }

   public static boolean isValidModelName(String name) {
      return name != null && name.matches("[A-Za-z0-9_-]{1,32}");
   }

   public static List<String> listModels() {
      try {
         if (!Files.isDirectory(obf_u00c2_u03b2)) {
            return List.<String>of();
         } else {
            List var1;
            try (Stream<Path> stream = Files.list(obf_u00c2_u03b2)) {
               var1 = stream.filter((path) -> {
                  return path.getFileName().toString().endsWith(".properties");
               }).map((path) -> {
                  return path.getFileName().toString();
               }).map((name) -> {
                  return name.substring(0, name.length() - ".properties".length());
               }).sorted(Comparator.naturalOrder()).toList();
            }

            return var1;
         }
      } catch (IOException var5) {
         return List.<String>of();
      }
   }

   public static boolean load(String name) {
      if (!isValidModelName(name)) {
         return false;
      }

      Path path = getModelPath(name);
      if (!Files.isRegularFile(path)) {
         return false;
      }

      Properties properties = new Properties();
      try (InputStream input = Files.newInputStream(path)) {
         properties.load(input);
      } catch (IOException ignored) {
         return false;
      }

      int frameCount = parseInt(properties.getProperty("frames"), 0);
      List<AimFrame> loaded = new ArrayList<AimFrame>();
      for (int index = 0; index < frameCount; index++) {
         AimFrame frame = parseFrame(properties.getProperty("frame." + index));
         if (frame != null) {
            loaded.add(frame);
         }
      }

      if (loaded.isEmpty()) {
         return false;
      }

      obf_u2229_u03b2.clear();
      obf_u2229_u03b2.addAll(loaded);
      obf_u0446_u03b2 = name;
      obf_u0457_u03b2 = obf_u040c_u03b2.nextInt(loaded.size());
      obf_u045d_u03b2 = null;
      obf_u2223_u03b2 = new RotationSpeeds(30.0F, 30.0F, 14.0F);
      return true;
   }

   public static boolean saveModel(String name, List<AimFrame> frames) {
      if (isValidModelName(name) && frames != null && !frames.isEmpty()) {
         try {
            Files.createDirectories(obf_u00c2_u03b2);
         } catch (IOException var7) {
            return false;
         }

         Properties properties = new Properties();
         properties.setProperty("version", "1");
         properties.setProperty("frames", String.valueOf(frames.size()));

         for(int i = 0; i < frames.size(); ++i) {
            AimFrame frame = frames.get(i);
            String var10001 = "frame." + String.valueOf(i);
            String var10002 = formatFloat(frame.yawDelta());
            properties.setProperty(var10001, var10002 + formatFloat(frame.pitchDelta()));
         }

         try (OutputStream output = Files.newOutputStream(getModelPath(name))) {
            properties.store(output, "Minar neuro camera model");
            return true;
         } catch (IOException exception) {
            return false;
         }
      } else {
         return false;
      }
   }

   public static RotationManager.Rotation applyModelRotation(RotationManager.Rotation desired, RotationManager.Rotation current, boolean attackReadySoon) {
      if (desired != null && current != null && !obf_u2229_u03b2.isEmpty()) {
         float yawDelta = class_3532.method_15393(desired.yaw() - current.yaw());
         float pitchDelta = desired.pitch() - current.pitch();
         float distance = (float)Math.hypot((double)yawDelta, (double)pitchDelta);
         if (!(distance > 95.0F) && !(distance < 0.45F)) {
            AimFrame frame = nextFrame();
            float frameYaw = class_3532.method_15363(frame.yawDelta(), -60.0F, 60.0F);
            float framePitch = class_3532.method_15363(frame.pitchDelta(), -38.0F, 38.0F);
            float frameEnergy = Math.max((float)Math.hypot((double)frameYaw, (double)framePitch), 0.1F);
            float unitYaw = yawDelta / Math.max(distance, 0.001F);
            float unitPitch = pitchDelta / Math.max(distance, 0.001F);
            float perpendicularYaw = -unitPitch;
            float var14 = class_3532.method_15363(1.0F - distance / 25.0F, 0.0F, 1.0F);
            float urgencyMultiplier = 1.0F + var14 * 0.6F;
            if (attackReadySoon) {
               urgencyMultiplier += class_3532.method_15363(2.79999995F - distance * 0.06F, 1.0F, 2.79999995F);
            }

            float learnedStep = class_3532.method_15363(frameEnergy * 0.18F, 0.18F, 12.0F);
            float catchUpStep = class_3532.method_15363(distance * 0.28F, 0.12F, 12.0F);
            float var18 = learnedStep + catchUpStep;
            float step = class_3532.method_15363(var18 * urgencyMultiplier, 0.18F, Math.min(distance, 25.0F));
            float perpDecay = class_3532.method_15363(distance / 18.0F, 0.08F, 1.0F);
            float perpendicular = (frameYaw * perpendicularYaw + framePitch * unitYaw) * 0.055F;
            perpendicular = class_3532.method_15363(perpendicular, -Math.min(4.0F, distance * 0.28F), Math.min(4.0F, distance * 0.28F));
            perpendicular *= perpDecay;
            float handDecay = class_3532.method_15363(distance / 12.0F, 0.12F, 1.0F);
            float handYaw = frameYaw * 0.025F * handDecay;
            float handPitch = framePitch * 0.022F * handDecay;
            float nextYaw = current.yaw() + unitYaw * step + perpendicularYaw * perpendicular + handYaw;
            float nextPitch = current.pitch() + unitPitch * step + unitYaw * perpendicular + handPitch;
            float finalYawDelta = class_3532.method_15393(nextYaw - current.yaw());
            float finalPitchDelta = nextPitch - current.pitch();
            obf_u045d_u03b2 = new RotationManager.Rotation(nextYaw, class_3532.method_15363(nextPitch, -90.0F, 90.0F));
            obf_u2223_u03b2 = new RotationSpeeds(class_3532.method_15363(Math.abs(finalYawDelta) + 0.05F, 0.05F, 30.0F), class_3532.method_15363(Math.abs(finalPitchDelta) + 0.05F, 0.05F, 30.0F), 14.0F);
            return obf_u045d_u03b2;
         } else {
            obf_u045d_u03b2 = desired;
            obf_u2223_u03b2 = new RotationSpeeds(30.0F, 30.0F, 14.0F);
            return desired;
         }
      } else {
         obf_u045d_u03b2 = desired;
         obf_u2223_u03b2 = new RotationSpeeds(30.0F, 30.0F, 14.0F);
         return desired;
      }
   }

   public static RotationSpeeds calculateRotationProfile(RotationManager.Rotation desired, RotationManager.Rotation current, boolean attackReadySoon) {
      if (desired != null && current != null && !obf_u2229_u03b2.isEmpty()) {
         float yawDelta = Math.abs(class_3532.method_15393(desired.yaw() - current.yaw()));
         float pitchDelta = Math.abs(desired.pitch() - current.pitch());
         float distance = (float)Math.hypot((double)yawDelta, (double)pitchDelta);
         return !attackReadySoon && !(distance > 95.0F) ? obf_u2223_u03b2 : new RotationSpeeds(30.0F, 30.0F, 14.0F);
      } else {
         return new RotationSpeeds(30.0F, 30.0F, 30.0F);
      }
   }

   public static void updateTargetState(boolean active, RotationManager.Rotation desired, RotationManager.Rotation current) {
      obf_u0428_u220e = active && desired != null && current != null;
      if (!obf_u0428_u220e) {
         obf_u03c8_u03b2 = 0.0F;
         obf_u221c_u220e = 0.0F;
      } else {
         float yawDelta = Math.abs(class_3532.method_15393(desired.yaw() - current.yaw()));
         float pitchDelta = Math.abs(desired.pitch() - current.pitch());
         obf_u221c_u220e = (float)Math.hypot((double)yawDelta, (double)pitchDelta);
         obf_u03c8_u03b2 = 1.0F - class_3532.method_15363(obf_u221c_u220e / 45.0F, 0.0F, 1.0F);
         obf_u2216_u220e = System.currentTimeMillis();
      }
   }

   public static void tickVisualState() {
      long now = System.currentTimeMillis();
      removeExpiredTrailPoints(now);
      if (obf_u2205_u220e > 0L && now - obf_u2205_u220e > 650L) {
         obf_u221b_u220e = lerp(obf_u221b_u220e, 0.0F, 0.12F);
         obf_u222f_u220e = lerp(obf_u222f_u220e, 0.0F, 0.18F);
      }

      if (obf_u2205_u220e > 0L && now - obf_u2205_u220e > 1600L) {
         obf_u039f_u220e = false;
         obf_u0426_u220e = 0.5F;
         obf_u00c9_u220e = 0.5F;
      }

   }

   public static void recordRotationSample(boolean active, RotationManager.Rotation rotation) {
      class_310 client = class_310.method_1551();
      if (active && rotation != null && client.field_1724 != null) {
         float yaw = rotation.yaw();
         float pitch = rotation.pitch();
         if (!obf_u039f_u220e) {
            obf_u0432_u220e = yaw;
            obf_u03b2_u220e = pitch;
            obf_u220e_u220e = 0.0F;
            obf_u2201_u220e = 0.0F;
            obf_u0426_u220e = 0.5F;
            obf_u00c9_u220e = 0.5F;
            obf_u039f_u220e = true;
            obf_u2205_u220e = System.currentTimeMillis();
            obf_u039c_u03b2.add(new AimTrailPoint(obf_u0426_u220e, obf_u00c9_u220e, 0.0F, obf_u2205_u220e));
         } else {
            float yawDelta = class_3532.method_15393(yaw - obf_u0432_u220e);
            float pitchDelta = pitch - obf_u03b2_u220e;
            obf_u0432_u220e = yaw;
            obf_u03b2_u220e = pitch;
            float speed = (float)Math.hypot((double)yawDelta, (double)pitchDelta);
            obf_u2208_u220e = lerp(obf_u2208_u220e, speed, 0.35F);
            if (speed < 0.005F) {
               if (System.currentTimeMillis() - obf_u2205_u220e > 650L) {
                  obf_u221b_u220e = lerp(obf_u221b_u220e, 0.0F, 0.12F);
                  obf_u222f_u220e = lerp(obf_u222f_u220e, 0.0F, 0.18F);
                  removeExpiredTrailPoints(System.currentTimeMillis());
               }

               obf_u220e_u220e = yawDelta;
               obf_u2201_u220e = pitchDelta;
            } else {
               float acceleration = (float)Math.hypot((double)(yawDelta - obf_u220e_u220e), (double)(pitchDelta - obf_u2201_u220e));
               float previousSpeed = (float)Math.hypot((double)obf_u220e_u220e, (double)obf_u2201_u220e);
               float turnPenalty = 0.0F;
               if (previousSpeed > 0.005F) {
                  float dot = (yawDelta * obf_u220e_u220e + pitchDelta * obf_u2201_u220e) / (speed * previousSpeed);
                  turnPenalty = (1.0F - class_3532.method_15363(dot, -1.0F, 1.0F)) * 0.5F;
               }

               float accelerationPenalty = class_3532.method_15363(acceleration / 7.5F, 0.0F, 1.0F);
               float shake = class_3532.method_15363(accelerationPenalty * 0.7F + turnPenalty * 0.55F, 0.0F, 1.0F);
               float smoothness = 1.0F - shake;
               obf_u222f_u220e = lerp(obf_u222f_u220e, shake, 0.32F);
               obf_u221b_u220e = lerp(obf_u221b_u220e, smoothness, 0.32F);
               addTrailPoint(yawDelta, pitchDelta, shake);
               obf_u220e_u220e = yawDelta;
               obf_u2201_u220e = pitchDelta;
               obf_u2205_u220e = System.currentTimeMillis();
            }
         }
      } else {
         tickVisualState();
      }
   }

   public static boolean isVisualizationActive() {
      long now = System.currentTimeMillis();
      return !(now - obf_u2205_u220e >= 1600L) || obf_u0428_u220e && !(now - obf_u2216_u220e >= 250L);
   }

   public static String getActiveModelName() {
      return obf_u0446_u03b2 == null ? "none" : obf_u0446_u03b2;
   }

   public static float getYawError() {
      return obf_u03c8_u03b2;
   }

   public static float getPitchError() {
      return obf_u221c_u220e;
   }

   public static float getYawMotion() {
      return obf_u221b_u220e;
   }

   public static float getPitchMotion() {
      return obf_u2208_u220e;
   }

   public static float getShakeMotion() {
      return obf_u222f_u220e;
   }

   public static List<AimTrailPoint> getTrailPoints() {
      removeExpiredTrailPoints(System.currentTimeMillis());
      return List.<AimTrailPoint>copyOf(obf_u039c_u03b2);
   }

   private static AimFrame nextFrame() {
      AimFrame frame = currentFrame();
      int advance = 1;
      if (obf_u2229_u03b2.size() > 8 && obf_u040c_u03b2.nextFloat() < 0.15F) {
         advance += 1 + obf_u040c_u03b2.nextInt(2);
      }

      obf_u0457_u03b2 = (obf_u0457_u03b2 + advance) % obf_u2229_u03b2.size();
      float noiseYaw = (obf_u040c_u03b2.nextFloat() - 0.5F) * 0.35F;
      float noisePitch = (obf_u040c_u03b2.nextFloat() - 0.5F) * 0.25F;
      return new AimFrame(frame.yawDelta() + noiseYaw, frame.pitchDelta() + noisePitch);
   }

   private static AimFrame currentFrame() {
      return obf_u2229_u03b2.get(obf_u0457_u03b2 % obf_u2229_u03b2.size());
   }

   private static AimFrame parseFrame(String value) {
      if (value == null) {
         return null;
      } else {
         String[] parts = value.split(",");
         if (parts.length != 2) {
            return null;
         } else {
            try {
               return new AimFrame(Float.parseFloat(parts[0]), Float.parseFloat(parts[1]));
            } catch (NumberFormatException var3) {
               return null;
            }
         }
      }
   }

   private static int parseInt(String value, int fallback) {
      try {
         return Integer.parseInt(value);
      } catch (NumberFormatException var3) {
         return fallback;
      }
   }

   private static String formatFloat(float value) {
      return String.format(Locale.US, "%.6f", value);
   }

   private static Path getModelPath(String name) {
      return obf_u00c2_u03b2.resolve("frame." + String.valueOf(name));
   }

   private static void addTrailPoint(float yawDelta, float pitchDelta, float shake) {
      long now = System.currentTimeMillis();
      if (now - obf_u2205_u220e > 1600L) {
         obf_u039c_u03b2.clear();
         obf_u0426_u220e = 0.5F;
         obf_u00c9_u220e = 0.5F;
      }

      obf_u0426_u220e += (0.5F - obf_u0426_u220e) * 0.018F;
      obf_u00c9_u220e += (0.5F - obf_u00c9_u220e) * 0.018F;
      float scale = 0.0062F;
      float startX = obf_u0426_u220e;
      float startY = obf_u00c9_u220e;
      float targetX = class_3532.method_15363(obf_u0426_u220e + yawDelta * scale, 0.06F, 0.94F);
      float targetY = class_3532.method_15363(obf_u00c9_u220e + pitchDelta * scale, 0.06F, 0.94F);
      float var10 = (float)Math.hypot((double)(targetX - startX), (double)(targetY - startY));
      int steps = class_3532.method_15340((int)Math.ceil((double)(var10 / 0.006F)), 1, 18);

      for(int i = 1; i <= steps; ++i) {
         float t = (float)i / (float)steps;
         float x = startX + (targetX - startX) * t;
         float y = startY + (targetY - startY) * t;
         obf_u039c_u03b2.add(new AimTrailPoint(x, y, shake, now));
      }

      obf_u0426_u220e = targetX;
      obf_u00c9_u220e = targetY;
      removeExpiredTrailPoints(now);

      while(obf_u039c_u03b2.size() > 220) {
         obf_u039c_u03b2.remove(0);
      }

   }

   private static void removeExpiredTrailPoints(long now) {
      obf_u039c_u03b2.removeIf((point) -> {
         return now - point.createdAt() > 2200L;
      });
   }

   private static float lerp(float current, float target, float speed) {
      return current + (target - current) * class_3532.method_15363(speed, 0.0F, 1.0F);
   }

   static {
      obf_u00c2_u03b2 = class_310.method_1551().field_1697.toPath().resolve("Minar").resolve("neuro");
      obf_u2229_u03b2 = new ArrayList<AimFrame>();
      obf_u039c_u03b2 = new ArrayList<AimTrailPoint>();
      obf_u040c_u03b2 = new Random();
      obf_u2223_u03b2 = new RotationSpeeds(30.0F, 30.0F, 30.0F);
      obf_u0426_u220e = 0.5F;
      obf_u00c9_u220e = 0.5F;
   }


   public static record AimFrame(float yawDelta, float pitchDelta) {
      public float yawDelta() {
         return this.getYawDeltaInternal();
      }

      public float pitchDelta() {
         return this.getPitchDeltaInternal();
      }

      private float getYawDeltaInternal() {
         return this.yawDelta;
      }

      private float getPitchDeltaInternal() {
         return this.pitchDelta;
      }

   }

   public static record RotationSpeeds(float yaw, float pitch, float returnSpeed) {
      public float yaw() {
         return this.getYawInternal();
      }

      public float pitch() {
         return this.getPitchInternal();
      }

      public float returnSpeed() {
         return this.getReturnSpeedInternal();
      }

      private float getYawInternal() {
         return this.yaw;
      }

      private float getPitchInternal() {
         return this.pitch;
      }

      private float getReturnSpeedInternal() {
         return this.returnSpeed;
      }

   }

   public static record AimTrailPoint(float x, float y, float shake, long createdAt) {
      public float x() {
         return this.getXInternal();
      }

      public float y() {
         return this.getYInternal();
      }

      public float shake() {
         return this.getShakeInternal();
      }

      public long createdAt() {
         return this.getCreatedAtInternal();
      }

      private float getXInternal() {
         return this.x;
      }

      private float getYInternal() {
         return this.y;
      }

      private float getShakeInternal() {
         return this.shake;
      }

      private long getCreatedAtInternal() {
         return this.createdAt;
      }

   }
}
