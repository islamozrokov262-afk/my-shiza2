package atheryx.neuro;

import atheryx.command.CommandFeedback;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_124;
import net.minecraft.class_310;

public final class NeuroCommand {
   public static final String COMMAND = "neuro";
   private static String obf_u0438_u03b2;

   private NeuroCommand() {
   }

   public static boolean execute(String input) {
      String commandLine = input.trim();
      if (!matchesCommand(commandLine)) {
         return false;
      } else {
         String[] arguments = commandLine.split("\\s+");
         if (arguments.length >= 2 && arguments.length <= 3) {
            String action = arguments[1].toLowerCase(Locale.ROOT);
            if (isStartAction(action) && arguments.length == 2) {
               showModels();
               return true;
            } else {
               String model = arguments.length == 3 ? arguments[2] : "record";
               if (!NeuroManager.isValidModelName(model)) {
                  CommandFeedback.sendFeedback("Invalid model name. Use letters, numbers, _ or -.", class_124.field_1054);
                  return true;
               } else if (isRecordAction(action)) {
                  startRecording(model);
                  CommandFeedback.sendFeedback("Neuro recording started: " + String.valueOf(model), class_124.field_1060);
                  return true;
               } else if (isStartAction(action)) {
                  if (NeuroManager.load(model)) {
                     CommandFeedback.sendFeedback("Neuro model loaded: " + String.valueOf(model) + ". Select Neuro rotation in AttackAura.", class_124.field_1060);
                  } else {
                     CommandFeedback.sendFeedback("Neuro model not found or empty: " + String.valueOf(model), class_124.field_1061);
                  }

                  return true;
               } else {
                  printUsage();
                  return true;
               }
            }
         } else {
            printUsage();
            return true;
         }
      }
   }

   public static List<String> getSuggestions(String input) {
      String commandLine = input.stripLeading().toLowerCase(Locale.ROOT);
      if (!".".equals(commandLine) && (!commandLine.startsWith(".") || !".neuro".startsWith(commandLine))) {
         if (commandLine.startsWith(".") && ".нейро".startsWith(commandLine)) {
            return List.of(".нейро");
         } else if (!commandLine.startsWith(".neuro ") && !commandLine.startsWith(".нейро ")) {
            return List.<String>of();
         } else {
            String prefix = commandLine.startsWith(".нейро ") ? ".нейро " : ".neuro ";
            String tail = commandLine.substring(prefix.length());
            if (isStartAction(tail)) {
               return NeuroManager.listModels().stream().<String>map((name) -> {
                  return prefix + tail + name;
               }).filter((suggestion) -> {
                  return suggestion.toLowerCase(Locale.ROOT).startsWith(commandLine);
               }).toList();
            } else if (!tail.contains(" ")) {
               return List.of(String.valueOf(prefix) + "record", String.valueOf(prefix) + "start", String.valueOf(prefix) + "рекод", String.valueOf(prefix) + "старт").stream().filter((suggestion) -> {
                  return suggestion.substring(prefix.length()).startsWith(tail);
               }).toList();
            } else {
               int actionEnd = tail.indexOf(32);
               String action = actionEnd == -1 ? tail : tail.substring(0, actionEnd);
               return isStartAction(action) ? NeuroManager.listModels().stream().map((name) -> {
                  return prefix + action + name;
               }).filter((suggestion) -> {
                  return suggestion.toLowerCase(Locale.ROOT).startsWith(commandLine);
               }).toList() : List.of();
            }
         }
      } else {
         return List.<String>of(".neuro", ".нейро");
      }
   }

   private static boolean matchesCommand(String input) {
      String lowerInput = input.toLowerCase(Locale.ROOT);
      return lowerInput.equals(".neuro") || lowerInput.startsWith(".neuro ") || lowerInput.equals(".нейро") || lowerInput.startsWith(".нейро ") || lowerInput.equals("neuro") || lowerInput.startsWith("neuro ") || lowerInput.equals("нейро") || lowerInput.startsWith("нейро ");
   }

   private static boolean isRecordAction(String action) {
      return "record".equals(action) || "rec".equals(action) || "recod".equals(action) || "рекорд".equals(action) || "рекод".equals(action) || "запись".equals(action);
   }

   private static boolean isStartAction(String action) {
      return "start".equals(action) || "старт".equals(action) || "запуск".equals(action);
   }

   private static void startRecording(String model) {
      obf_u0438_u03b2 = model;
   }

   public static void stop() {
      if (obf_u0438_u03b2 != null) {
         class_310 client = class_310.method_1551();
         if (client.field_1724 != null) {
            String model = obf_u0438_u03b2;
            obf_u0438_u03b2 = null;
            client.method_1507(new NeuroTrainingScreen(model));
         }
      }
   }

   private static void printUsage() {
      CommandFeedback.sendFeedback(".neuro record <model> - record a human model", class_124.field_1080);
      CommandFeedback.sendFeedback(".neuro start <model> - load model for AttackAura Neuro", class_124.field_1080);
      CommandFeedback.sendFeedback(".neuro start - show saved models", class_124.field_1080);
   }

   private static void showModels() {
      List<String> models = NeuroManager.listModels();
      if (models.isEmpty()) {
         CommandFeedback.sendFeedback("Neuro model list is empty. Use .neuro record <model> first.", class_124.field_1054);
      } else {
         CommandFeedback.sendFeedback("Neuro models:", class_124.field_1075);

         for(String model : models) {
            CommandFeedback.sendFeedback("- " + String.valueOf(model), class_124.field_1075);
         }

      }
   }

}
