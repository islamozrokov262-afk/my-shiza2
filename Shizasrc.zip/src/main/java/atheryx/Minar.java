package atheryx;

import atheryx.command.MinarClientCommands;
import atheryx.event.EventBus;
import atheryx.event.EventManager;
import atheryx.gui.ThemeManager;
import atheryx.manager.AltManager;
import atheryx.manager.ConfigManager;
import atheryx.module.FunctionManager;
import atheryx.module.render.BlockOverlay;
import atheryx.module.render.ChinaHat;
import atheryx.module.render.EntityESP;
import atheryx.module.render.FireFly;
import atheryx.module.render.HitWave;
import atheryx.module.render.JumpCircles;
import atheryx.module.render.Particles;
import atheryx.module.render.Predictions;
import atheryx.module.render.ShaderSky;
import atheryx.module.render.TargetESP;
import atheryx.module.world.AresFarm;
import atheryx.module.world.TrapViewer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;

public class Minar implements ClientModInitializer {
   public void onInitializeClient() {
      ThemeManager.init();
      AltManager.init();
      FunctionManager.init();
      ConfigManager.init();
      MinarClientCommands.init();
      WorldRenderEvents.START_MAIN.register(ShaderSky::onWorldRenderStart);
      WorldRenderEvents.END_MAIN.register(Particles::onWorldRender);
      WorldRenderEvents.END_MAIN.register(FireFly::onWorldRender);
      WorldRenderEvents.END_MAIN.register(JumpCircles::onWorldRender);
      WorldRenderEvents.END_MAIN.register(TargetESP::onWorldRender);
      WorldRenderEvents.END_MAIN.register(BlockOverlay::onWorldRender);
      WorldRenderEvents.END_MAIN.register(Predictions::onWorldRender);
      WorldRenderEvents.END_MAIN.register(EntityESP::onWorldRender);
      WorldRenderEvents.END_MAIN.register(HitWave::onWorldRender);
      WorldRenderEvents.END_MAIN.register(AresFarm::onWorldRender);
      WorldRenderEvents.END_MAIN.register(TrapViewer::onWorldRender);
      WorldRenderEvents.END_MAIN.register(ChinaHat::onWorldRender);
      WorldRenderEvents.BEFORE_BLOCK_OUTLINE.register((WorldRenderEvents.BeforeBlockOutline)(context, outlineRenderState) -> BlockOverlay.shouldRenderBlockOutline());
      EventBus.register(new EventManager());
   }
}
