package atheryx.setting.impl;

import atheryx.setting.Setting;
import lombok.Generated;
import org.lwjgl.glfw.GLFW;

public class KeybindSetting extends Setting {
   private static final int obf_u00d7_u220e = 1000;
   int keybind;
   private boolean mouseDown;

   public KeybindSetting(String name, int keybind) {
      super(name);
      this.writeKeybind(keybind);
   }

   public static int mouseButtonToKey(int button) {
      return 1000 + button;
   }

   public static boolean isMouseBinding(int keybind) {
      return keybind >= 1000;
   }

   public static int keyToMouseButton(int keybind) {
      return keybind - 1000;
   }

   public static boolean isSupportedMouseButton(int button) {
      return button == 2 || button == 3 || button == 4;
   }

   public boolean matchesKey(int key) {
      return this.readKeybind() > 0 && !isMouseBinding(this.readKeybind()) && this.readKeybind() == key;
   }

   public boolean consumeMouseClick(long windowHandle) {
      if (!isMouseBinding(this.readKeybind())) {
         this.writeMouseDown(false);
         return false;
      } else {
         boolean down = GLFW.glfwGetMouseButton(windowHandle, keyToMouseButton(this.readKeybind())) == 1;
         boolean clicked = down && !this.readMouseDown();
         this.writeMouseDown(down);
         return clicked;
      }
   }

   @Generated
   public int getKeybind() {
      return this.readKeybind();
   }

   @Generated
   public void setKeybind(int keybind) {
      this.writeKeybind(keybind);
   }

   private int readKeybind() {
      return this.keybind;
   }

   private void writeKeybind(int var1) {
      this.keybind = var1;
   }

   private boolean readMouseDown() {
      return this.mouseDown;
   }

   private void writeMouseDown(boolean var1) {
      this.mouseDown = var1;
   }

}
