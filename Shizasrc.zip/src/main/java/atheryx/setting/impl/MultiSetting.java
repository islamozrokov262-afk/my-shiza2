package atheryx.setting.impl;

import atheryx.setting.Setting;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import lombok.Generated;

public class MultiSetting extends Setting {
   private final Map<String, Boolean> selectionByOption = new HashMap<String, Boolean>();
   private final List<String> selectedOptions = new ArrayList<String>();
   private final List<String> options = new ArrayList<String>();
   private Runnable changeListener;

   public MultiSetting(String name, String... defaultOptions) {
      super(name);

      for(String opt : defaultOptions) {
         this.readSelectionByOption().put(opt, true);
         this.readSelectedOptions().add(opt);
         this.readOptions().add(opt);
      }

   }

   public boolean isSelected(String option) {
      return (Boolean)this.readSelectionByOption().getOrDefault(option, false);
   }

   public void toggleOption(String option) {
      if (this.readSelectionByOption().containsKey(option)) {
         boolean value = !(Boolean)this.readSelectionByOption().get(option);
         this.readSelectionByOption().put(option, value);
         if (value && !this.readSelectedOptions().contains(option)) {
            this.readSelectedOptions().add(option);
         } else if (!value) {
            this.readSelectedOptions().remove(option);
         }

         this.notifyChanged();
      }

   }

   public void setSelectedOptions(Set<String> enabledOptions) {
      this.readSelectedOptions().clear();

      for(String option : this.readOptions()) {
         boolean value = enabledOptions.contains(option);
         this.readSelectionByOption().put(option, value);
         if (value) {
            this.readSelectedOptions().add(option);
         }
      }

      this.notifyChanged();
   }

   public void setChangeListener(Runnable runnable) {
      this.writeChangeListener(runnable);
      this.notifyChanged();
   }

   private void notifyChanged() {
      if (this.readChangeListener() != null) {
         this.readChangeListener().run();
      }

   }

   @Generated
   public List<String> getSelectedOptions() {
      return this.readSelectedOptions();
   }

   @Generated
   public List<String> getOptions() {
      return this.readOptions();
   }

   private Map<String, Boolean> readSelectionByOption() {
      return this.selectionByOption;
   }

   private List<String> readSelectedOptions() {
      return this.selectedOptions;
   }

   private List<String> readOptions() {
      return this.options;
   }

   private Runnable readChangeListener() {
      return this.changeListener;
   }

   private void writeChangeListener(Runnable var1) {
      this.changeListener = var1;
   }

}
