package atheryx.setting.impl;

public class ListSetting extends ModeSetting {
   public ListSetting(String name, String... modes) {
      super(name, modes);
   }

}
