package atheryx.setting.impl;

import atheryx.setting.Setting;
import java.awt.Color;
import lombok.Generated;

public class ColorSetting extends Setting {
   Color color;

   public ColorSetting(String name, Color color) {
      super(name);
      this.writeColor(color);
   }

   @Generated
   public Color getColor() {
      return this.readColor();
   }

   @Generated
   public void setColor(Color color) {
      this.writeColor(color);
   }

   private Color readColor() {
      return this.color;
   }

   private void writeColor(Color var1) {
      this.color = var1;
   }

}
