package atheryx.setting.impl;

public class MultiListSetting extends MultiSetting {
   public MultiListSetting(String name, String... options) {
      super(name, options);
   }

}
