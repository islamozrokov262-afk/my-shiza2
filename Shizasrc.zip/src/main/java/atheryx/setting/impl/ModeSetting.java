package atheryx.setting.impl;

import atheryx.setting.Setting;
import java.util.Arrays;
import java.util.List;
import lombok.Generated;

public class ModeSetting extends Setting {
   private String value;
   private final List<String> options;
   private Runnable changeListener;

   public ModeSetting(String name, String... modes) {
      super(name);
      this.options = Arrays.<String>asList(modes);
      this.writeValue(modes[0]);
   }

   public void setValue(String mode) {
      if (this.readOptions().contains(mode)) {
         this.writeValue(mode);
         if (this.readChangeListener() != null) {
            this.readChangeListener().run();
         }
      }

   }

   public boolean isSelected(String mode) {
      return this.readValue().equalsIgnoreCase(mode);
   }

   public void setChangeListener(Runnable runnable) {
      this.writeChangeListener(runnable);
      runnable.run();
   }

   @Generated
   public String getValue() {
      return this.readValue();
   }

   @Generated
   public List<String> getOptions() {
      return this.readOptions();
   }

   private String readValue() {
      return this.value;
   }

   private void writeValue(String var1) {
      this.value = var1;
   }

   private List readOptions() {
      return this.options;
   }

   private Runnable readChangeListener() {
      return this.changeListener;
   }

   private void writeChangeListener(Runnable var1) {
      this.changeListener = var1;
   }

}
