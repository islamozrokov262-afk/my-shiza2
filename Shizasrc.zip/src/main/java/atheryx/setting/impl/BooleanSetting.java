package atheryx.setting.impl;

import atheryx.setting.Setting;
import lombok.Generated;

public class BooleanSetting extends Setting {
   private boolean value;
   private Runnable changeListener;

   public BooleanSetting(String name, boolean enabled) {
      super(name);
      this.writeValue(enabled);
   }

   public void setEnabled(boolean enabled) {
      this.writeValue(enabled);
      if (this.readChangeListener() != null) {
         this.readChangeListener().run();
      }

   }

   public void setChangeListener(Runnable runnable) {
      this.writeChangeListener(runnable);
      runnable.run();
   }

   @Generated
   public boolean isEnabled() {
      return this.readValue();
   }

   private boolean readValue() {
      return this.value;
   }

   private void writeValue(boolean var1) {
      this.value = var1;
   }

   private Runnable readChangeListener() {
      return this.changeListener;
   }

   private void writeChangeListener(Runnable var1) {
      this.changeListener = var1;
   }

}
