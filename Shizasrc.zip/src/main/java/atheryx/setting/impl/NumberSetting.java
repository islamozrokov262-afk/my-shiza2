package atheryx.setting.impl;

import atheryx.setting.Setting;
import java.util.function.DoubleSupplier;
import lombok.Generated;

public class NumberSetting extends Setting {
   private double value;
   private double min;
   private double max;
   private double step;
   private Runnable changeListener;

   public NumberSetting(String name, double defaultValue, double min, double max, double step) {
      super(name);
      this.writeValue(Math.clamp(defaultValue, min, max));
      this.writeMin(min);
      this.writeMax(max);
      this.writeStep(step);
   }

   public NumberSetting(String name, double defaultValue, DoubleSupplier min, DoubleSupplier max, double step) {
      super(name);
      this.writeValue(Math.clamp(defaultValue, min.getAsDouble(), max.getAsDouble()));
      this.writeMin(min.getAsDouble());
      this.writeMax(max.getAsDouble());
      this.writeStep(step);
   }

   public void setValue(double value) {
      this.writeValue(Math.clamp(value, this.readMin(), this.readMax()));
      if (this.readChangeListener() != null) {
         this.readChangeListener().run();
      }

   }

   public void setChangeListener(Runnable runnable) {
      this.writeChangeListener(runnable);
      runnable.run();
   }

   @Generated
   public double getValue() {
      return this.readValue();
   }

   @Generated
   public double getMin() {
      return this.readMin();
   }

   @Generated
   public double getMax() {
      return this.readMax();
   }

   @Generated
   public double getStep() {
      return this.readStep();
   }

   @Generated
   public void setMin(double min) {
      this.writeMin(min);
   }

   @Generated
   public void setMax(double max) {
      this.writeMax(max);
   }

   @Generated
   public void setStep(double step) {
      this.writeStep(step);
   }

   private double readValue() {
      return this.value;
   }

   private void writeValue(double var1) {
      this.value = var1;
   }

   private double readMin() {
      return this.min;
   }

   private void writeMin(double var1) {
      this.min = var1;
   }

   private double readMax() {
      return this.max;
   }

   private void writeMax(double var1) {
      this.max = var1;
   }

   private double readStep() {
      return this.step;
   }

   private void writeStep(double var1) {
      this.step = var1;
   }

   private Runnable readChangeListener() {
      return this.changeListener;
   }

   private void writeChangeListener(Runnable var1) {
      this.changeListener = var1;
   }

}
