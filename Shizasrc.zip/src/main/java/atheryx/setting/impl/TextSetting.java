package atheryx.setting.impl;

import atheryx.setting.Setting;
import lombok.Generated;

public class TextSetting extends Setting {
   private String text;
   private boolean editing;
   private final int maxLength;

   public TextSetting(String name, String defaultValue) {
      this(name, defaultValue, 96);
   }

   public TextSetting(String name, String defaultValue, int maxLength) {
      super(name);
      this.maxLength = Math.max(1, maxLength);
      this.setText(defaultValue);
   }

   public void setText(String value) {
      String sanitized = value == null ? "" : value.replace('\n', ' ').replace('\r', ' ');
      this.writeText(sanitized.length() > this.readMaxLength() ? sanitized.substring(0, this.readMaxLength()) : sanitized);
   }

   public void setEditing(boolean editing) {
      this.writeEditing(editing);
   }

   public void appendCharacter(char chr) {
      if (this.readText().length() < this.readMaxLength() && !Character.isISOControl(chr)) {
         String var10001 = this.readText();
         this.setText(var10001 + chr);
      }
   }

   public void appendText(String text) {
      if (text != null && !text.isEmpty()) {
         for(int i = 0; i < text.length(); ++i) {
            this.appendCharacter(text.charAt(i));
         }

      }
   }

   public void backspace() {
      if (!this.readText().isEmpty()) {
         this.writeText(this.readText().substring(0, this.readText().length() - 1));
      }

   }

   @Generated
   public String getText() {
      return this.readText();
   }

   @Generated
   public boolean isEditing() {
      return this.readEditing();
   }

   @Generated
   public int getMaxLength() {
      return this.readMaxLength();
   }

   private String readText() {
      return this.text;
   }

   private void writeText(String var1) {
      this.text = var1;
   }

   private boolean readEditing() {
      return this.editing;
   }

   private void writeEditing(boolean var1) {
      this.editing = var1;
   }

   private int readMaxLength() {
      return this.maxLength;
   }

}
