package atheryx.setting;

import lombok.Generated;

public class Setting {
   String name;
   boolean visible;

   public Setting(String name) {
      this.setNameInternal(name);
      this.setVisibleInternal(true);
   }

   @Generated
   public String getName() {
      return this.getNameInternal();
   }

   @Generated
   public boolean isVisible() {
      return this.getVisibleInternal();
   }

   @Generated
   public void setVisible(boolean visible) {
      this.setVisibleInternal(visible);
   }

   private String getNameInternal() {
      return this.name;
   }

   private void setNameInternal(String var1) {
      this.name = var1;
   }

   private boolean getVisibleInternal() {
      return this.visible;
   }

   private void setVisibleInternal(boolean var1) {
      this.visible = var1;
   }

}
