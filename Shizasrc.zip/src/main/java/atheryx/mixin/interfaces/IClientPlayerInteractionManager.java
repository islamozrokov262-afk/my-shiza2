package atheryx.mixin.interfaces;

import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_636.class})
public interface IClientPlayerInteractionManager {
   @Accessor("field_3716")
   void setBlockBreakingCooldown(int var1);
}
