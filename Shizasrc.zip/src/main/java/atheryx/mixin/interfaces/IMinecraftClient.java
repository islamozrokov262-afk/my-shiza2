package atheryx.mixin.interfaces;

import net.minecraft.class_310;
import net.minecraft.class_320;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_310.class})
public interface IMinecraftClient {
   @Accessor("field_1752")
   void setItemUseCooldown(int var1);

   @Invoker("method_1536")
   boolean invokeDoAttack();

   @Invoker("method_1583")
   void invokeDoItemUse();

   @Accessor("field_1726")
   @Mutable
   void setSession(class_320 var1);
}
