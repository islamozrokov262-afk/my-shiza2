package atheryx.mixin.interfaces;

import com.mojang.brigadier.suggestion.Suggestions;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_342;
import net.minecraft.class_4717;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_4717.class})
public interface IChatInputSuggestor {
   @Accessor("field_21599")
   class_342 minar$getTextField();

   @Accessor("field_21611")
   void minar$setPendingSuggestions(CompletableFuture<Suggestions> var1);
}
