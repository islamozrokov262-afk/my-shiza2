package atheryx.mixin.interfaces;

import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_7172.class})
public interface ISimpleOption {
   @Accessor("field_37868")
   void minar$setValue(Object var1);

   @Accessor("field_37868")
   Object minar$getValue();
}
