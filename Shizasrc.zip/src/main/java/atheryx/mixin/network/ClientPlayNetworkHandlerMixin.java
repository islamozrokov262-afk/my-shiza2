package atheryx.mixin.network;

import atheryx.event.EventBus;
import atheryx.event.impl.EntityStatusEvent;
import atheryx.event.impl.GameMessageEvent;
import atheryx.module.movement.GrimExploit;
import net.minecraft.class_2663;
import net.minecraft.class_2708;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_7439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_634.class})
public class ClientPlayNetworkHandlerMixin {
   @Inject(
      method = {"method_11157"},
      at = {@At("HEAD")}
   )
   private void minar$beginGrimExploitVisualCorrection(class_2708 packet, CallbackInfo ci) {
      GrimExploit grimExploit = GrimExploit.resolveGrimExploit();
      if (grimExploit != null) {
         grimExploit.refreshTarget();
      }

   }

   @Inject(
      method = {"method_11157"},
      at = {@At("TAIL")}
   )
   private void minar$endGrimExploitVisualCorrection(class_2708 packet, CallbackInfo ci) {
      GrimExploit grimExploit = GrimExploit.resolveGrimExploit();
      if (grimExploit != null) {
         grimExploit.updateRotation();
      }

   }

   @Inject(
      method = {"method_43596"},
      at = {@At("HEAD")}
   )
   private void onGameMessage(class_7439 packet, CallbackInfo ci) {
      EventBus.post(new GameMessageEvent(packet));
   }

   @Inject(
      method = {"method_11148"},
      at = {@At("HEAD")}
   )
   private void onEntityStatus(class_2663 packet, CallbackInfo ci) {
      class_634 handler = (class_634)(Object)this;
      class_638 world = handler.method_2890();
      if (world != null) {
         EventBus.post(new EntityStatusEvent(packet, packet.method_11469(world)));
      }
   }
}
