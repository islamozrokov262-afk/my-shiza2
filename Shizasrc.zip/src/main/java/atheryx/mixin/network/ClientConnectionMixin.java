package atheryx.mixin.network;

import atheryx.event.EventManager;
import atheryx.event.impl.PacketReceiveEvent;
import atheryx.event.impl.PacketSendEvent;
import atheryx.manager.RotationManager;
import io.netty.channel.ChannelHandlerContext;
import java.lang.reflect.Method;
import net.minecraft.class_1268;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2886;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_2535.class})
public class ClientConnectionMixin {
   @ModifyVariable(
      method = {"method_10743"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private class_2596<?> onSendModify(class_2596<?> packet) {
      if (RotationManager.isRotating() && packet instanceof class_2886 interactItem) {
         try {
            return new class_2886(interactItem.method_12551(), interactItem.method_42081(), RotationManager.getCurrentRotation().yaw(), RotationManager.getCurrentRotation().pitch());
         } catch (NoSuchMethodError var9) {
            try {
               Method handMethod = interactItem.getClass().getMethod("hand");
               Method seqMethod = interactItem.getClass().getMethod("sequence");
               class_1268 hand = (class_1268)handMethod.invoke(interactItem);
               int sequence = (Integer)seqMethod.invoke(interactItem);
               return new class_2886(hand, sequence, RotationManager.getCurrentRotation().yaw(), RotationManager.getCurrentRotation().pitch());
            } catch (Exception ex) {
               ex.printStackTrace();
            }
         }
      }

      return packet;
   }

   @Inject(
      method = {"method_10743"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onSend(class_2596<?> packet, CallbackInfo ci) {
      PacketSendEvent event = new PacketSendEvent(packet);
      EventManager.post(event);
      if (event.isCancelled()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_10770"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onReceive(ChannelHandlerContext channelHandlerContext, class_2596<?> packet, CallbackInfo ci) {
      PacketReceiveEvent event = new PacketReceiveEvent(packet);
      EventManager.post(event);
      if (event.isCancelled()) {
         ci.cancel();
      }

   }
}
