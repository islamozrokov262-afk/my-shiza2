package atheryx.mixin.network;

import net.minecraft.class_2886;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_2886.class})
public interface PlayerInteractItemC2SPacketMixin {
   @Mutable
   @Accessor("field_51930")
   void setYaw(float var1);

   @Mutable
   @Accessor("field_51931")
   void setPitch(float var1);
}
