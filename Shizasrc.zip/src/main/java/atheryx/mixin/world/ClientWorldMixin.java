package atheryx.mixin.world;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_638.class})
public class ClientWorldMixin {
   @Inject(
      method = {"method_16109"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onScheduleBlockRerenderIfNeeded(class_2338 pos, class_2680 old, class_2680 updated, CallbackInfo ci) {
      if (class_310.method_1551().field_1687 != (Object)this) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_8413"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onUpdateListeners(class_2338 pos, class_2680 oldState, class_2680 newState, int flags, CallbackInfo ci) {
      if (class_310.method_1551().field_1687 != (Object)this) {
         ci.cancel();
      }

   }
}
