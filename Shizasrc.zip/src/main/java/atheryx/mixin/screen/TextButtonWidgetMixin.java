package atheryx.mixin.screen;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_4185.class_12231.class})
public class TextButtonWidgetMixin {
   @Inject(
      method = {"method_75752"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void atheryx$drawBoldTitleButton(class_332 context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
      if (class_310.method_1551().field_1755 instanceof class_442) {
         ci.cancel();
      }
   }
}
