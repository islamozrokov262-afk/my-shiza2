package atheryx.mixin.screen;

import atheryx.command.DotCommandSuggestions;
import atheryx.mixin.interfaces.IChatInputSuggestor;
import com.mojang.brigadier.suggestion.Suggestions;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_342;
import net.minecraft.class_4717;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_4717.class})
public abstract class ChatInputSuggestorMixin {
   @Shadow
   public abstract void method_23920(boolean var1);

   @Shadow
   public abstract void method_44931();

   @Inject(
      method = {"method_23934"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$refreshDotCommands(CallbackInfo ci) {
      IChatInputSuggestor accessor = (IChatInputSuggestor)this;
      class_342 textField = accessor.minar$getTextField();
      String input = textField.method_1882();
      if (input.startsWith(".")) {
         this.method_44931();
         CompletableFuture<Suggestions> pendingSuggestions = DotCommandSuggestions.getSuggestions(input, textField.method_1881());
         accessor.minar$setPendingSuggestions(pendingSuggestions);
         if (pendingSuggestions.isDone()) {
            this.method_23920(false);
         } else {
            pendingSuggestions.thenRun(() -> this.method_23920(false));
         }

         ci.cancel();
      }
   }
}
