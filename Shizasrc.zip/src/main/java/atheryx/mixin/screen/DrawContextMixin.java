package atheryx.mixin.screen;

import atheryx.gui.TitleScreenMenuRenderer;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_332.class})
public class DrawContextMixin {
   @Inject(
      method = {"method_25303"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void atheryx$hideTitleAccountString(class_327 textRenderer, String text, int x, int y, int color, CallbackInfo ci) {
      if (TitleScreenMenuRenderer.isAccountWidgetText(text)) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_27535"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void atheryx$hideTitleAccountText(class_327 textRenderer, class_2561 text, int x, int y, int color, CallbackInfo ci) {
      if (TitleScreenMenuRenderer.isAccountWidgetText(text.getString())) {
         ci.cancel();
      }

   }
}
