package atheryx.mixin.screen;

import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({class_465.class})
public class HandledScreenMixin {
}
