package atheryx.mixin.screen;

import atheryx.gui.TitleScreenMenuRenderer;
import atheryx.gui.screen.AltManagerScreen;
import atheryx.render.pipeline.TitleBackgroundPipeline;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_7077;
import net.minecraft.class_8020;
import net.minecraft.class_8519;
import net.minecraft.class_8662;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_442.class})
public abstract class TitleScreenMixin extends class_437 {
   protected TitleScreenMixin(class_2561 title) {
      super(title);
   }

   @Redirect(
      method = {"method_25394"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_442;method_57728(Lnet/minecraft/class_332;F)V"
)
   )
   private void atheryx$renderCustomBackground(class_442 screen, class_332 context, float deltaTicks) {
      TitleBackgroundPipeline.render();
   }

   @Inject(
      method = {"method_25394"},
      at = {@At("HEAD")}
   )
   private void atheryx$captureContext(class_332 context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
      TitleScreenMenuRenderer.hideVanillaButtons((class_442)(Object)this);
      TitleScreenMenuRenderer.setDrawContext(context);
   }

   @Inject(
      method = {"method_25426"},
      at = {@At("RETURN")}
   )
   private void atheryx$layoutButtons(CallbackInfo ci) {
      class_442 screen = (class_442)(Object)this;
      List<class_4185.class_12231> buttons = new ArrayList<class_4185.class_12231>();
      TitleScreenMenuRenderer.hideVanillaButtons(screen);

      for(class_364 element : screen.method_25396()) {
         if (element instanceof class_8662 iconButton) {
            iconButton.field_22764 = false;
            iconButton.field_22763 = false;
         } else if (element instanceof class_7077 textWidget) {
            textWidget.field_22764 = false;
            textWidget.field_22763 = false;
         } else if (element instanceof class_4185.class_12231 textButton) {
            buttons.add(textButton);
         }
      }

      int centerX = screen.field_22789 / 2;
      int size = 42;
      int gap = 13;
      int y = screen.field_22790 / 4 + 118;
      class_4185 altManagerBtn = class_4185.method_46430(class_2561.method_43470("Открыть альтменеджер"), (btn) -> class_310.method_1551().method_1507(new AltManagerScreen(screen))).method_46434(0, 0, size, size).method_46431();
      this.method_37063(altManagerBtn);
      List<class_4185> layoutButtons = new ArrayList<class_4185>();
      if (buttons.size() >= 5) {
         layoutButtons.add((class_4185)buttons.get(0));
         layoutButtons.add((class_4185)buttons.get(1));
         layoutButtons.add(altManagerBtn);
         layoutButtons.add((class_4185)buttons.get(3));
         layoutButtons.add((class_4185)buttons.get(4));
         (buttons.get(2)).field_22764 = false;
         (buttons.get(2)).field_22763 = false;
      } else {
         layoutButtons.add(altManagerBtn);
      }

      int rowWidth = size * layoutButtons.size() + gap * (layoutButtons.size() - 1);
      int x = centerX - rowWidth / 2;

      for(int i = 0; i < layoutButtons.size(); ++i) {
         ((class_4185)layoutButtons.get(i)).method_55444(size, size, x + (size + gap) * i, y);
      }

   }

   @Redirect(
      method = {"method_25394"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_8020;method_48209(Lnet/minecraft/class_332;IF)V"
)
   )
   private void atheryx$hideMinecraftLogo(class_8020 logoDrawer, class_332 context, int screenWidth, float alpha) {
   }

   @Redirect(
      method = {"method_25394"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_8519;method_51453(Lnet/minecraft/class_332;ILnet/minecraft/class_327;F)V"
)
   )
   private void atheryx$hideSplashText(class_8519 splashText, class_332 context, int screenWidth, class_327 textRenderer, float alpha) {
   }

   @Redirect(
      method = {"method_25394"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_332;method_25303(Lnet/minecraft/class_327;Ljava/lang/String;III)V"
)
   )
   private void atheryx$hideVersionText(class_332 context, class_327 textRenderer, String text, int x, int y, int color) {
   }
}
