package atheryx.mixin.screen;

import atheryx.command.CommandManager;
import net.minecraft.class_310;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_408.class})
public class ChatScreenMixin {
   @Inject(
      method = {"method_44056"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$handleCommand(String chatText, boolean addToHistory, CallbackInfo ci) {
      if (CommandManager.execute(chatText)) {
         class_310 client = class_310.method_1551();
         if (addToHistory) {
            client.field_1705.method_1743().method_1803(chatText.trim());
         }

         ci.cancel();
      }
   }
}
