package atheryx.mixin.screen;

import atheryx.render.RenderUtil;
import java.awt.Color;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4264;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_4264.class})
public class PressableWidgetMixin {
   @Inject(
      method = {"method_75794"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void atheryx$drawLiquidGlassButton(class_332 context, CallbackInfo ci) {
      if (class_310.method_1551().field_1755 instanceof class_442) {
         class_339 widget = (class_339)(Object)this;
         float alpha = widget.method_75798();
         this.atheryx$drawGlassButton(widget, alpha);
         ci.cancel();
      }
   }

   private void atheryx$drawGlassButton(class_339 widget, float alpha) {
      float x = (float)widget.method_46426();
      float y = (float)widget.method_46427();
      float width = (float)widget.method_25368();
      float height = (float)widget.method_25364();
      boolean selected = widget.method_25367();
      float radius = 4.0F;
      Color tint = selected ? new Color(255, 255, 255, Math.round(130.0F * alpha)) : new Color(210, 218, 225, Math.round(92.0F * alpha));
      RenderUtil.drawShadow(x + 0.5F, y + 1.2F, width - 1.0F, height - 0.4F, radius, 9.0F, 0.28F * alpha, 2.2F, new Color(0, 0, 0, 170));
      RenderUtil.drawRoundedRect(x, y, width, height, radius, new Color(18, 22, 28, Math.round((selected ? 128.0F : 96.0F) * alpha)));
      RenderUtil.drawFluidGlass(x, y, width, height, radius, selected ? 1.0F : 0.9F, widget.field_22763 ? 0.94F * alpha : 0.52F * alpha, tint);
      RenderUtil.drawRoundedOutline(x + 0.45F, y + 0.45F, width - 0.9F, height - 0.9F, radius, 0.85F, new Color(255, 255, 255, Math.round((selected ? 128.0F : 76.0F) * alpha)), new Color(255, 255, 255, Math.round(32.0F * alpha)));
      RenderUtil.drawRoundedRect(x + 6.0F, y + 2.0F, width - 12.0F, 1.05F, 0.5F, new Color(255, 255, 255, Math.round((selected ? 74.0F : 48.0F) * alpha)), new Color(255, 255, 255, 0));
   }
}
