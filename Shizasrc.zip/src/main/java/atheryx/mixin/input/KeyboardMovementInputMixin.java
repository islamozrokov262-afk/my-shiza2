package atheryx.mixin.input;

import atheryx.event.EventBus;
import atheryx.event.impl.InputEvent;
import atheryx.manager.RotationManager;
import atheryx.mixin.interfaces.IInput;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_743.class})
public class KeyboardMovementInputMixin {
   @Inject(
      method = {"method_3129"},
      at = {@At("TAIL")}
   )
   private void correctSilentMovement(CallbackInfo ci) {
      IInput accessor = (IInput)((class_744)(Object)this);
      if (RotationManager.usesSilentMoveCorrection()) {
         class_241 movementVector = accessor.getMovementVector();
         class_10185 playerInput = accessor.getPlayerInput();
         class_241 corrected = RotationManager.correctMovementInput(movementVector.field_1342, movementVector.field_1343);
         accessor.setMovementVector(corrected.method_35581());
         accessor.setPlayerInput(new class_10185(corrected.field_1342 > 0.0F, corrected.field_1342 < 0.0F, corrected.field_1343 > 0.0F, corrected.field_1343 < 0.0F, playerInput.comp_3163(), playerInput.comp_3164(), playerInput.comp_3165()));
      }
   }

   @Inject(
      method = {"method_3129"},
      at = {@At("TAIL")}
   )
   private void onInput(CallbackInfo ci) {
      IInput accessor = (IInput)((class_744)(Object)this);
      class_241 movementVector = accessor.getMovementVector();
      class_10185 playerInput = accessor.getPlayerInput();
      InputEvent event = new InputEvent(movementVector.field_1342, movementVector.field_1343, playerInput.comp_3163(), playerInput.comp_3164(), playerInput.comp_3165());
      EventBus.post(event);
      accessor.setMovementVector(new class_241(event.getStrafe(), event.getForward()));
      accessor.setPlayerInput(new class_10185(event.getForward() > 0.0F, event.getForward() < 0.0F, event.getStrafe() > 0.0F, event.getStrafe() < 0.0F, event.isJumping(), event.isSneaking(), event.isSprinting()));
   }
}
