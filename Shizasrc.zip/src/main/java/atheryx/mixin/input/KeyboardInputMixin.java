package atheryx.mixin.input;

import atheryx.event.EventBus;
import atheryx.event.impl.KeyEvent;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_309.class})
public class KeyboardInputMixin {
   @Inject(
      method = {"method_1466"},
      at = {@At("HEAD")}
   )
   private void onKey(long window, int action, class_11908 input, CallbackInfo ci) {
      EventBus.post(new KeyEvent(action, input));
   }
}
