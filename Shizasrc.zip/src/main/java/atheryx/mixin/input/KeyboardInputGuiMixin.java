package atheryx.mixin.input;

import atheryx.event.EventManager;
import atheryx.mixin.interfaces.IKeyBinding;
import atheryx.module.FunctionManager;
import atheryx.module.movement.GuiMove;
import net.minecraft.class_1041;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3675;
import net.minecraft.class_743;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_743.class})
public class KeyboardInputGuiMixin {
   @Inject(
      method = {"method_3129"},
      at = {@At("HEAD")}
   )
   private void forceKeysWhileClickGuiOpen(CallbackInfo ci) {
      class_310 mc = class_310.method_1551();
      if (mc.field_1755 != null && mc.method_22683() != null) {
         if (mc.field_1755 == EventManager.clickGui) {
            forceKeys(mc, true);
         } else {
            GuiMove guiMove = (GuiMove)FunctionManager.getFunction(GuiMove.class);
            if (guiMove == null || !guiMove.isEnabled()) {
               forceKeys(mc, false);
            }
         }
      }
   }

   private static void forceKeys(class_310 mc, boolean pollGlfw) {
      class_1041 window = mc.method_22683();
      class_315 options = mc.field_1690;

      for(class_304 keyBinding : new class_304[]{options.field_1894, options.field_1881, options.field_1913, options.field_1849, options.field_1903, options.field_1832, options.field_1867}) {
         class_3675.class_306 key = ((IKeyBinding)keyBinding).getBoundKey();
         if (key != null) {
            keyBinding.method_23481(pollGlfw && class_3675.method_15987(window, key.method_1444()));
         }
      }

   }
}
