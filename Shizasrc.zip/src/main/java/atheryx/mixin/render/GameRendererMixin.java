package atheryx.mixin.render;

import atheryx.event.EventBus;
import atheryx.event.impl.Render2DEvent;
import atheryx.manager.RotationManager;
import atheryx.module.FunctionManager;
import atheryx.module.render.HandChams;
import atheryx.module.render.NoRender;
import atheryx.render.pipeline.HudBlurPipeline;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_4587;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_757.class})
public abstract class GameRendererMixin {
   @Unique
   private boolean minar$capturingChamsHand;

   @Shadow
   private void method_3172(float tickProgress, boolean sleeping, Matrix4f positionMatrix) {
   }

   @Inject(
      method = {"method_3192"},
      at = {@At("RETURN")}
   )
   private void render(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
      RotationManager.updateRenderRotation(tickCounter.method_60637(true));
      HudBlurPipeline.markSceneDirty();
      EventBus.post(new Render2DEvent(tickCounter));
   }

   @Inject(
      method = {"method_3172"},
      at = {@At("RETURN")}
   )
   private void minar$drawChamsHandPost(float tickProgress, boolean sleeping, Matrix4f positionMatrix, CallbackInfo ci) {
      HandChams chams = (HandChams)FunctionManager.getFunction(HandChams.class);
      if (chams != null && chams.isFeatureActive() && !this.minar$capturingChamsHand) {
         this.minar$capturingChamsHand = true;

         try {
            chams.refreshTarget(() -> this.method_3172(tickProgress, sleeping, positionMatrix));
         } finally {
            this.minar$capturingChamsHand = false;
         }

         chams.applyChamsSettings();
      }
   }

   @Inject(
      method = {"method_3198"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$noRenderHurtCamera(class_4587 matrices, float tickProgress, CallbackInfo ci) {
      if (NoRender.isFeatureActiveCurrent()) {
         ci.cancel();
      }

   }

   @Redirect(
      method = {"method_3188"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_746;method_66279(Lnet/minecraft/class_6880;F)F"
)
   )
   private float minar$noRenderNauseaProjection(class_746 player, class_6880<class_1291> effect, float tickProgress) {
      return NoRender.isFeatureActivePrimary() && effect == class_1294.field_5916 ? 0.0F : player.method_66279(effect, tickProgress);
   }
}
