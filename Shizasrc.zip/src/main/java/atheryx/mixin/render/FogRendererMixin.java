package atheryx.mixin.render;

import atheryx.module.render.Fog;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_758;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_758.class})
public class FogRendererMixin {
   @Inject(
      method = {"method_62185"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void applyFogColor(class_4184 camera, float tickProgress, class_638 world, int viewDistance, float skyDarkness, CallbackInfoReturnable<Vector4f> cir) {
      cir.setReturnValue(Fog.calculateFogColor(camera, (Vector4f)cir.getReturnValue()));
   }
}
