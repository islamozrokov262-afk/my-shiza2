package atheryx.mixin.render;

import atheryx.module.render.NameTags;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1007.class})
public class PlayerEntityRendererMixin {
   @Inject(
      method = {"method_4213"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$hideVanillaPlayerNameTags(class_10055 state, class_4587 matrices, class_11659 queue, class_12075 cameraRenderState, CallbackInfo ci) {
      if (NameTags.Instance != null && NameTags.Instance.isEnabled() && NameTags.Instance.shouldProcess()) {
         ci.cancel();
      }

   }
}
