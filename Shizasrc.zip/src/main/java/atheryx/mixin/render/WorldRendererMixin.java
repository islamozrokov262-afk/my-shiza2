package atheryx.mixin.render;

import net.minecraft.class_761;
import net.minecraft.class_769;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_761.class})
public class WorldRendererMixin {
   @Shadow
   private class_769 field_4112;

   @Inject(
      method = {"method_18146"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onScheduleBlockRenders(int minX, int minY, int minZ, int maxX, int maxY, int maxZ, CallbackInfo ci) {
      if (this.field_4112 == null) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_8571"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onScheduleChunkRender(int x, int y, int z, CallbackInfo ci) {
      if (this.field_4112 == null) {
         ci.cancel();
      }

   }
}
