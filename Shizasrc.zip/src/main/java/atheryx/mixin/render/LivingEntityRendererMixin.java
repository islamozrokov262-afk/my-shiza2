package atheryx.mixin.render;

import atheryx.module.FunctionManager;
import atheryx.module.render.ChinaHat;
import atheryx.module.render.EntityESP;
import atheryx.render.ImmediateMaskQueue;
import java.util.List;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1299;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_922;
import net.minecraft.class_9799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_922.class})
public abstract class LivingEntityRendererMixin<S extends class_10042, M extends class_583<? super S>> {
   @Unique
   private static class_4597.class_4598 minar$chamsConsumers;
   @Shadow
   protected M field_4737;
   @Shadow
   protected List<class_3887<S, M>> field_4738;

   @Shadow
   public abstract class_2960 method_3885(S var1);

   @Shadow
   protected abstract boolean method_62483(S var1);

   @Inject(
      method = {"method_24302"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$hideModelLayer(S state, boolean showBody, boolean translucent, boolean showOutline, CallbackInfoReturnable<class_1921> cir) {
      EntityESP chams = (EntityESP)FunctionManager.getFunction(EntityESP.class);
      if (chams != null && chams.matchesStatePrimary(state)) {
         cir.setReturnValue(null);
      }

   }

   @Inject(
      method = {"method_4054"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_4587;method_22909()V"
)}
   )
   private void minar$renderEntityChams(S state, class_4587 matrices, class_11659 queue, class_12075 cameraRenderState, CallbackInfo ci) {
      EntityESP chams = (EntityESP)FunctionManager.getFunction(EntityESP.class);
      if (chams != null && chams.matchesState(state)) {
         chams.refreshTarget(() -> {
            this.field_4737.method_2819(state);
            if (chams.isFeatureActiveSecondary() && state.field_58171 == class_1299.field_6097) {
               if (minar$chamsConsumers == null) {
                  minar$chamsConsumers = class_4597.method_22991(new class_9799(786432));
               }

               matrices.method_22903();
               float scale = 1.01F;
               matrices.method_22905(scale, scale, scale);
               matrices.method_46416(0.0F, -0.01F, 0.0F);
               class_4588 buffer = minar$chamsConsumers.method_73477(this.field_4737.method_23500(this.method_3885(state)));
               this.field_4737.method_62100(matrices, buffer, state.field_61820, class_922.method_23622(state, 0.0F), -1);
               minar$chamsConsumers.method_22993();
               matrices.method_22909();
            }

            if (chams.isFeatureActive()) {
               class_583 patt0$temp = this.field_4737;
               if (patt0$temp instanceof class_572) {
                  class_572<?> bipedModel = (class_572)patt0$temp;
                  if (EntityESP.skeletonConsumers == null) {
                     EntityESP.skeletonConsumers = class_4597.method_22991(new class_9799(786432));
                  }

                  chams.resetTransientState(matrices, EntityESP.skeletonConsumers, bipedModel, state);
               } else {
                  if (EntityESP.chamsConsumers == null) {
                     EntityESP.chamsConsumers = class_4597.method_22991(new class_9799(786432));
                  }

                  class_4588 buffer = EntityESP.chamsConsumers.method_73477(class_12249.method_75984(this.method_3885(state), false));
                  this.field_4737.method_62100(matrices, buffer, state.field_61820, class_922.method_23622(state, 0.0F), -16777216);
                  if (this.method_62483(state) && !this.field_4738.isEmpty()) {
                     ImmediateMaskQueue maskQueue = new ImmediateMaskQueue(EntityESP.chamsConsumers);

                     for(class_3887<S, M> feature : this.field_4738) {
                        feature.method_4199(matrices, maskQueue, state.field_61820, state, state.field_53447, state.field_53448);
                     }
                  }
               }
            }

         }, state);
         if (chams != null && chams.isFeatureActivePrimary()) {
            class_583 var8 = this.field_4737;
            if (var8 instanceof class_572) {
               class_572<?> bipedModel = (class_572)var8;
               if (EntityESP.skeletonConsumers == null) {
                  EntityESP.skeletonConsumers = class_4597.method_22991(new class_9799(786432));
               }

               chams.prepareInteraction(matrices, EntityESP.skeletonConsumers, bipedModel, state);
            }
         }

      }
   }

   @Inject(
      method = {"method_4054"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_4587;method_22909()V"
)}
   )
   private void minar$renderChinaHat(S state, class_4587 matrices, class_11659 queue, class_12075 cameraRenderState, CallbackInfo ci) {
      ChinaHat chinaHat = (ChinaHat)FunctionManager.getFunction(ChinaHat.class);
      if (chinaHat != null && chinaHat.isEnabled() && state instanceof class_10055 playerState) {
         class_310 mc = class_310.method_1551();
         if (mc.field_1724 != null && playerState.field_53528 == mc.field_1724.method_5628() && !mc.field_1690.method_31044().method_31034()) {
            class_583 var10 = this.field_4737;
            if (var10 instanceof class_572) {
               class_572<?> bipedModel = (class_572)var10;
               chinaHat.updateRotation(matrices, bipedModel);
            }
         }
      }

   }
}
