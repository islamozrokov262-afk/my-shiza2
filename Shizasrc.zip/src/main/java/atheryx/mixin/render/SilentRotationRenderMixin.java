package atheryx.mixin.render;

import atheryx.manager.RotationManager;
import atheryx.module.movement.GrimExploit;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_243;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1007.class})
public class SilentRotationRenderMixin {
   private final class_310 mc = class_310.method_1551();

   @Inject(
      method = {"method_62604"},
      at = {@At("TAIL")}
   )
   private void updateSilentRenderState(class_11890 entity, class_10055 state, float tickProgress, CallbackInfo ci) {
      if (entity == this.mc.field_1724) {
         GrimExploit grimExploit = GrimExploit.resolveGrimExploit();
         if (grimExploit != null && grimExploit.shouldProcess()) {
            class_243 pos = grimExploit.getTargetPositionPrimary(tickProgress);
            state.field_53325 = pos.field_1352;
            state.field_53326 = pos.field_1351;
            state.field_53327 = pos.field_1350;
         }

         if (RotationManager.isRotating()) {
            float yaw = RotationManager.getRenderYaw(state.field_53446);
            state.field_53446 = yaw;
            state.field_53447 = 0.0F;
            state.field_53448 = RotationManager.getRenderPitch(state.field_53448);
         }
      }
   }
}
