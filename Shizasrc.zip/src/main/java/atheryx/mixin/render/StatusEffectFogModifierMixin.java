package atheryx.mixin.render;

import atheryx.module.render.NoRender;
import net.minecraft.class_1297;
import net.minecraft.class_5636;
import net.minecraft.class_7286;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_7286.class})
public class StatusEffectFogModifierMixin {
   @Inject(
      method = {"method_42593"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$noRenderBadEffectFog(class_5636 submersionType, class_1297 entity, CallbackInfoReturnable<Boolean> cir) {
      if (NoRender.isFeatureActivePrimary()) {
         cir.setReturnValue(false);
      }

   }
}
