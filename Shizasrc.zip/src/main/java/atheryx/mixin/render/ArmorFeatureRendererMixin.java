package atheryx.mixin.render;

import atheryx.module.FunctionManager;
import atheryx.module.render.EntityESP;
import net.minecraft.class_10034;
import net.minecraft.class_10042;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_970.class})
public class ArmorFeatureRendererMixin {
   @Inject(
      method = {"method_17157"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$hideArmorWithChams(class_4587 matrices, class_11659 queue, int light, class_10034 state, float limbAngle, float limbDistance, CallbackInfo ci) {
      EntityESP chams = (EntityESP)FunctionManager.getFunction(EntityESP.class);
      if (chams != null && state instanceof class_10042 && chams.matchesStatePrimary(state)) {
         ci.cancel();
      }

   }
}
