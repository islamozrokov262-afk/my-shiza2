package atheryx.mixin.render;

import atheryx.module.misc.FreeCam;
import atheryx.module.movement.GrimExploit;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin({class_4184.class})
public abstract class CameraMixin {
   @Shadow
   private boolean field_18719;

   @ModifyArgs(
      method = {"method_19321"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_4184;method_19325(FF)V"
)
   )
   private void minar$freeCamRotation(Args args) {
      FreeCam freeCam = FreeCam.resolveFreeCam();
      if (freeCam != null && freeCam.isEnabled()) {
         float tickDelta = class_310.method_1551().method_61966().method_60637(true);
         args.set(0, freeCam.calculateAnimationFactorForTarget(tickDelta));
         args.set(1, freeCam.calculateMovementSpeedForTarget(tickDelta));
         this.field_18719 = true;
      }

   }

   @ModifyArgs(
      method = {"method_19321"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_4184;method_19327(DDD)V"
)
   )
   private void minar$freeCamPosition(Args args) {
      FreeCam freeCam = FreeCam.resolveFreeCam();
      class_310 mc = class_310.method_1551();
      if (freeCam != null && freeCam.isEnabled()) {
         float tickDelta = mc.method_61966().method_60637(true);
         args.set(0, freeCam.calculateAnimationFactor(tickDelta));
         args.set(1, freeCam.calculateMovementSpeed(tickDelta));
         args.set(2, freeCam.calculateTargetDistance(tickDelta));
      } else {
         GrimExploit grimExploit = GrimExploit.resolveGrimExploit();
         if (grimExploit != null && grimExploit.shouldProcess()) {
            float tickDelta = mc.method_61966().method_60637(true);
            class_243 pos = grimExploit.getTargetPosition(tickDelta);
            args.set(0, pos.field_1352);
            args.set(1, pos.field_1351);
            args.set(2, pos.field_1350);
         }

      }
   }
}
