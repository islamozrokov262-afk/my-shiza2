package atheryx.mixin.render;

import atheryx.manager.TimerManager;
import it.unimi.dsi.fastutil.floats.FloatUnaryOperator;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_9779.class_9781.class})
public class RenderTickCounterDynamicMixin {
   @Shadow
   private float field_51958;
   @Shadow
   private float field_51959;
   @Shadow
   private long field_51962;
   @Shadow
   private float field_51964;
   @Shadow
   private FloatUnaryOperator field_51965;

   @Inject(
      method = {"method_60639"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void beginRenderTick(long timeMillis, CallbackInfoReturnable<Integer> cir) {
      float timer = TimerManager.getTimerSpeed();
      if (timer != 1.0F) {
         this.field_51958 = (float)(timeMillis - this.field_51962) / this.field_51965.apply(this.field_51964) * timer;
         this.field_51962 = timeMillis;
         this.field_51959 += this.field_51958;
         int ticks = (int)this.field_51959;
         this.field_51959 -= (float)ticks;
         cir.setReturnValue(ticks);
      }
   }
}
