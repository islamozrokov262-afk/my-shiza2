package atheryx.mixin.render;

import net.minecraft.class_355;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({class_355.class})
public class PlayerListHudMixin {
}
