package atheryx.mixin.render;

import atheryx.module.misc.StreamerMode;
import net.minecraft.class_5223;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin({class_5223.class})
public class TextVisitFactoryMixin {
   @ModifyArg(
      method = {"method_27472"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_5223;method_27473(Ljava/lang/String;ILnet/minecraft/class_2583;Lnet/minecraft/class_2583;Lnet/minecraft/class_5224;)Z"
),
      index = 0
   )
   private static String minar$streamerMode(String text) {
      return StreamerMode.resolveText(text);
   }
}
