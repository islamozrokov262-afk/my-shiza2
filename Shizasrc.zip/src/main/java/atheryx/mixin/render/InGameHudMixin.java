package atheryx.mixin.render;

import atheryx.event.EventBus;
import atheryx.event.EventManager;
import atheryx.event.impl.Render2DEvent;
import atheryx.module.render.HUD;
import atheryx.module.render.NoRender;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_636;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_329.class})
public class InGameHudMixin {
   class_310 mc = class_310.method_1551();

   @Inject(
      method = {"method_1753"},
      at = {@At("RETURN")}
   )
   private void renderHud(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      EventBus.post(new Render2DEvent(tickCounter, context));
   }

   @Inject(
      method = {"method_1736"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void renderCrosshair(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      if (this.mc.field_1755 == EventManager.clickGui || NoRender.isFeatureActivePrevious()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_1735"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$noRenderVignette(class_332 context, class_1297 entity, CallbackInfo ci) {
      if (NoRender.isFeatureActive()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_61980"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$noRenderBadEffects(class_332 context, float distortionStrength, CallbackInfo ci) {
      if (NoRender.isFeatureActivePrimary()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_1759"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$cancelDefaultHotbar(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      if (HUD.isFeatureActive()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_1760"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$cancelDefaultStatusBars(class_332 context, CallbackInfo ci) {
      if (HUD.isFeatureActive()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_1765"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$hideDefaultStatusEffectIcons(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      if (HUD.isFeatureActivePrimary()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_1749"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$cancelDefaultHeldItemTooltip(class_332 context, CallbackInfo ci) {
      if (HUD.isFeatureActive()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_70840"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$hideDefaultExperienceBar(CallbackInfoReturnable<Boolean> cir) {
      if (HUD.isFeatureActive()) {
         cir.setReturnValue(false);
      }

   }

   @Redirect(
      method = {"method_70842"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_636;method_2913()Z"
)
   )
   private boolean minar$disableExperienceBarType(class_636 interactionManager) {
      return !HUD.isFeatureActive() && interactionManager.method_2913();
   }

   @Redirect(
      method = {"method_55805"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_636;method_2913()Z"
)
   )
   private boolean minar$disableExperienceLevelText(class_636 interactionManager) {
      return !HUD.isFeatureActive() && interactionManager.method_2913();
   }

   @Inject(
      method = {"method_55803"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$cancelScoreboard(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      if (HUD.isFeatureActiveSecondary()) {
         ci.cancel();
      }

   }
}
