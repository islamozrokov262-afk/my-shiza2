package atheryx.mixin.render;

import atheryx.module.render.Fog;
import net.minecraft.class_11398;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_7285;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_11398.class})
public class AtmosphericFogModifierMixin {
   @Inject(
      method = {"method_42591"},
      at = {@At("RETURN")}
   )
   private void applyFogSettings(class_7285 data, class_4184 camera, class_638 world, float viewDistance, class_9779 renderTickCounter, CallbackInfo ci) {
      Fog.refreshTarget(data);
   }
}
