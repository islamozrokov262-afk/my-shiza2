package atheryx.mixin.render;

import atheryx.gui.TitleScreenMenuRenderer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.class_11228;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_11228.class})
public class GuiRendererMixin {
   @Inject(
      method = {"method_70890"},
      at = {@At("RETURN")}
   )
   private void atheryx$renderTitleScreenButtons(GpuBufferSlice fogBuffer, CallbackInfo ci) {
      TitleScreenMenuRenderer.render();
   }
}
