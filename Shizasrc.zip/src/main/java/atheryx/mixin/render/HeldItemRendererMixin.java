package atheryx.mixin.render;

import atheryx.module.FunctionManager;
import atheryx.module.render.BeautifulHands;
import atheryx.module.render.HandChams;
import atheryx.module.render.SwingAnimations;
import atheryx.module.render.ViewModel;
import atheryx.render.pipeline.ChamsPipeline;
import atheryx.render.pipeline.SmokeHandsRenderer;
import net.minecraft.class_11659;
import net.minecraft.class_12122;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1787;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1839;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_9334;
import org.joml.Quaternionfc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_759.class})
public abstract class HeldItemRendererMixin {
   @Shadow
   private float field_4043;
   @Shadow
   private float field_4053;
   @Unique
   private boolean minar$overrideSwing;
   @Unique
   private float minar$tickProgress;
   @Unique
   private float minar$equipProgress;

   @Shadow
   private void method_3224(class_4587 matrices, class_1306 arm, float equipProgress) {
   }

   @Shadow
   private void method_65816(float swingProgress, class_4587 matrixStack, int i, class_1306 arm) {
   }

   @Shadow
   private void method_3219(class_4587 matrices, class_11659 queue, int light, float equipProgress, float swingProgress, class_1306 arm) {
   }

   @Shadow
   public abstract void method_3233(class_1309 var1, class_1799 var2, class_811 var3, class_4587 var4, class_11659 var5, int var6);

   @Redirect(
      method = {"method_22976"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_4587;method_22907(Lorg/joml/Quaternionfc;)V",
   ordinal = 0
)
   )
   private void minar$skipViewBobPitch(class_4587 matrices, Quaternionfc rotation) {
      ViewModel viewModel = (ViewModel)FunctionManager.getFunction(ViewModel.class);
      if (viewModel == null || !viewModel.isFeatureActive()) {
         matrices.method_22907(rotation);
      }
   }

   @Redirect(
      method = {"method_22976"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_4587;method_22907(Lorg/joml/Quaternionfc;)V",
   ordinal = 1
)
   )
   private void minar$skipViewBobYaw(class_4587 matrices, Quaternionfc rotation) {
      ViewModel viewModel = (ViewModel)FunctionManager.getFunction(ViewModel.class);
      if (viewModel == null || !viewModel.isFeatureActive()) {
         matrices.method_22907(rotation);
      }
   }

   @Inject(
      method = {"method_3228"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_4587;method_22903()V",
   shift = Shift.AFTER
)}
   )
   private void minar$applyViewModel(class_742 player, float tickProgress, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_11659 orderedRenderCommandQueue, int light, CallbackInfo ci) {
      ViewModel viewModel = (ViewModel)FunctionManager.getFunction(ViewModel.class);
      if (viewModel != null) {
         boolean mainHand = hand == class_1268.field_5808;
         class_1306 arm = mainHand ? player.method_6068() : player.method_6068().method_5928();
         viewModel.refreshTarget(matrices, arm);
      }
   }

   @Inject(
      method = {"method_3228"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void minar$captureSwingState(class_742 player, float tickProgress, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_11659 orderedRenderCommandQueue, int light, CallbackInfo ci) {
      HandChams chams = (HandChams)FunctionManager.getFunction(HandChams.class);
      if (chams != null && chams.isFeatureActivePrimary() && !ChamsPipeline.isRenderingMask()) {
         this.minar$overrideSwing = false;
         ci.cancel();
      } else if (this.minar$renderBeautifulHandsCustom(player, tickProgress, hand, swingProgress, item, equipProgress, matrices, orderedRenderCommandQueue, light)) {
         this.minar$overrideSwing = false;
         ci.cancel();
      } else {
         this.minar$tickProgress = tickProgress;
         this.minar$equipProgress = equipProgress;
         this.minar$overrideSwing = this.minar$shouldOverride(player, hand, item);
      }
   }

   @Inject(
      method = {"method_3228"},
      at = {@At("RETURN")}
   )
   private void minar$clearSwingState(class_742 player, float tickProgress, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_11659 orderedRenderCommandQueue, int light, CallbackInfo ci) {
      this.minar$overrideSwing = false;
   }

   @Inject(
      method = {"method_22976"},
      at = {@At("HEAD")}
   )
   private void minar$smokeHandsCaptureBefore(float tickProgress, class_4587 matrices, class_11659 orderedRenderCommandQueue, class_746 player, int light, CallbackInfo ci) {
      if (!ChamsPipeline.isRenderingMask()) {
         SmokeHandsRenderer.getInstance().captureBeforeHands();
      }
   }

   @Inject(
      method = {"method_22976"},
      at = {@At("RETURN")}
   )
   private void minar$smokeHandsRenderEffect(float tickProgress, class_4587 matrices, class_11659 orderedRenderCommandQueue, class_746 player, int light, CallbackInfo ci) {
      if (!ChamsPipeline.isRenderingMask()) {
         SmokeHandsRenderer.getInstance().captureAfterHands();
         SmokeHandsRenderer.getInstance().renderEffect();
      }
   }

   @Redirect(
      method = {"method_3228"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_759;method_3224(Lnet/minecraft/class_4587;Lnet/minecraft/class_1306;F)V"
)
   )
   private void minar$redirectEquipOffset(class_759 renderer, class_4587 matrices, class_1306 arm, float equipProgress) {
      if (!this.minar$overrideSwing) {
         this.method_3224(matrices, arm, equipProgress);
      }

   }

   @Redirect(
      method = {"method_3228"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_759;method_65816(FLnet/minecraft/class_4587;ILnet/minecraft/class_1306;)V"
)
   )
   private void minar$redirectSwingArm(class_759 renderer, float swingProgress, class_4587 matrices, int side, class_1306 arm) {
      SwingAnimations swingAnimations = (SwingAnimations)FunctionManager.getFunction(SwingAnimations.class);
      if (this.minar$overrideSwing && swingAnimations != null) {
         swingAnimations.refreshTarget(matrices, swingProgress, this.minar$equipProgress, arm, this.minar$tickProgress, this.field_4053, this.field_4043);
      } else {
         this.method_65816(swingProgress, matrices, side, arm);
      }
   }

   @Redirect(
      method = {"method_3228"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_759;method_3233(Lnet/minecraft/class_1309;Lnet/minecraft/class_1799;Lnet/minecraft/class_811;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;I)V"
)
   )
   private void minar$redirectRenderItem(class_759 renderer, class_1309 entity, class_1799 stack, class_811 renderMode, class_4587 matrices, class_11659 orderedRenderCommandQueue, int light) {
      this.minar$applyViewModelRotation(matrices, this.minar$armFromRenderMode(renderMode));
      this.method_3233(entity, stack, renderMode, matrices, orderedRenderCommandQueue, light);
   }

   @Unique
   private boolean minar$shouldOverride(class_742 player, class_1268 hand, class_1799 item) {
      SwingAnimations swingAnimations = (SwingAnimations)FunctionManager.getFunction(SwingAnimations.class);
      return swingAnimations != null && swingAnimations.isFeatureActive() && hand == class_1268.field_5808 && !item.method_7960() && !item.method_57826(class_9334.field_49646) && !item.method_31574(class_1802.field_8399) && !player.method_31550() && !player.method_6123() && (!player.method_6115() || player.method_6014() <= 0 || player.method_6058() != hand) && item.method_75218().comp_4975() == class_12122.field_63399;
   }

   @Unique
   private boolean minar$renderBeautifulHandsCustom(class_742 player, float tickProgress, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_11659 queue, int light) {
      BeautifulHands beautifulHands = (BeautifulHands)FunctionManager.getFunction(BeautifulHands.class);
      if (beautifulHands != null && beautifulHands.isEnabled() && !item.method_57826(class_9334.field_49646) && !player.method_31550() && !player.method_6123()) {
         if (item.method_7960() && !beautifulHands.isFeatureActive()) {
            return false;
         } else {
            class_1306 arm = hand == class_1268.field_5808 ? player.method_6068() : player.method_6068().method_5928();
            int side = arm == class_1306.field_6183 ? 1 : -1;
            boolean right = arm == class_1306.field_6183;
            double frameStep = beautifulHands.calculateAnimationFactor();
            class_243 velocity = player.method_18798();
            double horizontalSpeed = Math.sqrt(velocity.field_1352 * velocity.field_1352 + velocity.field_1350 * velocity.field_1350);
            float yawDelta = player.field_5982 - player.method_36454();
            float pitchDelta = player.field_6004 - player.method_36455();
            matrices.method_22903();
            ViewModel viewModel = (ViewModel)FunctionManager.getFunction(ViewModel.class);
            if (viewModel != null) {
               viewModel.refreshTarget(matrices, arm);
            }

            beautifulHands.refreshTarget(matrices, arm);
            beautifulHands.updateRotation(matrices, arm, horizontalSpeed, velocity.field_1351, yawDelta, pitchDelta, swingProgress, frameStep);
            if (item.method_7960()) {
               this.minar$applyViewModelRotation(matrices, arm);
               this.method_3219(matrices, queue, light, equipProgress, beautifulHands.calculateAnimationFactor(swingProgress), arm);
               matrices.method_22909();
               return true;
            } else {
               float swingRot = beautifulHands.calculateTargetDistance(swingProgress);
               float swing = beautifulHands.calculateMovementSpeed(class_3532.method_15374((double)(swingProgress * (float)Math.PI)));
               boolean alternateLeft = beautifulHands.isValidAttackKeyPressed(this.minar$isAttackPressed(), swingProgress);
               this.minar$applyHoldMyItemsSwing(matrices, beautifulHands, item, arm, side, swing, swingRot, alternateLeft);
               matrices.method_22903();
               this.minar$applyHeldArmPose(matrices, item, arm, side, equipProgress, swingProgress);
               matrices.method_22903();
               this.minar$applyViewModelRotation(matrices, arm);
               this.method_3219(matrices, queue, light, 0.0F, beautifulHands.calculateAnimationFactor(swingProgress), arm);
               matrices.method_22909();
               this.minar$applyHeldItemPose(matrices, beautifulHands, player, item, arm, side, equipProgress, swing, swingRot, horizontalSpeed, frameStep);
               this.minar$applyViewModelRotation(matrices, arm);
               this.method_3233(player, item, right ? class_811.field_4320 : class_811.field_4323, matrices, queue, light);
               matrices.method_22909();
               matrices.method_22909();
               return true;
            }
         }
      } else {
         return false;
      }
   }

   @Unique
   private class_1306 minar$armFromRenderMode(class_811 renderMode) {
      return renderMode == class_811.field_4321 ? class_1306.field_6182 : class_1306.field_6183;
   }

   @Unique
   private void minar$applyViewModelRotation(class_4587 matrices, class_1306 arm) {
      ViewModel viewModel = (ViewModel)FunctionManager.getFunction(ViewModel.class);
      if (viewModel != null) {
         viewModel.updateRotation(matrices, arm);
      }

   }

   @Unique
   private void minar$applyHoldMyItemsSwing(class_4587 matrices, BeautifulHands beautifulHands, class_1799 stack, class_1306 arm, int side, float swing, float swingRot, boolean alternateLeft) {
      if (!beautifulHands.shouldProcess()) {
         boolean leftSlash = alternateLeft || stack.method_31573(class_3489.field_42612) || stack.method_7976() == class_1839.field_8951 || stack.method_7976() == class_1839.field_63380 || stack.method_7976() == class_1839.field_8949;
         if (stack.method_31573(class_3489.field_42615)) {
            matrices.method_46416(0.0F, 0.15F * swingRot, -0.25F * swingRot - 0.2F * swing);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(15.0F * swingRot));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-35.0F * swingRot + 30.0F * swing));
         } else {
            if (leftSlash && stack.method_31573(class_3489.field_42611)) {
               matrices.method_46416(0.8F * (float)side * swingRot, 0.3F * swingRot, -0.5F * swing);
               matrices.method_22907(class_7833.field_40716.rotationDegrees(15.0F * swingRot * (float)side));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(-20.0F * swingRot));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(-70.0F * swingRot * (float)side));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(40.0F * swing));
            } else if (!leftSlash && stack.method_31573(class_3489.field_42611)) {
               matrices.method_46416(-0.55F * (float)side * swingRot, -0.8F * swingRot, -0.77F * swing);
               matrices.method_22907(class_7833.field_40716.rotationDegrees(5.0F * swingRot * (float)side));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(-30.0F * swingRot));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(70.0F * swingRot * (float)side));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(50.0F * swing));
            } else if (this.minar$isToolLike(stack)) {
               matrices.method_46416(0.1F * (float)side * swingRot, 0.1F * swingRot, -0.5F * swing);
               matrices.method_22907(class_7833.field_40713.rotationDegrees(-30.0F * swingRot));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(-20.0F * swingRot * (float)side));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(40.0F * swing));
            } else {
               matrices.method_46416(0.1F * (float)side * swingRot, 0.1F * swingRot, -0.1F * swing);
               matrices.method_22907(class_7833.field_40713.rotationDegrees(-30.0F * swingRot));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(-10.0F * swingRot * (float)side));
               matrices.method_22907(class_7833.field_40713.rotationDegrees(40.0F * swing));
               matrices.method_22907(class_7833.field_40716.rotationDegrees(10.0F * swing * (float)side));
            }

         }
      }
   }

   @Unique
   private void minar$applyHeldArmPose(class_4587 matrices, class_1799 stack, class_1306 arm, int side, float equipProgress, float swingProgress) {
      if (stack.method_7976() == class_1839.field_8949) {
         matrices.method_46416(0.0F, -0.2F, 0.0F);
      } else if (stack.method_31573(class_3489.field_61892) || stack.method_31573(class_3489.field_40108)) {
         matrices.method_46416(0.1F * (float)side, 0.0F, -0.1F);
         matrices.method_22907(class_7833.field_40714.rotationDegrees(10.0F));
      }

      matrices.method_46416((float)side, -equipProgress * 0.3F, 0.3F);
      matrices.method_22907(class_7833.field_40716.rotationDegrees(45.0F * (float)side));
      matrices.method_22907(class_7833.field_40718.rotationDegrees(-40.0F * (float)side));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(30.0F));
      this.minar$applyAltSwing(matrices, arm, swingProgress);
      matrices.method_22905(0.9F, 0.9F, 0.9F);
      if (this.minar$isThrowable(stack)) {
         matrices.method_22907(class_7833.field_40716.rotationDegrees(-25.0F * (float)side));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(-10.0F));
         matrices.method_46416(-0.15F * (float)side, 0.1F, 0.1F);
      } else {
         if (stack.method_7976() == class_1839.field_8949) {
            matrices.method_46416((float)side * 0.22F, -0.04F, -0.06F);
            matrices.method_22907(class_7833.field_40718.rotationDegrees(18.0F * (float)side));
         } else if (stack.method_7976() != class_1839.field_8953 && !stack.method_31574(class_1802.field_8399)) {
            if (stack.method_7976() != class_1839.field_63380 && stack.method_7976() != class_1839.field_8951) {
               matrices.method_46416((float)side * 0.08F, 0.02F, -0.02F);
            } else {
               matrices.method_46416((float)side * -0.18F, 0.0F, -0.15F);
               matrices.method_22907(class_7833.field_40718.rotationDegrees(20.0F * (float)side));
            }
         } else {
            matrices.method_46416((float)side * -0.05F, -0.05F, -0.18F);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-18.0F));
         }

      }
   }

   @Unique
   private void minar$applyHeldItemPose(class_4587 matrices, BeautifulHands beautifulHands, class_742 player, class_1799 stack, class_1306 arm, int side, float equipProgress, float swing, float swingRot, double horizontalSpeed, double frameStep) {
      matrices.method_46416(0.0F, -0.5F, -0.1F);
      matrices.method_22907(class_7833.field_40716.rotationDegrees(-65.0F * (float)side));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(10.0F));
      class_1839 useAction = stack.method_7976();
      if (useAction == class_1839.field_8949) {
         matrices.method_22907(class_7833.field_40718.rotationDegrees(160.0F * (float)side));
         matrices.method_22907(class_7833.field_40716.rotationDegrees(-60.0F * (float)side));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(-70.0F));
         matrices.method_22905(0.75F, 0.75F, 0.75F);
         matrices.method_46416(0.32F * (float)side, 0.35F, 0.15F);
         matrices.method_22907(class_7833.field_40716.rotationDegrees(-90.0F * (float)side));
      } else if (useAction != class_1839.field_8953 && !stack.method_31574(class_1802.field_8399)) {
         if (useAction != class_1839.field_63380 && useAction != class_1839.field_8951) {
            if (stack.method_31573(class_3489.field_42615)) {
               matrices.method_46416(0.07F * (float)side, 0.0F, 0.05F);
               matrices.method_22907(class_7833.field_40716.rotationDegrees(90.0F * (float)side));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(-15.0F - 80.0F * swingRot + 30.0F * swing));
            } else if (this.minar$isSimpleHeldItem(stack)) {
               matrices.method_22907(class_7833.field_40715.rotationDegrees(5.0F * (float)side));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(15.0F));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(75.0F * (float)side));
               matrices.method_46416(0.0F, -0.05F, -0.1F);
               matrices.method_22905(0.72F, 0.72F, 0.72F);
               if (this.minar$isSoftItem(stack)) {
                  beautifulHands.advanceActionPhase(matrices, swing, horizontalSpeed, frameStep);
               }
            } else {
               matrices.method_22907(class_7833.field_40713.rotationDegrees(10.0F));
               matrices.method_22907(class_7833.field_40715.rotationDegrees(-65.0F * (float)side));
               matrices.method_46416(0.0F, 0.5F, 0.1F);
               matrices.method_22907(class_7833.field_40716.rotationDegrees(92.0F));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(45.0F));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(-41.0F * (float)side));
               matrices.method_46416((float)side * -0.075F, -0.5375F, 0.5125F);
               matrices.method_46416(beautifulHands.calculateRotationStep() * (float)side, beautifulHands.calculateRenderOffset(), beautifulHands.calculateCooldown());
               matrices.method_22907(class_7833.field_40714.rotationDegrees(beautifulHands.calculateInterpolation()));
               matrices.method_22907(class_7833.field_40716.rotationDegrees(beautifulHands.calculateOpacity() * (float)side));
               matrices.method_22907(class_7833.field_40718.rotationDegrees(beautifulHands.calculateScale() * (float)side));
               if (useAction != class_1839.field_8949) {
                  matrices.method_22905(1.2F, 1.2F, 1.2F);
               }
            }
         } else {
            matrices.method_22907(class_7833.field_40715.rotationDegrees(75.0F * (float)side));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(90.0F - 40.0F * swingRot));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(45.0F * (float)side));
            matrices.method_46416(-0.3F * (float)side, 0.1F * swingRot, -0.1F * swingRot);
            matrices.method_22905(1.15F, 1.15F, 1.15F);
         }
      } else {
         matrices.method_22907(class_7833.field_40715.rotationDegrees(75.0F * (float)side));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(60.0F));
         matrices.method_22907(class_7833.field_40718.rotationDegrees(45.0F * (float)side));
         matrices.method_46416(-0.1F * (float)side, -0.2F, 0.0F);
         matrices.method_22905(1.12F, 1.12F, 1.12F);
      }

      if (stack.method_31574(class_1802.field_8137) || stack.method_31574(class_1802.field_8301)) {
         float idle = (float)((double)System.nanoTime() / (double)1.0E9F);
         matrices.method_46416(0.0F, 0.25F + 0.02F * class_3532.method_15374((double)(idle * 3.0F)), 0.0F);
         matrices.method_22907(class_7833.field_40714.rotationDegrees(3.0F * class_3532.method_15374((double)(idle * 6.0F))));
         float scale = 1.0F + 0.01F * class_3532.method_15374((double)(idle * 12.0F));
         matrices.method_22905(scale, scale, scale);
      }

   }

   @Unique
   private void minar$applyAltSwing(class_4587 matrices, class_1306 arm, float swingProgress) {
      int side = arm == class_1306.field_6183 ? 1 : -1;
      float swing = class_3532.method_15374((double)(swingProgress * (float)Math.PI));
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * (45.0F + swing * 0.0F)));
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)side * -45.0F));
   }

   @Unique
   private boolean minar$isAttackPressed() {
      return class_310.method_1551().field_1690.field_1886.method_1434();
   }

   @Unique
   private boolean minar$isThrowable(class_1799 stack) {
      return stack.method_31574(class_1802.field_8287) || stack.method_31574(class_1802.field_8803) || stack.method_31574(class_1802.field_8449) || stack.method_31574(class_1802.field_8543) || stack.method_31574(class_1802.field_8634) || stack.method_31574(class_1802.field_8436) || stack.method_31574(class_1802.field_8150);
   }

   @Unique
   private boolean minar$isToolLike(class_1799 stack) {
      return stack.method_31573(class_3489.field_42611) || stack.method_31573(class_3489.field_42612) || stack.method_31573(class_3489.field_42614) || stack.method_31573(class_3489.field_42613) || stack.method_31573(class_3489.field_42615) || stack.method_31573(class_3489.field_63258) || stack.method_31573(class_3489.field_48306) || stack.method_7909() instanceof class_1787 || stack.method_31574(class_1802.field_8868) || stack.method_31574(class_1802.field_8184) || stack.method_31574(class_1802.field_23254);
   }

   @Unique
   private boolean minar$isSimpleHeldItem(class_1799 stack) {
      class_2248 block = class_2248.method_9503(stack.method_7909());
      boolean simpleBlock = block != class_2246.field_10124 && !block.method_9564().method_26164(class_3481.field_15463) && !block.method_9564().method_26164(class_3481.field_22414) && !block.method_9564().method_26164(class_3481.field_43170);
      return simpleBlock || stack.method_7976() == class_1839.field_8950 || stack.method_7976() == class_1839.field_8946 || stack.method_7976() == class_1839.field_42717 || stack.method_31573(class_3489.field_15556) || stack.method_31573(class_3489.field_61892) || stack.method_31574(class_1802.field_8276) || stack.method_31574(class_1802.field_8725) || stack.method_31574(class_1802.field_8865) || stack.method_31574(class_1802.field_8366);
   }

   @Unique
   private boolean minar$isSoftItem(class_1799 stack) {
      class_2248 block = class_2248.method_9503(stack.method_7909());
      return stack.method_31574(class_1802.field_8153) || stack.method_31574(class_1802.field_8777) || stack.method_31574(class_1802.field_8323) || stack.method_31574(class_1802.field_8828) || stack.method_31574(class_1802.field_21086) || block.method_9564().method_26164(class_3481.field_20339) || block.method_9564().method_26164(class_3481.field_15503) || block.method_9564().method_26164(class_3481.field_15462) || block.method_9564().method_26164(class_3481.field_44469);
   }
}
