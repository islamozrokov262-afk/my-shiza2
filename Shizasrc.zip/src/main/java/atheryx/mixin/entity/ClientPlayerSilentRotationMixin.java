package atheryx.mixin.entity;

import atheryx.manager.RotationManager;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_746.class})
public class ClientPlayerSilentRotationMixin {
   @Redirect(
      method = {"method_3136"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_746;method_36454()F"
)
   )
   private float getSilentYaw(class_746 instance) {
      return RotationManager.getServerYaw(instance.method_36454());
   }

   @Redirect(
      method = {"method_3136"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_746;method_36455()F"
)
   )
   private float getSilentPitch(class_746 instance) {
      return RotationManager.getServerPitch(instance.method_36455());
   }
}
