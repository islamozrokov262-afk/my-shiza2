package atheryx.mixin.entity;

import atheryx.event.EventBus;
import atheryx.event.impl.AttackEntityEvent;
import atheryx.manager.RotationManager;
import atheryx.module.FunctionManager;
import atheryx.module.player.NoInteract;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_636.class})
public class ClientPlayerInteractionManagerMixin {
   @Inject(
      method = {"method_2918"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void noInteractAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
      NoInteract noInteract = (NoInteract)FunctionManager.getFunction(NoInteract.class);
      if (noInteract != null && noInteract.isValidEntity(target)) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"method_2918"},
      at = {@At("TAIL")}
   )
   private void attackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
      EventBus.post(new AttackEntityEvent(player, target));
   }

   @Inject(
      method = {"method_2896"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void interactBlock(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
      NoInteract noInteract = (NoInteract)FunctionManager.getFunction(NoInteract.class);
      if (noInteract != null && noInteract.matchesPos(hitResult.method_17777())) {
         cir.setReturnValue(class_1269.field_5814);
      }

   }

   @Inject(
      method = {"method_2905"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void interactEntity(class_1657 player, class_1297 entity, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
      if (RotationManager.isRotating()) {
         cir.setReturnValue(class_1269.field_5811);
      } else {
         NoInteract noInteract = (NoInteract)FunctionManager.getFunction(NoInteract.class);
         if (noInteract != null && noInteract.isValidEntity(entity)) {
            cir.setReturnValue(class_1269.field_5814);
         }

      }
   }

   @Inject(
      method = {"method_2917"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void interactEntityAtLocation(class_1657 player, class_1297 entity, class_3966 hitResult, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
      if (RotationManager.isRotating()) {
         cir.setReturnValue(class_1269.field_5811);
      } else {
         NoInteract noInteract = (NoInteract)FunctionManager.getFunction(NoInteract.class);
         if (noInteract != null && noInteract.isValidEntity(entity)) {
            cir.setReturnValue(class_1269.field_5814);
         }

      }
   }
}
