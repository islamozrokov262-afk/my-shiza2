package atheryx.mixin.entity;

import atheryx.manager.RotationManager;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1297.class})
public class EntityRotationVectorMixin {
   @Inject(
      method = {"method_5720"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void redirectRotationVector(CallbackInfoReturnable<class_243> cir) {
      if ((Object)this instanceof class_746 player) {
         if (RotationManager.hasMoveCorrection() && player.method_6128()) {
            float pitch = RotationManager.getServerPitch(player.method_36455());
            float yaw = RotationManager.getServerYaw(player.method_36454());
            float f = pitch * ((float)Math.PI / 180F);
            float g = -yaw * ((float)Math.PI / 180F);
            float h = class_3532.method_15362((double)g);
            float i = class_3532.method_15374((double)g);
            float j = class_3532.method_15362((double)f);
            float k = class_3532.method_15374((double)f);
            cir.setReturnValue(new class_243((double)(i * j), (double)(-k), (double)(h * j)));
         }
      }

   }
}
