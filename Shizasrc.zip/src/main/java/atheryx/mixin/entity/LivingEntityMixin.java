package atheryx.mixin.entity;

import atheryx.manager.RotationManager;
import atheryx.module.FunctionManager;
import atheryx.module.combat.AttackAura;
import atheryx.module.movement.NoPush;
import atheryx.module.render.BeautifulHands;
import atheryx.module.render.SwingAnimations;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1309.class})
public class LivingEntityMixin {
   private boolean minar_modifiedElytraRotations = false;
   private float minar_prevElytraYaw;
   private float minar_prevElytraPitch;

   @Inject(
      method = {"method_5810"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void isPushable(CallbackInfoReturnable<Boolean> cir) {
      if (NoPush.Instance.isEnabled() && NoPush.players.isEnabled()) {
         cir.setReturnValue(false);
      }

   }

   @Inject(
      method = {"method_5728"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void preventAuraSprintReset(boolean sprinting, CallbackInfo ci) {
      if (sprinting && (Object)this instanceof class_746) {
         AttackAura aura = (AttackAura)FunctionManager.getFunction(AttackAura.class);
         if (aura != null && aura.shouldPreventSprintReset()) {
            ci.cancel();
         }

      }
   }

   @Inject(
      method = {"method_6028"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void modifyHandSwingDuration(CallbackInfoReturnable<Integer> cir) {
      class_310 client = class_310.method_1551();
      if ((Object)this == client.field_1724) {
         SwingAnimations animations = (SwingAnimations)FunctionManager.getFunction(SwingAnimations.class);
         class_1309 player = (class_1309)(Object)this;
         if (animations != null && animations.isFeatureActive()) {
            cir.setReturnValue(animations.calculateAnimationFactor((Integer)cir.getReturnValue(), player.field_6252, player.field_6279));
         } else {
            BeautifulHands beautifulHands = (BeautifulHands)FunctionManager.getFunction(BeautifulHands.class);
            if (beautifulHands != null && beautifulHands.isEnabled()) {
               cir.setReturnValue(beautifulHands.calculateAnimationFactor((Integer)cir.getReturnValue()));
            }

         }
      }
   }

   @Redirect(
      method = {"method_6043"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_1309;method_36454()F"
)
   )
   private float correctJumpYaw(class_1309 instance) {
      return (Object)this == class_310.method_1551().field_1724 && RotationManager.hasMoveCorrection() ? RotationManager.getServerYaw(instance.method_36454()) : instance.method_36454();
   }

   @Inject(
      method = {"method_6091"},
      at = {@At("HEAD")}
   )
   private void onTravelHead(class_243 movementInput, CallbackInfo ci) {
      if ((Object)this instanceof class_746 player) {
         if (RotationManager.hasMoveCorrection() && player.method_6128()) {
            this.minar_prevElytraYaw = player.method_36454();
            this.minar_prevElytraPitch = player.method_36455();
            player.method_36456(RotationManager.getServerYaw(this.minar_prevElytraYaw));
            player.method_36457(RotationManager.getServerPitch(this.minar_prevElytraPitch));
            this.minar_modifiedElytraRotations = true;
         }
      }

   }

   @Inject(
      method = {"method_6091"},
      at = {@At("RETURN")}
   )
   private void onTravelReturn(class_243 movementInput, CallbackInfo ci) {
      if (this.minar_modifiedElytraRotations && (Object)this instanceof class_746 player) {
         player.method_36456(this.minar_prevElytraYaw);
         player.method_36457(this.minar_prevElytraPitch);
         this.minar_modifiedElytraRotations = false;
      }

   }
}
