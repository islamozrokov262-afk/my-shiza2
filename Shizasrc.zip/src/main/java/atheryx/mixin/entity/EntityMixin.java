package atheryx.mixin.entity;

import atheryx.event.EventBus;
import atheryx.event.impl.EventOnMovePost;
import atheryx.manager.RotationManager;
import atheryx.module.movement.NoPush;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_1297.class})
public class EntityMixin {
   @Redirect(
      method = {"method_5692"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_3610;method_15758(Lnet/minecraft/class_1922;Lnet/minecraft/class_2338;)Lnet/minecraft/class_243;"
)
   )
   private class_243 stopWaterVelocity(class_3610 instance, class_1922 world, class_2338 pos) {
      return NoPush.Instance.isEnabled() && NoPush.water.isEnabled() ? class_243.field_1353 : instance.method_15758(world, pos);
   }

   @Redirect(
      method = {"method_5724"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_1297;method_36454()F"
)
   )
   private float correctMovementYaw(class_1297 instance) {
      return RotationManager.hasMoveCorrection() && instance instanceof class_746 ? RotationManager.getServerYaw(instance.method_36454()) : instance.method_36454();
   }

   @Inject(
      method = {"method_5724"},
      at = {@At("TAIL")}
   )
   private void onUpdateVelocityPost(float speed, class_243 movementInput, CallbackInfo ci) {
      class_1297 self = (class_1297)(Object)this;
      class_746 player = class_310.method_1551().field_1724;
      if (player != null && self.method_5628() == player.method_5628()) {
         EventBus.post(new EventOnMovePost(speed, movementInput));
      }

   }
}
