package atheryx.mixin.entity;

import atheryx.event.EventBus;
import atheryx.event.impl.NoSlowEvent;
import atheryx.event.impl.PostMotionEvent;
import atheryx.event.impl.UpdateEvent;
import atheryx.manager.RotationManager;
import atheryx.neuro.NeuroCommand;
import atheryx.neuro.NeuroManager;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_746.class})
public class ClientPlayerEntityMixin {
   @Inject(
      method = {"method_5773"},
      at = {@At("HEAD")}
   )
   private void update(CallbackInfo ci) {
      RotationManager.update();
      NeuroManager.tickVisualState();
      NeuroCommand.stop();
      EventBus.post(new UpdateEvent());
   }

   @Inject(
      method = {"method_5773"},
      at = {@At("TAIL")}
   )
   private void postMotion(CallbackInfo ci) {
      EventBus.post(new PostMotionEvent());
   }

   @Redirect(
      method = {"method_67270"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_746;method_6115()Z"
)
   )
   private boolean applyMovementSpeedFactors(class_746 instance) {
      NoSlowEvent event = new NoSlowEvent();
      EventBus.post(event);
      return event.isCancelled() ? false : instance.method_6115();
   }
}
