package atheryx.gui.screen;

import atheryx.bot.BotSessionManager;
import atheryx.render.RenderUtil;
import atheryx.render.pipeline.TexturePipeline;
import atheryx.util.math.Easings;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1068;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_8685;
import org.lwjgl.glfw.GLFW;

public class BotsWheelScreen extends class_437 {
   private long field_6d2b79f5;
   private long field_da56f3ea;
   private final Map<String, Float> field_47826ddf = new HashMap<String, Float>();
   private boolean field_b4ade7d4;
   private String field_21d961c9;
   private String field_8f04dbbe;
   private boolean field_fc3055b3;
   private boolean field_695bcfa8;
   private int field_d687499d;
   private boolean field_43b2c392;
   private float field_b0de3d87;
   private float field_1e09b77c;
   private BotSessionManager.BotSession field_8b353171;
   private static final float obf_u0401_u220e = 400.0F;

   public BotsWheelScreen() {
      super(class_2561.method_43470("Bots Wheel"));
      this.setConnectDialogOpenInternal(false);
      this.setBotNameInputInternal("");
      this.setAddressInputInternal("");
      this.setNameFieldFocusedInternal(false);
      this.setAddressFieldFocusedInternal(false);
      this.setSelectedIndexInternal(-1);
      this.setContextMenuOpenInternal(false);
      this.setContextMenuXInternal(0.0F);
      this.setContextMenuYInternal(0.0F);
      this.setContextBotInternal((BotSessionManager.BotSession)null);
   }

   protected void init() {
      super.method_25426();
      this.setOpenTimeInternal(System.currentTimeMillis());
      this.setLastFrameTimeInternal(System.currentTimeMillis());
      int var1 = RenderUtil.getScaledWidth() / 2;
      int var2 = RenderUtil.getScaledHeight() / 2;
   }

   public void renderScreenContent(class_332 context, int mouseX, int mouseY, float deltaTicks) {
   }

   public void renderScreen(class_332 context, int mouseX, int mouseY, float delta) {
      int scaledWidth = RenderUtil.getScaledWidth();
      int scaledHeight = RenderUtil.getScaledHeight();
      float mx = RenderUtil.toScaledX((float)mouseX);
      float my = RenderUtil.toScaledY((float)mouseY);
      long currentTime = System.currentTimeMillis();
      float deltaMs = (float)(currentTime - this.getLastFrameTimeInternal());
      this.setLastFrameTimeInternal(currentTime);
      float timePassed = (float)(currentTime - this.getOpenTimeInternal());
      float var13 = Math.min(1.0F, timePassed / 400.0F);
      float anim = Easings.easeOutBack(var13);
      float centerX = (float)scaledWidth / 2.0F;
      float centerY = (float)scaledHeight / 2.0F;
      float radius = 100.0F * anim;
      if (anim > 0.01F) {
         RenderUtil.drawShadow(centerX - radius, centerY - radius, radius * 2.0F, radius * 2.0F, radius, 20.0F, 0.4F, 2.0F, new Color(10, 10, 10, 200));
         RenderUtil.drawRoundedRect(centerX - radius, centerY - radius, radius * 2.0F, radius * 2.0F, radius, new Color(15, 15, 15, 230));
         float plusSize = 30.0F * anim;
         boolean hoverPlus = mx > centerX - plusSize / 2.0F && mx < centerX + plusSize / 2.0F && my > centerY - plusSize / 2.0F && my < centerY + plusSize / 2.0F;
         Color plusColor = hoverPlus ? new Color(60, 150, 255) : new Color(40, 120, 220);
         RenderUtil.drawRoundedRect(centerX - plusSize / 2.0F, centerY - plusSize / 2.0F, plusSize, plusSize, plusSize / 2.0F, plusColor);
         RenderUtil.drawAlignedText(context, centerX, centerY - 6.0F * anim, "+", 18.0F * anim, Color.WHITE, "center");
         List bots = BotSessionManager.getConnections();
         int botCount = bots.size();

         for(int i = 0; i < botCount; ++i) {
            BotSessionManager.BotSession bot = (BotSessionManager.BotSession)bots.get(i);
            float angle = (float)((double)i * 6.2831853071795862D / (double)botCount) - ((float)Math.PI / 2F);
            float botX = centerX + (float)Math.cos((double)angle) * radius * 0.7F;
            float botY = centerY + (float)Math.sin((double)angle) * radius * 0.7F;
            float baseSize = 24.0F * anim;
            boolean hoverBot = mx > botX - baseSize / 2.0F && mx < botX + baseSize / 2.0F && my > botY - baseSize / 2.0F && my < botY + baseSize / 2.0F;
            float currentHover = (Float)this.getBotHoverAnimationsInternal().getOrDefault(bot.name(), 0.0F);
            float targetHover = hoverBot ? 1.0F : 0.0F;
            currentHover += (targetHover - currentHover) * (deltaMs / 100.0F);
            currentHover = Math.max(0.0F, Math.min(1.0F, currentHover));
            this.getBotHoverAnimationsInternal().put(bot.name(), currentHover);
            float hoverAnim = Easings.easeOutBack(currentHover);
            float currentSize = baseSize + 12.0F * hoverAnim;
            class_8685 skin = bot.player() != null ? bot.player().method_52814() : class_1068.method_4648(UUID.randomUUID());
            class_2960 texture = skin.comp_1626().comp_3627();
            int alpha = (int)(255.0F * Math.max(0.0F, Math.min(1.0F, anim)));
            int colorRGB = (new Color(255, 255, 255, alpha)).getRGB();
            GpuTextureView view = this.field_22787.method_1531().method_4619(texture).method_71659();
            float hr = currentSize / 4.0F;
            TexturePipeline.drawSquareTextureRegionFiltered(RenderUtil.createGuiProjection(), botX - currentSize / 2.0F, botY - currentSize / 2.0F, currentSize, view, colorRGB, hr, 0.0F, 0.125F, 0.125F, 0.125F, 0.125F, false);
            TexturePipeline.drawSquareTextureRegionFiltered(RenderUtil.createGuiProjection(), botX - currentSize / 2.0F, botY - currentSize / 2.0F, currentSize, view, colorRGB, hr, 0.0F, 0.625F, 0.125F, 0.125F, 0.125F, false);
            if (currentHover > 0.01F) {
               float flyY = botY + (currentSize / 2.0F + 8.0F) * hoverAnim;
               int nameAlpha = (int)(255.0F * Math.max(0.0F, Math.min(1.0F, currentHover * 2.0F * anim)));
               Color nameCol = new Color(255, 255, 255, nameAlpha);
               RenderUtil.drawAlignedText(context, botX, flyY, bot.name(), Math.max(0.0F, 10.0F * anim), nameCol, "center");
            }
         }

         if (this.getConnectDialogOpenInternal()) {
            RenderUtil.drawRoundedRect(0.0F, 0.0F, (float)scaledWidth, (float)scaledHeight, 0.0F, new Color(0, 0, 0, 150));
            float panelW = 160.0F;
            float panelH = 120.0F;
            float panelX = centerX - panelW / 2.0F;
            float panelY = centerY - panelH / 2.0F;
            RenderUtil.drawRoundedRect(panelX, panelY, panelW, panelH, 8.0F, new Color(20, 20, 20, 255));
            RenderUtil.drawAlignedText(context, centerX, panelY + 10.0F, "Connect Bot", 14.0F, Color.WHITE, "center");
            float fieldW = 120.0F;
            float fieldH = 20.0F;
            float nameFieldX = centerX - fieldW / 2.0F;
            float var59 = panelY + 30.0F;
            float ipFieldX = centerX - fieldW / 2.0F;
            float ipFieldY = panelY + 60.0F;
            RenderUtil.drawRoundedRect(nameFieldX, var59, (float)fieldW, (float)fieldH, 4.0F, this.getNameFieldFocusedInternal() ? new Color(40, 40, 45, 255) : new Color(30, 30, 35, 255));
            if (this.getNameFieldFocusedInternal()) {
               RenderUtil.drawRoundedOutline(nameFieldX, var59, (float)fieldW, (float)fieldH, 4.0F, 1.0F, new Color(80, 160, 255));
            }

            if (this.getBotNameInputInternal().isEmpty() && !this.getNameFieldFocusedInternal()) {
               RenderUtil.drawText(context, nameFieldX + 5.0F, var59 + 5.0F, "Nickname", 10.0F, new Color(150, 150, 150));
            } else {
               float var10001 = nameFieldX + 5.0F;
               float var10002 = var59 + 5.0F;
               String var10003 = this.getBotNameInputInternal();
               RenderUtil.drawText(context, var10001, var10002, var10003 + (this.getNameFieldFocusedInternal() && System.currentTimeMillis() / 500L % 2L == 0L ? "_" : ""), 10.0F, Color.WHITE);
            }

            RenderUtil.drawRoundedRect(ipFieldX, ipFieldY, (float)fieldW, (float)fieldH, 4.0F, this.getAddressFieldFocusedInternal() ? new Color(40, 40, 45, 255) : new Color(30, 30, 35, 255));
            if (this.getAddressFieldFocusedInternal()) {
               RenderUtil.drawRoundedOutline(ipFieldX, ipFieldY, (float)fieldW, (float)fieldH, 4.0F, 1.0F, new Color(80, 160, 255));
            }

            if (this.getAddressInputInternal().isEmpty() && !this.getAddressFieldFocusedInternal()) {
               RenderUtil.drawText(context, ipFieldX + 5.0F, ipFieldY + 5.0F, "IP Address", 10.0F, new Color(150, 150, 150));
            } else {
               float var67 = ipFieldX + 5.0F;
               float var68 = ipFieldY + 5.0F;
               String var69 = this.getAddressInputInternal();
               RenderUtil.drawText(context, var67, var68, var69 + (this.getAddressFieldFocusedInternal() && System.currentTimeMillis() / 500L % 2L == 0L ? "_" : ""), 10.0F, Color.WHITE);
            }

            float btnW = 80.0F;
            float btnH = 20.0F;
            float btnX = centerX - btnW / 2.0F;
            float btnY = panelY + 90.0F;
            boolean hoverBtn = mx > btnX && mx < btnX + btnW && my > btnY && my < btnY + btnH;
            RenderUtil.drawRoundedRect(btnX, btnY, btnW, (float)btnH, 4.0F, hoverBtn ? new Color(0, 150, 0) : new Color(0, 120, 0));
            RenderUtil.drawAlignedText(context, centerX, btnY + 5.0F, "Connect", 10.0F, Color.WHITE, "center");
         }

         if (this.getContextMenuOpenInternal() && this.getContextBotInternal() != null) {
            float menuW = 80.0F;
            float menuH = 80.0F;
            RenderUtil.drawRoundedRect(this.getContextMenuXInternal(), this.getContextMenuYInternal(), menuW, (float)menuH, 4.0F, new Color(30, 30, 30, 255));
            String[] options = new String[]{"Control", "Say All", "Pulse", "Remove"};

            for(int i = 0; i < options.length; ++i) {
               float optY = this.getContextMenuYInternal() + (float)i * 20.0F;
               boolean hoverOpt = mx > this.getContextMenuXInternal() && mx < this.getContextMenuXInternal() + menuW && my > optY && my < optY + 20.0F;
               if (hoverOpt) {
                  RenderUtil.drawRoundedRect(this.getContextMenuXInternal(), optY, menuW, 20.0F, 0.0F, new Color(60, 60, 60, 255));
               }

               Color textColor = options[i].equals("Remove") ? new Color(255, 80, 80) : Color.WHITE;
               RenderUtil.drawAlignedText(context, this.getContextMenuXInternal() + menuW / 2.0F, optY + 6.0F, options[i], 10.0F, textColor, "center");
            }
         }
      }

      super.method_25394(context, mouseX, mouseY, delta);
   }

   public boolean mouseClicked(class_11909 click, boolean doubled) {
      float scaledWidth = (float)RenderUtil.getScaledWidth();
      float scaledHeight = (float)RenderUtil.getScaledHeight();
      double mouseX = click.comp_4798();
      double mouseY = click.comp_4799();
      int button = click.method_74245();
      float mx = RenderUtil.toScaledX((float)mouseX);
      float my = RenderUtil.toScaledY((float)mouseY);
      float centerX = scaledWidth / 2.0F;
      float centerY = scaledHeight / 2.0F;
      if (this.getContextMenuOpenInternal()) {
         float menuW = 80.0F;
         float menuH = 80.0F;
         if (mx >= this.getContextMenuXInternal() && mx <= this.getContextMenuXInternal() + menuW && my >= this.getContextMenuYInternal() && my <= this.getContextMenuYInternal() + menuH) {
            int optIndex = (int)((my - this.getContextMenuYInternal()) / 20.0F);
            if (optIndex == 0) {
               BotSessionManager.controlBot(this.getContextBotInternal().name());
            }

            if (optIndex == 1) {
               this.field_22787.field_1724.method_7353(class_2561.method_43470("Чат от имени бота в разработке..."), false);
            }

            if (optIndex == 2) {
               BotSessionManager.interactAll(false);
            }

            if (optIndex == 3) {
               BotSessionManager.removeBot(this.getContextBotInternal().name());
            }

            this.setContextMenuOpenInternal(false);
            return true;
         } else {
            this.setContextMenuOpenInternal(false);
            return true;
         }
      } else if (this.getConnectDialogOpenInternal()) {
         float panelW = 160.0F;
         float panelH = 120.0F;
         float panelX = centerX - panelW / 2.0F;
         float botCount = centerY - panelH / 2.0F;
         float var35 = 80.0F;
         float bot = 20.0F;
         float angle = centerX - var35 / 2.0F;
         float botX = botCount + 90.0F;
         if (mx > angle && mx < angle + var35 && my > botX && my < botX + bot) {
            if (!this.getBotNameInputInternal().isEmpty() && !this.getAddressInputInternal().isEmpty()) {
               BotSessionManager.connectBot(this.getBotNameInputInternal(), this.getAddressInputInternal());
               this.setConnectDialogOpenInternal(false);
            }

            return true;
         } else {
            float fieldW = 120.0F;
            float fieldH = 20.0F;
            float nameFieldX = centerX - fieldW / 2.0F;
            float nameFieldY = botCount + 30.0F;
            float ipFieldX = centerX - fieldW / 2.0F;
            float ipFieldY = botCount + 60.0F;
            this.setNameFieldFocusedInternal(mx >= nameFieldX && mx <= nameFieldX + fieldW && my >= nameFieldY && my <= nameFieldY + fieldH);
            this.setAddressFieldFocusedInternal(mx >= ipFieldX && mx <= ipFieldX + fieldW && my >= ipFieldY && my <= ipFieldY + fieldH);
            if (!this.getNameFieldFocusedInternal() && !this.getAddressFieldFocusedInternal()) {
               if (mx < panelX || mx > panelX + panelW || my < botCount || my > botCount + panelH) {
                  this.setConnectDialogOpenInternal(false);
               }

               return true;
            } else {
               return true;
            }
         }
      } else {
         float radius = 100.0F;
         float plusSize = 30.0F;
         if (mx > centerX - plusSize / 2.0F && mx < centerX + plusSize / 2.0F && my > centerY - plusSize / 2.0F && my < centerY + plusSize / 2.0F && button == 0) {
            this.setConnectDialogOpenInternal(true);
            return true;
         } else {
            List<BotSessionManager.BotSession> bots = BotSessionManager.getConnections();
            int botCount = bots.size();

            for(int btnW = 0; btnW < botCount; ++btnW) {
               BotSessionManager.BotSession bot = bots.get(btnW);
               float btnX = (float)((double)btnW * 6.2831853071795862D / (double)botCount) - ((float)Math.PI / 2F);
               float btnY = centerX + (float)Math.cos((double)btnX) * radius * 0.7F;
               float fieldW = centerY + (float)Math.sin((double)btnX) * radius * 0.7F;
               float fieldH = 24.0F;
               if (mx > btnY - fieldH / 2.0F && mx < btnY + fieldH / 2.0F && my > fieldW - fieldH / 2.0F && my < fieldW + fieldH / 2.0F) {
                  if (button == 1) {
                     this.setContextMenuOpenInternal(true);
                     this.setContextMenuXInternal(mx);
                     this.setContextMenuYInternal(my);
                     this.setContextBotInternal(bot);
                  } else if (button == 0) {
                     BotSessionManager.controlBot(bot.name());
                  }

                  return true;
               }
            }

            return super.method_25402(click, doubled);
         }
      }
   }

   public boolean charTyped(class_11908 input) {
      if (input.comp_4795() == 256) {
         if (this.getContextMenuOpenInternal()) {
            this.setContextMenuOpenInternal(false);
            return true;
         } else if (this.getConnectDialogOpenInternal()) {
            this.setConnectDialogOpenInternal(false);
            return true;
         } else {
            this.method_25419();
            return true;
         }
      } else {
         if (this.getConnectDialogOpenInternal()) {
            if (input.comp_4795() == 259) {
               if (this.getNameFieldFocusedInternal() && this.getBotNameInputInternal().length() > 0) {
                  this.setBotNameInputInternal(this.getBotNameInputInternal().substring(0, this.getBotNameInputInternal().length() - 1));
                  return true;
               }

               if (this.getAddressFieldFocusedInternal() && this.getAddressInputInternal().length() > 0) {
                  this.setAddressInputInternal(this.getAddressInputInternal().substring(0, this.getAddressInputInternal().length() - 1));
                  return true;
               }
            } else if (input.comp_4795() == 257) {
               if (this.getNameFieldFocusedInternal()) {
                  this.setNameFieldFocusedInternal(false);
                  this.setAddressFieldFocusedInternal(true);
                  return true;
               }

               if (this.getAddressFieldFocusedInternal()) {
                  if (!this.getBotNameInputInternal().isEmpty() && !this.getAddressInputInternal().isEmpty()) {
                     BotSessionManager.connectBot(this.getBotNameInputInternal(), this.getAddressInputInternal());
                     this.setConnectDialogOpenInternal(false);
                  }

                  return true;
               }
            } else if (input.comp_4795() == 86 && (GLFW.glfwGetKey(this.field_22787.method_22683().method_4490(), 341) == 1 || GLFW.glfwGetKey(this.field_22787.method_22683().method_4490(), 345) == 1)) {
               String clipboard = this.field_22787.field_1774.method_1460();
               if (this.getNameFieldFocusedInternal() && this.getBotNameInputInternal().length() < 16) {
                  String var10001 = this.getBotNameInputInternal();
                  this.setBotNameInputInternal(var10001 + clipboard);
                  if (this.getBotNameInputInternal().length() > 16) {
                     this.setBotNameInputInternal(this.getBotNameInputInternal().substring(0, 16));
                  }
               }

               if (this.getAddressFieldFocusedInternal() && this.getAddressInputInternal().length() < 64) {
                  String var3 = this.getAddressInputInternal();
                  this.setAddressInputInternal(var3 + clipboard);
                  if (this.getAddressInputInternal().length() > 64) {
                     this.setAddressInputInternal(this.getAddressInputInternal().substring(0, 64));
                  }
               }

               return true;
            }
         }

         return super.method_25404(input);
      }
   }

   public boolean keyPressed(class_11905 input) {
      if (this.getConnectDialogOpenInternal() && input.method_74227()) {
         if (this.getNameFieldFocusedInternal() && this.getBotNameInputInternal().length() < 16) {
            String var2 = this.getBotNameInputInternal();
            this.setBotNameInputInternal(var2 + input.method_74226());
            return true;
         }

         if (this.getAddressFieldFocusedInternal() && this.getAddressInputInternal().length() < 64) {
            String var10001 = this.getAddressInputInternal();
            this.setAddressInputInternal(var10001 + input.method_74226());
            return true;
         }
      }

      return super.method_25400(input);
   }

   public boolean shouldPause() {
      return false;
   }

   private long getOpenTimeInternal() {
      return this.field_6d2b79f5;
   }

   private void setOpenTimeInternal(long var1) {
      this.field_6d2b79f5 = var1;
   }

   private long getLastFrameTimeInternal() {
      return this.field_da56f3ea;
   }

   private void setLastFrameTimeInternal(long var1) {
      this.field_da56f3ea = var1;
   }

   private Map getBotHoverAnimationsInternal() {
      return this.field_47826ddf;
   }

   private boolean getConnectDialogOpenInternal() {
      return this.field_b4ade7d4;
   }

   private void setConnectDialogOpenInternal(boolean var1) {
      this.field_b4ade7d4 = var1;
   }

   private String getBotNameInputInternal() {
      return this.field_21d961c9;
   }

   private void setBotNameInputInternal(String var1) {
      this.field_21d961c9 = var1;
   }

   private String getAddressInputInternal() {
      return this.field_8f04dbbe;
   }

   private void setAddressInputInternal(String var1) {
      this.field_8f04dbbe = var1;
   }

   private boolean getNameFieldFocusedInternal() {
      return this.field_fc3055b3;
   }

   private void setNameFieldFocusedInternal(boolean var1) {
      this.field_fc3055b3 = var1;
   }

   private boolean getAddressFieldFocusedInternal() {
      return this.field_695bcfa8;
   }

   private void setAddressFieldFocusedInternal(boolean var1) {
      this.field_695bcfa8 = var1;
   }

   private int getSelectedIndexInternal() {
      return this.field_d687499d;
   }

   private void setSelectedIndexInternal(int var1) {
      this.field_d687499d = var1;
   }

   private boolean getContextMenuOpenInternal() {
      return this.field_43b2c392;
   }

   private void setContextMenuOpenInternal(boolean var1) {
      this.field_43b2c392 = var1;
   }

   private float getContextMenuXInternal() {
      return this.field_b0de3d87;
   }

   private void setContextMenuXInternal(float var1) {
      this.field_b0de3d87 = var1;
   }

   private float getContextMenuYInternal() {
      return this.field_1e09b77c;
   }

   private void setContextMenuYInternal(float var1) {
      this.field_1e09b77c = var1;
   }

   private BotSessionManager.BotSession getContextBotInternal() {
      return this.field_8b353171;
   }

   private void setContextBotInternal(BotSessionManager.BotSession var1) {
      this.field_8b353171 = var1;
   }

}
