package atheryx.gui.screen;

import atheryx.manager.AltManager;
import atheryx.mixin.interfaces.IMinecraftClient;
import atheryx.render.RenderUtil;
import atheryx.render.SkinUtil;
import atheryx.render.font.Msdf;
import atheryx.render.font.MsdfFont;
import atheryx.render.font.MsdfManager;
import atheryx.render.pipeline.TexturePipeline;
import atheryx.render.pipeline.TitleBackgroundPipeline;
import atheryx.render.scissor.Scissor;
import atheryx.util.math.Easings;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.awt.Color;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import net.minecraft.class_1068;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_320;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public class AltManagerScreen extends class_437 {
   private final class_437 field_6d2b79f5;
   private String field_da56f3ea;
   private boolean field_47826ddf;
   private float field_b4ade7d4;
   private long field_21d961c9;
   private long field_8f04dbbe;
   private final Map<String, Float> field_fc3055b3;
   private String field_695bcfa8;
   private float field_d687499d;
   private float field_43b2c392;
   private final Map<String, Float> field_b0de3d87;
   private final Map<String, Float> field_1e09b77c;
   private String field_8b353171;
   private String field_f860ab66;
   private long field_658c255b;
   private final Map<String, Long> field_d2b79f50;
   private final float[] field_3fe31945;
   private static final float obf_u00fb_u220e = 400.0F;
   private static final class_2960 obf_u00ec_u220e = class_2960.method_60655("atheryx", "images/background.png");

   public AltManagerScreen(class_437 parent) {
      super(class_2561.method_43470("Alt Manager"));
      this.setNameInputInternal("");
      this.setInputFocusedInternal(false);
      this.setScrollOffsetInternal(0.0F);
      this.field_fc3055b3 = new HashMap<String, Float>();
      this.setEditingAccountNameInternal((String)null);
      this.setUnusedAnimationXInternal(0.0F);
      this.setUnusedAnimationYInternal(0.0F);
      this.field_b0de3d87 = new HashMap<String, Float>();
      this.field_1e09b77c = new HashMap<String, Float>();
      this.setCurrentSessionNameInternal("");
      this.setPreviousSessionNameInternal("");
      this.setSessionNameChangeTimeInternal(0L);
      this.field_d2b79f50 = new HashMap<String, Long>();
      this.field_3fe31945 = new float[16];
      this.field_6d2b79f5 = parent;
   }

   protected void init() {
      super.method_25426();
      this.setOpenTimeInternal(System.currentTimeMillis());
      this.setLastFrameTimeInternal(System.currentTimeMillis());
   }

   public void renderScreenContent(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      TitleBackgroundPipeline.render();
   }

   public void renderScreen(class_332 context, int mouseX, int mouseY, float delta) {
      this.renderScreenContent(context, mouseX, mouseY, delta);
      int scaledWidth = RenderUtil.getScaledWidth();
      int scaledHeight = RenderUtil.getScaledHeight();
      float mx = RenderUtil.toScaledX((float)mouseX);
      float my = RenderUtil.toScaledY((float)mouseY);
      long currentTime = System.currentTimeMillis();
      float deltaMs = (float)(currentTime - this.getLastFrameTimeInternal());
      this.setLastFrameTimeInternal(currentTime);

      for(Map.Entry<String, Float> entry : this.getClickAnimationsInternal().entrySet()) {
         float val = (Float)entry.getValue();
         if (val > 0.0F) {
            entry.setValue(Math.max(0.0F, val - deltaMs / 100.0F));
         }
      }

      float timePassed = (float)(currentTime - this.getOpenTimeInternal());
      float progress = Math.min(1.0F, timePassed / 400.0F);
      float anim = Easings.easeOutBack(progress);
      float panelW = 320.0F;
      float panelH = 240.0F;
      float centerX = (float)scaledWidth / 2.0F;
      float centerY = (float)scaledHeight / 2.0F;
      float panelX = centerX - panelW / 2.0F;
      float panelY = centerY - panelH / 2.0F + (1.0F - anim) * 50.0F;
      float alpha = Math.min(1.0F, progress * 2.0F);
      int alphaInt = (int)(255.0F * alpha);
      float radius = 10.0F;
      RenderUtil.drawShadow(panelX, panelY + 1.5F, (float)panelW, (float)panelH, (float)radius, 8.0F, 0.22F * alpha, 2.0F, new Color(0, 0, 0, 170));
      RenderUtil.drawHudBlur(panelX, panelY, (float)panelW, (float)panelH, (float)radius, 10.0F, alpha, new Color(100, 100, 100, 10));
      RenderUtil.drawAlignedText(context, Msdf.SF_BOLD, centerX, panelY + 15.0F, "Alt Manager", 16.0F, new Color(245, 247, 250, alphaInt), "center");
      String currentName = this.field_22787.method_1548().method_1676();
      if (this.getCurrentSessionNameInternal().isEmpty()) {
         this.setCurrentSessionNameInternal(currentName);
         this.setPreviousSessionNameInternal(currentName);
      } else if (!currentName.equals(this.getCurrentSessionNameInternal())) {
         this.setPreviousSessionNameInternal(this.getCurrentSessionNameInternal());
         this.setCurrentSessionNameInternal(currentName);
         this.setSessionNameChangeTimeInternal(System.currentTimeMillis());
      }

      long now = System.currentTimeMillis();
      float animProgress = 1.0F;
      if (this.getSessionNameChangeTimeInternal() > 0L) {
         animProgress = Math.min(1.0F, (float)(now - this.getSessionNameChangeTimeInternal()) / 400.0F);
      }

      MsdfFont headerFont = MsdfManager.getDefaultFont();
      String prefix = "Current: ";
      float prefixWidth = Msdf.getTextWidth(headerFont, prefix, 12.0F);
      if (animProgress >= 1.0F) {
         float nameWidth = Msdf.getTextWidth(headerFont, this.getCurrentSessionNameInternal(), 12.0F);
         float startX = centerX - (prefixWidth + nameWidth) / 2.0F;
         RenderUtil.drawText(context, startX, panelY + 35.0F, prefix, 12.0F, new Color(185, 190, 196, alphaInt));
         RenderUtil.drawText(context, startX + prefixWidth, panelY + 35.0F, this.getCurrentSessionNameInternal(), 12.0F, new Color(185, 190, 196, alphaInt));
      } else {
         float inAnim = Easings.easeOutBack(animProgress);
         float outAnim = Easings.easeOutCubic(animProgress);
         float newNameWidth = Msdf.getTextWidth(headerFont, this.getCurrentSessionNameInternal(), 12.0F);
         float oldNameWidth = Msdf.getTextWidth(headerFont, this.getPreviousSessionNameInternal(), 12.0F);
         float currentTotalWidth = prefixWidth + oldNameWidth + (newNameWidth - oldNameWidth) * inAnim;
         float startX = centerX - currentTotalWidth / 2.0F;
         RenderUtil.drawText(context, startX, panelY + 35.0F, prefix, 12.0F, new Color(185, 190, 196, alphaInt));
         float clipPad = 6.0F;
         Scissor.push((double)(startX + prefixWidth - clipPad), (double)(panelY + 35.0F - clipPad), (double)(Math.max(newNameWidth, oldNameWidth) + clipPad * 2.0F), (double)(12.0F + clipPad * 2.0F));
         float outYOffset = -15.0F * outAnim;
         int outAlpha = (int)((float)alphaInt * (1.0F - animProgress));
         if (outAlpha > 0) {
            RenderUtil.drawText(context, startX + prefixWidth, panelY + 35.0F + outYOffset, this.getPreviousSessionNameInternal(), 12.0F, new Color(185, 190, 196, outAlpha));
         }

         float inYOffset = 15.0F * (1.0F - inAnim);
         int inAlpha = (int)((float)alphaInt * Math.min(1.0F, animProgress * 2.0F));
         if (inAlpha > 0) {
            RenderUtil.drawText(context, startX + prefixWidth, panelY + 35.0F + inYOffset, this.getCurrentSessionNameInternal(), 12.0F, new Color(185, 190, 196, inAlpha));
         }

         Scissor.popTertiary();
      }

      float listX = panelX + 10.0F;
      float listY = panelY + 55.0F;
      float listW = (float)(panelW - 130.0F);
      float listH = (float)(panelH - 70.0F);
      RenderUtil.drawHudBlur(listX, listY, listW, listH, (float)radius, 8.0F, alpha, new Color(150, 150, 150, 20));
      List alts = AltManager.getAccounts();
      Scissor.push((double)listX, (double)listY, (double)listW, (double)listH);
      float currentY = listY + 5.0F + this.getScrollOffsetInternal();

      for(int i = 0; i < alts.size(); ++i) {
         AltManager.AltAccount alt = (AltManager.AltAccount)alts.get(i);
         if (!this.getEntryAppearTimesInternal().containsKey(alt.name)) {
            long stagger = currentTime - this.getOpenTimeInternal() < 100L ? (long)i * 40L : 0L;
            this.getEntryAppearTimesInternal().put(alt.name, currentTime + stagger);
         }

         long addTime = (Long)this.getEntryAppearTimesInternal().get(alt.name);
         float itemProgress = Math.max(0.0F, Math.min(1.0F, (float)(currentTime - addTime) / 400.0F));
         if (itemProgress != 0.0F) {
            float itemBounce = Easings.easeOutBack(itemProgress);
            float itemH = 26.0F;
            float actualItemH = itemH * Math.max(0.0F, Math.min(1.0F, itemProgress));
            float itemXOffset = (1.0F - itemBounce) * 20.0F;
            float itemAlphaMult = Math.max(0.0F, Math.min(1.0F, itemProgress * 2.0F));
            int itemAlphaInt = (int)((float)alphaInt * itemAlphaMult);
            float itemAlpha = alpha * itemAlphaMult;
            boolean hoverItem = mx >= listX + 5.0F && mx <= listX + listW - 5.0F && my >= currentY && my <= currentY + itemH;
            float targetHover = hoverItem ? 1.0F : 0.0F;
            float currentHover = (Float)this.getEntryHoverAnimationsInternal().getOrDefault(alt.name, 0.0F);
            currentHover += (targetHover - currentHover) * (deltaMs / 80.0F);
            currentHover = Math.max(0.0F, Math.min(1.0F, currentHover));
            this.getEntryHoverAnimationsInternal().put(alt.name, currentHover);
            float headSize = 16.0F;
            float headScale = 1.0F - currentHover;
            float actualHeadSize = headSize * headScale;
            float headX = listX + 10.0F + itemXOffset + (headSize - actualHeadSize) / 2.0F;
            float headY = currentY + 5.0F + (headSize - actualHeadSize) / 2.0F;
            if (actualHeadSize > 0.5F) {
               class_2960 avatar = SkinUtil.getOrLoadAvatar(alt.name);
               int colorRGB = (new Color(255, 255, 255, Math.round(255.0F * itemAlpha * headScale))).getRGB();
               if (avatar != null) {
                  GpuTextureView view = this.field_22787.method_1531().method_4619(avatar).method_71659();
                  TexturePipeline.drawSquareTextureRegionFiltered(RenderUtil.createGuiProjection(), headX, headY, actualHeadSize, view, colorRGB, 2.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, false);
               } else {
                  UUID offlineUuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + alt.name).getBytes());
                  class_2960 defaultSkin = class_1068.method_4648(offlineUuid).comp_1626().comp_3627();
                  GpuTextureView view = this.field_22787.method_1531().method_4619(defaultSkin).method_71659();
                  TexturePipeline.drawSquareTextureRegionFiltered(RenderUtil.createGuiProjection(), headX, headY, actualHeadSize, view, colorRGB, 2.0F, 0.0F, 0.125F, 0.125F, 0.125F, 0.125F, false);
                  TexturePipeline.drawSquareTextureRegionFiltered(RenderUtil.createGuiProjection(), headX, headY, actualHeadSize, view, colorRGB, 2.0F, 0.0F, 0.625F, 0.125F, 0.125F, 0.125F, false);
               }
            }

            float nameX = listX + 10.0F + itemXOffset + headSize + 6.0F - currentHover * (headSize + 6.0F);
            Color nameColor = currentName.equals(alt.name) ? new Color(255, 255, 255, itemAlphaInt) : new Color(100, 100, 100, itemAlphaInt);
            if (alt.isFavorite) {
               nameColor = new Color(255, 200, 50, itemAlphaInt);
            }

            RenderUtil.drawText(context, nameX, currentY + 9.0F, alt.name, 10.0F, nameColor);
            if (currentHover > 0.01F) {
               float iconAnim = Easings.easeOutBack(currentHover);
               float btnSize = 14.0F;
               float btnStartX = listX + listW - 5.0F - btnSize * 3.0F - 10.0F + itemXOffset;
               this.renderIconButton(context, "R", btnStartX, currentY + 6.0F, btnSize, mx, my, itemAlpha, alt.isFavorite ? new Color(255, 200, 50) : new Color(200, 200, 200), iconAnim);
               this.renderIconButton(context, "T", btnStartX + btnSize + 5.0F, currentY + 6.0F, btnSize, mx, my, itemAlpha, new Color(200, 200, 200), iconAnim);
               this.renderIconButton(context, "S", btnStartX + (btnSize + 5.0F) * 2.0F, currentY + 6.0F, btnSize, mx, my, itemAlpha, new Color(255, 80, 80), iconAnim);
            }

            currentY += actualItemH + 2.0F;
         }
      }

      Scissor.popTertiary();
      float controlsX = listX + listW + 10.0F;
      float controlsW = panelW - listW - 30.0F;
      float fieldH = 20.0F;
      float fieldClick = Easings.easeOutBack((Float)this.getClickAnimationsInternal().getOrDefault("field", 0.0F));
      float fieldScale = 1.0F - fieldClick * 0.05F;
      float actualFieldW = controlsW * fieldScale;
      float actualFieldH = fieldH * fieldScale;
      float fX = controlsX + (controlsW - actualFieldW) / 2.0F;
      float fY = listY + (fieldH - actualFieldH) / 2.0F;
      RenderUtil.drawHudBlur(fX, fY, actualFieldW, actualFieldH, 7.0F, 5.0F, alpha, new Color(150, 150, 150, 20));
      if (this.getNameInputInternal().isEmpty() && !this.getInputFocusedInternal()) {
         RenderUtil.drawText(context, fX + 5.0F, fY + 5.0F, "Nickname", 10.0F, new Color(185, 190, 196, alphaInt));
      } else {
         float currentX = fX + 5.0F;
         MsdfFont font = MsdfManager.getDefaultFont();

         for(int i = 0; i < this.getNameInputInternal().length(); ++i) {
            char c = this.getNameInputInternal().charAt(i);
            if (this.getInputCharacterAnimationsInternal()[i] < 1.0F) {
               float[] var109 = this.getInputCharacterAnimationsInternal();
               var109[i] += (1.0F - this.getInputCharacterAnimationsInternal()[i]) * (deltaMs / 60.0F);
               if (this.getInputCharacterAnimationsInternal()[i] > 1.0F) {
                  this.getInputCharacterAnimationsInternal()[i] = 1.0F;
               }
            }

            float charAnim = Easings.easeOutBack(this.getInputCharacterAnimationsInternal()[i]);
            if (charAnim > 0.05F) {
               int charAlpha = (int)(255.0F * alpha * Math.max(0.0F, Math.min(1.0F, this.getInputCharacterAnimationsInternal()[i])));
               float fullWidth = Msdf.getTextWidth(font, String.valueOf(c), 10.0F);
               float scaledSize = 10.0F * charAnim;
               float charScaledWidth = Msdf.getTextWidth(font, String.valueOf(c), scaledSize);
               float charX = currentX + (fullWidth - charScaledWidth) / 2.0F;
               float charY = fY + 5.0F + (10.0F - scaledSize) / 2.0F;
               RenderUtil.drawText(context, charX, charY, String.valueOf(c), scaledSize, new Color(245, 247, 250, charAlpha));
            }

            currentX += Msdf.getTextWidth(font, String.valueOf(c), 10.0F) + 0.5F;
         }

         if (this.getInputFocusedInternal() && System.currentTimeMillis() / 500L % 2L == 0L) {
            RenderUtil.drawText(context, currentX, fY + 5.0F, "_", 10.0F, new Color(245, 247, 250, alphaInt));
         }
      }

      float btnY = listY + 30.0F;
      String actionBtnText = this.getEditingAccountNameInternal() != null ? "Save" : "Add";
      this.renderButton(context, actionBtnText, controlsX, btnY, controlsW, 20.0F, mx, my, alpha, "actionBtn", deltaMs);
      btnY += 25.0F;
      this.renderButton(context, "Randomize", controlsX, btnY, controlsW, 20.0F, mx, my, alpha, "randBtn", deltaMs);
      super.method_25394(context, mouseX, mouseY, delta);
   }

   private void renderIconButton(class_332 context, String symbol, float x, float y, float size, float mx, float my, float alpha, Color baseColor, float iconAnim) {
      boolean hover = mx >= x && mx <= x + size && my >= y && my <= y + size;
      Color c = hover ? baseColor : new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), Math.round(150.0F));
      float flyAlpha = Math.max(0.0F, Math.min(1.0F, iconAnim));
      c = new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.round((float)c.getAlpha() * alpha * flyAlpha));
      if (flyAlpha > 0.05F) {
         float drawX = x + (1.0F - iconAnim) * 20.0F;
         RenderUtil.drawAlignedText(context, Msdf.WTMICO, drawX + size / 2.0F, y + 2.0F, symbol, 10.0F, c, "center");
      }

   }

   private void renderButton(class_332 context, String text, float x, float y, float w, float h, float mx, float my, float alpha, String id, float deltaMs) {
      boolean hover = mx >= x && mx <= x + w && my >= y && my <= y + h;
      float click = Easings.easeOutBack((Float)this.getClickAnimationsInternal().getOrDefault(id, 0.0F));
      float targetHover = hover ? 1.0F : 0.0F;
      float currentHover = (Float)this.getButtonHoverAnimationsInternal().getOrDefault(id, 0.0F);
      currentHover += (targetHover - currentHover) * (deltaMs / 60.0F);
      this.getButtonHoverAnimationsInternal().put(id, currentHover);
      float var16 = 1.0F + Easings.easeOutBack(currentHover) * 0.05F;
      float scale = var16 - click * 0.05F;
      float actualW = w * scale;
      float actualH = h * scale;
      float drawX = x + (w - actualW) / 2.0F;
      float drawY = y + (h - actualH) / 2.0F;
      float radius = 4.0F;
      RenderUtil.drawHudBlur(drawX, drawY, actualW, actualH, radius + 3.0F, 5.0F, alpha, new Color(150, 150, 150, 20));
      Color textColor = hover ? new Color(248, 250, 252, Math.round(255.0F * alpha)) : new Color(185, 190, 196, Math.round(210.0F * alpha));
      RenderUtil.drawAlignedText(context, drawX + actualW / 2.0F, drawY + 5.0F * scale, text, 10.0F * scale, textColor, "center");
   }

   public boolean mouseClicked(class_11909 click, boolean doubled) {
      float scaledWidth = (float)RenderUtil.getScaledWidth();
      float scaledHeight = (float)RenderUtil.getScaledHeight();
      double mouseX = click.comp_4798();
      double mouseY = click.comp_4799();
      int button = click.method_74245();
      float mx = RenderUtil.toScaledX((float)mouseX);
      float my = RenderUtil.toScaledY((float)mouseY);
      float panelW = 320.0F;
      float panelH = 240.0F;
      float centerX = scaledWidth / 2.0F;
      float centerY = scaledHeight / 2.0F;
      float panelX = centerX - panelW / 2.0F;
      float panelY = centerY - panelH / 2.0F;
      float listX = panelX + 10.0F;
      float listY = panelY + 55.0F;
      int listW = (int)(panelW - 130.0F);
      int listH = (int)(panelH - 70.0F);
      if (mx >= listX && mx <= listX + listW && my >= listY && my <= listY + listH) {
         List<AltManager.AltAccount> alts = AltManager.getAccounts();
         float currentY = listY + 5.0F + this.getScrollOffsetInternal();

         for(int i = 0; i < alts.size(); ++i) {
            float itemH = 26.0F;
            if (mx >= listX + 5.0F && mx <= listX + listW - 5.0F && my >= currentY && my <= currentY + itemH) {
               float currentHover = (Float)this.getEntryHoverAnimationsInternal().getOrDefault((alts.get(i)).name, 0.0F);
               if (currentHover > 0.5F) {
                  float btnSize = 14.0F;
                  float btnStartX = listX + listW - 5.0F - btnSize * 3.0F - 10.0F;
                  if (mx >= btnStartX && mx <= btnStartX + btnSize) {
                     AltManager.toggleFavorite((alts.get(i)).name);
                     return true;
                  }

                  if (mx >= btnStartX + btnSize + 5.0F && mx <= btnStartX + btnSize * 2.0F + 5.0F) {
                     this.setEditingAccountNameInternal((alts.get(i)).name);
                     this.setNameInputInternal(this.getEditingAccountNameInternal());
                     this.setInputFocusedInternal(true);

                     for(int j = 0; j < 16; ++j) {
                        this.getInputCharacterAnimationsInternal()[j] = j < this.getNameInputInternal().length() ? 1.0F : 0.0F;
                     }

                     return true;
                  }

                  if (mx >= btnStartX + (btnSize + 5.0F) * 2.0F && mx <= btnStartX + btnSize * 3.0F + 10.0F) {
                     AltManager.removeAccount((alts.get(i)).name);
                     return true;
                  }
               }

               this.switchSession((alts.get(i)).name);
               return true;
            }

            currentY += itemH + 2.0F;
         }
      }

      float controlsX = listX + listW + 10.0F;
      float controlsW = (float)(panelW - listW - 30.0F);
      this.setInputFocusedInternal(mx >= controlsX && mx <= controlsX + controlsW && my >= listY && my <= listY + 20.0F);
      if (this.getInputFocusedInternal() && button == 0) {
         this.getClickAnimationsInternal().put("field", 1.0F);
      }

      if (!this.getInputFocusedInternal() && button == 0 && mx >= panelX && mx <= panelX + panelW && my >= panelY && my <= panelY + panelH && (this.getEditingAccountNameInternal() == null || !this.isPointInside(mx, my, controlsX, listY + 30.0F, controlsW, 20.0F))) {
         this.setEditingAccountNameInternal((String)null);
      }

      float btnY = listY + 30.0F;
      if (!this.isPointInside(mx, my, controlsX, btnY, controlsW, 20.0F)) {
         btnY += 25.0F;
         if (this.isPointInside(mx, my, controlsX, btnY, controlsW, 20.0F)) {
            this.getClickAnimationsInternal().put("randBtn", 1.0F);
            String generated = this.generateRandomName();
            AltManager.addAccount(generated);
            return true;
         } else {
            return super.method_25402(click, doubled);
         }
      } else {
         this.getClickAnimationsInternal().put("actionBtn", 1.0F);
         if (!this.getNameInputInternal().isEmpty()) {
            if (this.getEditingAccountNameInternal() != null) {
               AltManager.renameAccount(this.getEditingAccountNameInternal(), this.getNameInputInternal());
               this.setEditingAccountNameInternal((String)null);
            } else {
               AltManager.addAccount(this.getNameInputInternal());
            }

            this.setNameInputInternal("");

            for(int j = 0; j < 16; ++j) {
               this.getInputCharacterAnimationsInternal()[j] = 0.0F;
            }
         }

         return true;
      }
   }

   private boolean isPointInside(float mx, float my, float x, float y, float w, float h) {
      return mx >= x && mx <= x + w && my >= y && my <= y + h;
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.setScrollOffsetInternal(this.getScrollOffsetInternal() + (float)(verticalAmount * 15.0D));
      if (this.getScrollOffsetInternal() > 0.0F) {
         this.setScrollOffsetInternal(0.0F);
      }

      return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
   }

   private void switchSession(String name) {
      ((IMinecraftClient)this.field_22787).setSession(this.createSessionWithName(this.field_22787.method_1548(), name));
   }

   private class_320 createSessionWithName(class_320 current, String name) {
      try {
         Constructor<class_320> c = class_320.class.getDeclaredConstructor(String.class, UUID.class, String.class, Optional.class, Optional.class);
         c.setAccessible(true);
         return c.newInstance(name, UUID.randomUUID(), current.method_1674(), Optional.empty(), Optional.empty());
      } catch (Exception var4) {
         throw new RuntimeException(var4);
      }
   }

   private String generateRandomName() {
      String[] prefixes = new String[]{"sacrificed", "angel", "dark", "shadow", "blood", "crimson", "silent", "dead", "cursed", "broken", "lost", "fallen", "hollow", "pale", "grim", "frost", "night", "doom", "void", "ghost", "weeping", "black", "ruined", "bleeding", "forsaken", "mystic", "cruel", "cold", "bitter", "fatal", "toxic", "venom", "death", "fear", "pain", "agony", "grief", "sorrow", "tragic", "gothic", "vamp", "witch", "demon", "devil", "evil", "sin", "vile", "pure", "divine", "holy", "sacred", "abyss", "phantom", "specter", "spirit", "wraith", "ghoul", "vampire", "werewolf", "dragon", "beast", "monster", "astral", "lunar", "solar", "cosmic", "stellar", "twilight", "midnight", "dusk", "eclipse", "storm", "thunder", "rain", "wind", "fire", "flame", "ash", "ember", "smoke", "dust", "iron", "steel", "silver", "gold", "ruby", "onyx", "opal", "jade", "pearl", "diamond", "crystal", "glass", "mirror", "dream", "nightmare", "vision", "starlight", "moonlight", "sad", "lonely", "hidden", "secret", "blind", "freezing", "burning", "glowing", "fading", "dying", "crying", "sighing", "sleeping", "waking", "dreaming", "falling", "flying", "drowning", "sinking", "floating", "rising", "hiding", "seeking", "losing", "taking", "breaking", "destroying", "killing", "saving", "healing", "hurting", "loving", "hating", "kissing", "biting", "scratching", "feeling", "surviving", "escaping", "fleeing", "crawling", "creeping", "sneaking", "waiting", "watching", "listening", "somber", "morbid", "ghastly", "macabre", "eerie", "spooky", "creepy", "sinister", "diabolical", "fiendish", "hellish", "infernal", "wicked", "corrupt", "twisted", "warped", "sick", "deranged", "insane", "mad", "psycho", "manic", "frantic", "wild", "savage", "feral", "rabid", "vicious", "brutal", "ruthless", "merciless", "pitiless", "heartless", "soulless", "mindless", "faceless", "nameless", "formless", "endless", "timeless", "deathless", "immortal", "eternal", "infinite", "grave", "tomb", "crypt", "vault", "cage", "trap", "snare", "net", "web"};
      String[] suffixes = new String[]{"heart", "knife", "blade", "soul", "tears", "blood", "moon", "star", "scythe", "shade", "thorn", "crown", "reaper", "raven", "rose", "dust", "ash", "bone", "skull", "ghost", "flame", "bane", "beast", "demon", "angel", "wing", "sword", "dagger", "fang", "claw", "horn", "eye", "gaze", "kiss", "bite", "mark", "scar", "vein", "pulse", "breath", "song", "cry", "scream", "whisper", "echo", "shadow", "night", "mist", "fog", "cloud", "vapor", "poison", "cure", "life", "death", "rebirth", "flesh", "skin", "hair", "tail", "feather", "silk", "thread", "chain", "wire", "cord", "path", "way", "gate", "door", "wall", "room", "base", "fort", "castle", "tower", "city", "town", "kingdom", "empire", "world", "planet", "galaxy", "universe", "dimension", "realm", "domain", "space", "heaven", "hell", "purgatory", "limbo", "nexus", "core", "edge", "end", "start", "origin", "source", "seed", "tree", "flower", "leaf", "branch", "root", "grass", "weed", "bush", "forest", "wood", "jungle", "swamp", "desert", "sand", "dirt", "mud", "rock", "stone", "mountain", "hill", "valley", "cliff", "cave", "mine", "pit", "hole", "volcano", "ocean", "sea", "lake", "river", "stream", "drop", "tear", "sweat", "nectar", "honey", "wax", "amber", "coral", "shell", "ivory", "hoof", "slayer", "walker", "hunter", "bringer", "seeker", "keeper", "master", "lord", "king", "queen", "prince", "princess", "child", "boy", "girl", "man", "woman", "god", "goddess", "deity", "idol", "hero", "villain", "friend", "foe", "enemy", "ally", "lover", "partner", "mate", "companion", "pet", "slave", "servant", "ruler", "leader", "follower", "guide", "teacher", "student", "learner", "speaker", "singer", "dancer", "player", "maker", "creator", "destroyer", "killer", "savior", "healer", "hurter", "pain", "agony", "fear", "terror", "horror", "dread", "panic", "fright", "shock", "awe", "wonder", "magic", "spell", "charm", "hex", "curse", "jinx", "trick", "illusion", "dream", "nightmare", "vision", "memory", "thought", "mind", "brain", "spirit", "phantom", "specter", "wraith", "ghoul", "zombie", "mummy", "vampire", "werewolf", "dragon", "serpent", "snake", "viper", "cobra", "spider", "scorpion", "wasp", "bee", "ant", "fly", "bug", "worm", "slug", "snail", "leech"};
      Random rand = new Random();
      String result = "";

      do {
         String p = prefixes[rand.nextInt(prefixes.length)];
         String s = suffixes[rand.nextInt(suffixes.length)];
         result = p + s;
      } while(result.length() > 16);

      return result;
   }

   public boolean charTyped(class_11908 input) {
      if (input.comp_4795() == 256) {
         this.field_22787.method_1507(this.getParentInternal());
         return true;
      } else {
         if (this.getInputFocusedInternal()) {
            if (input.comp_4795() == 259 && this.getNameInputInternal().length() > 0) {
               this.setNameInputInternal(this.getNameInputInternal().substring(0, this.getNameInputInternal().length() - 1));
               this.getInputCharacterAnimationsInternal()[this.getNameInputInternal().length()] = 0.0F;
               return true;
            }

            if (input.comp_4795() == 257) {
               if (!this.getNameInputInternal().isEmpty()) {
                  if (this.getEditingAccountNameInternal() != null) {
                     AltManager.renameAccount(this.getEditingAccountNameInternal(), this.getNameInputInternal());
                     this.setEditingAccountNameInternal((String)null);
                  } else {
                     AltManager.addAccount(this.getNameInputInternal());
                  }

                  this.setNameInputInternal("");

                  for(int i = 0; i < 16; ++i) {
                     this.getInputCharacterAnimationsInternal()[i] = 0.0F;
                  }
               }

               return true;
            }

            if (input.comp_4795() == 86 && (GLFW.glfwGetKey(this.field_22787.method_22683().method_4490(), 341) == 1 || GLFW.glfwGetKey(this.field_22787.method_22683().method_4490(), 345) == 1)) {
               String clipboard = this.field_22787.field_1774.method_1460();
               if (clipboard != null) {
                  String var10001 = this.getNameInputInternal();
                  this.setNameInputInternal(var10001 + clipboard.replaceAll("[^a-zA-Z0-9_]", ""));
                  if (this.getNameInputInternal().length() > 16) {
                     this.setNameInputInternal(this.getNameInputInternal().substring(0, 16));
                  }
               }

               return true;
            }
         }

         return super.method_25404(input);
      }
   }

   public boolean keyPressed(class_11905 input) {
      if (this.getInputFocusedInternal() && input.method_74227() && this.getNameInputInternal().length() < 16) {
         String var10001 = this.getNameInputInternal();
         this.setNameInputInternal(var10001 + input.method_74226());
         return true;
      } else {
         return super.method_25400(input);
      }
   }

   private class_437 getParentInternal() {
      return this.field_6d2b79f5;
   }

   private String getNameInputInternal() {
      return this.field_da56f3ea;
   }

   private void setNameInputInternal(String var1) {
      this.field_da56f3ea = var1;
   }

   private boolean getInputFocusedInternal() {
      return this.field_47826ddf;
   }

   private void setInputFocusedInternal(boolean var1) {
      this.field_47826ddf = var1;
   }

   private float getScrollOffsetInternal() {
      return this.field_b4ade7d4;
   }

   private void setScrollOffsetInternal(float var1) {
      this.field_b4ade7d4 = var1;
   }

   private long getOpenTimeInternal() {
      return this.field_21d961c9;
   }

   private void setOpenTimeInternal(long var1) {
      this.field_21d961c9 = var1;
   }

   private long getLastFrameTimeInternal() {
      return this.field_8f04dbbe;
   }

   private void setLastFrameTimeInternal(long var1) {
      this.field_8f04dbbe = var1;
   }

   private Map getEntryHoverAnimationsInternal() {
      return this.field_fc3055b3;
   }

   private String getEditingAccountNameInternal() {
      return this.field_695bcfa8;
   }

   private void setEditingAccountNameInternal(String var1) {
      this.field_695bcfa8 = var1;
   }

   private float getUnusedAnimationXInternal() {
      return this.field_d687499d;
   }

   private void setUnusedAnimationXInternal(float var1) {
      this.field_d687499d = var1;
   }

   private float getUnusedAnimationYInternal() {
      return this.field_43b2c392;
   }

   private void setUnusedAnimationYInternal(float var1) {
      this.field_43b2c392 = var1;
   }

   private Map<String, Float> getClickAnimationsInternal() {
      return this.field_b0de3d87;
   }

   private Map getButtonHoverAnimationsInternal() {
      return this.field_1e09b77c;
   }

   private String getCurrentSessionNameInternal() {
      return this.field_8b353171;
   }

   private void setCurrentSessionNameInternal(String var1) {
      this.field_8b353171 = var1;
   }

   private String getPreviousSessionNameInternal() {
      return this.field_f860ab66;
   }

   private void setPreviousSessionNameInternal(String var1) {
      this.field_f860ab66 = var1;
   }

   private long getSessionNameChangeTimeInternal() {
      return this.field_658c255b;
   }

   private void setSessionNameChangeTimeInternal(long var1) {
      this.field_658c255b = var1;
   }

   private Map getEntryAppearTimesInternal() {
      return this.field_d2b79f50;
   }

   private float[] getInputCharacterAnimationsInternal() {
      return this.field_3fe31945;
   }

}
