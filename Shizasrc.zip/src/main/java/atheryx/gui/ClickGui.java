package atheryx.gui;

import atheryx.gui.component.ModuleComponent;
import atheryx.module.Category;
import atheryx.module.FunctionManager;
import atheryx.render.RenderUtil;
import atheryx.render.font.Msdf;
import atheryx.render.scissor.Scissor;
import atheryx.util.math.Easings;
import java.awt.Color;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1109;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_437;

public class ClickGui extends class_437 {
   private static final Category[] obf_u042b_u0432;
   private static final float obf_u0455_u0432 = 112.0F;
   private static final float obf_u03a3_u0432 = 290.0F;
   private static final float obf_u2202_u0432 = 10.0F;
   private static final float obf_u00c2_u0432 = 8.0F;
   private static final float obf_u03a1_u0432 = 25.0F;
   private static final float obf_u00c1_u0432 = 21.0F;
   private static final float obf_u00f6_u0432 = 104.0F;
   private static final float obf_u2229_u0432 = 4.0F;
   private static final float obf_u039c_u0432 = 9.80000019F;
   private static final float obf_u040c_u0432 = 9.80000019F;
   private static final float obf_u0446_u0432 = 70.0F;
   private static final float obf_u0457_u0432 = 24.0F;
   private static final float obf_u045d_u0432 = 20.0F;
   private static final float obf_u2223_u0432 = 132.0F;
   private static final float obf_u03c8_u0432 = 108.0F;
   private static final float obf_u221c_u03b2 = 78.0F;
   private static final float obf_u221b_u03b2 = 10.0F;
   private static final float obf_u2208_u03b2 = 62.0F;
   private static final float obf_u222f_u03b2 = 18.0F;
   private static final float obf_u0432_u03b2 = 25.0F;
   private static final float obf_u03b2_u03b2 = 180.0F;
   private static final float obf_u220e_u03b2 = 180.0F;
   private static final float obf_u2201_u03b2 = 0.0199999996F;
   private static final float obf_u0426_u03b2 = 0.0179999992F;
   private static final float obf_u00c9_u03b2 = 0.0250000004F;
   private final Map<Category, List<ModuleComponent>> field_6d2b79f5 = new EnumMap<Category, List<ModuleComponent>>(Category.class);
   private final Map<Category, Float> field_da56f3ea = new EnumMap<Category, Float>(Category.class);
   private final Map<Category, Float> field_47826ddf = new EnumMap<Category, Float>(Category.class);
   private long field_b4ade7d4;
   private boolean field_21d961c9;
   private boolean field_8f04dbbe;
   private boolean field_fc3055b3;
   private boolean field_695bcfa8;
   private int field_d687499d;
   private float field_43b2c392;
   private float field_b0de3d87;
   private float field_1e09b77c;
   private float field_8b353171;
   private boolean field_f860ab66;
   private float field_658c255b;
   private long field_d2b79f50;
   private float field_3fe31945;
   private float field_ad0e933a;
   private int field_1a3a0d2f;
   private float field_87658724;
   private float field_f4910119;
   private long field_61bc7b0e;
   private long field_cee7f503;
   private ModuleComponent field_3c136ef8;
   private String field_a93ee8ed;
   private String field_166a62e2;
   private long field_8395dcd7;
   private boolean field_f0c156cc;
   private float field_5decd0c1;
   private long field_cb184ab6;
   private float field_3843c4ab;
   private float field_a56f3ea0;
   private float field_129ab895;
   private boolean field_7fc6328a;
   private boolean field_ecf1ac7f;
   private String field_5a1d2674;
   private boolean field_c748a069;
   private float field_34741a5e;
   private final List<AnimatedCharacter> field_a19f9453;

   public ClickGui() {
      super(class_2561.method_30163("Minar"));
      this.setSelectedThemeIndexInternal(-1);
      this.setContextThemeIndexInternal(-2147483648);
      this.setCurrentDescriptionInternal("");
      this.setPreviousDescriptionInternal("");
      this.setDescriptionChangeTimeInternal(0L);
      this.setSearchTextInternal("");
      this.setSearchFocusedInternal(false);
      this.setSearchAnimationInternal(0.0F);
      this.field_a19f9453 = new ArrayList<AnimatedCharacter>();
      this.rebuildModuleComponents();
   }

   /*
    * The project is compiled against intermediary Minecraft mappings.  Keep the
    * readable methods below, but expose the actual Screen overrides as bridges.
    * Without these bridges Minecraft only renders Screen's dimmed background and
    * dispatches input to Screen, so the ClickGUI itself is never drawn or clicked.
    */
   @Override
   public boolean method_25421() {
      return this.shouldPause();
   }

   @Override
   public void method_49589() {
      this.onOpened();
   }

   @Override
   public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      this.renderScreen(context, mouseX, mouseY, deltaTicks);
   }

   @Override
   public void method_25420(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      this.renderScreenContent(context, mouseX, mouseY, deltaTicks);
   }

   @Override
   public void method_25419() {
      this.close();
   }

   @Override
   public boolean method_25402(class_11909 click, boolean doubled) {
      return this.mouseClicked(click, doubled);
   }

   @Override
   public boolean method_25404(class_11908 input) {
      return this.charTyped(input);
   }

   @Override
   public boolean method_25400(class_11905 input) {
      return this.keyPressed(input);
   }

   @Override
   public boolean method_25403(class_11909 click, double offsetX, double offsetY) {
      return this.mouseDragged(click, offsetX, offsetY);
   }

   @Override
   public boolean method_25406(class_11909 click) {
      return this.mouseReleased(click);
   }

   @Override
   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      return this.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
   }

   public boolean shouldPause() {
      return false;
   }

   public void onOpened() {
      this.setClosingInternal(false);
      this.setScreenAnimationStartInternal(System.currentTimeMillis());
      this.setLastFrameTimeInternal(0L);
      this.setPickerAnimationInternal(this.getColorPickerOpenInternal() ? 1.0F : 0.0F);
      this.setPaletteOpenInternal(false);
      this.setPaletteAnimationOriginInternal(0.0F);
      float pickerOffset = this.getColorPickerOpenInternal() ? this.getPickerAnimationInternal() : 1.0F - this.getPickerAnimationInternal();
      this.setPickerAnimationStartInternal(System.currentTimeMillis() - (long)(pickerOffset * 180.0F));
      this.setContextMenuAnimationInternal(this.isThemeContextMenuOpen() ? 1.0F : 0.0F);
      this.setThemeListExpandedInternal(false);
      this.setThemeListAnimationOriginInternal(0.0F);
      class_310.method_1551().method_1483().method_4873(class_1109.method_4757(class_3414.method_47908(class_2960.method_60655("atheryx", "gui_open")), 1.0F, 1.0F));
      super.method_49589();
   }

   public void renderScreen(class_332 context, int mouseX, int mouseY, float deltaTicks) {
      float fixedMouseX = RenderUtil.toScaledX((float)mouseX);
      float fixedMouseY = RenderUtil.toScaledY((float)mouseY);
      this.updateAnimations();
      this.setHoveredModuleInternal((ModuleComponent)null);
      float animation = this.getOpenAnimationProgress();
      if (this.getClosingInternal() && animation <= 0.01F) {
         this.field_22787.method_1507((class_437)null);
      } else {
         float eased = Easings.easeOutCubic(animation);
         float scale = 0.86F + eased * 0.14F;
         float totalWidth = this.getPanelAreaWidth();
         float totalHeight = this.getPanelAreaHeight();
         float x = ((float)RenderUtil.getScaledWidth() - totalWidth) / 2.0F;
         float y = ((float)RenderUtil.getScaledHeight() - totalHeight) / 2.0F;
         float centerX = (float)RenderUtil.getScaledWidth() / 2.0F;
         float centerY = (float)RenderUtil.getScaledHeight() / 2.0F;
         this.renderCategoryPanels(context, x, y + 27.0F, fixedMouseX, fixedMouseY, centerX, centerY, scale, eased);
         this.renderSearchBar(context, x, y + 27.0F + 290.0F + 8.0F, centerX, centerY, scale, eased);
         this.renderThemeSelector(context, fixedMouseX, fixedMouseY, centerX, centerY, scale, eased);
         if (this.getHoveredModuleInternal() != null && this.getHoveredModuleInternal().getFunction().getDescription() != null) {
            String desc = this.getHoveredModuleInternal().getFunction().getDescription();
            if (this.getCurrentDescriptionInternal().isEmpty()) {
               this.setCurrentDescriptionInternal(desc);
               this.setPreviousDescriptionInternal("");
               this.setDescriptionChangeTimeInternal(System.currentTimeMillis());
            } else if (!desc.equals(this.getCurrentDescriptionInternal())) {
               this.setPreviousDescriptionInternal(this.getCurrentDescriptionInternal());
               this.setCurrentDescriptionInternal(desc);
               this.setDescriptionChangeTimeInternal(System.currentTimeMillis());
            }
         } else if (!this.getCurrentDescriptionInternal().isEmpty()) {
            this.setPreviousDescriptionInternal(this.getCurrentDescriptionInternal());
            this.setCurrentDescriptionInternal("");
            this.setDescriptionChangeTimeInternal(System.currentTimeMillis());
         }

         this.renderDescriptionTooltip(context, fixedMouseX, fixedMouseY, scale, eased);
         super.method_25394(context, mouseX, mouseY, deltaTicks);
      }
   }

   public void renderScreenContent(class_332 context, int mouseX, int mouseY, float deltaTicks) {
   }

   public void close() {
      if (!this.getClosingInternal()) {
         ThemeManager.save();
         this.setClosingInternal(true);
         this.setScreenAnimationStartInternal(System.currentTimeMillis());
         class_310.method_1551().method_1483().method_4873(class_1109.method_4757(class_3414.method_47908(class_2960.method_60655("atheryx", "gui_close")), 1.0F, 1.0F));
      }
   }

   public boolean mouseClicked(class_11909 click, boolean doubled) {
      if (!this.getClosingInternal() && !(this.getOpenAnimationProgress() < 0.95F)) {
         float fixedMouseX = RenderUtil.toScaledX((float)click.comp_4798());
         float fixedMouseY = RenderUtil.toScaledY((float)click.comp_4799());
         int button = click.method_74245();
         float totalWidth = this.getPanelAreaWidth();
         float totalHeight = this.getPanelAreaHeight();
         float x = ((float)RenderUtil.getScaledWidth() - totalWidth) / 2.0F;
         float y = ((float)RenderUtil.getScaledHeight() - totalHeight) / 2.0F + 27.0F;
         if (button == 0 || button == 1) {
            float searchWidth = 140.0F;
            float searchHeight = 24.0F;
            float searchX = x + (totalWidth - searchWidth) / 2.0F;
            float searchY = y + 290.0F + 8.0F;
            this.setSearchFocusedInternal(this.isPointInside(fixedMouseX, fixedMouseY, searchX, searchY, searchWidth, searchHeight));
            if (this.getSearchFocusedInternal()) {
               return true;
            }
         }

         if (this.handleThemeSelectorClick(fixedMouseX, fixedMouseY, button)) {
            return true;
         } else {
            for(int i = 0; i < obf_u042b_u0432.length; ++i) {
               Category category = obf_u042b_u0432[i];
               float panelX = this.getCategoryPanelX(x, i);
               float panelY = this.getCategoryPanelY(y, i);
               float moduleWidth = 104.0F;
               float viewportX = panelX + (112.0F - moduleWidth) / 2.0F;
               float viewportY = panelY + 25.0F + 8.0F;
               float viewportHeight = 249.0F;
               if (this.isPointInside(fixedMouseX, fixedMouseY, viewportX, viewportY, moduleWidth, (float)viewportHeight)) {
                  for(ModuleComponent component : this.getComponentsByCategoryInternal().getOrDefault(category, List.of())) {
                     if (component.mouseClicked(fixedMouseX, fixedMouseY, button)) {
                        return true;
                     }
                  }
               }
            }

            return super.method_25402(click, doubled);
         }
      } else {
         return true;
      }
   }

   public boolean charTyped(class_11908 input) {
      int keyCode = input.comp_4795();

      for(List<ModuleComponent> components : this.getComponentsByCategoryInternal().values()) {
         for(ModuleComponent component : components) {
            if (component.keyPressed(keyCode)) {
               if (keyCode == 259) {
                  this.playKeyboardSound();
               }

               return true;
            }
         }
      }

      if (this.getSearchFocusedInternal()) {
         if (keyCode == 259 && !this.getSearchTextInternal().isEmpty()) {
            this.setSearchTextInternal(this.getSearchTextInternal().substring(0, this.getSearchTextInternal().length() - 1));
            if (!this.getDescriptionGlyphsInternal().isEmpty()) {
               this.getDescriptionGlyphsInternal().remove(this.getDescriptionGlyphsInternal().size() - 1);
            }

            this.rebuildModuleComponents();
            this.playKeyboardSound();
            return true;
         }

         if (keyCode == 257 || keyCode == 335 || keyCode == 256) {
            this.setSearchFocusedInternal(false);
            return true;
         }
      }

      return super.method_25404(input);
   }

   public boolean keyPressed(class_11905 input) {
      if (!input.method_74227()) {
         return super.method_25400(input);
      } else {
         for(List<ModuleComponent> components : this.getComponentsByCategoryInternal().values()) {
            for(ModuleComponent component : components) {
               if (component.charTyped(input.method_74226())) {
                  this.playKeyboardSound();
                  return true;
               }
            }
         }

         if (this.getSearchFocusedInternal()) {
            String var10001 = this.getSearchTextInternal();
            this.setSearchTextInternal(var10001 + input.method_74226());
            this.getDescriptionGlyphsInternal().add(new AnimatedCharacter(input.method_74226()));
            this.rebuildModuleComponents();
            this.playKeyboardSound();
            return true;
         } else {
            return super.method_25400(input);
         }
      }
   }

   private void playKeyboardSound() {
      int randomId = 1 + (int)(Math.random() * 7.0D);
      class_310.method_1551().method_1483().method_4873(class_1109.method_4757(class_3414.method_47908(class_2960.method_60655("atheryx", "keyboard_" + String.valueOf(randomId))), 1.0F, 1.0F));
   }

   public boolean mouseDragged(class_11909 click, double offsetX, double offsetY) {
      if (!this.getColorPickerOpenInternal() && !(this.getPickerAnimationInternal() > 0.02F) || !this.getDraggingPrimaryPickerInternal() && !this.getDraggingPrimaryHueInternal() && !this.getDraggingSecondaryPickerInternal() && !this.getDraggingSecondaryHueInternal()) {
         float fixedMouseX = RenderUtil.toScaledX((float)click.comp_4798());
         float fixedMouseY = RenderUtil.toScaledY((float)click.comp_4799());
         int button = click.method_74245();

         for(List<ModuleComponent> components : this.getComponentsByCategoryInternal().values()) {
            for(ModuleComponent component : components) {
               if (component.mouseDragged(fixedMouseX, fixedMouseY, button)) {
                  return true;
               }
            }
         }

         return super.method_25403(click, offsetX, offsetY);
      } else {
         float fixedMouseX = RenderUtil.toScaledX((float)click.comp_4798());
         float fixedMouseY = RenderUtil.toScaledY((float)click.comp_4799());
         this.updateColorPickerDrag(fixedMouseX, fixedMouseY);
         return true;
      }
   }

   public boolean mouseReleased(class_11909 click) {
      this.setDraggingPrimaryPickerInternal(false);
      this.setDraggingPrimaryHueInternal(false);
      this.setDraggingSecondaryPickerInternal(false);
      this.setDraggingSecondaryHueInternal(false);

      for(List<ModuleComponent> components : this.getComponentsByCategoryInternal().values()) {
         for(ModuleComponent component : components) {
            component.cancelSettingDrag();
         }
      }

      if (this.getSelectedThemeIndexInternal() >= 0 && this.getSelectedThemeIndexInternal() < ThemeManager.CUSTOM_THEMES.size()) {
         ThemeManager.updateCustomTheme(this.getSelectedThemeIndexInternal(), ThemeManager.Theme_Color);
      } else {
         ThemeManager.save();
      }

      return super.method_25406(click);
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (!this.getClosingInternal() && !(this.getOpenAnimationProgress() < 0.95F)) {
         float fixedMouseX = RenderUtil.toScaledX((float)mouseX);
         float fixedMouseY = RenderUtil.toScaledY((float)mouseY);
         float totalWidth = this.getPanelAreaWidth();
         float totalHeight = this.getPanelAreaHeight();
         float x = ((float)RenderUtil.getScaledWidth() - totalWidth) / 2.0F;
         float y = ((float)RenderUtil.getScaledHeight() - totalHeight) / 2.0F + 27.0F;

         for(int i = 0; i < obf_u042b_u0432.length; ++i) {
            Category category = obf_u042b_u0432[i];
            float panelX = this.getCategoryPanelX(x, i);
            float panelY = this.getCategoryPanelY(y, i);
            if (this.isPointInside(fixedMouseX, fixedMouseY, panelX, panelY + 25.0F, 112.0F, 265.0F)) {
               float currentTarget = (Float)this.getTargetScrollOffsetsInternal().getOrDefault(category, (Float)this.getScrollOffsetsInternal().getOrDefault(category, 0.0F));
               float next = currentTarget - (float)verticalAmount * 25.0F;
               this.getTargetScrollOffsetsInternal().put(category, Math.clamp(next, 0.0F, this.getMaxScroll(category)));
               return true;
            }
         }

         return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
      } else {
         return true;
      }
   }

   private float getOpenAnimationProgress() {
      float progress = (float)(System.currentTimeMillis() - this.getScreenAnimationStartInternal()) / 180.0F;
      progress = Math.clamp(progress, 0.0F, 1.0F);
      return this.getClosingInternal() ? 1.0F - progress : progress;
   }

   private void updateAnimations() {
      long now = System.currentTimeMillis();
      if (this.getLastFrameTimeInternal() == 0L) {
         this.setLastFrameTimeInternal(now);
      } else {
         float delta = Math.min(50.0F, (float)(now - this.getLastFrameTimeInternal()));
         this.setLastFrameTimeInternal(now);
         this.setPickerAnimationInternal(this.getColorPickerAnimationProgress());
         this.setPaletteAnimationOriginInternal(this.getPaletteAnimationProgress());
         this.setThemeListAnimationOriginInternal(this.getThemeListAnimationProgress());
         this.setContextMenuAnimationInternal(this.animateTowards(this.getContextMenuAnimationInternal(), this.isThemeContextMenuOpen() ? 1.0F : 0.0F, 0.02F, delta));
         this.setThemeListAnimationInternal(this.animateTowards(this.getThemeListAnimationInternal(), 0.0F, 0.018F, delta));

         for(Category category : obf_u042b_u0432) {
            float current = (Float)this.getScrollOffsetsInternal().getOrDefault(category, 0.0F);
            float target = (Float)this.getTargetScrollOffsetsInternal().getOrDefault(category, current);
            target = Math.clamp(target, 0.0F, this.getMaxScroll(category));
            this.getTargetScrollOffsetsInternal().put(category, target);
            this.getScrollOffsetsInternal().put(category, this.animateTowards(current, target, 0.025F, delta));
         }

         for(AnimatedCharacter ac : this.getDescriptionGlyphsInternal()) {
            ac.animation = this.animateTowards(ac.animation, 1.0F, 0.03F, delta);
         }

         float targetPlaceholder = !this.getSearchFocusedInternal() && this.getSearchTextInternal().isEmpty() && this.getDescriptionGlyphsInternal().isEmpty() ? 0.0F : 1.0F;
         this.setSearchAnimationInternal(this.animateTowards(this.getSearchAnimationInternal(), targetPlaceholder, 0.04F, delta));
      }
   }

   private void renderCategoryPanels(class_332 context, float x, float y, float mouseX, float mouseY, float centerX, float centerY, float scale, float opacity) {
      for(int i = 0; i < obf_u042b_u0432.length; ++i) {
         Category category = obf_u042b_u0432[i];
         this.renderCategoryPanel(context, category, this.getCategoryPanelX(x, i), this.getCategoryPanelY(y, i), mouseX, mouseY, centerX, centerY, scale, opacity);
      }

   }

   private void renderThemeSelector(class_332 context, float mouseX, float mouseY, float centerX, float centerY, float scale, float opacity) {
      float buttonWidth = 70.0F * scale;
      float buttonHeight = 24.0F * scale;
      float buttonX = (float)RenderUtil.getScaledWidth() - 70.0F - 10.0F;
      float buttonY = (float)RenderUtil.getScaledHeight() - 24.0F - 10.0F;
      float renderX = this.scaleXAroundCenter(buttonX, centerX, scale);
      this.scaleYAroundCenter(buttonY, centerY, scale);
      int var14 = 2 + ThemeManager.CUSTOM_THEMES.size();
      float menuHeight = (float)var14 * 20.0F + 20.0F;
      float easeProgress = this.getThemeListExpandedInternal() ? Easings.easeOutBack(this.getThemeListAnimationOriginInternal()) : Easings.easeOutCubic(this.getThemeListAnimationOriginInternal());
      float expandedHeight = 24.0F + menuHeight * easeProgress;
      float currentY = buttonY + 24.0F - expandedHeight;
      float renderCurrentY = this.scaleYAroundCenter(currentY, centerY, scale);
      float renderExpandedHeight = expandedHeight * scale;
      RenderUtil.drawHudBlur(renderX, renderCurrentY, buttonWidth, renderExpandedHeight, 8.0F * scale, 25.0F, opacity, new Color(18, 18, 22, 140));
      if (this.getThemeListAnimationOriginInternal() > 0.02F) {
         Scissor.push((double)renderX, (double)renderCurrentY, (double)buttonWidth, (double)(renderExpandedHeight - buttonHeight));
         this.renderThemeOption(context, renderX, renderCurrentY, buttonWidth, 20.0F * scale, "Фиолетовая", ThemeManager.PASTEL_PURPLE, mouseX, mouseY, scale, opacity);
         float itemY = renderCurrentY + 20.0F * scale;
         this.renderThemeOption(context, renderX, itemY, buttonWidth, 20.0F * scale, "Синяя", ThemeManager.PASTEL_BLUE, mouseX, mouseY, scale, opacity);
         itemY += 20.0F * scale;

         for(int i = 0; i < ThemeManager.CUSTOM_THEMES.size(); ++i) {
            this.renderThemeOption(context, renderX, itemY, buttonWidth, 20.0F * scale, "Кастом " + String.valueOf(i + 1), ThemeManager.CUSTOM_THEMES.get(i), mouseX, mouseY, scale, opacity);
            itemY += 20.0F * scale;
         }

         float plusSize = 10.0F * scale;
         float plusX = renderX + buttonWidth / 2.0F;
         boolean var24 = this.isPointInside(mouseX, mouseY, renderX, itemY, buttonWidth, 20.0F * scale);
         Color plusColor = var24 ? this.applyOpacity(ThemeManager.Theme_Color, opacity) : this.applyOpacity(new Color(72, 72, 76), opacity);
         RenderUtil.drawAlignedText(context, plusX, itemY + (20.0F * scale - Msdf.getTextHeight(12.0F * scale)) / 2.0F, "+", 12.0F * scale, plusColor, "center");
         Scissor.popTertiary();
         if (this.getPaletteOpenInternal() || this.getPaletteAnimationOriginInternal() > 0.02F) {
            float plusMenuEase = Easings.easeOutCubic(this.getPaletteAnimationOriginInternal());
            float plusMenuOpacity = opacity * plusMenuEase;
            this.renderColorModeMenu(context, renderX - 70.0F * scale - 6.0F * scale, itemY - 36.0F * scale, scale, plusMenuOpacity);
         }
      }

      float textY = renderCurrentY + renderExpandedHeight - buttonHeight / 2.0F - Msdf.getTextHeight(8.5F * scale) / 2.0F;
      Color textColor = this.getThemeListExpandedInternal() ? this.applyOpacity(ThemeManager.Theme_Color, opacity) : this.applyOpacity(Color.WHITE, opacity);
      RenderUtil.drawAlignedText(context, renderX + buttonWidth / 2.0F, textY, "Темы", 8.5F * scale, textColor, "center");
      if (this.getColorPickerOpenInternal() || this.getPickerAnimationInternal() > 0.02F) {
         float pickerEase = Easings.easeOutCubic(this.getPickerAnimationInternal());
         float pickerScale = scale * (0.94F + pickerEase * 0.06F);
         float pickerOpacity = opacity * pickerEase;
         float plusMenuY = this.scaleXAroundCenter(this.getColorPickerX(), centerX, scale);
         float pickerY = this.scaleYAroundCenter(this.getColorPickerY(), centerY, scale);
         this.renderColorPickers(context, plusMenuY, pickerY, pickerScale, pickerOpacity);
      }

      if (this.isThemeContextMenuOpen() || this.getContextMenuAnimationInternal() > 0.02F) {
         this.renderThemeContextMenu(context, this.getContextMenuXInternal(), this.getContextMenuYInternal(), scale, opacity * this.getContextMenuAnimationInternal());
      }

   }

   private void renderThemeOption(class_332 context, float x, float y, float width, float height, String name, Color color, float mouseX, float mouseY, float scale, float opacity) {
      boolean hovered = this.isPointInside(mouseX, mouseY, x, y, width, height);
      if (hovered) {
         RenderUtil.drawRoundedRect(x, y, width, height, 0.0F, this.applyOpacity(new Color(255, 255, 255, 10), opacity));
      }

      float dotSize = 8.0F * scale;
      RenderUtil.drawRoundedRect(x + 8.0F * scale, y + (height - dotSize) / 2.0F, dotSize, dotSize, dotSize / 2.0F, this.applyOpacity(color, opacity));
      if (this.colorsEqual(color, ThemeManager.Theme_Color)) {
         RenderUtil.drawRoundedOutline(x + 8.0F * scale - 1.5F * scale, y + (height - dotSize) / 2.0F - 1.5F * scale, dotSize + 3.0F * scale, dotSize + 3.0F * scale, (dotSize + 3.0F * scale) / 2.0F, 1.0F * scale, this.applyOpacity(Color.WHITE, opacity));
      }

      RenderUtil.drawText(context, x + 22.0F * scale, y + (height - Msdf.getTextHeight(8.0F * scale)) / 2.0F, name, 8.0F * scale, this.applyOpacity(Color.WHITE, opacity));
   }

   private void renderSearchBar(class_332 context, float x, float y, float centerX, float centerY, float scale, float opacity) {
      float searchWidth = 140.0F;
      float headerWidth = 24.0F;
      float searchHeight = 24.0F;
      float renderX = this.scaleXAroundCenter(x + (this.getPanelAreaWidth() - searchWidth) / 2.0F, centerX, scale);
      float renderY = this.scaleYAroundCenter(y, centerY, scale);
      float rectOpacity = opacity * opacity * opacity;
      RenderUtil.drawHudBlur(renderX, renderY, searchWidth * scale, searchHeight * scale, 6.0F * scale, 25.0F, opacity, new Color(18, 18, 22, 140));
      if (rectOpacity > 0.02F) {
         float inset = 0.8F * scale;
         RenderUtil.drawRoundedRect(renderX + inset, renderY + inset, headerWidth * scale - inset, searchHeight * scale - inset * 2.0F, 6.0F * scale - inset, 0.0F, 0.0F, 6.0F * scale - inset, this.applyOpacity(new Color(0, 0, 0, 60), rectOpacity));
      }

      float iconSize = 9.80000019F * scale;
      float iconHeight = Msdf.getTextHeight(Msdf.WTMICO, iconSize);
      float iconWidth = Msdf.getTextWidth(Msdf.WTMICO, "V", iconSize);
      float iconX = renderX + (headerWidth * scale - iconWidth) / 2.0F;
      float iconY = renderY + (searchHeight * scale - iconHeight) / 2.0F;
      RenderUtil.drawText(context, Msdf.WTMICO, iconX, iconY, "V", iconSize, this.applyOpacity(ThemeManager.Theme_Color, opacity));
      float inputXOffset = headerWidth * scale + 8.0F * scale;
      Scissor.push((double)(renderX + headerWidth * scale), (double)renderY, (double)(searchWidth * scale - headerWidth * scale), (double)(searchHeight * scale));
      if (this.getSearchAnimationInternal() < 0.99F) {
         float placeholderOpacity = opacity * (1.0F - this.getSearchAnimationInternal());
         RenderUtil.drawText(context, renderX + inputXOffset, renderY + (searchHeight * scale - Msdf.getTextHeight(9.0F * scale)) / 2.0F, "Search modules...", 9.0F * scale, this.applyOpacity(new Color(150, 150, 150), Math.max(0.0F, placeholderOpacity)));
      }

      float textX = renderX + inputXOffset;

      for(AnimatedCharacter ac : this.getDescriptionGlyphsInternal()) {
         float charOpacity = opacity * Easings.easeOutCubic(ac.animation);
         float charY = renderY + (searchHeight * scale - Msdf.getTextHeight(9.0F * scale)) / 2.0F + (1.0F - Easings.easeOutCubic(ac.animation)) * 5.0F * scale;
         RenderUtil.drawText(context, textX, charY, ac.character, 9.0F * scale, this.applyOpacity(Color.WHITE, charOpacity));
         textX += Msdf.getTextWidth(ac.character, 9.0F * scale) * ac.animation;
      }

      if (this.getSearchFocusedInternal()) {
         float cursorAnim = (float)(Math.sin((double)System.currentTimeMillis() / 250.0D) * (double)0.5F + (double)0.5F);
         float cursorHeight = searchHeight * scale - 12.0F * scale;
         float animatedHeight = cursorHeight * cursorAnim;
         float cursorY = renderY + 6.0F * scale + (cursorHeight - animatedHeight) / 2.0F;
         float cursorOpacity = opacity * (0.2F + 0.8F * cursorAnim);
         float cX = this.getSearchTextInternal().isEmpty() && this.getDescriptionGlyphsInternal().isEmpty() ? renderX + inputXOffset : textX + 2.0F * scale;
         RenderUtil.drawRoundedRect(cX, cursorY, 1.0F * scale, animatedHeight, 0.5F * scale, this.applyOpacity(Color.WHITE, cursorOpacity));
      }

      Scissor.popTertiary();
   }

   private float getUnchangedPreviewX(float x, float y, Color color, float scale, float opacity) {
      return x;
   }

   private void renderThemeContextMenu(class_332 context, float x, float y, float scale, float opacity) {
      boolean custom = this.getContextThemeIndexInternal() >= 0;
      float menuHeight = 36.0F * scale;
      RenderUtil.drawHudBlur(x, y, 62.0F * scale, menuHeight, 5.0F * scale, 25.0F, opacity, new Color(18, 18, 22, 140));
      RenderUtil.drawText(context, x + 7.0F * scale, y + 5.19999981F * scale, "Change", 7.5F * scale, this.applyOpacity(new Color(226, 226, 230), opacity));
      Color deleteColor = custom ? new Color(245, 150, 150) : new Color(96, 96, 102);
      RenderUtil.drawText(context, x + 7.0F * scale, y + 23.2000008F * scale, "Delete", 7.5F * scale, this.applyOpacity(deleteColor, opacity));
   }

   private void renderColorModeMenu(class_332 context, float x, float y, float scale, float opacity) {
      float menuWidth = 70.0F * scale;
      float menuHeight = 36.0F * scale;
      RenderUtil.drawHudBlur(x, y, menuWidth, menuHeight, 5.0F * scale, 25.0F, opacity, new Color(18, 18, 22, 140));
      RenderUtil.drawText(context, x + 7.0F * scale, y + 5.19999981F * scale, "Один цвет", 7.5F * scale, this.applyOpacity(new Color(226, 226, 230), opacity));
      RenderUtil.drawText(context, x + 7.0F * scale, y + 23.2000008F * scale, "Два цвета", 7.5F * scale, this.applyOpacity(new Color(226, 226, 230), opacity));
   }

   private void renderColorPickers(class_332 context, float x, float y, float scale, float opacity) {
      if (ThemeManager.twoColors) {
         float picker2X = x + 132.0F * scale + 8.0F * scale;
         this.renderColorPicker(context, x, y, scale, opacity, this.getPrimaryHueInternal(), this.getPrimarySaturationInternal(), this.getPrimaryBrightnessInternal());
         this.renderColorPicker(context, picker2X, y, scale, opacity, this.getSecondaryHueInternal(), this.getSecondarySaturationInternal(), this.getSecondaryBrightnessInternal());
      } else {
         this.renderColorPicker(context, x, y, scale, opacity, this.getPrimaryHueInternal(), this.getPrimarySaturationInternal(), this.getPrimaryBrightnessInternal());
      }

   }

   private void renderColorPicker(class_332 context, float x, float y, float scale, float opacity, float hue, float saturation, float brightness) {
      float fieldX = x + 8.0F * scale;
      float fieldY = y + 8.0F * scale;
      float fieldSize = 78.0F * scale;
      float radius = 6.0F * scale;
      this.drawSaturationBrightnessField(fieldX, fieldY, fieldSize, fieldSize, radius, hue, opacity);
      RenderUtil.drawRoundedOutline(fieldX, fieldY, fieldSize, fieldSize, radius, 0.9F * scale, this.applyOpacity(new Color(255, 255, 255), opacity * 0.25F));
      float markerX = fieldX + saturation * fieldSize;
      float markerY = fieldY + (1.0F - brightness) * fieldSize;
      RenderUtil.drawRoundedOutline(markerX - 2.5F * scale, markerY - 2.5F * scale, 5.0F * scale, 5.0F * scale, 2.5F * scale, 1.0F * scale, this.applyOpacity(Color.WHITE, opacity));
      float hueX = fieldX + fieldSize + 8.0F * scale;
      this.drawHueSlider(hueX, fieldY, 10.0F * scale, fieldSize, opacity);
      RenderUtil.drawRoundedOutline(hueX, fieldY, 10.0F * scale, fieldSize, 10.0F * scale / 2.0F, 0.9F * scale, this.applyOpacity(new Color(255, 255, 255), opacity * 0.25F));
      float var16 = fieldY + hue * fieldSize;
      RenderUtil.drawRoundedOutline(hueX - 2.0F * scale, var16 - 1.5F * scale, 14.0F * scale, 3.0F * scale, 1.5F * scale, 1.0F * scale, this.applyOpacity(Color.WHITE, opacity));
   }

   private void drawSaturationBrightnessField(float x, float y, float width, float height, float radius, float hue, float opacity) {
      Color topLeft = Color.WHITE;
      Color topMid = this.lerpColor(Color.WHITE, Color.getHSBColor(hue, 1.0F, 1.0F), 0.5F);
      Color topRight = Color.getHSBColor(hue, 1.0F, 1.0F);
      Color midLeft = new Color(128, 128, 128);
      Color midMid = Color.getHSBColor(hue, 0.5F, 0.5F);
      Color midRight = Color.getHSBColor(hue, 1.0F, 0.5F);
      Color black = Color.BLACK;
      RenderUtil.drawRoundedRect(x, y, width, height, radius, this.applyOpacity(topLeft, opacity), this.applyOpacity(topMid, opacity), this.applyOpacity(topRight, opacity), this.applyOpacity(midLeft, opacity), this.applyOpacity(midMid, opacity), this.applyOpacity(midRight, opacity), this.applyOpacity(black, opacity), this.applyOpacity(black, opacity), this.applyOpacity(black, opacity));
   }

   private void drawHueSlider(float x, float y, float width, float height, float opacity) {
      if (!(height <= 0.0F) && !(width <= 0.0F)) {
         int dots = 40;
         float travel = Math.max(0.0F, height - width);
         float step = dots <= 1 ? 0.0F : travel / (float)(dots - 1);
         float radius = width / 2.0F;

         for(int i = 0; i < dots; ++i) {
            float progress = (float)i / (float)(dots - 1);
            RenderUtil.drawRoundedRect(x, y + (float)i * step, width, width, radius, this.applyOpacity(Color.getHSBColor(progress, 1.0F, 1.0F), opacity));
         }

      }
   }

   private void renderCategoryPanel(class_332 context, Category category, float x, float y, float mouseX, float mouseY, float centerX, float centerY, float scale, float opacity) {
      List<ModuleComponent> components = (List)this.getComponentsByCategoryInternal().getOrDefault(category, List.of());
      float renderX = this.scaleXAroundCenter(x, centerX, scale);
      float renderY = this.scaleYAroundCenter(y, centerY, scale);
      float renderWidth = 112.0F * scale;
      float renderHeight = 290.0F * scale;
      float rectOpacity = opacity * opacity * opacity;
      RenderUtil.drawHudBlur(renderX, renderY, renderWidth, renderHeight, 9.0F * scale, 25.0F, opacity, new Color(18, 18, 22, 140));
      if (rectOpacity > 0.02F) {
         float inset = 0.8F * scale;
         RenderUtil.drawRoundedRect(renderX + inset, renderY + inset, renderWidth - inset * 2.0F, 25.0F * scale - inset, 0.0F, 0.0F, 9.0F * scale - inset, 9.0F * scale - inset, this.applyOpacity(new Color(0, 0, 0, 60), rectOpacity));
      }

      this.renderCategoryHeader(context, category, renderX, renderY, renderWidth, scale, opacity);
      float moduleWidth = 104.0F * scale;
      float viewportX = renderX + (renderWidth - moduleWidth) / 2.0F;
      float viewportY = renderY + 30.0F * scale;
      float viewportWidth = moduleWidth;
      float viewportHeight = 249.0F * scale + 7.0F;
      float moduleY = viewportY - (Float)this.getScrollOffsetsInternal().getOrDefault(category, 0.0F) * scale;
      Scissor.push((double)viewportX, (double)viewportY, (double)moduleWidth, (double)viewportHeight);
      if (components.isEmpty()) {
         RenderUtil.drawAlignedText(context, renderX + renderWidth / 2.0F, moduleY + 8.19999981F * scale, "Empty", 10.1999998F * scale, this.applyOpacity(new Color(105, 105, 111), opacity), "center");
         Scissor.popTertiary();
      } else {
         float moduleOpacity = opacity * opacity;
         float viewportBottom = viewportY + viewportHeight;

         for(ModuleComponent component : components) {
            float moduleHeight = component.getHeight() * scale;
            if (moduleY + moduleHeight >= viewportY && moduleY <= viewportBottom) {
               if (this.isPointInside(mouseX, mouseY, viewportX, moduleY, viewportWidth, 21.0F * scale) && this.isPointInside(mouseX, mouseY, viewportX, viewportY, viewportWidth, viewportHeight)) {
                  this.setHoveredModuleInternal(component);
               }

               component.render(context, viewportX, moduleY, viewportWidth, mouseX, mouseY, scale, moduleOpacity);
            }

            moduleY += (moduleHeight + 4.0F) * scale;
         }

         Scissor.popTertiary();
         this.renderCategoryScrollbar(category, renderX, renderY, scale, opacity);
      }
   }

   private void renderCategoryHeader(class_332 context, Category category, float x, float y, float width, float scale, float opacity) {
      String icon = this.getCategoryIcon(category);
      String title = this.getCategoryTitle(category);
      float iconSize = 9.80000019F * scale;
      float titleSize = 9.80000019F * scale;
      float padding = 8.0F * scale;
      float iconWidth = Msdf.getTextWidth(Msdf.WTMICO, icon, iconSize);
      float titleHeight = Msdf.getTextHeight(titleSize);
      float iconHeight = Msdf.getTextHeight(Msdf.WTMICO, iconSize);
      float centerY = y + 25.0F * scale / 2.0F;
      float titleX = x + padding;
      float titleY = centerY - titleHeight / 2.0F;
      float iconX = x + width - iconWidth - padding;
      float iconY = centerY - iconHeight / 2.0F;
      RenderUtil.drawText(context, titleX, titleY, title, titleSize, this.applyOpacity(new Color(235, 235, 238), opacity));
      RenderUtil.drawText(context, Msdf.WTMICO, iconX, iconY, icon, iconSize, this.applyOpacity(ThemeManager.Theme_Color, opacity));
   }

   private void rebuildModuleComponents() {
      this.getComponentsByCategoryInternal().clear();

      for(Category category : Category.values()) {
         List<ModuleComponent> components = new ArrayList<ModuleComponent>();
         FunctionManager.getByCategory(category).forEach((function) -> {
            if (this.getSearchTextInternal().isEmpty() || function.getName().toLowerCase().contains(this.getSearchTextInternal().toLowerCase())) {
               components.add(new ModuleComponent(function));
            }

         });
         if (category == Category.MISC) {
            FunctionManager.getByCategory(Category.MENU).forEach((function) -> {
               if (this.getSearchTextInternal().isEmpty() || function.getName().toLowerCase().contains(this.getSearchTextInternal().toLowerCase())) {
                  components.add(new ModuleComponent(function));
               }

            });
            FunctionManager.getByCategory(Category.CONFIG).forEach((function) -> {
               if (this.getSearchTextInternal().isEmpty() || function.getName().toLowerCase().contains(this.getSearchTextInternal().toLowerCase())) {
                  components.add(new ModuleComponent(function));
               }

            });
         }

         this.getComponentsByCategoryInternal().put(category, components);
         this.getScrollOffsetsInternal().put(category, 0.0F);
         this.getTargetScrollOffsetsInternal().put(category, 0.0F);
      }

   }

   private void renderCategoryScrollbar(Category category, float x, float y, float scale, float opacity) {
      float maxScroll = this.getMaxScroll(category);
      if (!(maxScroll <= 0.0F)) {
         float trackHeight = 249.0F * scale;
         float trackX = x + 112.0F * scale - 4.0F * scale;
         float trackY = y + 33.0F * scale;
         float contentHeight = this.getCategoryContentHeight(category);
         float thumbHeight = Math.max(24.0F * scale, trackHeight * (249.0F / contentHeight));
         float progress = (Float)this.getScrollOffsetsInternal().getOrDefault(category, 0.0F) / maxScroll;
         float thumbY = trackY + (trackHeight - thumbHeight) * Math.clamp(progress, 0.0F, 1.0F);
         RenderUtil.drawRoundedRect(trackX, trackY, 2.0F * scale, trackHeight, 1.0F * scale, this.applyOpacity(new Color(27, 27, 29), opacity));
         RenderUtil.drawRoundedRect(trackX, thumbY, 2.0F * scale, thumbHeight, 1.0F * scale, this.applyOpacity(ThemeManager.Theme_Color, opacity));
      }
   }

   private float getMaxScroll(Category category) {
      float viewportHeight = 249.0F;
      return Math.max(0.0F, this.getCategoryContentHeight(category) - viewportHeight);
   }

   private float getCategoryContentHeight(Category category) {
      List<ModuleComponent> components = (List)this.getComponentsByCategoryInternal().getOrDefault(category, List.of());
      if (components.isEmpty()) {
         return 21.0F;
      } else {
         float height = 0.0F;

         for(ModuleComponent component : components) {
            height += component.getHeight();
         }

         return height + (float)Math.max(0, components.size() - 1) * 4.0F;
      }
   }

   private float getPanelAreaWidth() {
      return (float)obf_u042b_u0432.length * 112.0F + (float)(obf_u042b_u0432.length - 1) * 10.0F;
   }

   private float getPanelAreaHeight() {
      return 357.0F;
   }

   private float getThemeButtonWidth() {
      return 70.0F;
   }

   private float getCategoryPanelX(float startX, int index) {
      return startX + (float)index * 122.0F;
   }

   private float getCategoryPanelY(float startY, int index) {
      return startY;
   }

   private boolean isPointInside(float mouseX, float mouseY, float x, float y, float width, float height) {
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
   }

   private float scaleXAroundCenter(float x, float centerX, float scale) {
      return centerX + (x - centerX) * scale;
   }

   private float scaleYAroundCenter(float y, float centerY, float scale) {
      return centerY + (y - centerY) * scale;
   }

   private Color applyOpacity(Color color, float opacity) {
      int alpha = (int)((float)color.getAlpha() * Math.clamp(opacity, 0.0F, 1.0F));
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
   }

   private boolean handleThemeSelectorClick(float mouseX, float mouseY, int button) {
      if (button != 0 && button != 1) {
         return false;
      }

      if (this.handleThemeContextMenuClick(mouseX, mouseY, button)) {
         return true;
      }

      if (button == 0 && (this.getColorPickerOpenInternal() || this.getPickerAnimationInternal() > 0.02F) && this.handleColorPickerClick(mouseX, mouseY)) {
         return true;
      }

      float buttonWidth = 70.0F;
      float buttonHeight = 24.0F;
      float buttonX = RenderUtil.getScaledWidth() - buttonWidth - 10.0F;
      float buttonY = RenderUtil.getScaledHeight() - buttonHeight - 10.0F;
      int totalThemes = 2 + ThemeManager.CUSTOM_THEMES.size();
      float menuHeight = totalThemes * 20.0F + 20.0F;
      float easeProgress = this.getThemeListExpandedInternal()
         ? Easings.easeOutBack(this.getThemeListAnimationOriginInternal())
         : Easings.easeOutCubic(this.getThemeListAnimationOriginInternal());
      float expandedHeight = 24.0F + menuHeight * easeProgress;

      if (this.isPointInside(mouseX, mouseY, buttonX, buttonY, buttonWidth, buttonHeight) && button == 0) {
         this.setThemeListExpanded(!this.getThemeListExpandedInternal());
         return true;
      }

      if (this.getThemeListExpandedInternal() || this.getThemeListAnimationOriginInternal() > 0.02F) {
         float currentY = buttonY + 24.0F - expandedHeight;
         if (this.getPaletteOpenInternal()) {
            float popupWidth = 70.0F;
            float popupHeight = 36.0F;
            float popupX = buttonX - popupWidth - 6.0F;
            float popupY = currentY + totalThemes * 20.0F - popupHeight;
            if (this.isPointInside(mouseX, mouseY, popupX, popupY, popupWidth, popupHeight)) {
               if (button == 0) {
                  ThemeManager.twoColors = mouseY >= popupY + 18.0F;
                  this.setPaletteOpen(false);
                  this.addCustomTheme();
               }

               return true;
            }

            if (button == 0) {
               this.setPaletteOpen(false);
            }
         }

         if (this.isPointInside(mouseX, mouseY, buttonX, currentY, buttonWidth, expandedHeight - buttonHeight)) {
            float itemY = currentY;
            if (this.isPointInside(mouseX, mouseY, button, buttonX, itemY, buttonWidth, 20.0F, -1, ThemeManager.PASTEL_PURPLE)) {
               return true;
            }

            itemY += 20.0F;
            if (this.isPointInside(mouseX, mouseY, button, buttonX, itemY, buttonWidth, 20.0F, -2, ThemeManager.PASTEL_BLUE)) {
               return true;
            }

            itemY += 20.0F;
            for (int index = 0; index < ThemeManager.CUSTOM_THEMES.size(); index++) {
               if (this.isPointInside(
                  mouseX,
                  mouseY,
                  button,
                  buttonX,
                  itemY,
                  buttonWidth,
                  20.0F,
                  index,
                  ThemeManager.CUSTOM_THEMES.get(index)
               )) {
                  return true;
               }

               itemY += 20.0F;
            }

            if (button == 0 && this.isPointInside(mouseX, mouseY, buttonX, itemY, buttonWidth, 20.0F)) {
               this.closeThemeContextMenu();
               this.setPaletteOpen(!this.getPaletteOpenInternal());
               return true;
            }
         }
      } else if (this.getPaletteOpenInternal() && button == 0) {
         this.setPaletteOpen(false);
      }

      if (!this.isPointInside(mouseX, mouseY, buttonX, buttonY - expandedHeight, buttonWidth, expandedHeight)) {
         float totalPickerWidth = ThemeManager.twoColors ? 272.0F : 132.0F;
         if (button == 0
            && this.isPointInside(mouseX, mouseY, this.getColorPickerX(), this.getColorPickerY(), totalPickerWidth, 108.0F)) {
            return this.getColorPickerOpenInternal() || this.getPickerAnimationInternal() > 0.02F;
         }

         this.closeThemeContextMenu();
      }

      return false;
   }

   private boolean isPointInside(float mouseX, float mouseY, int button, float x, float y, float width, float height, int index, Color color) {
      if (!this.isPointInside(mouseX, mouseY, x, y, width, height)) {
         return false;
      } else {
         if (button == 1) {
            this.openThemeContextMenu(mouseX, mouseY, index);
         } else {
            this.selectTheme(color);
         }

         return true;
      }
   }

   private boolean selectTheme(Color color) {
      this.closeThemeContextMenu();
      this.setSelectedThemeIndexInternal(-1);
      ThemeManager.setPrimaryColor(color);
      this.syncPickerFromThemeColor(color);
      this.closeColorPicker();
      this.setDraggingPrimaryPickerInternal(false);
      this.setDraggingPrimaryHueInternal(false);
      this.setDraggingSecondaryPickerInternal(false);
      this.setDraggingSecondaryHueInternal(false);
      this.setThemeListAnimationInternal(1.0F);
      return true;
   }

   private void addCustomTheme() {
      this.syncPickerFromThemeColor(ThemeManager.Theme_Color);
      this.setSelectedThemeIndexInternal(ThemeManager.addCustomTheme(ThemeManager.Theme_Color));
      this.closeThemeContextMenu();
      this.openColorPicker();
      this.setThemeListAnimationInternal(1.0F);
   }

   private boolean handleColorPickerClick(float mouseX, float mouseY) {
      float pickerX = this.getColorPickerX();
      float pickerY = this.getColorPickerY();
      float totalPickerWidth = (float)(ThemeManager.twoColors ? 272.0F : 132.0F);
      if (!this.isPointInside(mouseX, mouseY, pickerX, pickerY, totalPickerWidth, 108.0F)) {
         return false;
      } else {
         float fieldX = pickerX + 8.0F;
         float fieldY = pickerY + 8.0F;
         float hueX = fieldX + 78.0F + 8.0F;
         this.setDraggingPrimaryPickerInternal(this.isPointInside(mouseX, mouseY, fieldX, fieldY, 78.0F, 78.0F));
         this.setDraggingPrimaryHueInternal(this.isPointInside(mouseX, mouseY, hueX, fieldY, 10.0F, 78.0F));
         if (ThemeManager.twoColors) {
            float picker2X = pickerX + 132.0F + 8.0F;
            float field2X = picker2X + 8.0F;
            float hue2X = field2X + 78.0F + 8.0F;
            this.setDraggingSecondaryPickerInternal(this.isPointInside(mouseX, mouseY, field2X, fieldY, 78.0F, 78.0F));
            this.setDraggingSecondaryHueInternal(this.isPointInside(mouseX, mouseY, hue2X, fieldY, 10.0F, 78.0F));
         }

         this.updateColorPickerDrag(mouseX, mouseY);
         return true;
      }
   }

   private void updateColorPickerDrag(float mouseX, float mouseY) {
      float pickerX = this.getColorPickerX();
      float pickerY = this.getColorPickerY();
      float fieldX = pickerX + 8.0F;
      float fieldY = pickerY + 8.0F;
      float hueX = fieldX + 78.0F + 8.0F;
      if (this.getDraggingPrimaryPickerInternal()) {
         this.setPrimarySaturationInternal(Math.clamp((mouseX - fieldX) / 78.0F, 0.0F, 1.0F));
         this.setPrimaryBrightnessInternal(1.0F - Math.clamp((mouseY - fieldY) / 78.0F, 0.0F, 1.0F));
      } else if (this.getDraggingPrimaryHueInternal() || this.isPointInside(mouseX, mouseY, hueX, fieldY, 10.0F, 78.0F)) {
         this.setPrimaryHueInternal(Math.clamp((mouseY - fieldY) / 78.0F, 0.0F, 1.0F));
      }

      if (ThemeManager.twoColors) {
         float picker2X = pickerX + 132.0F + 8.0F;
         float field2X = picker2X + 8.0F;
         float hue2X = field2X + 78.0F + 8.0F;
         if (this.getDraggingSecondaryPickerInternal()) {
            this.setSecondarySaturationInternal(Math.clamp((mouseX - field2X) / 78.0F, 0.0F, 1.0F));
            this.setSecondaryBrightnessInternal(1.0F - Math.clamp((mouseY - fieldY) / 78.0F, 0.0F, 1.0F));
         } else if (this.getDraggingSecondaryHueInternal() || this.isPointInside(mouseX, mouseY, hue2X, fieldY, 10.0F, 78.0F)) {
            this.setSecondaryHueInternal(Math.clamp((mouseY - fieldY) / 78.0F, 0.0F, 1.0F));
         }
      }

      Color picked = Color.getHSBColor(this.getPrimaryHueInternal(), this.getPrimarySaturationInternal(), this.getPrimaryBrightnessInternal());
      ThemeManager.Theme_Color = picked;
      if (ThemeManager.twoColors) {
         ThemeManager.Theme_Color2 = Color.getHSBColor(this.getSecondaryHueInternal(), this.getSecondarySaturationInternal(), this.getSecondaryBrightnessInternal());
      }

      if (this.getSelectedThemeIndexInternal() >= 0 && this.getSelectedThemeIndexInternal() < ThemeManager.CUSTOM_THEMES.size()) {
         ThemeManager.CUSTOM_THEMES.set(this.getSelectedThemeIndexInternal(), picked);
      }

   }

   private void syncPickerFromThemeColor(Color color) {
      float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), (float[])null);
      this.setPrimaryHueInternal(hsb[0]);
      this.setPrimarySaturationInternal(hsb[1]);
      this.setPrimaryBrightnessInternal(hsb[2]);
      if (ThemeManager.twoColors) {
         float[] hsb2 = Color.RGBtoHSB(ThemeManager.Theme_Color2.getRed(), ThemeManager.Theme_Color2.getGreen(), ThemeManager.Theme_Color2.getBlue(), (float[])null);
         this.setSecondaryHueInternal(hsb2[0]);
         this.setSecondarySaturationInternal(hsb2[1]);
         this.setSecondaryBrightnessInternal(hsb2[2]);
      }

   }

   private float getColorPickerX() {
      return (float)RenderUtil.getScaledWidth() - 70.0F - 20.0F - (ThemeManager.twoColors ? 272.0F : 132.0F);
   }

   private float getColorPickerY() {
      return (float)RenderUtil.getScaledHeight() - 108.0F - 10.0F;
   }

   private boolean handleThemeContextMenuClick(float mouseX, float mouseY, int button) {
      if (!this.isThemeContextMenuOpen()) {
         return false;
      } else {
         boolean custom = this.getContextThemeIndexInternal() >= 0;
         float menuHeight = 36.0F;
         if (!this.isPointInside(mouseX, mouseY, this.getContextMenuXInternal(), this.getContextMenuYInternal(), 62.0F, (float)menuHeight)) {
            if (button == 0) {
               this.closeThemeContextMenu();
            }

            return false;
         } else if (button != 0) {
            return true;
         } else {
            int row = (int)((mouseY - this.getContextMenuYInternal()) / 18.0F);
            if (row == 0) {
               this.applyContextThemeChange();
            } else {
               if (custom) {
                  ThemeManager.removeCustomTheme(this.getContextThemeIndexInternal());
                  this.setSelectedThemeIndexInternal(-1);
                  this.closeColorPicker();
                  this.setThemeListAnimationInternal(1.0F);
               }

               this.closeThemeContextMenu();
            }

            return true;
         }
      }
   }

   private void applyContextThemeChange() {
      Color color = this.getContextThemeColor();
      if (color == null) {
         this.closeThemeContextMenu();
      } else {
         this.syncPickerFromThemeColor(color);
         ThemeManager.setPrimaryColor(color);
         this.setSelectedThemeIndexInternal(this.getContextThemeIndexInternal() >= 0 ? this.getContextThemeIndexInternal() : ThemeManager.addCustomTheme(color));
         this.openColorPicker();
         this.setThemeListAnimationInternal(1.0F);
         this.closeThemeContextMenu();
      }
   }

   private Color getContextThemeColor() {
      if (this.getContextThemeIndexInternal() == -1) {
         return ThemeManager.PASTEL_PURPLE;
      } else if (this.getContextThemeIndexInternal() == -2) {
         return ThemeManager.PASTEL_BLUE;
      } else {
         return this.getContextThemeIndexInternal() >= 0 && this.getContextThemeIndexInternal() < ThemeManager.CUSTOM_THEMES.size() ? (Color)ThemeManager.CUSTOM_THEMES.get(this.getContextThemeIndexInternal()) : null;
      }
   }

   private void openThemeContextMenu(float mouseX, float mouseY, int index) {
      this.setContextThemeIndexInternal(index);
      this.setContextMenuXInternal(mouseX);
      this.setContextMenuYInternal(mouseY);
      this.closeColorPicker();
      this.setDraggingPrimaryPickerInternal(false);
      this.setDraggingPrimaryHueInternal(false);
      this.setDraggingSecondaryPickerInternal(false);
      this.setDraggingSecondaryHueInternal(false);
   }

   private void closeThemeContextMenu() {
      this.setContextThemeIndexInternal(-2147483648);
   }

   private boolean isThemeContextMenuOpen() {
      return this.getContextThemeIndexInternal() != -2147483648;
   }

   private void openColorPicker() {
      this.setColorPickerOpen(true);
   }

   private void closeColorPicker() {
      this.setColorPickerOpen(false);
   }

   private float getPaletteAnimationProgress() {
      if (this.getPaletteAnimationStartInternal() == 0L) {
         return 0.0F;
      } else {
         float progress = (float)(System.currentTimeMillis() - this.getPaletteAnimationStartInternal()) / 180.0F;
         progress = Math.clamp(progress, 0.0F, 1.0F);
         return this.getPaletteOpenInternal() ? progress : 1.0F - progress;
      }
   }

   private float getThemeListAnimationProgress() {
      if (this.getThemeListAnimationStartInternal() == 0L) {
         return 0.0F;
      } else {
         float progress = (float)(System.currentTimeMillis() - this.getThemeListAnimationStartInternal()) / 180.0F;
         progress = Math.clamp(progress, 0.0F, 1.0F);
         return this.getThemeListExpandedInternal() ? progress : 1.0F - progress;
      }
   }

   private void setThemeListExpanded(boolean expanded) {
      if (this.getThemeListExpandedInternal() != expanded) {
         this.setThemeListAnimationOriginInternal(this.getThemeListAnimationProgress());
         this.setThemeListExpandedInternal(expanded);
         long offset = (long)((expanded ? this.getThemeListAnimationOriginInternal() : 1.0F - this.getThemeListAnimationOriginInternal()) * 180.0F);
         this.setThemeListAnimationStartInternal(System.currentTimeMillis() - offset);
      }
   }

   private void setPaletteOpen(boolean open) {
      if (this.getPaletteOpenInternal() != open) {
         this.setPaletteAnimationOriginInternal(this.getPaletteAnimationProgress());
         this.setPaletteOpenInternal(open);
         long offset = (long)((open ? this.getPaletteAnimationOriginInternal() : 1.0F - this.getPaletteAnimationOriginInternal()) * 180.0F);
         this.setPaletteAnimationStartInternal(System.currentTimeMillis() - offset);
      }
   }

   private void setColorPickerOpen(boolean open) {
      if (this.getColorPickerOpenInternal() != open) {
         this.setPickerAnimationInternal(this.getColorPickerAnimationProgress());
         this.setPaletteAnimationOriginInternal(this.getPaletteAnimationProgress());
         this.setColorPickerOpenInternal(open);
         long offset = (long)((open ? this.getPickerAnimationInternal() : 1.0F - this.getPickerAnimationInternal()) * 180.0F);
         this.setPickerAnimationStartInternal(System.currentTimeMillis() - offset);
      }
   }

   private float getColorPickerAnimationProgress() {
      float progress = (float)(System.currentTimeMillis() - this.getPickerAnimationStartInternal()) / 180.0F;
      progress = Math.clamp(progress, 0.0F, 1.0F);
      return this.getColorPickerOpenInternal() ? progress : 1.0F - progress;
   }

   private float animateTowards(float current, float target, float speed, float delta) {
      float factor = 1.0F - (float)Math.exp((double)(-speed * delta));
      float next = current + (target - current) * Math.clamp(factor, 0.0F, 1.0F);
      return Math.abs(next - target) < 0.001F ? target : next;
   }

   private Color lerpColor(Color first, Color second, float progress) {
      float clamped = Math.clamp(progress, 0.0F, 1.0F);
      int red = (int)((float)first.getRed() + (float)(second.getRed() - first.getRed()) * clamped);
      int green = (int)((float)first.getGreen() + (float)(second.getGreen() - first.getGreen()) * clamped);
      int blue = (int)((float)first.getBlue() + (float)(second.getBlue() - first.getBlue()) * clamped);
      int alpha = (int)((float)first.getAlpha() + (float)(second.getAlpha() - first.getAlpha()) * clamped);
      return new Color(red, green, blue, alpha);
   }

   private boolean colorsEqual(Color first, Color second) {
      return first.getRed() == second.getRed() && first.getGreen() == second.getGreen() && first.getBlue() == second.getBlue();
   }

   private String getCategoryIcon(Category category) {
      String var2;
      switch (category) {
         case COMBAT -> var2 = "H";
         case RENDER -> var2 = "G";
         case MOVEMENT -> var2 = "D";
         case MISC -> var2 = "F";
         case PLAYER -> var2 = "P";
         case MENU -> var2 = "F";
         case CONFIG -> var2 = "F";
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var2;
   }

   private String getCategoryTitle(Category category) {
      String var2;
      switch (category) {
         case COMBAT -> var2 = "Combat";
         case RENDER -> var2 = "Visuals";
         case MOVEMENT -> var2 = "Move";
         case MISC -> var2 = "Misc";
         case PLAYER -> var2 = "Player";
         case MENU -> var2 = "Menu";
         case CONFIG -> var2 = "Config";
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var2;
   }

   private void renderDescriptionTooltip(class_332 context, float mouseX, float mouseY, float scale, float opacity) {
      long now = System.currentTimeMillis();
      float animProgress = 1.0F;
      if (this.getDescriptionChangeTimeInternal() > 0L) {
         animProgress = Math.min(1.0F, (float)(now - this.getDescriptionChangeTimeInternal()) / 400.0F);
      }

      if (!(animProgress >= 1.0F) || !this.getCurrentDescriptionInternal().isEmpty()) {
         float inAnim = Easings.easeOutBack(animProgress);
         float outAnim = Easings.easeOutCubic(animProgress);
         float padding = 5.0F * scale;
         float textSize = 8.5F * scale;
         float height = Msdf.getTextHeight(textSize) + padding * 2.0F;
         float oldWidth = this.getPreviousDescriptionInternal().isEmpty() ? 0.0F : Msdf.getTextWidth(this.getPreviousDescriptionInternal(), textSize) + padding * 2.0F;
         float newWidth = this.getCurrentDescriptionInternal().isEmpty() ? 0.0F : Msdf.getTextWidth(this.getCurrentDescriptionInternal(), textSize) + padding * 2.0F;
         float currentMaxWidth = Math.max(oldWidth, newWidth);
         float targetX = mouseX + 12.0F * scale;
         float targetY = mouseY + 12.0F * scale;
         Scissor.push((double)(targetX - 20.0F * scale), (double)(targetY - 20.0F * scale), (double)(currentMaxWidth + 40.0F * scale), (double)(height + 20.0F * scale));
         if (!this.getPreviousDescriptionInternal().isEmpty() && animProgress < 1.0F) {
            float outYOffset = (height + 15.0F * scale) * outAnim;
            float outAlpha = opacity * (1.0F - animProgress);
            if (outAlpha > 0.02F) {
               this.renderTooltipBox(context, this.getPreviousDescriptionInternal(), targetX, targetY + outYOffset, oldWidth, height, textSize, padding, scale, outAlpha);
            }
         }

         if (!this.getCurrentDescriptionInternal().isEmpty()) {
            float inYOffset = (height + 15.0F * scale) * (1.0F - inAnim);
            float inAlpha = opacity * Math.min(1.0F, animProgress * 2.0F);
            if (inAlpha > 0.02F) {
               this.renderTooltipBox(context, this.getCurrentDescriptionInternal(), targetX, targetY + inYOffset, newWidth, height, textSize, padding, scale, inAlpha);
            }
         }

         Scissor.popTertiary();
      }
   }

   private void renderTooltipBox(class_332 context, String text, float x, float y, float width, float height, float textSize, float padding, float scale, float opacity) {
      RenderUtil.drawHudBlur(x, y, width, height, 4.0F * scale, 15.0F, opacity, new Color(18, 18, 22, 140));
      RenderUtil.drawRoundedRect(x, y, width, height, 4.0F * scale, this.applyOpacity(new Color(255, 255, 255, 15), opacity));
      RenderUtil.drawText(context, x + padding, y + padding + 1.0F * scale, text, textSize, this.applyOpacity(new Color(230, 230, 235), opacity));
   }

   static {
      obf_u042b_u0432 = new Category[]{Category.COMBAT, Category.MOVEMENT, Category.RENDER, Category.PLAYER, Category.MISC};
   }

   private Map<Category, List<ModuleComponent>> getComponentsByCategoryInternal() {
      return this.field_6d2b79f5;
   }

   private Map getScrollOffsetsInternal() {
      return this.field_da56f3ea;
   }

   private Map getTargetScrollOffsetsInternal() {
      return this.field_47826ddf;
   }

   private long getScreenAnimationStartInternal() {
      return this.field_b4ade7d4;
   }

   private void setScreenAnimationStartInternal(long var1) {
      this.field_b4ade7d4 = var1;
   }

   private boolean getClosingInternal() {
      return this.field_21d961c9;
   }

   private void setClosingInternal(boolean var1) {
      this.field_21d961c9 = var1;
   }

   private boolean getColorPickerOpenInternal() {
      return this.field_8f04dbbe;
   }

   private void setColorPickerOpenInternal(boolean var1) {
      this.field_8f04dbbe = var1;
   }

   private boolean getDraggingPrimaryPickerInternal() {
      return this.field_fc3055b3;
   }

   private void setDraggingPrimaryPickerInternal(boolean var1) {
      this.field_fc3055b3 = var1;
   }

   private boolean getDraggingPrimaryHueInternal() {
      return this.field_695bcfa8;
   }

   private void setDraggingPrimaryHueInternal(boolean var1) {
      this.field_695bcfa8 = var1;
   }

   private int getSelectedThemeIndexInternal() {
      return this.field_d687499d;
   }

   private void setSelectedThemeIndexInternal(int var1) {
      this.field_d687499d = var1;
   }

   private float getPrimaryHueInternal() {
      return this.field_43b2c392;
   }

   private void setPrimaryHueInternal(float var1) {
      this.field_43b2c392 = var1;
   }

   private float getPrimarySaturationInternal() {
      return this.field_b0de3d87;
   }

   private void setPrimarySaturationInternal(float var1) {
      this.field_b0de3d87 = var1;
   }

   private float getPrimaryBrightnessInternal() {
      return this.field_1e09b77c;
   }

   private void setPrimaryBrightnessInternal(float var1) {
      this.field_1e09b77c = var1;
   }

   private float getPickerAnimationInternal() {
      return this.field_8b353171;
   }

   private void setPickerAnimationInternal(float var1) {
      this.field_8b353171 = var1;
   }

   private boolean getThemeListExpandedInternal() {
      return this.field_f860ab66;
   }

   private void setThemeListExpandedInternal(boolean var1) {
      this.field_f860ab66 = var1;
   }

   private float getThemeListAnimationOriginInternal() {
      return this.field_658c255b;
   }

   private void setThemeListAnimationOriginInternal(float var1) {
      this.field_658c255b = var1;
   }

   private long getThemeListAnimationStartInternal() {
      return this.field_d2b79f50;
   }

   private void setThemeListAnimationStartInternal(long var1) {
      this.field_d2b79f50 = var1;
   }

   private float getThemeListAnimationInternal() {
      return this.field_3fe31945;
   }

   private void setThemeListAnimationInternal(float var1) {
      this.field_3fe31945 = var1;
   }

   private float getContextMenuAnimationInternal() {
      return this.field_ad0e933a;
   }

   private void setContextMenuAnimationInternal(float var1) {
      this.field_ad0e933a = var1;
   }

   private int getContextThemeIndexInternal() {
      return this.field_1a3a0d2f;
   }

   private void setContextThemeIndexInternal(int var1) {
      this.field_1a3a0d2f = var1;
   }

   private float getContextMenuXInternal() {
      return this.field_87658724;
   }

   private void setContextMenuXInternal(float var1) {
      this.field_87658724 = var1;
   }

   private float getContextMenuYInternal() {
      return this.field_f4910119;
   }

   private void setContextMenuYInternal(float var1) {
      this.field_f4910119 = var1;
   }

   private long getPickerAnimationStartInternal() {
      return this.field_61bc7b0e;
   }

   private void setPickerAnimationStartInternal(long var1) {
      this.field_61bc7b0e = var1;
   }

   private long getLastFrameTimeInternal() {
      return this.field_cee7f503;
   }

   private void setLastFrameTimeInternal(long var1) {
      this.field_cee7f503 = var1;
   }

   private ModuleComponent getHoveredModuleInternal() {
      return this.field_3c136ef8;
   }

   private void setHoveredModuleInternal(ModuleComponent var1) {
      this.field_3c136ef8 = var1;
   }

   private String getCurrentDescriptionInternal() {
      return this.field_a93ee8ed;
   }

   private void setCurrentDescriptionInternal(String var1) {
      this.field_a93ee8ed = var1;
   }

   private String getPreviousDescriptionInternal() {
      return this.field_166a62e2;
   }

   private void setPreviousDescriptionInternal(String var1) {
      this.field_166a62e2 = var1;
   }

   private long getDescriptionChangeTimeInternal() {
      return this.field_8395dcd7;
   }

   private void setDescriptionChangeTimeInternal(long var1) {
      this.field_8395dcd7 = var1;
   }

   private boolean getPaletteOpenInternal() {
      return this.field_f0c156cc;
   }

   private void setPaletteOpenInternal(boolean var1) {
      this.field_f0c156cc = var1;
   }

   private float getPaletteAnimationOriginInternal() {
      return this.field_5decd0c1;
   }

   private void setPaletteAnimationOriginInternal(float var1) {
      this.field_5decd0c1 = var1;
   }

   private long getPaletteAnimationStartInternal() {
      return this.field_cb184ab6;
   }

   private void setPaletteAnimationStartInternal(long var1) {
      this.field_cb184ab6 = var1;
   }

   private float getSecondaryHueInternal() {
      return this.field_3843c4ab;
   }

   private void setSecondaryHueInternal(float var1) {
      this.field_3843c4ab = var1;
   }

   private float getSecondarySaturationInternal() {
      return this.field_a56f3ea0;
   }

   private void setSecondarySaturationInternal(float var1) {
      this.field_a56f3ea0 = var1;
   }

   private float getSecondaryBrightnessInternal() {
      return this.field_129ab895;
   }

   private void setSecondaryBrightnessInternal(float var1) {
      this.field_129ab895 = var1;
   }

   private boolean getDraggingSecondaryPickerInternal() {
      return this.field_7fc6328a;
   }

   private void setDraggingSecondaryPickerInternal(boolean var1) {
      this.field_7fc6328a = var1;
   }

   private boolean getDraggingSecondaryHueInternal() {
      return this.field_ecf1ac7f;
   }

   private void setDraggingSecondaryHueInternal(boolean var1) {
      this.field_ecf1ac7f = var1;
   }

   private String getSearchTextInternal() {
      return this.field_5a1d2674;
   }

   private void setSearchTextInternal(String var1) {
      this.field_5a1d2674 = var1;
   }

   private boolean getSearchFocusedInternal() {
      return this.field_c748a069;
   }

   private void setSearchFocusedInternal(boolean var1) {
      this.field_c748a069 = var1;
   }

   private float getSearchAnimationInternal() {
      return this.field_34741a5e;
   }

   private void setSearchAnimationInternal(float var1) {
      this.field_34741a5e = var1;
   }

   private List<AnimatedCharacter> getDescriptionGlyphsInternal() {
      return this.field_a19f9453;
   }


   private static class AnimatedCharacter {
      String character;
      float animation;

      AnimatedCharacter(String character) {
         this.setCharacterInternal(character);
         this.setAnimationInternal(0.0F);
      }

      private String getCharacterInternal() {
         return this.character;
      }

      private void setCharacterInternal(String var1) {
         this.character = var1;
      }

      private float getAnimationInternal() {
         return this.animation;
      }

      private void setAnimationInternal(float var1) {
         this.animation = var1;
      }

   }
}
