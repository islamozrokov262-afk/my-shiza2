package atheryx.gui.component;

import atheryx.gui.ThemeManager;
import atheryx.gui.setting.SettingRenderer;
import atheryx.gui.setting.SettingRendererContext;
import atheryx.gui.setting.SettingRendererRegistry;
import atheryx.module.Function;
import atheryx.render.RenderUtil;
import atheryx.render.font.Msdf;
import atheryx.render.scissor.Scissor;
import atheryx.setting.Setting;
import atheryx.setting.impl.KeybindSetting;
import atheryx.setting.impl.TextSetting;
import java.awt.Color;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.class_1109;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3414;

public class ModuleComponent {
   private static final float obf_u2217_u03b2 = 21.0F;
   private static final float obf_u00c5_u03b2 = 8.80000019F;
   private static final float obf_u0447_u03b2 = 8.0F;
   private static final float obf_u0410_u03b2 = 0.00449999981F;
   private static final float obf_u00e9_u03b2 = 0.00600000005F;
   private static final float obf_u03ae_u03b2 = 0.00999999978F;
   private static final float obf_u03bc_u03b2 = 0.00999999978F;
   private static final float obf_u043b_u03b2 = 3.0F;
   private static ModuleComponent obf_u00d6_u03b2;
   private static final SettingRendererRegistry obf_u0422_u03b2 = new SettingRendererRegistry();
   private final Function field_6d2b79f5;
   private final SettingRendererContext field_da56f3ea;
   private float field_47826ddf;
   private float field_b4ade7d4;
   private float field_21d961c9;
   private float field_8f04dbbe;
   private float field_fc3055b3;
   private float field_695bcfa8;
   private float field_d687499d;
   private long field_43b2c392;
   private boolean field_b0de3d87;
   private boolean field_1e09b77c;
   private KeybindSetting field_8b353171;
   private Setting field_f860ab66;
   private final Set<Setting> field_658c255b;
   private final Map<Setting, Float> field_d2b79f50;
   private float field_3fe31945;
   private long field_ad0e933a;
   private float field_1a3a0d2f;
   private boolean field_87658724;

   public ModuleComponent(Function function) {
      this.setScaleInternal(1.0F);
      this.field_658c255b = new HashSet<Setting>();
      this.field_d2b79f50 = new HashMap<Setting, Float>();
      this.field_6d2b79f5 = function;
      Set var10003 = this.getExpandedSettingsInternal();
      Objects.requireNonNull(var10003);
      this.field_da56f3ea = new SettingRendererContext(var10003::contains, (setting) -> {
         return (Float)this.getSettingExpansionAnimationsInternal().getOrDefault(setting, 0.0F);
      }, this::toggleSettingExpansion);
      this.setEnabledAnimationInternal(function.isEnabled() ? 1.0F : 0.0F);
      this.setLastAnimationTimeInternal(System.currentTimeMillis());
   }

   public Function getFunction() {
      return this.getFunctionInternal();
   }

   public void render(class_332 context, float x, float y, float width, float mouseX, float mouseY) {
      this.render(context, x, y, width, mouseX, mouseY, 1.0F, 1.0F);
   }

   public void render(class_332 context, float x, float y, float width, float mouseX, float mouseY, float scale, float opacity) {
      this.setXInternal(x);
      this.setYInternal(y);
      this.setWidthInternal(width);
      this.setScaleInternal(scale);
      this.updateAnimations();
      boolean enabled = this.getFunctionInternal().isEnabled();
      float settingsHeight = this.getSettingsHeight() * this.getSettingsExpansionInternal();
      float settingsGap = 3.0F * this.getSettingsExpansionInternal();
      float height = (21.0F + settingsGap + settingsHeight) * scale;
      boolean hovered = this.isPointInside(mouseX, mouseY, x, y, width, 21.0F * scale);
      Color disabledBackground = new Color(255, 255, 255, 10);
      Color var15 = new Color(ThemeManager.getCurrentColor().getRed(), ThemeManager.getCurrentColor().getGreen(), ThemeManager.getCurrentColor().getBlue(), 140);
      Color background = this.lerpColor(disabledBackground, var15, this.getEnabledAnimationInternal());
      Color text = enabled ? new Color(255, 255, 255) : (hovered ? new Color(230, 230, 235) : new Color(190, 190, 195));
      if (hovered && !this.getHoveredInternal()) {
         class_310.method_1551().method_1483().method_4873(class_1109.method_4757(class_3414.method_47908(class_2960.method_60655("atheryx", "scroll")), 1.0F, 1.0F));
      }

      this.setHoveredInternal(hovered);
      float rectOpacity = opacity * opacity * opacity;
      if (rectOpacity > 0.02F) {
         Color settingsColor = new Color(255, 255, 255, 12);
         if (this.getSettingsExpansionInternal() > 0.02F) {
            float topRadius = (4.0F - 4.0F * this.getSettingsExpansionInternal()) * scale;
            float bottomRadius = (4.0F + 2.0F * this.getSettingsExpansionInternal()) * scale;
            RenderUtil.drawRoundedRect(x, y, width, 21.0F * scale, topRadius, topRadius, bottomRadius, bottomRadius, this.applyOpacity(background, rectOpacity));
            RenderUtil.drawRoundedRect(x, y + (21.0F + settingsGap) * scale, width, settingsHeight * scale, 6.0F * scale, 6.0F * scale, 0.0F, 0.0F, this.applyOpacity(settingsColor, rectOpacity * this.getSettingsExpansionInternal()));
         } else {
            RenderUtil.drawRoundedRect(x, y, width, height, 4.0F * scale, this.applyOpacity(background, rectOpacity));
         }
      }

      float switchWidth = 14.0F * scale;
      float switchHeight = 8.0F * scale;
      float knobSize = 7.0F * scale;
      float switchX = x + width - 8.0F * scale - switchWidth;
      float switchY = y + (21.0F * scale - switchHeight) / 2.0F;
      float textX = x + 8.0F * scale;
      float textY = y + 6.19999981F * scale;
      float textWidth = width - 16.0F * scale - switchWidth - 4.0F * scale;
      float textSize = 8.80000019F * scale;
      String renderName = this.getFunctionInternal().getName();
      float actualTextWidth = Msdf.getTextWidth(renderName, textSize);
      if (actualTextWidth <= textWidth) {
         RenderUtil.drawText(context, textX, textY, renderName, textSize, this.applyOpacity(text, opacity * (1.0F - this.getKeybindAnimationInternal())));
         this.setNameScrollOffsetInternal(0.0F);
         this.setNameScrollLastTimeInternal(0L);
         this.setNameScrollElapsedInternal(0.0F);
      } else {
         float overflow = actualTextWidth - textWidth + 6.0F * scale;
         long now = System.currentTimeMillis();
         long last = this.getNameScrollLastTimeInternal() == 0L ? now : this.getNameScrollLastTimeInternal();
         float delta = Math.min(50.0F, (float)(now - last)) / 1000.0F;
         this.setNameScrollLastTimeInternal(now);
         if (!hovered) {
            if (this.getNameScrollOffsetInternal() > 0.0F) {
               this.setNameScrollOffsetInternal(Math.max(0.0F, this.getNameScrollOffsetInternal() - 46.7999992F * delta));
            } else if (this.getNameScrollOffsetInternal() < 0.0F) {
               this.setNameScrollOffsetInternal(0.0F);
            }

            this.setNameScrollElapsedInternal(0.0F);
         } else {
            this.setNameScrollElapsedInternal(this.getNameScrollElapsedInternal() + delta);
            float cycleDuration = Math.max(1.8F, overflow * 2.0F / 26.0F);
            float phase = this.getNameScrollElapsedInternal() % cycleDuration / cycleDuration;
            this.setNameScrollOffsetInternal(overflow * (0.5F - 0.5F * (float)Math.cos((double)phase * 3.1415926535897931D * 2.0D)));
         }

         Scissor.push((double)textX, (double)(textY - 2.0F * scale), (double)textWidth, (double)(textSize + 6.0F * scale));
         RenderUtil.drawText(context, textX - this.getNameScrollOffsetInternal(), textY, renderName, textSize, this.applyOpacity(text, opacity * (1.0F - this.getKeybindAnimationInternal())));
         Scissor.popTertiary();
      }

      RenderUtil.drawText(context, textX, textY, this.ellipsize("Нажмите бинд", textWidth, textSize), textSize, this.applyOpacity(text, opacity * this.getKeybindAnimationInternal()));
      if (rectOpacity > 0.02F) {
         float eased = this.easeInOutQuad(this.getEnabledAnimationInternal());
         float knobTravel = switchWidth - knobSize;
         float knobX = switchX + knobTravel * eased;
         float knobY = switchY + (switchHeight - knobSize) / 2.0F;
         Color trackBg = new Color(90, 90, 90, 80);
         Color trackActive = ThemeManager.getCurrentColor();
         Color track = this.lerpColor(trackBg, trackActive, eased);
         RenderUtil.drawRoundedRect(switchX, switchY, switchWidth, switchHeight, 3.0F * scale, this.applyOpacity(track, rectOpacity));
         Color knobColor = this.applyOpacity(Color.WHITE, rectOpacity);
         RenderUtil.drawRoundedRect(knobX, knobY, knobSize, knobSize, knobSize / 2.0F, knobColor);
      }

      if (this.getSettingsExpansionInternal() > 0.02F) {
         float settingY = y + (21.0F + settingsGap) * scale;
         float settingOpacity = opacity * this.getSettingsExpansionInternal();

         for(Setting setting : this.getVisibleSettings()) {
            float settingHeight = this.getSettingHeight(setting) * scale;
            this.renderSetting(context, setting, x + 8.0F * scale, settingY, width - 16.0F * scale, mouseX, mouseY, scale, settingOpacity);
            settingY += settingHeight;
         }
      }

   }

   public boolean mouseClicked(float mouseX, float mouseY, int button) {
      if (button == 0) {
         this.stopTextEditing();
      }

      if (this.getKeybindSettingInternal() != null) {
         if (KeybindSetting.isSupportedMouseButton(button)) {
            this.getKeybindSettingInternal().setKeybind(KeybindSetting.mouseButtonToKey(button));
            this.endKeyBinding();
            return true;
         } else {
            return button == 0;
         }
      } else if (this.getBindingKeyInternal()) {
         if (KeybindSetting.isSupportedMouseButton(button)) {
            this.getFunctionInternal().setKeybind(KeybindSetting.mouseButtonToKey(button));
            this.endKeyBinding();
            return true;
         } else {
            return button == 0;
         }
      } else if (button != 0 && button != 1 && button != 2) {
         return false;
      } else {
         if (this.getExpandedInternal() && this.getSettingsExpansionInternal() > 0.85F) {
            float settingY = this.getYInternal() + 21.0F + 3.0F;

            for(Setting setting : this.getVisibleSettings()) {
               float settingHeight = this.getSettingHeight(setting);
               if (this.isPointInside(mouseX, mouseY, this.getXInternal(), settingY, this.getWidthInternal(), settingHeight)) {
                  float settingX = this.getXInternal() + 8.0F * this.getScaleInternal();
                  float settingWidth = this.getWidthInternal() - 16.0F * this.getScaleInternal();
                  if (this.handleSettingClick(setting, button, mouseX - settingX, mouseY - settingY, settingWidth)) {
                     this.setDraggedSettingInternal(setting);
                  }

                  return true;
               }

               settingY += settingHeight;
            }
         }

         if (!this.isPointInside(mouseX, mouseY, this.getXInternal(), this.getYInternal(), this.getWidthInternal(), 21.0F)) {
            return false;
         } else {
            if (button == 0) {
               this.getFunctionInternal().toggle();
            } else if (button == 1) {
               this.setExpandedInternal(!this.getExpandedInternal());
               class_310.method_1551().method_1483().method_4873(class_1109.method_4757(class_3414.method_47908(class_2960.method_60655("atheryx", "switchcategory")), 1.0F, 1.0F));
            } else {
               this.beginKeyBinding();
            }

            return true;
         }
      }
   }

   public boolean mouseDragged(float mouseX, float mouseY, int button) {
      if (this.getDraggedSettingInternal() == null) {
         return false;
      } else {
         SettingRenderer<Setting> renderer = obf_u0422_u03b2.<Setting>getRenderer(this.getDraggedSettingInternal());
         float settingX = this.getXInternal() + 8.0F * this.getScaleInternal();
         float settingWidth = this.getWidthInternal() - 16.0F * this.getScaleInternal();
         float settingY = this.getSettingY(this.getDraggedSettingInternal());
         return renderer.popupMouseClicked(this.getDraggedSettingInternal(), this.getRendererContextInternal(), button, mouseX - settingX, mouseY - settingY, settingWidth);
      }
   }

   public void cancelSettingDrag() {
      this.setDraggedSettingInternal((Setting)null);
   }

   public boolean keyPressed(int keyCode) {
      TextSetting editingText = this.getEditingTextSetting();
      if (editingText != null) {
         if (keyCode != 256 && keyCode != 257 && keyCode != 335) {
            if (keyCode == 259) {
               editingText.backspace();
               return true;
            } else {
               return true;
            }
         } else {
            editingText.setEditing(false);
            return true;
         }
      } else if (this.getKeybindSettingInternal() != null) {
         this.getKeybindSettingInternal().setKeybind(keyCode != 256 && keyCode != 261 ? keyCode : 0);
         this.setKeybindSettingInternal((KeybindSetting)null);
         this.endKeyBinding();
         return true;
      } else if (!this.getBindingKeyInternal()) {
         return false;
      } else {
         this.getFunctionInternal().setKeybind(keyCode != 256 && keyCode != 261 ? keyCode : 0);
         this.endKeyBinding();
         return true;
      }
   }

   public boolean charTyped(String text) {
      TextSetting editingText = this.getEditingTextSetting();
      if (editingText == null) {
         return false;
      } else {
         editingText.appendText(text);
         return true;
      }
   }

   public float getHeight() {
      return 21.0F + (3.0F + this.getSettingsHeight()) * this.getSettingsExpansionInternal();
   }

   private void updateAnimations() {
      long now = System.currentTimeMillis();
      float delta = Math.min(50.0F, (float)(now - this.getLastAnimationTimeInternal()));
      this.setLastAnimationTimeInternal(now);
      float target = this.getFunctionInternal().isEnabled() ? 1.0F : 0.0F;
      if (this.getEnabledAnimationInternal() < target) {
         this.setEnabledAnimationInternal(Math.min(target, this.getEnabledAnimationInternal() + delta * 0.0045F));
      } else if (this.getEnabledAnimationInternal() > target) {
         this.setEnabledAnimationInternal(Math.max(target, this.getEnabledAnimationInternal() - delta * 0.0045F));
      }

      float expandTarget = this.getExpandedInternal() ? 1.0F : 0.0F;
      if (this.getSettingsExpansionInternal() < expandTarget) {
         this.setSettingsExpansionInternal(Math.min(expandTarget, this.getSettingsExpansionInternal() + delta * 0.006F));
      } else if (this.getSettingsExpansionInternal() > expandTarget) {
         this.setSettingsExpansionInternal(Math.max(expandTarget, this.getSettingsExpansionInternal() - delta * 0.006F));
      }

      float bindTarget = this.getBindingKeyInternal() ? 1.0F : 0.0F;
      if (this.getKeybindAnimationInternal() < bindTarget) {
         this.setKeybindAnimationInternal(Math.min(bindTarget, this.getKeybindAnimationInternal() + delta * 0.01F));
      } else if (this.getKeybindAnimationInternal() > bindTarget) {
         this.setKeybindAnimationInternal(Math.max(bindTarget, this.getKeybindAnimationInternal() - delta * 0.01F));
      }

      for(Setting setting : this.getVisibleSettings()) {
         float current = (Float)this.getSettingExpansionAnimationsInternal().getOrDefault(setting, 0.0F);
         float targetProgress = this.getExpandedSettingsInternal().contains(setting) ? 1.0F : 0.0F;
         if (current < targetProgress) {
            current = Math.min(targetProgress, current + delta * 0.01F);
         } else if (current > targetProgress) {
            current = Math.max(targetProgress, current - delta * 0.01F);
         }

         this.getSettingExpansionAnimationsInternal().put(setting, current);
      }

   }

   private void beginKeyBinding() {
      if (obf_u00d6_u03b2 != null && obf_u00d6_u03b2 != this) {
         obf_u00d6_u03b2.endKeyBinding();
      }

      obf_u00d6_u03b2 = this;
      this.setBindingKeyInternal(true);
   }

   private void endKeyBinding() {
      this.setBindingKeyInternal(false);
      this.setKeybindSettingInternal((KeybindSetting)null);
      if (obf_u00d6_u03b2 == this) {
         obf_u00d6_u03b2 = null;
      }

   }

   private void renderSetting(class_332 context, Setting setting, float x, float y, float width, float mouseX, float mouseY, float scale, float opacity) {
      SettingRenderer<Setting> renderer = obf_u0422_u03b2.<Setting>getRenderer(setting);
      this.getRendererContextInternal().setMousePosition(mouseX, mouseY);
      renderer.render(context, setting, this.getRendererContextInternal(), x, y, width, scale, opacity);
   }

   private boolean handleSettingClick(Setting setting, int button, float localX, float localY, float width) {
      SettingRenderer<Setting> renderer = obf_u0422_u03b2.<Setting>getRenderer(setting);
      boolean handled = renderer.mouseClicked(setting, this.getRendererContextInternal(), button, localX, localY, width);
      if (handled && setting instanceof KeybindSetting keybindSetting) {
         if (button == 0) {
            this.beginKeyBinding();
            this.setKeybindSettingInternal(keybindSetting);
            keybindSetting.setKeybind(-1);
         }
      }

      return handled;
   }

   private void stopTextEditing() {
      for(Setting setting : this.getFunctionInternal().getSettings()) {
         if (setting instanceof TextSetting textSetting) {
            textSetting.setEditing(false);
         }
      }

   }

   private TextSetting getEditingTextSetting() {
      for(Setting setting : this.getFunctionInternal().getSettings()) {
         if (setting instanceof TextSetting textSetting) {
            if (textSetting.isEditing()) {
               return textSetting;
            }
         }
      }

      return null;
   }

   private float getSettingsHeight() {
      float height = 0.0F;

      for(Setting setting : this.getVisibleSettings()) {
         height += this.getSettingHeight(setting);
      }

      return height;
   }

   private float getSettingHeight(Setting setting) {
      SettingRenderer<Setting> renderer = obf_u0422_u03b2.<Setting>getRenderer(setting);
      return renderer.getHeight(setting, this.getRendererContextInternal());
   }

   private float getSettingY(Setting targetSetting) {
      float settingY = this.getYInternal() + 21.0F + 3.0F;

      for(Setting setting : this.getVisibleSettings()) {
         if (setting == targetSetting) {
            return settingY;
         }

         settingY += this.getSettingHeight(setting);
      }

      return this.getYInternal();
   }

   private void toggleSettingExpansion(Setting setting) {
      if (this.getExpandedSettingsInternal().contains(setting)) {
         this.getExpandedSettingsInternal().remove(setting);
      } else {
         this.getExpandedSettingsInternal().add(setting);
      }

      class_310.method_1551().method_1483().method_4873(class_1109.method_4757(class_3414.method_47908(class_2960.method_60655("atheryx", "switchcategory")), 1.0F, 1.0F));
   }

   private List<Setting> getVisibleSettings() {
      return this.getFunctionInternal().getSettings().stream().filter(Setting::isVisible).toList();
   }

   private boolean isPointInside(float mouseX, float mouseY, float x, float y, float width, float height) {
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
   }

   private Color lerpColor(Color from, Color to, float progress) {
      float t = this.easeInOutQuad(Math.clamp(progress, 0.0F, 1.0F));
      int red = (int)((float)from.getRed() + (float)(to.getRed() - from.getRed()) * t);
      int green = (int)((float)from.getGreen() + (float)(to.getGreen() - from.getGreen()) * t);
      int blue = (int)((float)from.getBlue() + (float)(to.getBlue() - from.getBlue()) * t);
      int alpha = (int)((float)from.getAlpha() + (float)(to.getAlpha() - from.getAlpha()) * t);
      return new Color(red, green, blue, alpha);
   }

   private float easeInOutQuad(float progress) {
      return progress < 0.5F ? 2.0F * progress * progress : 1.0F - (float)Math.pow((double)(-2.0F * progress + 2.0F), 2.0D) / 2.0F;
   }

   private Color applyOpacity(Color color, float opacity) {
      int alpha = (int)((float)color.getAlpha() * Math.clamp(opacity, 0.0F, 1.0F));
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
   }

   private String ellipsize(String text, float maxWidth, float size) {
      if (Msdf.getTextWidth(text, size) <= maxWidth) {
         return text;
      } else {
         String ellipsis = "...";

         String trimmed;
         for(trimmed = text; !trimmed.isEmpty() && Msdf.getTextWidth(trimmed + ellipsis, size) > maxWidth; trimmed = trimmed.substring(0, trimmed.length() - 1)) {
         }

         return trimmed.isEmpty() ? ellipsis : trimmed + ellipsis;
      }
   }

   private Function getFunctionInternal() {
      return this.field_6d2b79f5;
   }

   private SettingRendererContext getRendererContextInternal() {
      return this.field_da56f3ea;
   }

   private float getXInternal() {
      return this.field_47826ddf;
   }

   private void setXInternal(float var1) {
      this.field_47826ddf = var1;
   }

   private float getYInternal() {
      return this.field_b4ade7d4;
   }

   private void setYInternal(float var1) {
      this.field_b4ade7d4 = var1;
   }

   private float getWidthInternal() {
      return this.field_21d961c9;
   }

   private void setWidthInternal(float var1) {
      this.field_21d961c9 = var1;
   }

   private float getScaleInternal() {
      return this.field_8f04dbbe;
   }

   private void setScaleInternal(float var1) {
      this.field_8f04dbbe = var1;
   }

   private float getEnabledAnimationInternal() {
      return this.field_fc3055b3;
   }

   private void setEnabledAnimationInternal(float var1) {
      this.field_fc3055b3 = var1;
   }

   private float getSettingsExpansionInternal() {
      return this.field_695bcfa8;
   }

   private void setSettingsExpansionInternal(float var1) {
      this.field_695bcfa8 = var1;
   }

   private float getKeybindAnimationInternal() {
      return this.field_d687499d;
   }

   private void setKeybindAnimationInternal(float var1) {
      this.field_d687499d = var1;
   }

   private long getLastAnimationTimeInternal() {
      return this.field_43b2c392;
   }

   private void setLastAnimationTimeInternal(long var1) {
      this.field_43b2c392 = var1;
   }

   private boolean getExpandedInternal() {
      return this.field_b0de3d87;
   }

   private void setExpandedInternal(boolean var1) {
      this.field_b0de3d87 = var1;
   }

   private boolean getBindingKeyInternal() {
      return this.field_1e09b77c;
   }

   private void setBindingKeyInternal(boolean var1) {
      this.field_1e09b77c = var1;
   }

   private KeybindSetting getKeybindSettingInternal() {
      return this.field_8b353171;
   }

   private void setKeybindSettingInternal(KeybindSetting var1) {
      this.field_8b353171 = var1;
   }

   private Setting getDraggedSettingInternal() {
      return this.field_f860ab66;
   }

   private void setDraggedSettingInternal(Setting var1) {
      this.field_f860ab66 = var1;
   }

   private Set getExpandedSettingsInternal() {
      return this.field_658c255b;
   }

   private Map getSettingExpansionAnimationsInternal() {
      return this.field_d2b79f50;
   }

   private float getNameScrollOffsetInternal() {
      return this.field_3fe31945;
   }

   private void setNameScrollOffsetInternal(float var1) {
      this.field_3fe31945 = var1;
   }

   private long getNameScrollLastTimeInternal() {
      return this.field_ad0e933a;
   }

   private void setNameScrollLastTimeInternal(long var1) {
      this.field_ad0e933a = var1;
   }

   private float getNameScrollElapsedInternal() {
      return this.field_1a3a0d2f;
   }

   private void setNameScrollElapsedInternal(float var1) {
      this.field_1a3a0d2f = var1;
   }

   private boolean getHoveredInternal() {
      return this.field_87658724;
   }

   private void setHoveredInternal(boolean var1) {
      this.field_87658724 = var1;
   }

}
