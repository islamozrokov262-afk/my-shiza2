package atheryx.gui;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

public class ThemeManager {
   public static Color Theme_Color = new Color(168, 85, 247);
   public static Color Theme_Color2 = new Color(138, 180, 248);
   public static boolean twoColors = false;
   public static final Color PASTEL_PURPLE = new Color(168, 85, 247);
   public static final Color PASTEL_BLUE = new Color(138, 180, 248);
   public static final List<Color> CUSTOM_THEMES = new ArrayList<Color>();
   private static Path obf_u00c7_u03b2;

   private ThemeManager() {
   }

   public static void init() {
      Path minarDir = FabricLoader.getInstance().getGameDir().resolve("Minar");
      obf_u00c7_u03b2 = minarDir.resolve("themes.properties");

      try {
         Files.createDirectories(minarDir);
         load();
      } catch (IOException var2) {
      }

   }

   public static void setPrimaryColor(Color color) {
      Theme_Color = copyOpaqueColor(color);
      save();
   }

   public static void setSecondaryColor(Color color) {
      Theme_Color2 = copyOpaqueColor(color);
      save();
   }

   public static Color getCurrentColor() {
      if (!twoColors) {
         return Theme_Color;
      } else {
         float time = (float)(System.currentTimeMillis() % 2000L) / 2000.0F;
         float t = (float)(Math.sin((double)time * 3.1415926535897931D * 2.0D) * (double)0.5F + (double)0.5F);
         int r = (int)((float)Theme_Color.getRed() + (float)(Theme_Color2.getRed() - Theme_Color.getRed()) * t);
         int g = (int)((float)Theme_Color.getGreen() + (float)(Theme_Color2.getGreen() - Theme_Color.getGreen()) * t);
         int b = (int)((float)Theme_Color.getBlue() + (float)(Theme_Color2.getBlue() - Theme_Color.getBlue()) * t);
         return new Color(r, g, b);
      }
   }

   public static int addCustomTheme(Color color) {
      CUSTOM_THEMES.add(copyOpaqueColor(color));
      save();
      return CUSTOM_THEMES.size() - 1;
   }

   public static void updateCustomTheme(int index, Color color) {
      if (index >= 0 && index < CUSTOM_THEMES.size()) {
         CUSTOM_THEMES.set(index, copyOpaqueColor(color));
         save();
      }
   }

   public static void removeCustomTheme(int index) {
      if (index >= 0 && index < CUSTOM_THEMES.size()) {
         Color removed = CUSTOM_THEMES.remove(index);
         if (colorsEqual(removed, Theme_Color)) {
            Theme_Color = CUSTOM_THEMES.isEmpty() ? PASTEL_PURPLE : (Color)CUSTOM_THEMES.get(Math.min(index, CUSTOM_THEMES.size() - 1));
         }

         save();
      }
   }

   public static void save() {
      if (obf_u00c7_u03b2 == null) {
         return;
      }

      Properties properties = new Properties();
      properties.setProperty("selected", formatColor(Theme_Color));
      properties.setProperty("selected2", formatColor(Theme_Color2));
      properties.setProperty("twoColors", String.valueOf(twoColors));
      properties.setProperty("custom.count", String.valueOf(CUSTOM_THEMES.size()));

      for (int index = 0; index < CUSTOM_THEMES.size(); index++) {
         properties.setProperty("custom." + index, formatColor(CUSTOM_THEMES.get(index)));
      }

      try (BufferedWriter writer = Files.newBufferedWriter(obf_u00c7_u03b2)) {
         properties.store(writer, "Minar themes");
      } catch (IOException ignored) {
      }
   }

   private static void load() throws IOException {
      if (!Files.exists(obf_u00c7_u03b2)) {
         save();
      } else {
         Properties properties = new Properties();

         try (BufferedReader reader = Files.newBufferedReader(obf_u00c7_u03b2)) {
            properties.load((Reader)reader);
         }

         Theme_Color = parseColor(properties.getProperty("selected"), PASTEL_PURPLE);
         Theme_Color2 = parseColor(properties.getProperty("selected2"), PASTEL_BLUE);
         twoColors = Boolean.parseBoolean(properties.getProperty("twoColors", "false"));
         CUSTOM_THEMES.clear();
         int count = parseInt(properties.getProperty("custom.count"), 0);

         for(int i = 0; i < count; ++i) {
            CUSTOM_THEMES.add(parseColor(properties.getProperty("custom." + String.valueOf(i)), PASTEL_PURPLE));
         }

      }
   }

   private static Color parseColor(String value, Color fallback) {
      if (value != null && value.length() == 7 && value.charAt(0) == '#') {
         try {
            return new Color(Integer.parseInt(value.substring(1), 16));
         } catch (NumberFormatException var3) {
            return fallback;
         }
      } else {
         return fallback;
      }
   }

   private static int parseInt(String value, int fallback) {
      try {
         return Integer.parseInt(value);
      } catch (NumberFormatException var3) {
         return fallback;
      }
   }

   private static String formatColor(Color color) {
      return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
   }

   private static Color copyOpaqueColor(Color color) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue());
   }

   private static boolean colorsEqual(Color first, Color second) {
      return first.getRed() == second.getRed() && first.getGreen() == second.getGreen() && first.getBlue() == second.getBlue();
   }

}
