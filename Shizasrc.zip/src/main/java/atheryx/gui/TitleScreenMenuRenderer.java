package atheryx.gui;

import atheryx.render.RenderUtil;
import atheryx.render.font.Msdf;
import atheryx.render.scissor.Scissor;
import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_7077;

public class TitleScreenMenuRenderer {
   private static final DateTimeFormatter obf_u2226_u03b2 = DateTimeFormatter.ofPattern("HH:mm:ss");
   private static final long obf_u2221_u03b2 = 720L;
   private static final Map<class_339, Float> obf_u040e_u03b2 = new IdentityHashMap<class_339, Float>();
   private static class_332 obf_u043d_u03b2;
   private static long obf_u03b5_u03b2;
   private static String obf_u03aa_u03b2 = "";
   private static String obf_u00dc_u03b2 = "";
   private static long[] obf_u222d_u03b2 = new long[0];
   private static final String obf_u03a5_u03b2 = "U";

   public static void setDrawContext(class_332 context) {
      obf_u043d_u03b2 = context;
   }

   public static void hideVanillaButtons(class_442 titleScreen) {
      for(class_364 element : titleScreen.method_25396()) {
         if (!(element instanceof class_4185.class_12231) && element instanceof class_339 widget) {
            widget.field_22764 = false;
            widget.field_22763 = false;
         }
      }

   }

   public static boolean isAccountWidgetText(String text) {
      class_310 client = class_310.method_1551();
      if (client.field_1755 instanceof class_442 && text != null) {
         return text.contains("Текущий аккаунт") || text.contains("Current account");
      } else {
         return false;
      }
   }

   public static void render() {
      class_310 client = class_310.method_1551();
      class_437 var2 = client.field_1755;
      if (var2 instanceof class_442 titleScreen) {
         renderClock();
         updateAnimations();

         for(class_364 element : titleScreen.method_25396()) {
            if (element instanceof class_4185.class_12231 textButton) {
               String icon = getButtonIcon(textButton);
               if (icon != null) {
                  renderButtonIcon(textButton, icon);
                  renderTooltip(textButton, getButtonTooltip(icon));
               }
            }
         }

      }
   }

   private static void renderClock() {
      if (obf_u043d_u03b2 != null) {
         String time = LocalTime.now().format(obf_u2226_u03b2);
         updateClockDigits(time);
         float size = 42.0F;
         float x = (float)RenderUtil.getScaledWidth() / 2.0F;
         float y = 150.0F;
         renderAnimatedClock(x, y, size);
      }
   }

   private static void updateAnimations() {
      long now = System.currentTimeMillis();
      if (obf_u03b5_u03b2 == 0L) {
         obf_u03b5_u03b2 = now;
      } else {
         float delta = Math.min(50.0F, (float)(now - obf_u03b5_u03b2));
         obf_u03b5_u03b2 = now;
         obf_u040e_u03b2.entrySet().removeIf((entryx) -> {
            return !((class_339)entryx.getKey()).field_22764;
         });

         for(Map.Entry<class_339, Float> entry : obf_u040e_u03b2.entrySet()) {
            class_339 widget = entry.getKey();
            float target = widget.method_25367() ? 1.0F : 0.0F;
            float factor = 1.0F - (float)Math.exp((double)(-0.018F * delta));
            float next = (Float)entry.getValue() + (target - (Float)entry.getValue()) * Math.clamp(factor, 0.0F, 1.0F);
            entry.setValue(Math.abs(next - target) < 0.001F ? target : next);
         }

      }
   }

   private static void renderButtonIcon(class_339 widget, String icon) {
      if (!(widget instanceof class_7077)) {
         float alpha = widget.method_75798();
         float progress = (Float)obf_u040e_u03b2.computeIfAbsent(widget, (ignored) -> {
            return 0.0F;
         });
         float scale = 1.0F + easeOutCubic(progress) * 0.065F;
         float width = (float)widget.method_25368() * scale;
         float height = (float)widget.method_25364() * scale;
         float x = (float)widget.method_46426() + ((float)widget.method_25368() - width) / 2.0F;
         float y = (float)widget.method_46427() + ((float)widget.method_25364() - height) / 2.0F;
         float radius = 4.0F;
         RenderUtil.drawShadow(x + 0.5F, y + 1.2F, width - 1.0F, height - 0.4F, (float)radius, 9.0F, 0.28F * alpha, 2.20000005F, new Color(0, 0, 0, 170));
         RenderUtil.drawRoundedRect(x, y, width, height, (float)radius, new Color(150, 150, 150, 20));
         Color textColor = widget.field_22763 ? new Color(248, 250, 252, Math.round(255.0F * alpha)) : new Color(185, 190, 196, Math.round(210.0F * alpha));
         float iconSize = 22.0F * scale;
         float iconWidth = Msdf.getTextWidth(Msdf.WTMICO, icon, iconSize);
         float iconX = x + (width - iconWidth) / 2.0F;
         float iconY = y + height / 2.0F - iconSize * 0.47F;
         RenderUtil.drawText(obf_u043d_u03b2, Msdf.WTMICO, iconX, iconY, icon, iconSize, textColor);
      }
   }

   private static void renderTooltip(class_339 widget, String tooltip) {
      if (tooltip != null) {
         float progress = (Float)obf_u040e_u03b2.getOrDefault(widget, 0.0F);
         if (!(progress <= 0.01F)) {
            float eased = easeOutCubic(progress);
            float alpha = widget.method_75798() * eased;
            float scale = 0.96F + eased * 0.04F;
            float textSize = 8.39999962F * scale;
            float paddingX = 7.0F * scale;
            float paddingY = 4.5F * scale;
            float textWidth = Msdf.getTextWidth(Msdf.SF_BOLD, tooltip, textSize);
            float textHeight = Msdf.getTextHeight(Msdf.SF_BOLD, textSize);
            float width = textWidth + paddingX * 2.0F;
            float height = textHeight + paddingY * 2.0F;
            float x = (float)widget.method_46426() + (float)widget.method_25368() / 2.0F - width / 2.0F;
            float y = (float)widget.method_46427() - height - 9.0F + (1.0F - eased) * 6.0F;
            float radius = 4.0F * scale;
            RenderUtil.drawShadow(x, y + 1.5F, width, height, radius, 8.0F, 0.22F * alpha, 2.0F, new Color(0, 0, 0, 170));
            RenderUtil.drawRoundedRect(x, y, width, height, radius, new Color(150, 150, 150, 20));
            RenderUtil.drawRoundedOutline(x + 0.45F, y + 0.45F, width - 0.9F, height - 0.9F, radius, 0.75F, new Color(255, 255, 255, Math.round(58.0F * alpha)));
            RenderUtil.drawText(obf_u043d_u03b2, Msdf.SF_BOLD, x + paddingX, y + paddingY - 0.5F, tooltip, textSize, new Color(245, 247, 250, Math.round(255.0F * alpha)));
         }
      }
   }

   private static void updateClockDigits(String time) {
      long now = System.currentTimeMillis();
      if (obf_u03aa_u03b2.length() != time.length()) {
         obf_u03aa_u03b2 = time;
         obf_u00dc_u03b2 = time;
         obf_u222d_u03b2 = new long[time.length()];
      } else {
         if (obf_u222d_u03b2.length != time.length()) {
            obf_u222d_u03b2 = new long[time.length()];
         }

         char[] current = obf_u03aa_u03b2.toCharArray();
         char[] previous = obf_u00dc_u03b2.toCharArray();

         for(int i = 0; i < time.length(); ++i) {
            char next = time.charAt(i);
            if (current[i] != next) {
               previous[i] = current[i];
               current[i] = next;
               obf_u222d_u03b2[i] = now;
            }
         }

         obf_u03aa_u03b2 = new String(current);
         obf_u00dc_u03b2 = new String(previous);
      }
   }

   private static void renderAnimatedClock(float centerX, float y, float size) {
      if (!obf_u03aa_u03b2.isEmpty()) {
         float digitWidth = Math.max(Msdf.getTextWidth(Msdf.SF_BOLD, "0", size), Msdf.getTextWidth(Msdf.SF_BOLD, "8", size));
         float colonWidth = Msdf.getTextWidth(Msdf.SF_BOLD, ":", size) + 2.0F;
         float gap = 1.5F;
         float height = Msdf.getTextHeight(Msdf.SF_BOLD, size);
         float totalWidth = 0.0F;

         for(int i = 0; i < obf_u03aa_u03b2.length(); ++i) {
            totalWidth += getClockCellWidth(obf_u03aa_u03b2.charAt(i), digitWidth, colonWidth);
            if (i < obf_u03aa_u03b2.length() - 1) {
               totalWidth += gap;
            }
         }

         long now = System.currentTimeMillis();
         float x = centerX - totalWidth / 2.0F;
         Color color = new Color(245, 247, 250);

         for(int i = 0; i < obf_u03aa_u03b2.length(); ++i) {
            char current = obf_u03aa_u03b2.charAt(i);
            char previous = obf_u00dc_u03b2.charAt(i);
            float cellWidth = getClockCellWidth(current, digitWidth, colonWidth);
            float charWidth = Msdf.getTextWidth(Msdf.SF_BOLD, String.valueOf(current), size);
            float charX = x + (cellWidth - charWidth) / 2.0F;
            if (current != ':' && obf_u222d_u03b2[i] != 0L) {
               float progress = Math.clamp((float)(now - obf_u222d_u03b2[i]) / 720.0F, 0.0F, 1.0F);
               float incoming = easeOutBack(progress);
               float outgoing = easeOutCubic(progress);
               float clipPad = 6.0F;
               Scissor.push((double)(x - clipPad), (double)(y - clipPad), (double)(cellWidth + clipPad * 2.0F), (double)(height + clipPad * 2.0F));
               RenderUtil.drawText(obf_u043d_u03b2, Msdf.SF_BOLD, x + (cellWidth - Msdf.getTextWidth(Msdf.SF_BOLD, String.valueOf(previous), size)) / 2.0F, y - height * outgoing, String.valueOf(previous), size, withAlpha(color, 1.0F - progress * 0.35F));
               RenderUtil.drawText(obf_u043d_u03b2, Msdf.SF_BOLD, charX, y + height * (1.0F - incoming), String.valueOf(current), size, color);
               Scissor.popTertiary();
               if (progress >= 1.0F) {
                  obf_u222d_u03b2[i] = 0L;
                  char[] previousChars = obf_u00dc_u03b2.toCharArray();
                  previousChars[i] = current;
                  obf_u00dc_u03b2 = new String(previousChars);
               }
            } else {
               RenderUtil.drawText(obf_u043d_u03b2, Msdf.SF_BOLD, charX, y, String.valueOf(current), size, color);
            }

            x += cellWidth + gap;
         }

      }
   }

   private static float getClockCellWidth(char c, float digitWidth, float colonWidth) {
      return c == ':' ? colonWidth : digitWidth;
   }

   private static Color withAlpha(Color color, float alpha) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.round(255.0F * Math.clamp(alpha, 0.0F, 1.0F)));
   }

   private static String getButtonIcon(class_339 widget) {
      String text = widget.method_25369().getString().toLowerCase();
      if (!text.contains("одиноч") && !text.contains("singleplayer")) {
         if (!text.contains("сетев") && !text.contains("multiplayer")) {
            if (!text.contains("настрой") && !text.contains("options")) {
               if (!text.contains("выйти") && !text.contains("quit")) {
                  return !text.contains("альт") && !text.contains("alt") ? null : "U";
               } else {
                  return "Q";
               }
            } else {
               return "O";
            }
         } else {
            return "N";
         }
      } else {
         return "P";
      }
   }

   private static String getButtonTooltip(String icon) {
      if (icon == null) {
         return null;
      } else if (icon.equals("U")) {
         return "Открыть альтменеджер";
      } else {
         byte var2 = -1;
         switch (icon.hashCode()) {
            case 78:
               if (icon.equals("N")) {
                  var2 = 1;
               }
               break;
            case 79:
               if (icon.equals("O")) {
                  var2 = 2;
               }
               break;
            case 80:
               if (icon.equals("P")) {
                  var2 = 0;
               }
               break;
            case 81:
               if (icon.equals("Q")) {
                  var2 = 3;
               }
         }

         String var3;
         switch (var2) {
            case 0 -> var3 = "Открыть одиночную игру";
            case 1 -> var3 = "Открыть мультиплеер";
            case 2 -> var3 = "Открыть настройки";
            case 3 -> var3 = "Выйти из игры";
            default -> var3 = null;
         }

         return var3;
      }
   }

   private static float easeOutCubic(float progress) {
      float t = Math.clamp(progress, 0.0F, 1.0F) - 1.0F;
      return t * t * t + 1.0F;
   }

   private static float easeOutBack(float progress) {
      float t = Math.clamp(progress, 0.0F, 1.0F) - 1.0F;
      float c = 1.70158F;
      return 1.0F + (c + 1.0F) * t * t * t + c * t * t;
   }

}
