package atheryx.gui.setting;

import atheryx.gui.ThemeManager;
import atheryx.render.RenderUtil;
import atheryx.render.scissor.Scissor;
import atheryx.setting.Setting;
import atheryx.setting.impl.ModeSetting;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_332;

public class ModeSettingRenderer implements SettingRenderer<ModeSetting> {
   private final Map<Setting, Float> field_6d2b79f5 = new HashMap<Setting, Float>();
   private final Map<Setting, Long> field_da56f3ea = new HashMap<Setting, Long>();
   private final Map<Setting, String> field_47826ddf = new HashMap<Setting, String>();
   private final Map<Setting, String> field_b4ade7d4 = new HashMap<Setting, String>();
   private final Map<Setting, Float> field_21d961c9 = new HashMap<Setting, Float>();
   private final Map<String, Float> field_8f04dbbe = new HashMap<String, Float>();

   public boolean supports(Setting setting) {
      return setting instanceof ModeSetting;
   }

   private Color lerpColor(Color from, Color to, float progress) {
      float t = Math.clamp(progress, 0.0F, 1.0F);
      int red = (int)((float)from.getRed() + (float)(to.getRed() - from.getRed()) * t);
      int green = (int)((float)from.getGreen() + (float)(to.getGreen() - from.getGreen()) * t);
      int blue = (int)((float)from.getBlue() + (float)(to.getBlue() - from.getBlue()) * t);
      int alpha = (int)((float)from.getAlpha() + (float)(to.getAlpha() - from.getAlpha()) * t);
      return new Color(red, green, blue, alpha);
   }

   private float easeOutBounce(float x) {
      float n1 = 7.5625F;
      float d1 = 2.75F;
      if (x < 1.0F / d1) {
         return n1 * x * x;
      } else if (x < 2.0F / d1) {
         float var6;
         return n1 * (var6 = x - 1.5F / d1) * var6 + 0.75F;
      } else {
         float var4;
         float var5;
         return x < 2.5F / d1 ? n1 * (var4 = x - 2.25F / d1) * var4 + 0.9375F : n1 * (var5 = x - 2.625F / d1) * var5 + 0.984375F;
      }
   }

   public void render(class_332 context, ModeSetting setting, SettingRendererContext rendererContext, float x, float y, float width, float scale, float opacity) {
      long now = System.currentTimeMillis();
      long last = (Long)this.getLastUpdateTimesInternal().getOrDefault(setting, now);
      float delta = Math.min(50.0F, (float)(now - last)) / 1000.0F;
      this.getLastUpdateTimesInternal().put(setting, now);
      float totalComponentHeight = this.getHeight(setting, rendererContext) * scale;
      float rx = x - 4.0F * scale;
      float rWidth = width + 8.0F * scale;
      RenderUtil.drawHudBlur(rx, y, rWidth, totalComponentHeight, 4.0F * scale, 15.0F, opacity, new Color(30, 30, 35, 100));
      Color label = rendererContext.applyOpacity(new Color(210, 210, 214), opacity);
      float textSizeName = 7.69999981F * scale;
      rendererContext.renderScrollingTextPart(context, setting, "name", setting.getName(), x, y + 4.5F * scale, width * 0.55F, 18.0F * scale, textSizeName, label, false, rendererContext.isMouseInside(x, y, width, 18.0F * scale));
      String actualMode = setting.getValue();
      String prevMode = (String)this.getOptionClickAnimationsInternal().getOrDefault(setting, actualMode);
      String currMode = (String)this.getOptionHoverAnimationsInternal().getOrDefault(setting, actualMode);
      if (!currMode.equals(actualMode)) {
         this.getOptionClickAnimationsInternal().put(setting, currMode);
         this.getOptionHoverAnimationsInternal().put(setting, actualMode);
         this.getExpansionAnimationsInternal().put(setting, 0.0F);
         prevMode = currMode;
      }

      float animSpeed = 2.5F;
      float textProgress = (Float)this.getExpansionAnimationsInternal().getOrDefault(setting, 1.0F);
      if (textProgress < 1.0F) {
         textProgress = Math.min(1.0F, textProgress + delta * animSpeed);
         this.getExpansionAnimationsInternal().put(setting, textProgress);
      }

      Color valueColor = rendererContext.applyOpacity(new Color(150, 150, 156), opacity);
      float rightX = x + width - width * 0.45F;
      float maxWidth = width * 0.45F;
      float textYBase = y + 4.5F * scale;
      float height = 18.0F * scale;
      Scissor.push((double)rightX, (double)y, (double)maxWidth, (double)height);
      if (textProgress < 1.0F) {
         float eased = this.easeOutBounce(textProgress);
         float offset = eased * height;
         rendererContext.renderScrollingTextPart(context, setting, "value_old", prevMode, rightX, textYBase - offset, maxWidth, height, textSizeName, rendererContext.applyOpacity(valueColor, opacity * (1.0F - textProgress)), true, false);
         rendererContext.renderScrollingTextPart(context, setting, "value_new", actualMode, rightX, textYBase + height - offset, maxWidth, height, textSizeName, rendererContext.applyOpacity(valueColor, opacity * textProgress), true, false);
      } else {
         rendererContext.renderScrollingTextPart(context, setting, "value", actualMode, rightX, textYBase, maxWidth, height, textSizeName, valueColor, true, rendererContext.isMouseInside(x, y, width, 18.0F * scale));
      }

      Scissor.popTertiary();
      List modes = setting.getOptions();
      int activeIndex = Math.max(0, modes.indexOf(setting.getValue()));
      float targetOffset = (float)activeIndex * 18.0F * scale;
      float currentOffset = (Float)this.getOptionAnimationsInternal().getOrDefault(setting, targetOffset);
      if (currentOffset < targetOffset) {
         currentOffset = Math.min(targetOffset, currentOffset + delta * 250.0F * scale);
      } else if (currentOffset > targetOffset) {
         currentOffset = Math.max(targetOffset, currentOffset - delta * 250.0F * scale);
      }

      this.getOptionAnimationsInternal().put(setting, currentOffset);
      float startY = y + 18.0F * scale;
      float totalHeight = (float)modes.size() * 18.0F * scale;
      RenderUtil.drawRoundedRect(x, startY + 2.0F * scale, 1.5F * scale, totalHeight - 4.0F * scale, 0.75F * scale, rendererContext.applyOpacity(new Color(60, 60, 65, 100), opacity));
      RenderUtil.drawRoundedRect(x, startY + currentOffset + 2.0F * scale, 1.5F * scale, 18.0F * scale - 4.0F * scale, 0.75F * scale, rendererContext.applyOpacity(ThemeManager.getCurrentColor(), opacity));
      float optionY = startY;
      float textSize = 7.19999981F * scale;

      for(int i = 0; i < modes.size(); ++i) {
         String option = (String)modes.get(i);
         boolean isSelected = i == activeIndex;
         int var47 = System.identityHashCode(setting);
         String key = var47 + option;
         float currentProgress = (Float)this.getSelectionAnimationsInternal().getOrDefault(key, isSelected ? 1.0F : 0.0F);
         if (isSelected && currentProgress < 1.0F) {
            currentProgress = Math.min(1.0F, currentProgress + delta * 8.0F);
         } else if (!isSelected && currentProgress > 0.0F) {
            currentProgress = Math.max(0.0F, currentProgress - delta * 8.0F);
         }

         this.getSelectionAnimationsInternal().put(key, currentProgress);
         Color idleColor = rendererContext.applyOpacity(new Color(170, 170, 175), opacity);
         Color activeColor = rendererContext.applyOpacity(ThemeManager.getCurrentColor(), opacity);
         Color color = this.lerpColor(idleColor, activeColor, currentProgress);
         rendererContext.renderScrollingTextPart(context, setting, "option:" + String.valueOf(option), option, x + 6.0F * scale, optionY + 4.19999981F * scale, width - 6.0F * scale, 18.0F * scale, textSize, color, false, rendererContext.isMouseInside(x, optionY, width, 18.0F * scale));
         optionY += 18.0F * scale;
      }

   }

   public boolean mouseClicked(ModeSetting setting, SettingRendererContext rendererContext, int button, float localX, float localY, float width) {
      if (button != 0) {
         return false;
      } else if (localY >= 18.0F) {
         int index = (int)((localY - 18.0F) / 18.0F);
         List<String> modes = setting.getOptions();
         if (index >= 0 && index < modes.size()) {
            setting.setValue(modes.get(index));
         }

         return true;
      } else {
         return false;
      }
   }

   public float getHeight(ModeSetting setting, SettingRendererContext rendererContext) {
      return 18.0F * (1.0F + (float)setting.getOptions().size());
   }

   public String getDisplayValue(ModeSetting setting) {
      return setting.getValue();
   }

   private Map getOptionAnimationsInternal() {
      return this.field_6d2b79f5;
   }

   private Map getLastUpdateTimesInternal() {
      return this.field_da56f3ea;
   }

   private Map getOptionHoverAnimationsInternal() {
      return this.field_47826ddf;
   }

   private Map getOptionClickAnimationsInternal() {
      return this.field_b4ade7d4;
   }

   private Map getExpansionAnimationsInternal() {
      return this.field_21d961c9;
   }

   private Map getSelectionAnimationsInternal() {
      return this.field_8f04dbbe;
   }

}
