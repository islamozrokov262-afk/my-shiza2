package atheryx.gui.setting;

import atheryx.gui.ThemeManager;
import atheryx.render.RenderUtil;
import atheryx.setting.Setting;
import atheryx.setting.impl.TextSetting;
import java.awt.Color;
import net.minecraft.class_332;

public class TextSettingRenderer implements SettingRenderer<TextSetting> {
   public boolean supports(Setting setting) {
      return setting instanceof TextSetting;
   }

   public void render(class_332 context, TextSetting setting, SettingRendererContext rendererContext, float x, float y, float width, float scale, float opacity) {
      rendererContext.renderLabelAndValue(context, setting, this.getDisplayValue(setting), x, y, width, scale, opacity);
      if (setting.isEditing()) {
         Color color = rendererContext.applyOpacity(ThemeManager.getCurrentColor(), opacity);
         RenderUtil.drawRoundedRect(x + width - 2.0F * scale, y + 4.0F * scale, 1.0F * scale, 10.0F * scale, 0.5F * scale, color);
      }

   }

   public boolean mouseClicked(TextSetting setting, SettingRendererContext rendererContext, int button, float localX, float localY, float width) {
      if (button != 0) {
         return false;
      } else {
         setting.setEditing(true);
         return true;
      }
   }

   public float getHeight(TextSetting setting, SettingRendererContext rendererContext) {
      return 18.0F;
   }

   public String getDisplayValue(TextSetting setting) {
      return setting.isEditing() ? String.valueOf(setting.getText()) + "_" : setting.getText();
   }

}
