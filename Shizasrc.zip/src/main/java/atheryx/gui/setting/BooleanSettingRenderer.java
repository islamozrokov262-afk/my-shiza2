package atheryx.gui.setting;

import atheryx.gui.ThemeManager;
import atheryx.render.RenderUtil;
import atheryx.setting.Setting;
import atheryx.setting.impl.BooleanSetting;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_332;

public class BooleanSettingRenderer implements SettingRenderer<BooleanSetting> {
   private static final float obf_u221a_u03b2 = 14.0F;
   private static final float obf_u043a_u03b2 = 6.0F;
   private static final float obf_u2214_u03b2 = 7.0F;
   private static final float obf_u2211_u03b2 = 0.00549999997F;
   private final Map<BooleanSetting, Float> field_6d2b79f5 = new HashMap<BooleanSetting, Float>();
   private final Map<BooleanSetting, Long> field_da56f3ea = new HashMap<BooleanSetting, Long>();

   public boolean supports(Setting setting) {
      return setting instanceof BooleanSetting;
   }

   public void render(class_332 context, BooleanSetting setting, SettingRendererContext rendererContext, float x, float y, float width, float scale, float opacity) {
      float checkboxProgress = this.updateToggleAnimation(setting);
      float eased = this.smoothstep(checkboxProgress);
      float textSize = 7.69999981F * scale;
      float switchWidth = 14.0F * scale;
      float switchHeight = 6.0F * scale;
      float knobSize = 7.0F * scale;
      float switchX = x + width - switchWidth;
      float switchY = y + (18.0F * scale - switchHeight) / 2.0F;
      float var17 = switchWidth - knobSize;
      float knobX = switchX + var17 * eased;
      float knobY = switchY + (switchHeight - knobSize) / 2.0F;
      Color label = rendererContext.applyOpacity(new Color(210, 210, 214), opacity);
      Color track = rendererContext.applyOpacity(this.lerpColor(new Color(86, 86, 86), ThemeManager.getCurrentColor(), eased), opacity);
      Color knob = rendererContext.applyOpacity(Color.WHITE, opacity);
      Color knobShadow = rendererContext.applyOpacity(new Color(0, 0, 0), opacity * 0.18F);
      rendererContext.renderScrollingTextPart(context, setting, "name", setting.getName(), x, y + 4.5F * scale, width - switchWidth - 8.0F * scale, 18.0F * scale, textSize, label, false, rendererContext.isMouseInside(x, y, width, 18.0F * scale));
      RenderUtil.drawRoundedRect(switchX, switchY, switchWidth, switchHeight, switchHeight / 2.0F, track);
      RenderUtil.drawShadow(knobX, knobY, knobSize, knobSize, knobSize / 2.0F, 2.0F * scale, 0.25F, 1.0F, knobShadow);
      RenderUtil.drawRoundedRect(knobX, knobY, knobSize, knobSize, knobSize / 2.0F, knob);
   }

   public boolean mouseClicked(BooleanSetting setting, SettingRendererContext rendererContext, int button, float localX, float localY, float width) {
      setting.setEnabled(!setting.isEnabled());
      return true;
   }

   public float getHeight(BooleanSetting setting, SettingRendererContext rendererContext) {
      return 18.0F;
   }

   public String getDisplayValue(BooleanSetting setting) {
      return "";
   }

   private float updateToggleAnimation(BooleanSetting setting) {
      long now = System.currentTimeMillis();
      long last = (Long)this.getLastUpdateTimesInternal().getOrDefault(setting, now);
      float delta = Math.min(50.0F, (float)(now - last));
      this.getLastUpdateTimesInternal().put(setting, now);
      float current = (Float)this.getToggleAnimationsInternal().getOrDefault(setting, setting.isEnabled() ? 1.0F : 0.0F);
      float target = setting.isEnabled() ? 1.0F : 0.0F;
      if (current < target) {
         current = Math.min(target, current + delta * 0.0055F);
      } else if (current > target) {
         current = Math.max(target, current - delta * 0.0055F);
      }

      this.getToggleAnimationsInternal().put(setting, current);
      return current;
   }

   private Color lerpColor(Color from, Color to, float progress) {
      float t = Math.clamp(progress, 0.0F, 1.0F);
      int red = (int)((float)from.getRed() + (float)(to.getRed() - from.getRed()) * t);
      int green = (int)((float)from.getGreen() + (float)(to.getGreen() - from.getGreen()) * t);
      int blue = (int)((float)from.getBlue() + (float)(to.getBlue() - from.getBlue()) * t);
      int alpha = (int)((float)from.getAlpha() + (float)(to.getAlpha() - from.getAlpha()) * t);
      return new Color(red, green, blue, alpha);
   }

   private float smoothstep(float progress) {
      float t = Math.clamp(progress, 0.0F, 1.0F);
      return t * t * (3.0F - 2.0F * t);
   }

   private Map getToggleAnimationsInternal() {
      return this.field_6d2b79f5;
   }

   private Map getLastUpdateTimesInternal() {
      return this.field_da56f3ea;
   }

}
