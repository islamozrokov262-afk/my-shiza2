package atheryx.gui.setting;

import atheryx.setting.Setting;
import atheryx.setting.impl.KeybindSetting;
import atheryx.util.KeyHelper;
import net.minecraft.class_332;

public class KeybindSettingRenderer implements SettingRenderer<KeybindSetting> {
   public boolean supports(Setting setting) {
      return setting instanceof KeybindSetting;
   }

   public void render(class_332 context, KeybindSetting setting, SettingRendererContext rendererContext, float x, float y, float width, float scale, float opacity) {
      rendererContext.renderLabelAndValue(context, setting, this.getDisplayValue(setting), x, y, width, scale, opacity);
   }

   public boolean mouseClicked(KeybindSetting setting, SettingRendererContext rendererContext, int button, float localX, float localY, float width) {
      return button == 0;
   }

   public float getHeight(KeybindSetting setting, SettingRendererContext rendererContext) {
      return 18.0F;
   }

   public String getDisplayValue(KeybindSetting setting) {
      return setting.getKeybind() < 0 ? "Press key..." : KeyHelper.getKeyName(setting.getKeybind());
   }

}
