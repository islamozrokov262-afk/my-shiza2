package atheryx.gui.setting;

import atheryx.setting.Setting;
import net.minecraft.class_332;

public interface SettingRenderer<T extends Setting> {
   boolean supports(Setting var1);

   void render(class_332 var1, T var2, SettingRendererContext var3, float var4, float var5, float var6, float var7, float var8);

   boolean mouseClicked(T var1, SettingRendererContext var2, int var3, float var4, float var5, float var6);

   default boolean popupMouseClicked(T setting, SettingRendererContext rendererContext, int button, float localX, float localY, float width) {
      return false;
   }

   float getHeight(T var1, SettingRendererContext var2);

   default String getDisplayName(T setting) {
      return setting.getName();
   }

}
