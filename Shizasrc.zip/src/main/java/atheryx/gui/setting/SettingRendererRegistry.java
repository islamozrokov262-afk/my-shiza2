package atheryx.gui.setting;

import atheryx.setting.Setting;
import java.util.List;
import net.minecraft.class_332;

public class SettingRendererRegistry {
   private final List<SettingRenderer<? extends Setting>> field_6d2b79f5 = List.<SettingRenderer<? extends Setting>>of(new BooleanSettingRenderer(), new ColorSettingRenderer(), new ModeSettingRenderer(), new NumberSettingRenderer(), new MultiSettingRenderer(), new TextSettingRenderer(), new KeybindSettingRenderer());

   @SuppressWarnings("unchecked")
   public <T extends Setting> SettingRenderer<T> getRenderer(T setting) {
      for(SettingRenderer<? extends Setting> renderer : this.getRenderersInternal()) {
         if (renderer.supports(setting)) {
            return (SettingRenderer<T>)renderer;
         }
      }

      return (SettingRenderer<T>)SettingRendererRegistry.FallbackSettingRenderer.obf_u2239_u03b2;
   }

   private List<SettingRenderer<? extends Setting>> getRenderersInternal() {
      return this.field_6d2b79f5;
   }


   private static class FallbackSettingRenderer implements SettingRenderer<Setting> {
      private static final FallbackSettingRenderer obf_u2239_u03b2 = new FallbackSettingRenderer();

      public boolean supports(Setting setting) {
         return true;
      }

      public void render(class_332 context, Setting setting, SettingRendererContext rendererContext, float x, float y, float width, float scale, float opacity) {
         rendererContext.renderLabelAndValue(context, setting, this.getDisplayName(setting), x, y, width, scale, opacity);
      }

      public boolean mouseClicked(Setting setting, SettingRendererContext rendererContext, int button, float localX, float localY, float width) {
         return true;
      }

      public float getHeight(Setting setting, SettingRendererContext rendererContext) {
         return 18.0F;
      }

      public String getDisplayName(Setting setting) {
         return "...";
      }

   }
}
