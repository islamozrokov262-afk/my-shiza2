package atheryx.gui.setting;

import atheryx.render.RenderUtil;
import atheryx.setting.Setting;
import atheryx.setting.impl.ColorSetting;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_332;

public class ColorSettingRenderer implements SettingRenderer<ColorSetting> {
   private static final float obf_u039d_u03b2 = 62.0F;
   private static final float obf_u00ea_u03b2 = 7.0F;
   private static final float obf_u00f5_u03b2 = 7.0F;
   private static final int obf_u041e_u03b2 = 72;
   private final Map<ColorSetting, ColorPickerState> field_6d2b79f5 = new HashMap<ColorSetting, ColorPickerState>();

   public boolean supports(Setting setting) {
      return setting instanceof ColorSetting;
   }

   public void render(class_332 context, ColorSetting setting, SettingRendererContext rendererContext, float x, float y, float width, float scale, float opacity) {
      Color color = setting.getColor();
      float textSize = 7.69999981F * scale;
      Color label = rendererContext.applyOpacity(new Color(210, 210, 214), opacity);
      Color value = rendererContext.applyOpacity(new Color(150, 150, 156), opacity);
      float swatchSize = 10.0F * scale;
      float swatchX = x + width - swatchSize;
      float swatchY = y + 4.0F * scale;
      rendererContext.renderScrollingTextPart(context, setting, "name", setting.getName(), x, y + 4.5F * scale, width * 0.55F, 18.0F * scale, textSize, label, false, rendererContext.isMouseInside(x, y, width, 18.0F * scale));
      RenderUtil.drawAlignedText(context, swatchX - 6.0F * scale, y + 4.5F * scale, this.formatHexColor(color), textSize, value, "right");
      RenderUtil.drawRoundedRect(swatchX, swatchY, swatchSize, swatchSize, 3.0F * scale, rendererContext.applyOpacity(color, opacity));
      RenderUtil.drawRoundedOutline(swatchX, swatchY, swatchSize, swatchSize, 3.0F * scale, 0.8F * scale, rendererContext.applyOpacity(new Color(255, 255, 255), opacity * 0.42F));
      float expansion = rendererContext.getExpansionProgress(setting);
      if (!(expansion <= 0.02F)) {
         ColorPickerState state = this.getPickerState(setting);
         float pickerY = y + 18.0F * scale;
         float pickerHeight = 62.0F * scale * expansion;
         float fieldSize = 62.0F * scale;
         float hueWidth = 7.0F * scale;
         float gap = 7.0F * scale;
         float hueX = x + fieldSize + gap;
         float radius = 5.0F * scale;
         this.drawSaturationBrightnessField(rendererContext, x, pickerY, fieldSize, pickerHeight, radius, state.field_6d2b79f5, opacity * expansion);
         RenderUtil.drawRoundedOutline(x, pickerY, fieldSize, pickerHeight, radius, 0.9F * scale, rendererContext.applyOpacity(new Color(255, 255, 255), opacity * expansion * 0.25F));
         this.drawHueSlider(rendererContext, hueX, pickerY, hueWidth, pickerHeight, hueWidth / 2.0F, opacity * expansion);
         RenderUtil.drawRoundedOutline(hueX, pickerY, hueWidth, pickerHeight, hueWidth / 2.0F, 0.9F * scale, rendererContext.applyOpacity(new Color(255, 255, 255), opacity * expansion * 0.25F));
         float markerX = x + state.field_da56f3ea * fieldSize;
         float markerY = pickerY + (1.0F - state.field_47826ddf) * fieldSize;
         float hueMarkerY = pickerY + state.field_6d2b79f5 * fieldSize;
         Color marker = rendererContext.applyOpacity(Color.WHITE, opacity * expansion);
         RenderUtil.drawRoundedOutline(markerX - 2.5F * scale, markerY - 2.5F * scale, 5.0F * scale, 5.0F * scale, 2.5F * scale, 1.0F * scale, marker);
         RenderUtil.drawRoundedOutline(hueX - 1.5F * scale, hueMarkerY - 1.5F * scale, hueWidth + 3.0F * scale, 3.0F * scale, 1.5F * scale, 1.0F * scale, marker);
      }
   }

   public boolean mouseClicked(ColorSetting setting, SettingRendererContext rendererContext, int button, float localX, float localY, float width) {
      if (button == 1) {
         rendererContext.toggleExpanded(setting);
         return false;
      } else if (rendererContext.isExpanded(setting) && !(localY < 18.0F)) {
         this.updateColorFromMouse(setting, localX, localY);
         return true;
      } else {
         rendererContext.toggleExpanded(setting);
         return false;
      }
   }

   public boolean mouseDragged(ColorSetting setting, SettingRendererContext rendererContext, int button, float localX, float localY, float width) {
      if (button == 0 && rendererContext.isExpanded(setting)) {
         this.updateColorFromMouse(setting, localX, localY);
         return true;
      } else {
         return false;
      }
   }

   public float getHeight(ColorSetting setting, SettingRendererContext rendererContext) {
      return 18.0F + 62.0F * rendererContext.getExpansionProgress(setting);
   }

   public String getDisplayValue(ColorSetting setting) {
      return this.formatHexColor(setting.getColor());
   }

   private void updateColorFromMouse(ColorSetting setting, float localX, float localY) {
      ColorPickerState state = this.getPickerState(setting);
      float pickerY = 18.0F;
      float hueX = 69.0F;
      if (localX >= 0.0F && localX <= 62.0F && localY >= pickerY && localY <= pickerY + 62.0F) {
         state.field_da56f3ea = Math.clamp(localX / 62.0F, 0.0F, 1.0F);
         state.field_47826ddf = 1.0F - Math.clamp((localY - pickerY) / 62.0F, 0.0F, 1.0F);
         this.applyPickerState(setting, state);
      } else if (localX >= hueX && localX <= hueX + 7.0F && localY >= pickerY && localY <= pickerY + 62.0F) {
         state.field_6d2b79f5 = Math.clamp((localY - pickerY) / 62.0F, 0.0F, 1.0F);
         this.applyPickerState(setting, state);
      }

   }

   private ColorPickerState getPickerState(ColorSetting setting) {
      ColorPickerState state = (ColorPickerState)this.getPickerStatesInternal().computeIfAbsent(setting, (ignored) -> {
         return new ColorPickerState();
      });
      Color color = setting.getColor();
      if (state.field_b4ade7d4 != color.getRGB()) {
         float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), (float[])null);
         state.field_6d2b79f5 = hsb[0];
         state.field_da56f3ea = hsb[1];
         state.field_47826ddf = hsb[2];
         state.field_b4ade7d4 = color.getRGB();
      }

      return state;
   }

   private void applyPickerState(ColorSetting setting, ColorPickerState state) {
      Color color = Color.getHSBColor(state.field_6d2b79f5, state.field_da56f3ea, state.field_47826ddf);
      if (setting.getColor().getRGB() != color.getRGB()) {
         setting.setColor(color);
         state.field_b4ade7d4 = color.getRGB();
      }
   }

   private String formatHexColor(Color color) {
      return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
   }

   private void drawSaturationBrightnessField(SettingRendererContext rendererContext, float x, float y, float width, float height, float radius, float hue, float opacity) {
      Color topLeft = Color.WHITE;
      Color topMid = this.lerpColor(Color.WHITE, Color.getHSBColor(hue, 1.0F, 1.0F), 0.5F);
      Color topRight = Color.getHSBColor(hue, 1.0F, 1.0F);
      Color midLeft = new Color(128, 128, 128);
      Color midMid = Color.getHSBColor(hue, 0.5F, 0.5F);
      Color midRight = Color.getHSBColor(hue, 1.0F, 0.5F);
      Color black = Color.BLACK;
      RenderUtil.drawRoundedRect(x, y, width, height, radius, rendererContext.applyOpacity(topLeft, opacity), rendererContext.applyOpacity(topMid, opacity), rendererContext.applyOpacity(topRight, opacity), rendererContext.applyOpacity(midLeft, opacity), rendererContext.applyOpacity(midMid, opacity), rendererContext.applyOpacity(midRight, opacity), rendererContext.applyOpacity(black, opacity), rendererContext.applyOpacity(black, opacity), rendererContext.applyOpacity(black, opacity));
   }

   private Color lerpColor(Color first, Color second, float progress) {
      float clamped = Math.clamp(progress, 0.0F, 1.0F);
      int red = (int)((float)first.getRed() + (float)(second.getRed() - first.getRed()) * clamped);
      int green = (int)((float)first.getGreen() + (float)(second.getGreen() - first.getGreen()) * clamped);
      int blue = (int)((float)first.getBlue() + (float)(second.getBlue() - first.getBlue()) * clamped);
      int alpha = (int)((float)first.getAlpha() + (float)(second.getAlpha() - first.getAlpha()) * clamped);
      return new Color(red, green, blue, alpha);
   }

   private void drawHueSlider(SettingRendererContext rendererContext, float x, float y, float width, float height, float radius, float opacity) {
      if (!(height <= 0.0F) && !(width <= 0.0F)) {
         float dotSize = width;
         float travel = Math.max(0.0F, height - width);
         float step = travel / 71.0F;

         for(int i = 0; i < 72; ++i) {
            float progress = (float)i / 71.0F;
            Color color = rendererContext.applyOpacity(Color.getHSBColor(progress, 1.0F, 1.0F), opacity);
            RenderUtil.drawRoundedRect(x, y + (float)i * step, dotSize, dotSize, radius, color);
         }

      }
   }

   private Map getPickerStatesInternal() {
      return this.field_6d2b79f5;
   }


   private static class ColorPickerState {
      private float field_6d2b79f5;
      private float field_da56f3ea;
      private float field_47826ddf;
      private int field_b4ade7d4;

      private ColorPickerState() {
         this.setBrightnessInternal(1.0F);
      }

      private float getHueInternal() {
         return this.field_6d2b79f5;
      }

      private void setHueInternal(float var1) {
         this.field_6d2b79f5 = var1;
      }

      private float getSaturationInternal() {
         return this.field_da56f3ea;
      }

      private void setSaturationInternal(float var1) {
         this.field_da56f3ea = var1;
      }

      private float getBrightnessInternal() {
         return this.field_47826ddf;
      }

      private void setBrightnessInternal(float var1) {
         this.field_47826ddf = var1;
      }

      private int getLastRgbInternal() {
         return this.field_b4ade7d4;
      }

      private void setLastRgbInternal(int var1) {
         this.field_b4ade7d4 = var1;
      }

   }
}
