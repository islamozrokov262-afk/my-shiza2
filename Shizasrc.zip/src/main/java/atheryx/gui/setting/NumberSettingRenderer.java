package atheryx.gui.setting;

import atheryx.gui.ThemeManager;
import atheryx.render.RenderUtil;
import atheryx.setting.Setting;
import atheryx.setting.impl.NumberSetting;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_332;

public class NumberSettingRenderer implements SettingRenderer<NumberSetting> {
   private static final float obf_u223d_u03b2 = 25.0F;
   private static final float obf_u042a_u03b2 = 5.5F;
   private static final float obf_u00de_u03b2 = 9.0F;
   private static final float obf_u03a6_u03b2 = 0.0120000001F;
   private static final float obf_u223c_u03b2 = 0.0199999996F;
   private final Map<NumberSetting, Double> field_6d2b79f5 = new HashMap<NumberSetting, Double>();
   private final Map<NumberSetting, Float> field_da56f3ea = new HashMap<NumberSetting, Float>();
   private final Map<NumberSetting, Long> field_47826ddf = new HashMap<NumberSetting, Long>();

   public boolean supports(Setting setting) {
      return setting instanceof NumberSetting;
   }

   public void render(class_332 context, NumberSetting setting, SettingRendererContext rendererContext, float x, float y, float width, float scale, float opacity) {
      float delta = this.getFrameDeltaMillis(setting);
      float textSize = 7.69999981F * scale;
      float trackHeight = 5.5F * scale;
      float knobSize = 9.0F * scale;
      float sliderY = y + 16.5F * scale;
      float progress = this.getAnimatedSliderProgress(setting, delta);
      float fillWidth = Math.max(trackHeight, width * progress);
      float knobX = x + (width - knobSize) * progress;
      float knobY = sliderY + (trackHeight - knobSize) / 2.0F;
      Color label = rendererContext.applyOpacity(new Color(210, 210, 214), opacity);
      Color value = rendererContext.applyOpacity(new Color(150, 150, 156), opacity);
      Color track = rendererContext.applyOpacity(new Color(64, 64, 68), opacity);
      Color fill = rendererContext.applyOpacity(ThemeManager.getCurrentColor(), opacity);
      Color knob = rendererContext.applyOpacity(ThemeManager.getCurrentColor(), opacity);
      Color knobShadow = rendererContext.applyOpacity(new Color(0, 0, 0), opacity * 0.18F);
      boolean hovered = rendererContext.isMouseInside(x, y, width, 25.0F * scale);
      rendererContext.renderScrollingTextPart(context, setting, "name", setting.getName(), x, y + 4.19999981F * scale, width * 0.58F, 25.0F * scale, textSize, label, false, hovered);
      rendererContext.renderScrollingTextPart(context, setting, "value", this.getAnimatedDisplayValue(setting, delta), x + width - width * 0.38F, y + 4.19999981F * scale, width * 0.38F, 25.0F * scale, textSize, value, true, hovered);
      RenderUtil.drawRoundedRect(x, sliderY, width, trackHeight, trackHeight / 2.0F, track);
      RenderUtil.drawRoundedRect(x, sliderY, fillWidth, trackHeight, trackHeight / 2.0F, fill);
      RenderUtil.drawShadow(knobX, knobY, knobSize, knobSize, knobSize / 2.0F, 2.29999995F * scale, 0.25F, 1.0F, knobShadow);
      RenderUtil.drawRoundedRect(knobX, knobY, knobSize, knobSize, knobSize / 2.0F, knob);
   }

   public boolean mouseClicked(NumberSetting setting, SettingRendererContext rendererContext, int button, float localX, float localY, float width) {
      if (button == 1) {
         setting.setValue(setting.getValue() - setting.getStep());
         return false;
      } else {
         this.updateValueFromSlider(setting, localX, width, 1.0F);
         return true;
      }
   }

   public boolean mouseDragged(NumberSetting setting, SettingRendererContext rendererContext, int button, float localX, float localY, float width) {
      if (button != 0) {
         return false;
      } else {
         this.updateValueFromSlider(setting, localX, width, 1.0F);
         return true;
      }
   }

   public float getHeight(NumberSetting setting, SettingRendererContext rendererContext) {
      return 25.0F;
   }

   public String getDisplayValue(NumberSetting setting) {
      return this.formatValue(setting, setting.getValue());
   }

   private float getNormalizedValue(NumberSetting setting) {
      double range = setting.getMax() - setting.getMin();
      return range <= (double)0.0F ? 0.0F : Math.clamp((float)((setting.getValue() - setting.getMin()) / range), 0.0F, 1.0F);
   }

   private String getAnimatedDisplayValue(NumberSetting setting, float delta) {
      double target = setting.getValue();
      double current = (Double)this.getDisplayValuesInternal().getOrDefault(setting, target);
      double factor = (double)1.0F - Math.exp((double)(-0.012F * delta));
      current += (target - current) * (double)Math.clamp((float)factor, 0.0F, 1.0F);
      if (Math.abs(target - current) <= Math.max(1.0E-4, setting.getStep() * 0.08)) {
         current = target;
      }

      this.getDisplayValuesInternal().put(setting, current);
      return this.formatValue(setting, current);
   }

   private float getAnimatedSliderProgress(NumberSetting setting, float delta) {
      float target = this.getNormalizedValue(setting);
      float current = (Float)this.getSliderProgressInternal().getOrDefault(setting, target);
      float factor = 1.0F - (float)Math.exp((double)(-0.02F * delta));
      current += (target - current) * Math.clamp(factor, 0.0F, 1.0F);
      if (Math.abs(target - current) <= 0.001F) {
         current = target;
      }

      this.getSliderProgressInternal().put(setting, current);
      return current;
   }

   private float getFrameDeltaMillis(NumberSetting setting) {
      long now = System.currentTimeMillis();
      long last = (Long)this.getLastUpdateTimesInternal().getOrDefault(setting, now);
      float delta = Math.min(50.0F, (float)(now - last));
      this.getLastUpdateTimesInternal().put(setting, now);
      return delta;
   }

   private String formatValue(NumberSetting setting, double value) {
      double step = setting.getStep();
      return !(step >= (double)1.0F) && value != Math.rint(value) ? String.format("%.1f", value) : String.valueOf((int)Math.round(value));
   }

   private void updateValueFromSlider(NumberSetting setting, float localX, float width, float scale) {
      float sliderX = 0.0F;
      float progress = Math.clamp((localX - sliderX) / width, 0.0F, 1.0F);
      double range = setting.getMax() - setting.getMin();
      double rawValue = setting.getMin() + range * (double)progress;
      double step = setting.getStep();
      double steppedValue = step > (double)0.0F ? (double)Math.round(rawValue / step) * step : rawValue;
      setting.setValue(steppedValue);
   }

   private Map getDisplayValuesInternal() {
      return this.field_6d2b79f5;
   }

   private Map getSliderProgressInternal() {
      return this.field_da56f3ea;
   }

   private Map getLastUpdateTimesInternal() {
      return this.field_47826ddf;
   }

}
