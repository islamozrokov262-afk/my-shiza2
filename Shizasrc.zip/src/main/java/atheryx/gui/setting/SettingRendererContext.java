package atheryx.gui.setting;

import atheryx.gui.ThemeManager;
import atheryx.render.RenderUtil;
import atheryx.render.font.Msdf;
import atheryx.render.scissor.Scissor;
import atheryx.setting.Setting;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_332;

public class SettingRendererContext {
   public static final float SETTING_HEIGHT = 18.0F;
   private static final float obf_u0396_u03b2 = 26.0F;
   private static final float obf_u2235_u03b2 = 6.0F;
   private final Predicate<Setting> field_6d2b79f5;
   private final Function<Setting, Float> field_da56f3ea;
   private final Consumer<Setting> field_47826ddf;
   private final Map<String, Float> field_b4ade7d4 = new HashMap<String, Float>();
   private final Map<String, Long> field_21d961c9 = new HashMap<String, Long>();
   private final Map<String, Float> field_8f04dbbe = new HashMap<String, Float>();
   private float field_fc3055b3;
   private float field_695bcfa8;

   public SettingRendererContext(Predicate<Setting> expandedPredicate, Function<Setting, Float> expansionProvider, Consumer<Setting> expansionToggle) {
      this.field_6d2b79f5 = expandedPredicate;
      this.field_da56f3ea = expansionProvider;
      this.field_47826ddf = expansionToggle;
   }

   public boolean isExpanded(Setting setting) {
      return this.getExpandedPredicateInternal().test(setting);
   }

   public float getExpansionProgress(Setting setting) {
      return Math.clamp((Float)this.getExpansionFunctionInternal().apply(setting), 0.0F, 1.0F);
   }

   public void toggleExpanded(Setting setting) {
      this.getToggleConsumerInternal().accept(setting);
   }

   public void setMousePosition(float mouseX, float mouseY) {
      this.setMouseXInternal(mouseX);
      this.setMouseYInternal(mouseY);
   }

   public void renderLabelAndValue(class_332 context, Setting setting, String value, float x, float y, float width, float scale, float opacity) {
      Color label = this.applyOpacity(new Color(210, 210, 214), opacity);
      Color valueColor = this.applyOpacity(new Color(150, 150, 156), opacity);
      float textSize = 7.69999981F * scale;
      this.renderScrollingTextPart(context, setting, "name", setting.getName(), x, y + 4.5F * scale, width * 0.55F, 18.0F * scale, textSize, label, false, this.isMouseInside(x, y, width, 18.0F * scale));
      this.renderScrollingTextPart(context, setting, "value", value, x + width - width * 0.45F, y + 4.5F * scale, width * 0.45F, 18.0F * scale, textSize, valueColor, true, this.isMouseInside(x, y, width, 18.0F * scale));
   }

   public void renderOptions(class_332 context, List<String> options, Predicate<String> selected, float x, float y, float width, float scale, float opacity, float expansion) {
      float optionY = y + 18.0F * scale;
      Color selectedColor = this.applyOpacity(ThemeManager.getCurrentColor(), opacity * expansion);
      Color idleColor = this.applyOpacity(new Color(130, 130, 136), opacity * expansion);
      float textSize = 7.19999981F * scale;
      Scissor.push((double)x, (double)optionY, (double)width, (double)((float)options.size() * 18.0F * scale * expansion));

      for(String option : options) {
         Color color = selected.test(option) ? selectedColor : idleColor;
         this.renderScrollingTextPart(context, (Setting)null, "option:" + String.valueOf(option), option, x + 8.0F * scale, optionY + 4.19999981F * scale, width - 8.0F * scale, 18.0F * scale, textSize, color, false, this.isMouseInside(x, optionY, width, 18.0F * scale));
         optionY += 18.0F * scale;
      }

      Scissor.popTertiary();
   }

   public Color applyOpacity(Color color, float opacity) {
      int alpha = (int)((float)color.getAlpha() * Math.clamp(opacity, 0.0F, 1.0F));
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
   }

   public String ellipsize(String text, float maxWidth, float size) {
      if (Msdf.getTextWidth(text, size) <= maxWidth) {
         return text;
      } else {
         String ellipsis = "...";

         String trimmed;
         for(trimmed = text; !trimmed.isEmpty() && Msdf.getTextWidth(trimmed + ellipsis, size) > maxWidth; trimmed = trimmed.substring(0, trimmed.length() - 1)) {
         }

         return trimmed.isEmpty() ? ellipsis : trimmed + ellipsis;
      }
   }

   public void renderScrollingTextPart(class_332 context, Setting setting, String part, String text, float x, float y, float maxWidth, float rowHeight, float size, Color color, boolean rightAligned, boolean hovered) {
      if (text != null && !text.isEmpty() && !(maxWidth <= 0.0F)) {
         float textWidth = Msdf.getTextWidth(text, size);
         if (textWidth <= maxWidth) {
            RenderUtil.drawAlignedText(context, rightAligned ? x + maxWidth : x, y, text, size, color, rightAligned ? "right" : "left");
            this.resetMarqueeState(this.buildMarqueeKey(setting, part, text));
         } else {
            String key = this.buildMarqueeKey(setting, part, text);
            float overflow = textWidth - maxWidth + 6.0F;
            float offset = this.updateMarqueeOffset(key, overflow, hovered);
            Scissor.push((double)x, (double)(y - 2.0F), (double)maxWidth, (double)(size + 6.0F));
            RenderUtil.drawText(context, x - offset, y, text, size, color);
            Scissor.popTertiary();
         }
      }
   }

   public boolean isMouseInside(float x, float y, float width, float height) {
      return this.getMouseXInternal() >= x && this.getMouseXInternal() <= x + width && this.getMouseYInternal() >= y && this.getMouseYInternal() <= y + height;
   }

   private float updateMarqueeOffset(String key, float overflow, boolean hovered) {
      long now = System.currentTimeMillis();
      long last = (Long)this.getScrollUpdateTimesInternal().getOrDefault(key, now);
      float delta = Math.min(50.0F, (float)(now - last)) / 1000.0F;
      this.getScrollUpdateTimesInternal().put(key, now);
      float offset = (Float)this.getScrollOffsetsInternal().getOrDefault(key, 0.0F);
      if (!hovered) {
         offset = this.clamp(offset, 0.0F, 46.7999992F * delta);
         this.getHoverStartTimesInternal().remove(key);
         this.getScrollOffsetsInternal().put(key, offset);
         return offset;
      } else {
         float elapsed = (Float)this.getHoverStartTimesInternal().getOrDefault(key, 0.0F) + delta;
         float cycleDuration = Math.max(1.8F, overflow * 2.0F / 26.0F);
         float phase = elapsed % cycleDuration / cycleDuration;
         offset = overflow * (0.5F - 0.5F * (float)Math.cos((double)phase * 3.1415926535897931D * 2.0D));
         this.getHoverStartTimesInternal().put(key, elapsed);
         this.getScrollOffsetsInternal().put(key, offset);
         return offset;
      }
   }

   private float clamp(float current, float target, float step) {
      if (current < target) {
         return Math.min(target, current + step);
      } else {
         return current > target ? Math.max(target, current - step) : current;
      }
   }

   private void resetMarqueeState(String key) {
      this.getScrollOffsetsInternal().remove(key);
      this.getScrollUpdateTimesInternal().remove(key);
      this.getHoverStartTimesInternal().remove(key);
   }

   private String buildMarqueeKey(Setting setting, String part, String text) {
      String var4 = String.valueOf(setting == null ? "options" : System.identityHashCode(setting));
      return var4 + part + text;
   }

   private Predicate getExpandedPredicateInternal() {
      return this.field_6d2b79f5;
   }

   private Function getExpansionFunctionInternal() {
      return this.field_da56f3ea;
   }

   private Consumer getToggleConsumerInternal() {
      return this.field_47826ddf;
   }

   private Map getScrollOffsetsInternal() {
      return this.field_b4ade7d4;
   }

   private Map getScrollUpdateTimesInternal() {
      return this.field_21d961c9;
   }

   private Map getHoverStartTimesInternal() {
      return this.field_8f04dbbe;
   }

   private float getMouseXInternal() {
      return this.field_fc3055b3;
   }

   private void setMouseXInternal(float var1) {
      this.field_fc3055b3 = var1;
   }

   private float getMouseYInternal() {
      return this.field_695bcfa8;
   }

   private void setMouseYInternal(float var1) {
      this.field_695bcfa8 = var1;
   }

}
