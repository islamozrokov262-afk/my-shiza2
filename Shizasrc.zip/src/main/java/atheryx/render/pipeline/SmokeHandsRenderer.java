package atheryx.render.pipeline;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_10799;
import net.minecraft.class_12137;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_6367;
import org.lwjgl.system.MemoryUtil;
import atheryx.internal.RuntimeCipher;
import atheryx.module.render.SmokeHands;


public class SmokeHandsRenderer {
   private static final int obf_u0424_u2201 = (int)(float)256.0F;
   private static final float[] obf_u0421_u2201 = new float[]{1.0F, 1.0F, 1.0F};
   private static final BlendFunction obf_u0459_u2201 = new BlendFunction(SourceFactor.ONE, DestFactor.ZERO, SourceFactor.ONE, DestFactor.ZERO);
   private static final BlendFunction obf_u00ef_u2201 = new BlendFunction(SourceFactor.SRC_ALPHA, DestFactor.ONE, SourceFactor.ZERO, DestFactor.ONE);
   private static final RenderPipeline obf_u0454_u2201 = class_10799.method_67887(
      RenderPipeline.builder(new Snippet[0])
         .withLocation(
            class_2960.method_60655(
               "atheryx",
               "hand_mask_diff"
            )
         )
         .withVertexShader(
            class_2960.method_60655(
               "atheryx",
               "hands_fsq_vertex"
            )
         )
         .withFragmentShader(
            class_2960.method_60655(
               "atheryx",
               "hand_mask_diff"
            )
         )
         .withVertexFormat(class_290.field_60033, class_5596.field_27379)
         .withUniform(
            "Uniforms",
            class_10789.field_60031
         )
         .withSampler(
            "Sampler0"
         )
         .withSampler(
            "Sampler1"
         )
         .withBlend(obf_u0459_u2201)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withCull(false)
         .build()
   );
   private static final RenderPipeline obf_u0396_u2201 = class_10799.method_67887(
      RenderPipeline.builder(new Snippet[0])
         .withLocation(
            class_2960.method_60655(
               "atheryx",
               "hand_trail"
            )
         )
         .withVertexShader(
            class_2960.method_60655(
               "atheryx",
               "hands_fsq_vertex"
            )
         )
         .withFragmentShader(
            class_2960.method_60655(
               "atheryx",
               "hand_trail"
            )
         )
         .withVertexFormat(class_290.field_60033, class_5596.field_27379)
         .withUniform(
            "Uniforms",
            class_10789.field_60031
         )
         .withSampler(
            "Sampler0"
         )
         .withSampler(
            "Sampler1"
         )
         .withSampler(
            "Sampler2"
         )
         .withBlend(obf_u0459_u2201)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withCull(false)
         .build()
   );
   private static final RenderPipeline obf_u2235_u2201 = class_10799.method_67887(
      RenderPipeline.builder(new Snippet[0])
         .withLocation(
            class_2960.method_60655(
               "atheryx",
               "hand_kawase_down"
            )
         )
         .withVertexShader(
            class_2960.method_60655(
               "atheryx",
               "hands_fsq_vertex"
            )
         )
         .withFragmentShader(
            class_2960.method_60655(
               "atheryx",
               "hand_kawase_down"
            )
         )
         .withVertexFormat(class_290.field_60033, class_5596.field_27379)
         .withUniform(
            "Uniforms",
            class_10789.field_60031
         )
         .withSampler(
            "Sampler0"
         )
         .withBlend(obf_u0459_u2201)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withCull(false)
         .build()
   );
   private static final RenderPipeline obf_u220a_u2201 = class_10799.method_67887(
      RenderPipeline.builder(new Snippet[0])
         .withLocation(
            class_2960.method_60655(
               "atheryx",
               "hand_kawase_up"
            )
         )
         .withVertexShader(
            class_2960.method_60655(
               "atheryx",
               "hands_fsq_vertex"
            )
         )
         .withFragmentShader(
            class_2960.method_60655(
               "atheryx",
               "hand_kawase_up"
            )
         )
         .withVertexFormat(class_290.field_60033, class_5596.field_27379)
         .withUniform(
            "Uniforms",
            class_10789.field_60031
         )
         .withSampler(
            "Sampler0"
         )
         .withBlend(obf_u0459_u2201)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withCull(false)
         .build()
   );
   private static final RenderPipeline obf_u0399_u2201 = class_10799.method_67887(
      RenderPipeline.builder(new Snippet[0])
         .withLocation(
            class_2960.method_60655(
               "atheryx",
               "hand_fire"
            )
         )
         .withVertexShader(
            class_2960.method_60655(
               "atheryx",
               "hands_fsq_vertex"
            )
         )
         .withFragmentShader(
            class_2960.method_60655(
               "atheryx",
               "hand_fire"
            )
         )
         .withVertexFormat(class_290.field_60033, class_5596.field_27379)
         .withUniform(
            "Uniforms",
            class_10789.field_60031
         )
         .withSampler(
            "Sampler0"
         )
         .withSampler(
            "Sampler1"
         )
         .withSampler(
            "Sampler2"
         )
         .withBlend(obf_u0459_u2201)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withCull(false)
         .build()
   );
   private static final RenderPipeline obf_u043c_u2201 = class_10799.method_67887(
      RenderPipeline.builder(new Snippet[0])
         .withLocation(
            class_2960.method_60655(
               "atheryx",
               "hand_fire_pretty"
            )
         )
         .withVertexShader(
            class_2960.method_60655(
               "atheryx",
               "hands_fsq_vertex"
            )
         )
         .withFragmentShader(
            class_2960.method_60655(
               "atheryx",
               "hand_fire_pretty"
            )
         )
         .withVertexFormat(class_290.field_60033, class_5596.field_27379)
         .withUniform(
            "Uniforms",
            class_10789.field_60031
         )
         .withSampler(
            "Sampler0"
         )
         .withSampler(
            "Sampler1"
         )
         .withBlend(obf_u00ef_u2201)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withCull(false)
         .build()
   );
   private static final SmokeHandsRenderer obf_u00f2_u2201 = new SmokeHandsRenderer();
   private class_6367 field_6d2b79f5;
   private class_6367 field_da56f3ea;
   private class_6367 field_47826ddf;
   private class_6367 field_b4ade7d4;
   private class_6367 field_21d961c9;
   private class_6367 field_8f04dbbe;
   private class_6367 field_fc3055b3;
   private GpuBuffer field_695bcfa8;
   private GpuBuffer field_d687499d;
   private ByteBuffer field_43b2c392;
   private boolean field_b0de3d87;
   private boolean field_1e09b77c;
   private boolean field_8b353171;
   private long field_f860ab66;
   private float field_658c255b;
   private float field_d2b79f50;
   private float field_3fe31945;
   private float field_ad0e933a;
   private boolean field_1a3a0d2f;
   private float field_87658724;
   private final long field_f4910119;
   private float field_61bc7b0e;
   private float field_cee7f503;
   private boolean field_3c136ef8;

   private SmokeHandsRenderer() {
      this.setEnabledInternal(false);
      this.setCapturedBeforeHandsInternal(false);
      this.setCapturedAfterHandsInternal(false);
      this.setLastFrameTimeInternal(0L);
      this.setSmoothedDeltaTimeInternal(0.016666668F);
      this.setActivityInternal(0.0F);
      this.setSwingImpulseInternal(0.0F);
      this.setSwingDirectionInternal(1.0F);
      this.setWasSwingingInternal(false);
      this.setPreviousSwingProgressInternal(0.0F);
      this.field_f4910119 = System.nanoTime();
      this.setPreviousCameraYawInternal(0.0F);
      this.setPreviousCameraPitchInternal(0.0F);
      this.setCameraInitializedInternal(false);
   }

   public static SmokeHandsRenderer getInstance() {

      return obf_u00f2_u2201;
   }

   public void setEnabled(boolean enabled) {

      this.setEnabledInternal(enabled);
      if (!enabled) {
         this.close();
      }
   }

   public boolean isEnabled() {

      return this.getEnabledInternal();
   }

   private boolean canRender() {

      class_310 mc = class_310.method_1551();
      if (!this.getEnabledInternal()) {
         return false;
      } else if (mc.method_1522() == null || mc.method_1522().method_30277() == null) {
         return false;
      } else {
         return !mc.method_1569() ? false : mc.method_22683().method_4489() > 0 && mc.method_22683().method_4506() > 0;
      }
   }

   public void captureBeforeHands() {

      if (this.canRender()) {
         class_310 mc = class_310.method_1551();
         int w = mc.method_22683().method_4489();
         int h = mc.method_22683().method_4506();
         this.ensureFramebuffers(w, h);
         if (this.getSceneBeforeHandsInternal() != null && this.getSceneBeforeHandsInternal().method_30277() != null) {
            this.ensureBuffers();
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            encoder.copyTextureToTexture(mc.method_1522().method_30277(), this.getSceneBeforeHandsInternal().method_30277(), 0, 0, 0, 0, 0, w, h);
            this.setCapturedBeforeHandsInternal(true);
            this.setCapturedAfterHandsInternal(false);
         }
      }
   }

   public void captureAfterHands() {

      if (this.canRender() && this.getCapturedBeforeHandsInternal()) {
         class_310 mc = class_310.method_1551();
         int w = mc.method_22683().method_4489();
         int h = mc.method_22683().method_4506();
         this.ensureFramebuffers(w, h);
         if (this.getSceneAfterHandsInternal() != null && this.getSceneAfterHandsInternal().method_30277() != null) {
            this.ensureBuffers();
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            encoder.copyTextureToTexture(mc.method_1522().method_30277(), this.getSceneAfterHandsInternal().method_30277(), 0, 0, 0, 0, 0, w, h);
            this.setCapturedAfterHandsInternal(true);
         }
      }
   }

   public void renderEffect() {

      if (this.getEnabledInternal() && this.getCapturedAfterHandsInternal()) {
         SmokeHands m = SmokeHands.Instance;
         if (m == null) {
            this.setCapturedBeforeHandsInternal(false);
            this.setCapturedAfterHandsInternal(false);
         } else {
            boolean prettyMode = m.mode
               .isSelected(
                  "Красивый"
               );
            if (!this.canRender()) {
               this.clearHistory();
               this.setCameraInitializedInternal(false);
               this.setLastFrameTimeInternal(0L);
               this.setCapturedBeforeHandsInternal(false);
               this.setCapturedAfterHandsInternal(false);
            } else {
               class_310 mc = class_310.method_1551();
               int w = mc.method_22683().method_4489();
               int h = mc.method_22683().method_4506();
               long now = System.currentTimeMillis();
               float rawDt = this.getLastFrameTimeInternal() > 0L
                  ? (float)(now - this.getLastFrameTimeInternal()) / (float)1000.0F
                  : 0.016666668F;
               this.setLastFrameTimeInternal(now);
               if (rawDt <= 0.0F || rawDt > 0.05F) {
                  rawDt = this.getSmoothedDeltaTimeInternal();
               }

               rawDt = Math.max(0.0069444445F, Math.min(0.033333335F, rawDt));
               this.setSmoothedDeltaTimeInternal(this.getSmoothedDeltaTimeInternal() + (rawDt - this.getSmoothedDeltaTimeInternal()) * 0.1F);
               float dt = this.getSmoothedDeltaTimeInternal();
               float time = (float)(System.nanoTime() - this.getStartNanoTimeInternal()) / (float)1e+09F;
               boolean swinging = mc.field_1724 != null && mc.field_1724.field_6252;
               float swingProgress = mc.field_1724 != null ? mc.field_1724.field_6251 : 0.0F;
               boolean restartedSwing = swinging && (swingProgress + 0.08F < this.getPreviousSwingProgressInternal() || !this.getWasSwingingInternal() && swingProgress > 0.02F);
               if (restartedSwing) {
                  this.setSwingImpulseInternal(1.0F);
                  this.setSwingDirectionInternal(-this.getSwingDirectionInternal());
               }

               this.setWasSwingingInternal(swinging);
               this.setPreviousSwingProgressInternal(swingProgress);
               if (swinging) {
                  this.setSwingImpulseInternal(Math.max(this.getSwingImpulseInternal(), 1.0F - Math.min(1.0F, swingProgress) * 0.72F));
               }

               this.setSwingImpulseInternal(Math.max(0.0F, this.getSwingImpulseInternal() - dt * (float)2.20000005F));
               float motion = 0.0F;
               if (mc.field_1724 != null) {
                  motion = (float)Math.min(1.0, mc.field_1724.method_18798().method_37267() * (double)2.2000000000000002D);
               }

               float swingActivity = swinging && mc.field_1724 != null ? 1.0F - Math.min(1.0F, swingProgress) : 0.0F;
               float useActivity = mc.field_1724 != null && mc.field_1724.method_6115() ? 0.55F + Math.min(0.45F, mc.field_1724.method_6048() * 0.06F) : 0.0F;
               float activityTarget = Math.max(Math.max(swingActivity, useActivity), motion);
               this.setActivityInternal(
                  this.getActivityInternal()
                     + (activityTarget - this.getActivityInternal())
                        * (1.0F - (float)Math.exp(-dt * (double)6.0D))
               );
               float activity = this.getActivityInternal();
               float[] glow = m.resolveProgress();
               float camShiftX = 0.0F;
               float camShiftY = 0.0F;
               if (mc.field_1773 != null && mc.field_1773.method_19418() != null) {
                  float yaw = mc.field_1773.method_19418().method_19330();
                  float sampler = mc.field_1773.method_19418().method_19329();
                  if (this.getCameraInitializedInternal()) {
                     float dYaw = wrapDegrees(yaw - this.getPreviousCameraYawInternal());
                     float dPitch = sampler - this.getPreviousCameraPitchInternal();
                     double blurred = ((Integer)mc.field_1690.method_41808().method_41753()).intValue();
                     float fovRad = (float)Math.toRadians(Math.max(1.0, blurred));
                     float tanHalf = (float)Math.tan(fovRad * 0.5F);
                     float aspect = h > 0 ? (float)w / h : 1.0F;
                     camShiftX = (float)Math.toRadians(dYaw) / (2.0F * tanHalf * aspect);
                     camShiftY = -((float)Math.toRadians(dPitch)) / (2.0F * tanHalf);
                     camShiftX = Math.max(-0.25F, Math.min(0.25F, camShiftX));
                     camShiftY = Math.max(-0.25F, Math.min(0.25F, camShiftY));
                  }

                  this.setPreviousCameraYawInternal(yaw);
                  this.setPreviousCameraPitchInternal(sampler);
                  this.setCameraInitializedInternal(true);
               }

               this.ensureBuffers();
               if (this.getUniformBufferInternal() != null && this.getFullscreenVertexBufferInternal() != null) {
                  CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
                  class_12137 sampler = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
                  this.prepareIdentityUniforms();
                  encoder.writeToBuffer(this.getUniformBufferInternal().slice(), this.getUniformDataInternal());
                  RenderPass var44 = encoder.createRenderPass(
                     () -> {

                        return "atheryx:hand_mask_diff";
                     },
                     this.getHandMaskInternal().method_71639(),
                     OptionalInt.empty(),
                     null,
                     OptionalDouble.empty()
                  );

                  try {
                     var44.setPipeline(obf_u0454_u2201);
                     var44.setVertexBuffer(0, this.getFullscreenVertexBufferInternal());
                     var44.setUniform(
                        "Uniforms",
                        this.getUniformBufferInternal()
                     );
                     var44.bindTexture(
                        "Sampler0",
                        this.getSceneBeforeHandsInternal().method_71639(),
                        sampler
                     );
                     var44.bindTexture(
                        "Sampler1",
                        this.getSceneAfterHandsInternal().method_71639(),
                        sampler
                     );
                     var44.draw(0, 3);
                  } catch (Throwable var38) {
                     if (var44 != null) {
                        try {
                           var44.close();
                        } catch (Throwable var34) {
                           var38.addSuppressed(var34);
                        }
                     }

                     throw var38;
                  }

                  if (var44 != null) {
                     var44.close();
                  }

                  this.writeTrailUniforms(
                     w, h, time, m, activity, this.getSwingImpulseInternal(), this.getSwingDirectionInternal(), getHandActivity(mc, swinging), camShiftX, camShiftY, glow
                  );
                  encoder.writeToBuffer(this.getUniformBufferInternal().slice(), this.getUniformDataInternal());
                  var44 = encoder.createRenderPass(
                     () -> {

                        return "atheryx:hand_trail";
                     },
                     this.getTrailHistorySecondaryInternal().method_71639(),
                     OptionalInt.empty(),
                     null,
                     OptionalDouble.empty()
                  );

                  try {
                     var44.setPipeline(obf_u0396_u2201);
                     var44.setVertexBuffer(0, this.getFullscreenVertexBufferInternal());
                     var44.setUniform(
                        "Uniforms",
                        this.getUniformBufferInternal()
                     );
                     var44.bindTexture(
                        "Sampler0",
                        this.getTrailHistoryPrimaryInternal().method_71639(),
                        sampler
                     );
                     var44.bindTexture(
                        "Sampler1",
                        this.getSceneAfterHandsInternal().method_71639(),
                        sampler
                     );
                     var44.bindTexture(
                        "Sampler2",
                        this.getHandMaskInternal().method_71639(),
                        sampler
                     );
                     var44.draw(0, 3);
                  } catch (Throwable var37) {
                     if (var44 != null) {
                        try {
                           var44.close();
                        } catch (Throwable var33) {
                           var37.addSuppressed(var33);
                        }
                     }

                     throw var37;
                  }

                  if (var44 != null) {
                     var44.close();
                  }

                  class_6367 blurSource;
                  float radius;
                  if (prettyMode) {
                     blurSource = this.getHandMaskInternal();
                     radius = (float)m.prettyGlow.getValue();
                  } else {
                     blurSource = this.getTrailHistorySecondaryInternal();
                     radius = (float)m.trailBlur.getValue();
                  }

                  GpuTextureView blurred = this.applyKawaseBlur(encoder, sampler, blurSource, radius, w, h);
                  if (prettyMode) {
                     this.preparePrettyModeUniforms(time, m, camShiftX, camShiftY, glow);
                     encoder.writeToBuffer(this.getUniformBufferInternal().slice(), this.getUniformDataInternal());
                     RenderPass tmp = encoder.createRenderPass(
                        () -> {

                           return "atheryx:hand_fire_pretty";
                        },
                        mc.method_1522().method_71639(),
                        OptionalInt.empty(),
                        mc.method_1522().method_71640(),
                        OptionalDouble.empty()
                     );

                     try {
                        tmp.setPipeline(obf_u043c_u2201);
                        tmp.setVertexBuffer(0, this.getFullscreenVertexBufferInternal());
                        tmp.setUniform(
                           "Uniforms",
                           this.getUniformBufferInternal()
                        );
                        tmp.bindTexture(
                           "Sampler0",
                           blurred,
                           sampler
                        );
                        tmp.bindTexture(
                           "Sampler1",
                           this.getHandMaskInternal().method_71639(),
                           sampler
                        );
                        tmp.draw(0, 3);
                     } catch (Throwable var36) {
                        if (tmp != null) {
                           try {
                              tmp.close();
                           } catch (Throwable var32) {
                              var36.addSuppressed(var32);
                           }
                        }

                        throw var36;
                     }

                     if (tmp != null) {
                        tmp.close();
                     }
                  } else {
                     this.prepareSmokeUniforms(w, h, time, m, activity, glow);
                     encoder.writeToBuffer(this.getUniformBufferInternal().slice(), this.getUniformDataInternal());
                     RenderPass var49 = encoder.createRenderPass(
                        () -> {

                           return "atheryx:hand_fire";
                        },
                        mc.method_1522().method_71639(),
                        OptionalInt.empty(),
                        mc.method_1522().method_71640(),
                        OptionalDouble.empty()
                     );

                     try {
                        var49.setPipeline(obf_u0399_u2201);
                        var49.setVertexBuffer(0, this.getFullscreenVertexBufferInternal());
                        var49.setUniform(
                           "Uniforms",
                           this.getUniformBufferInternal()
                        );
                        var49.bindTexture(
                           "Sampler0",
                           this.getSceneAfterHandsInternal().method_71639(),
                           sampler
                        );
                        var49.bindTexture(
                           "Sampler1",
                           blurred,
                           sampler
                        );
                        var49.bindTexture(
                           "Sampler2",
                           this.getHandMaskInternal().method_71639(),
                           sampler
                        );
                        var49.draw(0, 3);
                     } catch (Throwable var35) {
                        if (var49 != null) {
                           try {
                              var49.close();
                           } catch (Throwable var31) {
                              var35.addSuppressed(var31);
                           }
                        }

                        throw var35;
                     }

                     if (var49 != null) {
                        var49.close();
                     }
                  }

                  class_6367 tmp = this.getTrailHistoryPrimaryInternal();
                  this.setTrailHistoryPrimaryInternal(this.getTrailHistorySecondaryInternal());
                  this.setTrailHistorySecondaryInternal(tmp);
                  this.setCapturedBeforeHandsInternal(false);
                  this.setCapturedAfterHandsInternal(false);
               } else {
                  this.setCapturedBeforeHandsInternal(false);
                  this.setCapturedAfterHandsInternal(false);
               }
            }
         }
      } else {
         this.setCapturedBeforeHandsInternal(false);
         this.setCapturedAfterHandsInternal(false);
      }
   }

   private GpuTextureView applyKawaseBlur(CommandEncoder encoder, class_12137 sampler, class_6367 src, float radius, int w, int h) {

      if (this.getBlurTargetPrimaryInternal() != null && this.getBlurTargetSecondaryInternal() != null) {
         float o = Math.max(1.0F, 1.0F + radius);
         this.prepareBlurUniforms(o, w, h);
         encoder.writeToBuffer(this.getUniformBufferInternal().slice(), this.getUniformDataInternal());
         RenderPass pass = encoder.createRenderPass(
            () -> {

               return "atheryx:hand_kawase_down";
            },
            this.getBlurTargetPrimaryInternal().method_71639(),
            OptionalInt.empty(),
            null,
            OptionalDouble.empty()
         );

         try {
            pass.setPipeline(obf_u2235_u2201);
            pass.setVertexBuffer(0, this.getFullscreenVertexBufferInternal());
            pass.setUniform(
               "Uniforms",
               this.getUniformBufferInternal()
            );
            pass.bindTexture(
               "Sampler0",
               src.method_71639(),
               sampler
            );
            pass.draw(0, 3);
         } catch (Throwable var18) {
            if (pass != null) {
               try {
                  pass.close();
               } catch (Throwable var14) {
                  var18.addSuppressed(var14);
               }
            }

            throw var18;
         }

         if (pass != null) {
            pass.close();
         }

         this.prepareBlurUniforms(o * 2.0F, w, h);
         encoder.writeToBuffer(this.getUniformBufferInternal().slice(), this.getUniformDataInternal());
         pass = encoder.createRenderPass(
            () -> {

               return "atheryx:hand_kawase_down";
            },
            this.getBlurTargetSecondaryInternal().method_71639(),
            OptionalInt.empty(),
            null,
            OptionalDouble.empty()
         );

         try {
            pass.setPipeline(obf_u2235_u2201);
            pass.setVertexBuffer(0, this.getFullscreenVertexBufferInternal());
            pass.setUniform(
               "Uniforms",
               this.getUniformBufferInternal()
            );
            pass.bindTexture(
               "Sampler0",
               this.getBlurTargetPrimaryInternal().method_71639(),
               sampler
            );
            pass.draw(0, 3);
         } catch (Throwable var17) {
            if (pass != null) {
               try {
                  pass.close();
               } catch (Throwable var13) {
                  var17.addSuppressed(var13);
               }
            }

            throw var17;
         }

         if (pass != null) {
            pass.close();
         }

         this.prepareBlurCompositeUniforms(o * 2.0F, w, h);
         encoder.writeToBuffer(this.getUniformBufferInternal().slice(), this.getUniformDataInternal());
         pass = encoder.createRenderPass(
            () -> {

               return "atheryx:hand_kawase_up";
            },
            this.getBlurTargetPrimaryInternal().method_71639(),
            OptionalInt.empty(),
            null,
            OptionalDouble.empty()
         );

         try {
            pass.setPipeline(obf_u220a_u2201);
            pass.setVertexBuffer(0, this.getFullscreenVertexBufferInternal());
            pass.setUniform(
               "Uniforms",
               this.getUniformBufferInternal()
            );
            pass.bindTexture(
               "Sampler0",
               this.getBlurTargetSecondaryInternal().method_71639(),
               sampler
            );
            pass.draw(0, 3);
         } catch (Throwable var16) {
            if (pass != null) {
               try {
                  pass.close();
               } catch (Throwable var12) {
                  var16.addSuppressed(var12);
               }
            }

            throw var16;
         }

         if (pass != null) {
            pass.close();
         }

         this.prepareBlurCompositeUniforms(o, w, h);
         encoder.writeToBuffer(this.getUniformBufferInternal().slice(), this.getUniformDataInternal());
         pass = encoder.createRenderPass(
            () -> {

               return "atheryx:hand_kawase_up";
            },
            this.getBlurTargetSecondaryInternal().method_71639(),
            OptionalInt.empty(),
            null,
            OptionalDouble.empty()
         );

         try {
            pass.setPipeline(obf_u220a_u2201);
            pass.setVertexBuffer(0, this.getFullscreenVertexBufferInternal());
            pass.setUniform(
               "Uniforms",
               this.getUniformBufferInternal()
            );
            pass.bindTexture(
               "Sampler0",
               this.getBlurTargetPrimaryInternal().method_71639(),
               sampler
            );
            pass.draw(0, 3);
         } catch (Throwable var15) {
            if (pass != null) {
               try {
                  pass.close();
               } catch (Throwable var11) {
                  var15.addSuppressed(var11);
               }
            }

            throw var15;
         }

         if (pass != null) {
            pass.close();
         }

         return this.getBlurTargetSecondaryInternal().method_71639();
      } else {
         return null;
      }
   }

   private void resetUniformData() {

      this.getUniformDataInternal().clear();

      for (int i = 0; i < 16; i++) {
         this.getUniformDataInternal().putFloat(i % 5 == 0 ? 1.0F : 0.0F);
      }

      for (int i = 0; i < 48; i++) {
         this.getUniformDataInternal().putFloat(0.0F);
      }
   }

   private void putUniformVector(int index, float x, float y, float z, float w) {

      int pos = 64 + index * 16;
      this.getUniformDataInternal().putFloat(pos, x).putFloat(pos + 4, y).putFloat(pos + 8, z).putFloat(pos + 12, w);
   }

   private void prepareIdentityUniforms() {

      this.resetUniformData();
      this.getUniformDataInternal().flip();
   }

   private void writeTrailUniforms(
      int w, int h, float time, SmokeHands m, float activity, float slash, float slashDir, float swingHand, float camShiftX, float camShiftY, float[] glow
   ) {

      this.resetUniformData();
      this.putUniformVector(0, w, h, time, (float)m.intensity.getValue());
      this.putUniformVector(
         1,
         (float)m.speed.getValue(),
         (float)m.length.getValue(),
         (float)m.trailSoftness.getValue(),
         (float)m.trailBlur.getValue()
      );
      this.putUniformVector(2, (float)m.smoke.getValue(), activity, (float)m.trailFade.getValue(), slash);
      this.putUniformVector(3, slashDir, swingHand, camShiftX, camShiftY);
      this.putUniformVector(4, glow[0], glow[1], glow[2], 1.0F);
      this.getUniformDataInternal().flip();
   }

   private void prepareBlurUniforms(float offset, int w, int h) {

      this.resetUniformData();
      this.putUniformVector(0, offset, offset, 0.5F / w, 0.5F / h);
      this.putUniformVector(1, w, h, 1.0F, 1.0F);
      this.getUniformDataInternal().flip();
   }

   private void prepareBlurCompositeUniforms(float offset, int w, int h) {

      this.resetUniformData();
      this.putUniformVector(0, offset, offset, 0.5F / w, 0.5F / h);
      this.putUniformVector(1, w, h, 1.0F, 1.0F);
      this.putUniformVector(5, obf_u0421_u2201[0], obf_u0421_u2201[1], obf_u0421_u2201[2], 1.0F);
      this.getUniformDataInternal().flip();
   }

   private void prepareSmokeUniforms(int w, int h, float time, SmokeHands m, float activity, float[] glow) {

      this.resetUniformData();
      this.putUniformVector(0, w, h, time, (float)m.intensity.getValue());
      this.putUniformVector(
         1, (float)m.handSoftness.getValue(), (float)m.handBlur.getValue(), (float)m.smoke.getValue(), activity
      );
      this.putUniformVector(4, glow[0], glow[1], glow[2], 1.0F);
      this.getUniformDataInternal().flip();
   }

   private void preparePrettyModeUniforms(float time, SmokeHands m, float camShiftX, float camShiftY, float[] glow) {

      this.resetUniformData();
      this.putUniformVector(0, 0.0F, 0.0F, time, (float)m.prettyHeight.getValue());
      this.putUniformVector(
         1,
         (float)m.speed.getValue(),
         (float)m.intensity.getValue(),
         (float)m.prettyWind.getValue(),
         (float)m.prettyWave.getValue()
      );
      this.putUniformVector(3, 0.0F, 0.0F, camShiftX, camShiftY);
      this.putUniformVector(5, glow[0], glow[1], glow[2], 1.0F);
      this.putUniformVector(6, Math.min(1.0F, glow[0] + 0.25F), Math.max(0.0F, glow[1] * 0.55F), Math.max(0.0F, glow[2] * 0.45F), 1.0F);
      this.getUniformDataInternal().flip();
   }

   private void ensureBuffers() {

      if (this.getUniformBufferInternal() == null) {
         this.setUniformBufferInternal(
            RenderSystem.getDevice()
               .createBuffer(
                  () -> {

                     return "atheryx:hand_shader_uniforms";
                  },
                  136,
                  (long)256L
               )
         );
      }

      if (this.getFullscreenVertexBufferInternal() == null) {
         ByteBuffer dummy = MemoryUtil.memAlloc(4);
         dummy.putInt(0);
         dummy.flip();
         this.setFullscreenVertexBufferInternal(
            RenderSystem.getDevice()
               .createBuffer(
                  () -> {

                     return "atheryx:hand_shader_dummy_vertex";
                  },
                  32,
                  dummy
               )
         );
         MemoryUtil.memFree(dummy);
      }

      if (this.getUniformDataInternal() == null) {
         this.setUniformDataInternal(MemoryUtil.memAlloc(256));
      }
   }

   private void ensureFramebuffers(int w, int h) {

      if (this.getSceneBeforeHandsInternal() == null) {
         this.setSceneBeforeHandsInternal(
            new class_6367(
               "atheryx_hands_scene_before",
               w,
               h,
               false
            )
         );
         this.setSceneAfterHandsInternal(
            new class_6367(
               "atheryx_hands_scene_after",
               w,
               h,
               false
            )
         );
         this.setHandMaskInternal(
            new class_6367(
               "atheryx_hands_mask",
               w,
               h,
               false
            )
         );
         this.setTrailHistoryPrimaryInternal(
            new class_6367(
               "atheryx_hands_trail_a",
               w,
               h,
               false
            )
         );
         this.setTrailHistorySecondaryInternal(
            new class_6367(
               "atheryx_hands_trail_b",
               w,
               h,
               false
            )
         );
         this.clearHistory();
      } else if (this.getSceneBeforeHandsInternal().field_1482 != w || this.getSceneBeforeHandsInternal().field_1481 != h) {
         this.getSceneBeforeHandsInternal().method_1234(w, h);
         this.getSceneAfterHandsInternal().method_1234(w, h);
         this.getHandMaskInternal().method_1234(w, h);
         this.getTrailHistoryPrimaryInternal().method_1234(w, h);
         this.getTrailHistorySecondaryInternal().method_1234(w, h);
      }

      if (this.getBlurTargetPrimaryInternal() == null) {
         this.setBlurTargetPrimaryInternal(
            new class_6367(
               "atheryx_hands_blur_1",
               w,
               h,
               false
            )
         );
         this.setBlurTargetSecondaryInternal(
            new class_6367(
               "atheryx_hands_blur_2",
               w,
               h,
               false
            )
         );
      } else if (this.getBlurTargetPrimaryInternal().field_1482 != w || this.getBlurTargetPrimaryInternal().field_1481 != h) {
         this.getBlurTargetPrimaryInternal().method_1234(w, h);
         this.getBlurTargetSecondaryInternal().method_1234(w, h);
      }
   }

   private void clearHistory() {

      if (this.getTrailHistoryPrimaryInternal() != null && this.getTrailHistoryPrimaryInternal().method_30277() != null) {
         RenderSystem.getDevice().createCommandEncoder().clearColorTexture(this.getTrailHistoryPrimaryInternal().method_30277(), 0);
      }

      if (this.getTrailHistorySecondaryInternal() != null && this.getTrailHistorySecondaryInternal().method_30277() != null) {
         RenderSystem.getDevice().createCommandEncoder().clearColorTexture(this.getTrailHistorySecondaryInternal().method_30277(), 0);
      }
   }

   private static float wrapDegrees(float deg) {

      deg %= (float)360.0F;
      if (deg >= (float)180.0F) {
         deg -= (float)360.0F;
      }

      if (deg < (float)-180.0F) {
         deg += (float)360.0F;
      }

      return deg;
   }

   private static float getHandActivity(class_310 mc, boolean swinging) {

      if (mc.field_1724 == null) {
         return 0.0F;
      } else {
         class_1268 activeSwingHand = swinging ? class_1268.field_5808 : (mc.field_1724.method_6115() ? mc.field_1724.method_6058() : class_1268.field_5808);
         if (activeSwingHand == class_1268.field_5808) {
            return mc.field_1724.method_6068() == class_1306.field_6182 ? -1.0F : 1.0F;
         } else if (activeSwingHand == class_1268.field_5810) {
            return mc.field_1724.method_6068() == class_1306.field_6182 ? 1.0F : -1.0F;
         } else {
            return 0.0F;
         }
      }
   }

   public void close() {

      Runnable cleanup = () -> {

         if (this.getSceneBeforeHandsInternal() != null) {
            this.getSceneBeforeHandsInternal().method_1238();
            this.setSceneBeforeHandsInternal(null);
         }

         if (this.getSceneAfterHandsInternal() != null) {
            this.getSceneAfterHandsInternal().method_1238();
            this.setSceneAfterHandsInternal(null);
         }

         if (this.getHandMaskInternal() != null) {
            this.getHandMaskInternal().method_1238();
            this.setHandMaskInternal(null);
         }

         if (this.getTrailHistoryPrimaryInternal() != null) {
            this.getTrailHistoryPrimaryInternal().method_1238();
            this.setTrailHistoryPrimaryInternal(null);
         }

         if (this.getTrailHistorySecondaryInternal() != null) {
            this.getTrailHistorySecondaryInternal().method_1238();
            this.setTrailHistorySecondaryInternal(null);
         }

         if (this.getBlurTargetPrimaryInternal() != null) {
            this.getBlurTargetPrimaryInternal().method_1238();
            this.setBlurTargetPrimaryInternal(null);
         }

         if (this.getBlurTargetSecondaryInternal() != null) {
            this.getBlurTargetSecondaryInternal().method_1238();
            this.setBlurTargetSecondaryInternal(null);
         }
      };
      if (RenderSystem.isOnRenderThread()) {
         cleanup.run();
      } else {
         RenderSystem.queueFencedTask(cleanup);
      }

      this.setCapturedBeforeHandsInternal(false);
      this.setCapturedAfterHandsInternal(false);
      this.setLastFrameTimeInternal(0L);
      this.setSmoothedDeltaTimeInternal(0.016666668F);
      this.setActivityInternal(0.0F);
      this.setSwingImpulseInternal(0.0F);
      this.setSwingDirectionInternal(1.0F);
      this.setWasSwingingInternal(false);
      this.setPreviousSwingProgressInternal(0.0F);
      this.setCameraInitializedInternal(false);
   }

   private class_6367 getSceneBeforeHandsInternal() {

      return this.field_6d2b79f5;
   }

   private void setSceneBeforeHandsInternal(class_6367 var1) {

      this.field_6d2b79f5 = var1;
   }

   private class_6367 getSceneAfterHandsInternal() {

      return this.field_da56f3ea;
   }

   private void setSceneAfterHandsInternal(class_6367 var1) {

      this.field_da56f3ea = var1;
   }

   private class_6367 getHandMaskInternal() {

      return this.field_47826ddf;
   }

   private void setHandMaskInternal(class_6367 var1) {

      this.field_47826ddf = var1;
   }

   private class_6367 getTrailHistoryPrimaryInternal() {

      return this.field_b4ade7d4;
   }

   private void setTrailHistoryPrimaryInternal(class_6367 var1) {

      this.field_b4ade7d4 = var1;
   }

   private class_6367 getTrailHistorySecondaryInternal() {

      return this.field_21d961c9;
   }

   private void setTrailHistorySecondaryInternal(class_6367 var1) {

      this.field_21d961c9 = var1;
   }

   private class_6367 getBlurTargetPrimaryInternal() {

      return this.field_8f04dbbe;
   }

   private void setBlurTargetPrimaryInternal(class_6367 var1) {

      this.field_8f04dbbe = var1;
   }

   private class_6367 getBlurTargetSecondaryInternal() {

      return this.field_fc3055b3;
   }

   private void setBlurTargetSecondaryInternal(class_6367 var1) {

      this.field_fc3055b3 = var1;
   }

   private GpuBuffer getUniformBufferInternal() {

      return this.field_695bcfa8;
   }

   private void setUniformBufferInternal(GpuBuffer var1) {

      this.field_695bcfa8 = var1;
   }

   private GpuBuffer getFullscreenVertexBufferInternal() {

      return this.field_d687499d;
   }

   private void setFullscreenVertexBufferInternal(GpuBuffer var1) {

      this.field_d687499d = var1;
   }

   private ByteBuffer getUniformDataInternal() {

      return this.field_43b2c392;
   }

   private void setUniformDataInternal(ByteBuffer var1) {

      this.field_43b2c392 = var1;
   }

   private boolean getEnabledInternal() {

      return this.field_b0de3d87;
   }

   private void setEnabledInternal(boolean var1) {

      this.field_b0de3d87 = var1;
   }

   private boolean getCapturedBeforeHandsInternal() {

      return this.field_1e09b77c;
   }

   private void setCapturedBeforeHandsInternal(boolean var1) {

      this.field_1e09b77c = var1;
   }

   private boolean getCapturedAfterHandsInternal() {

      return this.field_8b353171;
   }

   private void setCapturedAfterHandsInternal(boolean var1) {

      this.field_8b353171 = var1;
   }

   private long getLastFrameTimeInternal() {

      return this.field_f860ab66;
   }

   private void setLastFrameTimeInternal(long var1) {

      this.field_f860ab66 = var1;
   }

   private float getSmoothedDeltaTimeInternal() {

      return this.field_658c255b;
   }

   private void setSmoothedDeltaTimeInternal(float var1) {

      this.field_658c255b = var1;
   }

   private float getActivityInternal() {

      return this.field_d2b79f50;
   }

   private void setActivityInternal(float var1) {

      this.field_d2b79f50 = var1;
   }

   private float getSwingImpulseInternal() {

      return this.field_3fe31945;
   }

   private void setSwingImpulseInternal(float var1) {

      this.field_3fe31945 = var1;
   }

   private float getSwingDirectionInternal() {

      return this.field_ad0e933a;
   }

   private void setSwingDirectionInternal(float var1) {

      this.field_ad0e933a = var1;
   }

   private boolean getWasSwingingInternal() {

      return this.field_1a3a0d2f;
   }

   private void setWasSwingingInternal(boolean var1) {

      this.field_1a3a0d2f = var1;
   }

   private float getPreviousSwingProgressInternal() {

      return this.field_87658724;
   }

   private void setPreviousSwingProgressInternal(float var1) {

      this.field_87658724 = var1;
   }

   private long getStartNanoTimeInternal() {

      return this.field_f4910119;
   }

   private float getPreviousCameraYawInternal() {

      return this.field_61bc7b0e;
   }

   private void setPreviousCameraYawInternal(float var1) {

      this.field_61bc7b0e = var1;
   }

   private float getPreviousCameraPitchInternal() {

      return this.field_cee7f503;
   }

   private void setPreviousCameraPitchInternal(float var1) {

      this.field_cee7f503 = var1;
   }

   private boolean getCameraInitializedInternal() {

      return this.field_3c136ef8;
   }

   private void setCameraInitializedInternal(boolean var1) {

      this.field_3c136ef8 = var1;
   }

}
