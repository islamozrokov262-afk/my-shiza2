package atheryx.render.pipeline;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;
import atheryx.internal.RuntimeCipher;


public class GlowPipeline {
   private static RenderPipeline obf_u0401_u2201;
   private static GpuBuffer obf_u0405_u2201;
   private static final int obf_u044d_u2201 = (int)(float)128.0F;

   public static void init() {

      if (obf_u0401_u2201 == null) {
         try {
            obf_u0401_u2201 = RenderPipeline.builder(new Snippet[0])
               .withLocation(
                  class_2960.method_60655(
                     "atheryx",
                     "glow"
                  )
               )
               .withVertexShader(
                  class_2960.method_60655(
                     "atheryx",
                     "glow_vertex"
                  )
               )
               .withFragmentShader(
                  class_2960.method_60655(
                     "atheryx",
                     "glow_fragment"
                  )
               )
               .withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379)
               .withUniform(
                  "Uniforms",
                  class_10789.field_60031
               )
               .withBlend(BlendFunction.TRANSLUCENT)
               .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
               .withCull(false)
               .build();
            obf_u0405_u2201 = RenderSystem.getDevice()
               .createBuffer(
                  () -> {

                     return "GlowPipeline Uniforms";
                  },
                  136,
                  (long)128L
               );
         } catch (Exception var1) {
         }
      }
   }

   public static void drawGlow(Matrix4f matrix, float x, float y, float size, int color, float z) {

      if (obf_u0401_u2201 == null) {
         init();
      }

      if (obf_u0401_u2201 != null && obf_u0405_u2201 != null) {
         float r = (color >> 16 & 0xFF) / (float)255.0F;
         float g = (color >> 8 & 0xFF) / (float)255.0F;
         float b = (color & 0xFF) / (float)255.0F;
         float a = (color >> 24 & 0xFF) / (float)255.0F;
         ByteBuffer buffer = MemoryUtil.memAlloc(128);
         buffer.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
         buffer.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
         buffer.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
         buffer.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
         buffer.position(64);
         buffer.putFloat(x).putFloat(y).putFloat(size).putFloat(z);
         buffer.putFloat(r).putFloat(g).putFloat(b).putFloat(a);
         buffer.flip();
         CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
         encoder.writeToBuffer(obf_u0405_u2201.slice(), buffer);
         MemoryUtil.memFree(buffer);
         class_276 framebuffer = class_310.method_1551().method_1522();
         RenderPass pass = encoder.createRenderPass(
            () -> {

               return "GlowPipeline";
            },
            framebuffer.method_71639(),
            OptionalInt.empty(),
            framebuffer.method_71640(),
            OptionalDouble.of(1.0)
         );

         try {
            pass.setPipeline(obf_u0401_u2201);
            pass.setUniform(
               "Uniforms",
               obf_u0405_u2201
            );
            pass.draw(0, 6);
         } catch (Throwable var17) {
            if (pass != null) {
               try {
                  pass.close();
               } catch (Throwable var16) {
                  var17.addSuppressed(var16);
               }
            }

            throw var17;
         }

         if (pass != null) {
            pass.close();
         }
      }
   }

   public static void close() {

      if (obf_u0405_u2201 != null) {
         obf_u0405_u2201.close();
         obf_u0405_u2201 = null;
      }
   }

}
