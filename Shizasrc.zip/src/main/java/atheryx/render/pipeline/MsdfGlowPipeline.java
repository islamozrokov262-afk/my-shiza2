package atheryx.render.pipeline;

import atheryx.render.font.MsdfFont;
import atheryx.render.font.MsdfGlyph;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_12137;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

public class MsdfGlowPipeline {
   private static final int obf_u042c_u2201 = 128;
   private static final int obf_u00e7_u2201 = 128;
   private static final int obf_u00f9_u2201 = 4096;
   private static RenderPipeline obf_u00d2_u2201;
   private static GpuBuffer obf_u0418_u2201;
   private static GpuBuffer obf_u03c5_u2201;
   private static ByteBuffer obf_u00f4_u2201;
   private static ByteBuffer obf_u0452_u2201;
   private static boolean obf_u0435_u2201 = false;

   public static void init() {
      if (!obf_u0435_u2201) {
         try {
            obf_u00d2_u2201 = RenderPipeline.builder(new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655("atheryx", "msdf_glow")).withVertexShader(class_2960.method_60655("atheryx", "msdf_glow_vertex")).withFragmentShader(class_2960.method_60655("atheryx", "msdf_glow_fragment")).withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379).withUniform("MsdfData", class_10789.field_60031).withUniform("GlyphData", class_10789.field_60031).withSampler("Sampler0").withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withCull(false).build();
            obf_u0418_u2201 = RenderSystem.getDevice().createBuffer(() -> {
               return "MsdfGlowPipeline MsdfData";
            }, 136, 128L);
            obf_u03c5_u2201 = RenderSystem.getDevice().createBuffer(() -> {
               return "MsdfGlowPipeline GlyphData";
            }, 136, 4096L);
            obf_u00f4_u2201 = MemoryUtil.memAlloc(128);
            obf_u0452_u2201 = MemoryUtil.memAlloc(4096);
            obf_u0435_u2201 = true;
         } catch (Exception e) {
            System.err.println("[MsdfGlowPipeline] Failed to init: " + String.valueOf(e.getMessage()));
         }

      }
   }

   public static void drawGlowingText(Matrix4f matrix, MsdfFont font, String text, float x, float y, float size, int textColor, int glowColor, float glowIntensity, float z) {
      if (obf_u0435_u2201 && font != null && font.isLoaded() && !text.isEmpty()) {
         float scale = size / font.getEmSize();
         float cursorX = x;
         float baseline = y + font.getAscender() * scale;
         float tr = (float)(textColor >> 16 & 255) / 255.0F;
         float tg = (float)(textColor >> 8 & 255) / 255.0F;
         float tb = (float)(textColor & 255) / 255.0F;
         float ta = (float)(textColor >> 24 & 255) / 255.0F;
         float gr = (float)(glowColor >> 16 & 255) / 255.0F;
         float gg = (float)(glowColor >> 8 & 255) / 255.0F;
         float gb = (float)(glowColor & 255) / 255.0F;
         float ga = (float)(glowColor >> 24 & 255) / 255.0F;
         obf_u00f4_u2201.clear();
         obf_u00f4_u2201.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
         obf_u00f4_u2201.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
         obf_u00f4_u2201.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
         obf_u00f4_u2201.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
         obf_u00f4_u2201.putFloat(tr).putFloat(tg).putFloat(tb).putFloat(ta);
         obf_u00f4_u2201.putFloat(gr).putFloat(gg).putFloat(gb).putFloat(ga);
         obf_u00f4_u2201.putFloat(font.getDistanceRange()).putFloat(glowIntensity).putFloat(0.0F).putFloat(0.0F);
         obf_u00f4_u2201.putFloat(z).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
         obf_u00f4_u2201.flip();
         obf_u0452_u2201.clear();
         int glyphCount = 0;

         for(int i = 0; i < text.length() && glyphCount < 128; ++i) {
            int ch = text.charAt(i);
            MsdfGlyph glyph = font.getGlyph(ch);
            if (glyph == null) {
               glyph = font.getGlyph(63);
               if (glyph == null) {
                  continue;
               }
            }

            if (glyph.width > 0.0F && glyph.height > 0.0F) {
               float gx = cursorX + glyph.bearingX * scale;
               float gy = baseline - glyph.bearingY * scale;
               float gw = glyph.width * scale;
               float gh = glyph.height * scale;
               obf_u0452_u2201.putFloat(gx).putFloat(gy).putFloat(gw).putFloat(gh);
               obf_u0452_u2201.putFloat(glyph.u0).putFloat(glyph.v0);
               obf_u0452_u2201.putFloat(glyph.u1 - glyph.u0).putFloat(glyph.v1 - glyph.v0);
               ++glyphCount;
            }

            cursorX += glyph.advance * scale;
         }

         if (glyphCount != 0) {
            obf_u0452_u2201.flip();
            submitGlyphs(font, glyphCount);
         }
      }
   }

   private static void submitGlyphs(MsdfFont font, int glyphCount) {
      class_12137 sampler = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
      class_276 framebuffer = class_310.method_1551().method_1522();
      CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
      encoder.writeToBuffer(obf_u0418_u2201.slice(), obf_u00f4_u2201);
      encoder.writeToBuffer(obf_u03c5_u2201.slice(), obf_u0452_u2201);
      RenderPass pass = encoder.createRenderPass(() -> {
         return "MsdfGlowPipeline";
      }, framebuffer.method_71639(), OptionalInt.empty(), framebuffer.method_71640(), OptionalDouble.of((double)1.0F));

      try {
         pass.setPipeline(obf_u00d2_u2201);
         pass.setUniform("MsdfData", obf_u0418_u2201);
         pass.setUniform("GlyphData", obf_u03c5_u2201);
         pass.bindTexture("Sampler0", font.getTextureView(), sampler);
         pass.draw(0, glyphCount * 6);
      } catch (Throwable var9) {
         if (pass != null) {
            try {
               pass.close();
            } catch (Throwable var8) {
               var9.addSuppressed(var8);
            }
         }

         throw var9;
      }

      if (pass != null) {
         pass.close();
      }

   }

   public static void close() {
      if (obf_u0418_u2201 != null) {
         obf_u0418_u2201.close();
         obf_u0418_u2201 = null;
      }

      if (obf_u03c5_u2201 != null) {
         obf_u03c5_u2201.close();
         obf_u03c5_u2201 = null;
      }

      if (obf_u00f4_u2201 != null) {
         MemoryUtil.memFree(obf_u00f4_u2201);
         obf_u00f4_u2201 = null;
      }

      if (obf_u0452_u2201 != null) {
         MemoryUtil.memFree(obf_u0452_u2201);
         obf_u0452_u2201 = null;
      }

      obf_u0435_u2201 = false;
   }

}
