package atheryx.render.pipeline;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_10799;
import net.minecraft.class_276;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Vector3f;
import org.lwjgl.system.MemoryUtil;

public class ShaderSkyPipeline {
   private static final int obf_u044a_u2201 = 112;
   private static final RenderPipeline obf_u00d9_u2201;
   private static GpuBuffer obf_u00fa_u2201;
   private static GpuBuffer obf_u03b6_u2201;

   private ShaderSkyPipeline() {
   }

   public static void render(Color color, float alpha, float speed, int shaderMode, Vector3f right, Vector3f up, Vector3f forward) {
      class_310 client = class_310.method_1551();
      class_276 main = client.method_1522();
      if (main != null && main.method_71639() != null) {
         ensureBuffers();
         if (obf_u00fa_u2201 != null && obf_u03b6_u2201 != null) {
            ByteBuffer buffer = MemoryUtil.memAlloc(112);
            buffer.putFloat((float)main.field_1482).putFloat((float)main.field_1481).putFloat(0.0F).putFloat(0.0F);
            buffer.putFloat((float)color.getRed() / 255.0F).putFloat((float)color.getGreen() / 255.0F).putFloat((float)color.getBlue() / 255.0F).putFloat(1.0F);
            buffer.putFloat(Math.clamp(alpha, 0.0F, 1.0F)).putFloat(Math.max(0.01F, speed)).putFloat(0.0F).putFloat((float)(System.currentTimeMillis() % 100000L) / 1000.0F);
            buffer.putFloat((float)shaderMode).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
            buffer.putFloat(right.x).putFloat(right.y).putFloat(right.z).putFloat(0.0F);
            buffer.putFloat(up.x).putFloat(up.y).putFloat(up.z).putFloat(0.0F);
            buffer.putFloat(forward.x).putFloat(forward.y).putFloat(forward.z).putFloat(0.0F);
            buffer.flip();
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            encoder.writeToBuffer(obf_u00fa_u2201.slice(), buffer);
            MemoryUtil.memFree(buffer);
            RenderPass pass = encoder.createRenderPass(() -> {
               return "atheryx:shader_sky";
            }, main.method_71639(), OptionalInt.empty(), main.method_71640(), OptionalDouble.empty());

            try {
               pass.setPipeline(obf_u00d9_u2201);
               pass.setVertexBuffer(0, obf_u03b6_u2201);
               pass.setUniform("Uniforms", obf_u00fa_u2201);
               pass.draw(0, 3);
            } catch (Throwable var15) {
               if (pass != null) {
                  try {
                     pass.close();
                  } catch (Throwable var14) {
                     var15.addSuppressed(var14);
                  }
               }

               throw var15;
            }

            if (pass != null) {
               pass.close();
            }

         }
      }
   }

   private static void ensureBuffers() {
      if (obf_u00fa_u2201 == null) {
         obf_u00fa_u2201 = RenderSystem.getDevice().createBuffer(() -> {
            return "atheryx:shader_sky_uniforms";
         }, 136, 112L);
      }

      if (obf_u03b6_u2201 == null) {
         ByteBuffer dummy = MemoryUtil.memAlloc(4);
         dummy.putInt(0);
         dummy.flip();
         obf_u03b6_u2201 = RenderSystem.getDevice().createBuffer(() -> {
            return "atheryx:shader_sky_dummy_vertex";
         }, 32, dummy);
         MemoryUtil.memFree(dummy);
      }

   }

   public static void close() {
      if (obf_u00fa_u2201 != null) {
         obf_u00fa_u2201.close();
         obf_u00fa_u2201 = null;
      }

      if (obf_u03b6_u2201 != null) {
         obf_u03b6_u2201.close();
         obf_u03b6_u2201 = null;
      }

   }

   static {
      obf_u00d9_u2201 = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655("atheryx", "shader_sky")).withVertexShader(class_2960.method_60655("atheryx", "shader_sky_vertex")).withFragmentShader(class_2960.method_60655("atheryx", "shader_sky_fragment")).withVertexFormat(class_290.field_60033, class_5596.field_27379).withUniform("Uniforms", class_10789.field_60031).withUniform("Globals", class_10789.field_60031).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build());
   }

}
