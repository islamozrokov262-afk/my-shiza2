package atheryx.render.pipeline;

import atheryx.render.RenderUtil;
import java.awt.Color;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class TitleBackgroundPipeline {
   private static final class_2960 obf_u0455_u2201 = class_2960.method_60655("atheryx", "images/background.png");

   private TitleBackgroundPipeline() {
   }

   public static void render() {
      class_310 client = class_310.method_1551();
      float sw = (float)RenderUtil.getScaledWidth();
      float sh = (float)RenderUtil.getScaledHeight();
      float screenAspect = sw / sh;
      float imageAspect = 1.7777778F;
      float drawW;
      float drawH;
      float drawX;
      float drawY;
      if (screenAspect > imageAspect) {
         drawW = sw;
         drawH = sw / imageAspect;
         drawX = 0.0F;
         drawY = (sh - drawH) / 2.0F;
      } else {
         drawW = sh * imageAspect;
         drawH = sh;
         drawX = (sw - drawW) / 2.0F;
         drawY = 0.0F;
      }

      class_1044 tex = client.method_1531().method_4619(obf_u0455_u2201);
      if (tex != null) {
         TexturePipeline.drawTexture(RenderUtil.createGuiProjection(), drawX, drawY, drawW, drawH, tex.method_71659(), Color.WHITE.getRGB(), 0.0F, 0.0F);
      }

   }

   public static void close() {
   }

}
