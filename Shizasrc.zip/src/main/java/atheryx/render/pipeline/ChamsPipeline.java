package atheryx.render.pipeline;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_10799;
import net.minecraft.class_12137;
import net.minecraft.class_276;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_6367;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

public class ChamsPipeline {
   private static final int obf_u03b3_u2201 = 128;
   public static Matrix4f capturedInvViewProj;
   private static final RenderPipeline obf_u0406_u2201;
   private static class_6367 obf_u03c1_u2201;
   private static class_6367 obf_u03a0_u2201;
   private static GpuBuffer obf_u03b0_u2201;
   private static GpuBuffer obf_u045a_u2201;
   private static boolean obf_u03bb_u2201;
   private static boolean obf_u220d_u2201;
   private static boolean obf_u00e5_u2201;
   private static boolean obf_u0444_u2201;

   private ChamsPipeline() {
   }

   public static class_276 getMaskFramebuffer() {
      return getMaskFramebuffer(false);
   }

   private static class_276 getMaskFramebuffer(boolean friendMask) {
      class_310 client = class_310.method_1551();
      class_276 main = client.method_1522();
      if (main != null && main.method_71639() != null) {
         int width = main.field_1482;
         int height = main.field_1481;
         class_6367 framebuffer = friendMask ? obf_u03a0_u2201 : obf_u03c1_u2201;
         if (obf_u03c1_u2201 == null) {
            obf_u03c1_u2201 = new class_6367("atheryx_chams_mask", width, height, true);
         }

         if (obf_u03a0_u2201 == null) {
            obf_u03a0_u2201 = new class_6367("atheryx_chams_friend_mask", width, height, true);
         }

         framebuffer = friendMask ? obf_u03a0_u2201 : obf_u03c1_u2201;
         if (framebuffer.field_1482 != width || framebuffer.field_1481 != height) {
            framebuffer.method_1234(width, height);
         }

         return framebuffer;
      } else {
         return null;
      }
   }

   private static void clearMask() {
      clearMask(false);
   }

   private static void clearMask(boolean friendMask) {
      class_276 framebuffer = getMaskFramebuffer(friendMask);
      if (framebuffer != null && framebuffer.method_30277() != null) {
         CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
         encoder.clearColorTexture(framebuffer.method_30277(), 0);
         if (framebuffer.method_30278() != null) {
            encoder.clearDepthTexture(framebuffer.method_30278(), (double)1.0F);
         }

      }
   }

   public static void captureMask(Runnable renderer, boolean respectDepth) {
      clearMask();
      if (respectDepth) {
         copyDepthToMask();
      }

      renderIntoMask(renderer);
      obf_u00e5_u2201 = true;
   }

   public static void captureEntityMask(Runnable renderer, boolean respectDepth) {
      captureMask(renderer, respectDepth, false);
   }

   public static void captureFriendMask(Runnable renderer, boolean respectDepth) {
      captureMask(renderer, respectDepth, true);
   }

   private static void captureMask(Runnable renderer, boolean respectDepth, boolean friendMask) {
      if (!obf_u220d_u2201) {
         clearMask(false);
         clearMask(true);
         if (respectDepth) {
            copyDepthToMask(false);
            copyDepthToMask(true);
         }

         obf_u220d_u2201 = true;
      }

      renderIntoMask(renderer, friendMask);
      if (friendMask) {
         obf_u0444_u2201 = true;
      } else {
         obf_u00e5_u2201 = true;
      }

   }

   private static void renderIntoMask(Runnable renderer) {
      renderIntoMask(renderer, false);
   }

   private static void renderIntoMask(Runnable renderer, boolean friendMask) {
      class_276 framebuffer = getMaskFramebuffer(friendMask);
      if (framebuffer != null && framebuffer.method_71639() != null) {
         GpuTextureView previousColor = RenderSystem.outputColorTextureOverride;
         GpuTextureView previousDepth = RenderSystem.outputDepthTextureOverride;

         try {
            obf_u03bb_u2201 = true;
            RenderSystem.outputColorTextureOverride = framebuffer.method_71639();
            RenderSystem.outputDepthTextureOverride = framebuffer.method_71640();
            renderer.run();
         } finally {
            RenderSystem.outputColorTextureOverride = previousColor;
            RenderSystem.outputDepthTextureOverride = previousDepth;
            obf_u03bb_u2201 = false;
         }

      }
   }

   public static boolean isRenderingMask() {
      return obf_u03bb_u2201;
   }

   public static boolean hasCapturedMask() {
      return obf_u00e5_u2201 || obf_u0444_u2201;
   }

   public static boolean hasEntityMask() {
      return obf_u00e5_u2201;
   }

   public static boolean hasFriendMask() {
      return obf_u0444_u2201;
   }

   public static void resetCaptureState() {
      obf_u220d_u2201 = false;
      obf_u00e5_u2201 = false;
      obf_u0444_u2201 = false;
   }

   private static void copyDepthToMask() {
      copyDepthToMask(false);
   }

   private static void copyDepthToMask(boolean friendMask) {
      class_310 client = class_310.method_1551();
      class_276 main = client.method_1522();
      class_276 mask = getMaskFramebuffer(friendMask);
      if (main != null && mask != null && main.method_30278() != null && mask.method_30278() != null) {
         mask.method_29329(main);
      }

   }

   public static void compositeEntityMask(Color color, float fillAlpha, int shaderMode) {
      compositeMask(color, fillAlpha, shaderMode, 0, 0.0F, 0.0F, false, false);
   }

   public static void compositeEntityMask(Color color, float fillAlpha, int shaderMode, boolean useOffsets) {
      compositeMask(color, fillAlpha, shaderMode, 0, 0.0F, 0.0F, false, useOffsets);
   }

   public static void compositeEntityMask(Color color, float fillAlpha, int shaderMode, int outlineType, float outlineWidth, float glowStrength) {
      compositeMask(color, fillAlpha, shaderMode, outlineType, outlineWidth, glowStrength, false, false);
   }

   public static void compositeFriendMask(Color color, float fillAlpha, int shaderMode) {
      compositeMask(color, fillAlpha, shaderMode, 0, 0.0F, 0.0F, true, false);
   }

   public static void compositeFriendMask(Color color, float fillAlpha, int shaderMode, boolean useOffsets) {
      compositeMask(color, fillAlpha, shaderMode, 0, 0.0F, 0.0F, true, useOffsets);
   }

   public static void compositeFriendMask(Color color, float fillAlpha, int shaderMode, int outlineType, float outlineWidth, float glowStrength) {
      compositeMask(color, fillAlpha, shaderMode, outlineType, outlineWidth, glowStrength, true, false);
   }

   private static void compositeMask(Color color, float fillAlpha, int shaderMode, int outlineType, float outlineWidth, float glowStrength, boolean friendMask, boolean useOffsets) {
      class_310 client = class_310.method_1551();
      class_276 main = client.method_1522();
      class_276 mask = getMaskFramebuffer(friendMask);
      if (main != null && mask != null && main.method_71639() != null && mask.method_71639() != null) {
         boolean useShader = shaderMode >= 0;
         ensureBuffers();
         if (obf_u03b0_u2201 != null && obf_u045a_u2201 != null) {
            ByteBuffer buffer = MemoryUtil.memAlloc(128);
            buffer.putFloat((float)main.field_1482).putFloat((float)main.field_1481).putFloat(0.0F).putFloat(0.0F);
            buffer.putFloat((float)color.getRed() / 255.0F).putFloat((float)color.getGreen() / 255.0F).putFloat((float)color.getBlue() / 255.0F).putFloat(1.0F);
            buffer.putFloat(Math.clamp(fillAlpha, 0.0F, 1.0F)).putFloat(useOffsets ? 1.0F : 0.0F).putFloat(useShader ? 1.0F : 0.0F).putFloat((float)(System.currentTimeMillis() % 100000L) / 1000.0F);
            buffer.putFloat((float)shaderMode).putFloat((float)outlineType).putFloat(Math.clamp(outlineWidth, 0.0F, 16.0F));
            buffer.putFloat(Math.clamp(glowStrength, 0.0F, 4.0F));
            if (capturedInvViewProj != null) {
               float[] mat = new float[16];
               capturedInvViewProj.get(mat);

               for(float f : mat) {
                  buffer.putFloat(f);
               }
            } else {
               for(int i = 0; i < 16; ++i) {
                  buffer.putFloat(0.0F);
               }
            }

            buffer.flip();
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            encoder.writeToBuffer(obf_u03b0_u2201.slice(), buffer);
            MemoryUtil.memFree(buffer);
            class_12137 var22 = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
            RenderPass var23 = encoder.createRenderPass(() -> {
               return "atheryx:chams_post";
            }, main.method_71639(), OptionalInt.empty(), main.method_71640(), OptionalDouble.empty());

            try {
               var23.setPipeline(obf_u0406_u2201);
               var23.setVertexBuffer(0, obf_u045a_u2201);
               var23.setUniform("Uniforms", obf_u03b0_u2201);
               var23.bindTexture("Sampler0", mask.method_71639(), var22);
               var23.bindTexture("Sampler1", main.method_71640(), var22);
               var23.draw(0, 3);
            } catch (Throwable var19) {
               if (var23 != null) {
                  try {
                     var23.close();
                  } catch (Throwable var18) {
                     var19.addSuppressed(var18);
                  }
               }

               throw var19;
            }

            if (var23 != null) {
               var23.close();
            }

         }
      }
   }

   private static void ensureBuffers() {
      if (obf_u03b0_u2201 == null) {
         obf_u03b0_u2201 = RenderSystem.getDevice().createBuffer(() -> {
            return "atheryx:chams_uniforms";
         }, 136, 128L);
      }

      if (obf_u045a_u2201 == null) {
         ByteBuffer dummy = MemoryUtil.memAlloc(4);
         dummy.putInt(0);
         dummy.flip();
         obf_u045a_u2201 = RenderSystem.getDevice().createBuffer(() -> {
            return "atheryx:chams_dummy_vertex";
         }, 32, dummy);
         MemoryUtil.memFree(dummy);
      }

   }

   public static void close() {
      if (obf_u03c1_u2201 != null) {
         obf_u03c1_u2201.method_1238();
         obf_u03c1_u2201 = null;
      }

      if (obf_u03a0_u2201 != null) {
         obf_u03a0_u2201.method_1238();
         obf_u03a0_u2201 = null;
      }

      if (obf_u03b0_u2201 != null) {
         obf_u03b0_u2201.close();
         obf_u03b0_u2201 = null;
      }

      if (obf_u045a_u2201 != null) {
         obf_u045a_u2201.close();
         obf_u045a_u2201 = null;
      }

   }

   static {
      obf_u0406_u2201 = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655("atheryx", "chams_post")).withVertexShader(class_2960.method_60655("atheryx", "chams_post_vertex")).withFragmentShader(class_2960.method_60655("atheryx", "chams_post_fragment")).withVertexFormat(class_290.field_60033, class_5596.field_27379).withUniform("Uniforms", class_10789.field_60031).withUniform("Globals", class_10789.field_60031).withSampler("Sampler0").withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build());
   }

}
