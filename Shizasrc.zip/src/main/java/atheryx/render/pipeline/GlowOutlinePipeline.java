package atheryx.render.pipeline;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

public class GlowOutlinePipeline {
   private static RenderPipeline obf_u0443_u2201;
   private static GpuBuffer obf_u221a_u2201;
   private static ByteBuffer obf_u043a_u2201;
   private static final int obf_u2214_u2201 = 128;

   public static void init() {
      if (obf_u0443_u2201 == null) {
         try {
            obf_u0443_u2201 = RenderPipeline.builder(new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655("atheryx", "glow_outline")).withVertexShader(class_2960.method_60655("atheryx", "glow_outline_vertex")).withFragmentShader(class_2960.method_60655("atheryx", "glow_outline_fragment")).withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379).withUniform("Uniforms", class_10789.field_60031).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withCull(false).build();
            obf_u221a_u2201 = RenderSystem.getDevice().createBuffer(() -> {
               return "GlowOutlinePipeline Uniforms";
            }, 136, 128L);
            obf_u043a_u2201 = MemoryUtil.memAlloc(128);
         } catch (Exception var1) {
         }

      }
   }

   public static void render(Matrix4f matrix, float x, float y, float width, float height, float thickness, int color, float radius, float glowSize, float glowIntensity, float glowSoftness, float baseAlpha, float z) {
      if (obf_u0443_u2201 == null) {
         init();
      }

      if (obf_u0443_u2201 != null && obf_u221a_u2201 != null && obf_u043a_u2201 != null) {
         float r = (float)(color >> 16 & 255) / 255.0F;
         float g = (float)(color >> 8 & 255) / 255.0F;
         float b = (float)(color & 255) / 255.0F;
         float a = (float)(color >> 24 & 255) / 255.0F;
         ByteBuffer buffer = obf_u043a_u2201;
         buffer.clear();
         buffer.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
         buffer.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
         buffer.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
         buffer.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
         buffer.position(64);
         buffer.putFloat(x).putFloat(y).putFloat(width).putFloat(height);
         buffer.putFloat(radius).putFloat(thickness).putFloat(glowIntensity).putFloat(baseAlpha);
         buffer.putFloat(r).putFloat(g).putFloat(b).putFloat(a);
         buffer.putFloat(z).putFloat(glowSize).putFloat(glowSoftness).putFloat(0.0F);
         buffer.flip();
         CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
         encoder.writeToBuffer(obf_u221a_u2201.slice(), buffer);
         class_276 var19 = class_310.method_1551().method_1522();
         RenderPass pass = encoder.createRenderPass(() -> {
            return "GlowOutlinePipeline";
         }, var19.method_71639(), OptionalInt.empty(), var19.method_71640(), OptionalDouble.of((double)1.0F));

         try {
            pass.setPipeline(obf_u0443_u2201);
            pass.setUniform("Uniforms", obf_u221a_u2201);
            pass.draw(0, 6);
         } catch (Throwable var24) {
            if (pass != null) {
               try {
                  pass.close();
               } catch (Throwable var23) {
                  var24.addSuppressed(var23);
               }
            }

            throw var24;
         }

         if (pass != null) {
            pass.close();
         }

      }
   }

   public static void close() {
      if (obf_u221a_u2201 != null) {
         obf_u221a_u2201.close();
         obf_u221a_u2201 = null;
      }

      if (obf_u043a_u2201 != null) {
         MemoryUtil.memFree(obf_u043a_u2201);
         obf_u043a_u2201 = null;
      }

   }

}
