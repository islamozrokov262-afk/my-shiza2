package atheryx.render.pipeline;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_12137;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;
import atheryx.internal.RuntimeCipher;


public class LiquidGlassPipeline {
   private static final int obf_u0411_u2201 = (int)(float)256.0F;
   private static RenderPipeline obf_u039b_u2201;
   private static GpuBuffer obf_u2225_u2201;
   private static GpuTexture obf_u03ad_u2201;
   private static GpuTextureView obf_u039d_u2201;
   private static int obf_u00ea_u2201;
   private static int obf_u00f5_u2201;

   public static void init() {

      if (obf_u039b_u2201 == null) {
         obf_u039b_u2201 = RenderPipeline.builder(new Snippet[0])
            .withLocation(
               class_2960.method_60655(
                  "atheryx",
                  "liquid_glass"
               )
            )
            .withVertexShader(
               class_2960.method_60655(
                  "atheryx",
                  "liquid_glass_vertex"
               )
            )
            .withFragmentShader(
               class_2960.method_60655(
                  "atheryx",
                  "liquid_glass_fragment"
               )
            )
            .withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379)
            .withUniform(
               "Uniforms",
               class_10789.field_60031
            )
            .withSampler(
               "Sampler0"
            )
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withCull(false)
            .build();
         obf_u2225_u2201 = RenderSystem.getDevice()
            .createBuffer(
               () -> {

                  return "LiquidGlassPipeline Uniforms";
               },
               136,
               (long)256L
            );
      }
   }

   public static void render(
      Matrix4f matrix, float x, float y, float width, float height, float radius, float strength, float alpha, int tint, float z
   ) {

      class_310 client = class_310.method_1551();
      class_276 framebuffer = client.method_1522();
      if (framebuffer != null && framebuffer.method_30277() != null) {
         if (obf_u039b_u2201 == null) {
            init();
         }

         if (obf_u039b_u2201 != null && obf_u2225_u2201 != null) {
            int fbWidth = framebuffer.field_1482;
            int fbHeight = framebuffer.field_1481;
            int screenWidth = atheryx.render.RenderUtil.getScaledWidth();
            int screenHeight = atheryx.render.RenderUtil.getScaledHeight();
            ensureCaptureTexture(fbWidth, fbHeight);
            if (obf_u03ad_u2201 != null && obf_u039d_u2201 != null) {
               float red = (tint >> 16 & 0xFF) / (float)255.0F;
               float green = (tint >> 8 & 0xFF) / (float)255.0F;
               float blue = (tint & 0xFF) / (float)255.0F;
               float tintAlpha = (tint >> 24 & 0xFF) / (float)255.0F;
               float time = (float)(System.currentTimeMillis() % (long)120000L)
                  / (float)1000.0F;
               ByteBuffer buffer = MemoryUtil.memAlloc(256);
               buffer.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
               buffer.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
               buffer.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
               buffer.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
               buffer.position(64);
               buffer.putFloat(x).putFloat(y).putFloat(width).putFloat(height);
               buffer.putFloat(screenWidth).putFloat(screenHeight).putFloat(0.0F).putFloat(0.0F);
               buffer.putFloat(radius).putFloat(radius).putFloat(radius).putFloat(radius);
               buffer.putFloat(time).putFloat(Math.clamp(strength, 0.0F, 1.0F)).putFloat(Math.clamp(alpha, 0.0F, 1.0F)).putFloat(tintAlpha);
               buffer.putFloat(red).putFloat(green).putFloat(blue).putFloat(0.0F);
               buffer.putFloat(z).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
               buffer.flip();
               CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
               encoder.copyTextureToTexture(framebuffer.method_30277(), obf_u03ad_u2201, 0, 0, 0, 0, 0, fbWidth, fbHeight);
               encoder.writeToBuffer(obf_u2225_u2201.slice(), buffer);
               MemoryUtil.memFree(buffer);
               class_12137 sampler = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
               RenderPass pass = encoder.createRenderPass(
                  () -> {

                     return "LiquidGlassPipeline";
                  },
                  framebuffer.method_71639(),
                  OptionalInt.empty(),
                  framebuffer.method_71640(),
                  OptionalDouble.of(1.0)
               );

               try {
                  pass.setPipeline(obf_u039b_u2201);
                  pass.setUniform(
                     "Uniforms",
                     obf_u2225_u2201
                  );
                  pass.bindTexture(
                     "Sampler0",
                     obf_u039d_u2201,
                     sampler
                  );
                  pass.draw(0, 6);
               } catch (Throwable var28) {
                  if (pass != null) {
                     try {
                        pass.close();
                     } catch (Throwable var27) {
                        var28.addSuppressed(var27);
                     }
                  }

                  throw var28;
               }

               if (pass != null) {
                  pass.close();
               }
            }
         }
      }
   }

   private static void ensureCaptureTexture(int width, int height) {

      if (obf_u03ad_u2201 == null || width != obf_u00ea_u2201 || height != obf_u00f5_u2201) {
         if (obf_u039d_u2201 != null) {
            obf_u039d_u2201.close();
            obf_u039d_u2201 = null;
         }

         if (obf_u03ad_u2201 != null) {
            obf_u03ad_u2201.close();
            obf_u03ad_u2201 = null;
         }

         obf_u03ad_u2201 = RenderSystem.getDevice()
            .createTexture(
               () -> {

                  return "atheryx:liquid_glass_copy";
               },
               5,
               TextureFormat.RGBA8,
               width,
               height,
               1,
               1
            );
         obf_u039d_u2201 = RenderSystem.getDevice().createTextureView(obf_u03ad_u2201);
         obf_u00ea_u2201 = width;
         obf_u00f5_u2201 = height;
      }
   }

   public static void close() {

      if (obf_u2225_u2201 != null) {
         obf_u2225_u2201.close();
         obf_u2225_u2201 = null;
      }

      if (obf_u039d_u2201 != null) {
         obf_u039d_u2201.close();
         obf_u039d_u2201 = null;
      }

      if (obf_u03ad_u2201 != null) {
         obf_u03ad_u2201.close();
         obf_u03ad_u2201 = null;
      }

      obf_u00ea_u2201 = 0;
      obf_u00f5_u2201 = 0;
   }

}
