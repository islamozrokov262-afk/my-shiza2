package atheryx.render.pipeline;

import atheryx.render.font.MsdfFont;
import atheryx.render.font.MsdfGlyph;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_12137;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

public class MsdfPipeline {
   private static final int obf_u0391_u2201 = 128;
   private static final int obf_u0395_u2201 = 128;
   private static final int obf_u2210_u2201 = 4096;
   private static RenderPipeline obf_u220b_u2201;
   private static GpuBuffer obf_u00df_u2201;
   private static GpuBuffer obf_u045b_u2201;
   private static ByteBuffer obf_u03c2_u2201;
   private static ByteBuffer obf_u00c6_u2201;
   private static boolean obf_u0439_u2201 = false;

   public static void init() {
      if (!obf_u0439_u2201) {
         try {
            System.out.println("[MSDF] Initializing Msdf2D shaders and buffers...");
            obf_u220b_u2201 = RenderPipeline.builder(new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655("atheryx", "msdf")).withVertexShader(class_2960.method_60655("atheryx", "msdf_vertex")).withFragmentShader(class_2960.method_60655("atheryx", "msdf_fragment")).withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379).withUniform("MsdfData", class_10789.field_60031).withUniform("GlyphData", class_10789.field_60031).withSampler("Sampler0").withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withCull(false).build();
            obf_u00df_u2201 = RenderSystem.getDevice().createBuffer(() -> {
               return "MsdfPipeline MsdfData";
            }, 136, 128L);
            obf_u045b_u2201 = RenderSystem.getDevice().createBuffer(() -> {
               return "MsdfPipeline GlyphData";
            }, 136, 4096L);
            obf_u03c2_u2201 = MemoryUtil.memAlloc(128);
            obf_u00c6_u2201 = MemoryUtil.memAlloc(4096);
            obf_u0439_u2201 = true;
         } catch (Exception e) {
            System.err.println("[MSDF] Failed to initialize Msdf2D: " + String.valueOf(e.getMessage()));
            e.printStackTrace();
         }

      }
   }

   public static void drawText(Matrix4f matrix, MsdfFont font, String text, float x, float y, float size, int color, float rotation, float z) {
      if (obf_u0439_u2201 && font != null && font.isLoaded() && !text.isEmpty()) {
         float scale = size / font.getEmSize();
         float cursorX = x;
         float baseline = y + font.getAscender() * scale;
         float r = (float)(color >> 16 & 255) / 255.0F;
         float g = (float)(color >> 8 & 255) / 255.0F;
         float b = (float)(color & 255) / 255.0F;
         float a = (float)(color >> 24 & 255) / 255.0F;
         obf_u03c2_u2201.clear();
         obf_u03c2_u2201.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
         obf_u03c2_u2201.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
         obf_u03c2_u2201.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
         obf_u03c2_u2201.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
         obf_u03c2_u2201.putFloat(r).putFloat(g).putFloat(b).putFloat(a);
         obf_u03c2_u2201.putFloat(font.getDistanceRange()).putFloat((float)Math.toRadians((double)rotation)).putFloat(0.0F).putFloat(0.0F);
         obf_u03c2_u2201.putFloat(z).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
         obf_u03c2_u2201.flip();
         obf_u00c6_u2201.clear();
         int glyphCount = 0;

         for(int i = 0; i < text.length() && glyphCount < 128; ++i) {
            int ch = text.charAt(i);
            MsdfGlyph glyph = font.getGlyph(ch);
            if (glyph == null) {
               glyph = font.getGlyph(63);
               if (glyph == null) {
                  continue;
               }
            }

            if (glyph.width > 0.0F && glyph.height > 0.0F) {
               float gx = cursorX + glyph.bearingX * scale;
               float gy = baseline - glyph.bearingY * scale;
               float gw = glyph.width * scale;
               float gh = glyph.height * scale;
               obf_u00c6_u2201.putFloat(gx).putFloat(gy).putFloat(gw).putFloat(gh);
               obf_u00c6_u2201.putFloat(glyph.u0).putFloat(glyph.v0);
               obf_u00c6_u2201.putFloat(glyph.u1 - glyph.u0).putFloat(glyph.v1 - glyph.v0);
               ++glyphCount;
            }

            cursorX += glyph.advance * scale;
         }

         if (glyphCount != 0) {
            obf_u00c6_u2201.flip();
            submitGlyphs(font, glyphCount);
         }
      }
   }

   public static void drawMulticolorText(Matrix4f matrix, MsdfFont font, String text, float x, float y, float size, int[] colors, float z) {
      if (obf_u0439_u2201 && font != null && font.isLoaded() && !text.isEmpty()) {
         float scale = size / font.getEmSize();
         float cursorX = x;
         float baseline = y + font.getAscender() * scale;

         for(int i = 0; i < text.length(); ++i) {
            int ch = text.charAt(i);
            MsdfGlyph glyph = font.getGlyph(ch);
            if (glyph == null) {
               glyph = font.getGlyph(63);
               if (glyph == null) {
                  continue;
               }
            }

            if (glyph.width > 0.0F && glyph.height > 0.0F) {
               int color = colors[i % colors.length];
               drawGlyph(matrix, font, glyph, cursorX, baseline, scale, color, 0.0F, z);
            }

            cursorX += glyph.advance * scale;
         }

      }
   }

   public static float drawGlyph(Matrix4f matrix, MsdfFont font, MsdfGlyph glyph, float cursorX, float baseline, float scale, int color, float rotation, float z) {
      if (obf_u0439_u2201 && font != null && glyph != null) {
         float r = (float)(color >> 16 & 255) / 255.0F;
         float g = (float)(color >> 8 & 255) / 255.0F;
         float b = (float)(color & 255) / 255.0F;
         float a = (float)(color >> 24 & 255) / 255.0F;
         obf_u03c2_u2201.clear();
         obf_u03c2_u2201.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
         obf_u03c2_u2201.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
         obf_u03c2_u2201.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
         obf_u03c2_u2201.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
         obf_u03c2_u2201.putFloat(r).putFloat(g).putFloat(b).putFloat(a);
         obf_u03c2_u2201.putFloat(font.getDistanceRange()).putFloat((float)Math.toRadians((double)rotation)).putFloat(0.0F).putFloat(0.0F);
         obf_u03c2_u2201.putFloat(z).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
         obf_u03c2_u2201.flip();
         float gx = cursorX + glyph.bearingX * scale;
         float gy = baseline - glyph.bearingY * scale;
         float gw = glyph.width * scale;
         float gh = glyph.height * scale;
         obf_u00c6_u2201.clear();
         obf_u00c6_u2201.putFloat(gx).putFloat(gy).putFloat(gw).putFloat(gh);
         obf_u00c6_u2201.putFloat(glyph.u0).putFloat(glyph.v0);
         obf_u00c6_u2201.putFloat(glyph.u1 - glyph.u0).putFloat(glyph.v1 - glyph.v0);
         obf_u00c6_u2201.flip();
         submitGlyphs(font, 1);
         return glyph.advance * scale;
      } else {
         return 0.0F;
      }
   }

   private static void submitGlyphs(MsdfFont font, int glyphCount) {
      class_12137 sampler = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
      class_276 framebuffer = class_310.method_1551().method_1522();
      CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
      encoder.writeToBuffer(obf_u00df_u2201.slice(), obf_u03c2_u2201);
      encoder.writeToBuffer(obf_u045b_u2201.slice(), obf_u00c6_u2201);
      RenderPass pass = encoder.createRenderPass(() -> {
         return "MsdfPipeline";
      }, framebuffer.method_71639(), OptionalInt.empty(), framebuffer.method_71640(), OptionalDouble.of((double)1.0F));

      try {
         pass.setPipeline(obf_u220b_u2201);
         pass.setUniform("MsdfData", obf_u00df_u2201);
         pass.setUniform("GlyphData", obf_u045b_u2201);
         pass.bindTexture("Sampler0", font.getTextureView(), sampler);
         pass.draw(0, glyphCount * 6);
      } catch (Throwable var9) {
         if (pass != null) {
            try {
               pass.close();
            } catch (Throwable var8) {
               var9.addSuppressed(var8);
            }
         }

         throw var9;
      }

      if (pass != null) {
         pass.close();
      }

   }

   public static void close() {
      if (obf_u00df_u2201 != null) {
         obf_u00df_u2201.close();
         obf_u00df_u2201 = null;
      }

      if (obf_u045b_u2201 != null) {
         obf_u045b_u2201.close();
         obf_u045b_u2201 = null;
      }

      if (obf_u03c2_u2201 != null) {
         MemoryUtil.memFree(obf_u03c2_u2201);
         obf_u03c2_u2201 = null;
      }

      if (obf_u00c6_u2201 != null) {
         MemoryUtil.memFree(obf_u00c6_u2201);
         obf_u00c6_u2201 = null;
      }

      obf_u0439_u2201 = false;
   }

}
