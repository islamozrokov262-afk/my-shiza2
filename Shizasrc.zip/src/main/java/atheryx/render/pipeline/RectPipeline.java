package atheryx.render.pipeline;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;
import atheryx.internal.RuntimeCipher;


public class RectPipeline {
   private static RenderPipeline obf_u044c_u2201;
   private static GpuBuffer obf_u2213_u2201;
   private static final int obf_u041c_u2201 = (int)(float)256.0F;

   public static void init() {

      if (obf_u044c_u2201 == null) {
         try {
            obf_u044c_u2201 = RenderPipeline.builder(new Snippet[0])
               .withLocation(
                  class_2960.method_60655(
                     "atheryx",
                     "rectangle"
                  )
               )
               .withVertexShader(
                  class_2960.method_60655(
                     "atheryx",
                     "rectangle_vertex"
                  )
               )
               .withFragmentShader(
                  class_2960.method_60655(
                     "atheryx",
                     "rectangle_fragment"
                  )
               )
               .withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379)
               .withUniform(
                  "Uniforms",
                  class_10789.field_60031
               )
               .withBlend(BlendFunction.TRANSLUCENT)
               .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
               .withCull(false)
               .build();
            obf_u2213_u2201 = RenderSystem.getDevice()
               .createBuffer(
                  () -> {

                     return "RectanglePipeline Uniforms";
                  },
                  136,
                  (long)256L
               );
         } catch (Exception var1) {
         }
      }
   }

   public static void drawRoundedRect(
      Matrix4f matrix, float x, float y, float width, float height, float tl, float tr, float br, float bl, float z, int... colors
   ) {

      if (obf_u044c_u2201 == null) {
         init();
      }

      if (obf_u044c_u2201 != null && obf_u2213_u2201 != null) {
         int[] finalColors = normalizeCornerColors(colors);
         ByteBuffer buffer = MemoryUtil.memAlloc(256);
         buffer.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
         buffer.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
         buffer.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
         buffer.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
         buffer.position(64);
         buffer.putFloat(x).putFloat(y).putFloat(width).putFloat(height);
         buffer.putFloat(tr).putFloat(br).putFloat(tl).putFloat(bl);
         buffer.putFloat(z);
         buffer.putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);

         for (int encoder = 0; encoder < 9; encoder++) {
            int color = finalColors[encoder];
            buffer.putFloat((color >> 16 & 0xFF) / (float)255.0F);
            buffer.putFloat((color >> 8 & 0xFF) / (float)255.0F);
            buffer.putFloat((color & 0xFF) / (float)255.0F);
            buffer.putFloat((color >> 24 & 0xFF) / (float)255.0F);
         }

         buffer.flip();
         CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
         encoder.writeToBuffer(obf_u2213_u2201.slice(), buffer);
         MemoryUtil.memFree(buffer);
         class_276 framebuffer = class_310.method_1551().method_1522();
         RenderPass pass = encoder.createRenderPass(
            () -> {

               return "RectanglePipeline";
            },
            framebuffer.method_71639(),
            OptionalInt.empty(),
            framebuffer.method_71640(),
            OptionalDouble.of(1.0)
         );

         try {
            pass.setPipeline(obf_u044c_u2201);
            pass.setUniform(
               "Uniforms",
               obf_u2213_u2201
            );
            pass.draw(0, 6);
         } catch (Throwable var19) {
            if (pass != null) {
               try {
                  pass.close();
               } catch (Throwable var18) {
                  var19.addSuppressed(var18);
               }
            }

            throw var19;
         }

         if (pass != null) {
            pass.close();
         }
      }
   }

   private static int[] normalizeCornerColors(int[] colors) {

      if (colors != null && colors.length != 0) {
         if (colors.length == 1) {
            int c = colors[0];
            return new int[]{c, c, c, c, c, c, c, c, c};
         }

         if (colors.length >= 9) {
            return colors;
         }

         int[] result = new int[9];

         for (int i = 0; i < 9; i++) {
            result[i] = colors[Math.min(i, colors.length - 1)];
         }

         return result;
      } else {
         int c = -1;
         return new int[]{c, c, c, c, c, c, c, c, c};
      }
   }

   public static void close() {

      if (obf_u2213_u2201 != null) {
         obf_u2213_u2201.close();
         obf_u2213_u2201 = null;
      }
   }

}
