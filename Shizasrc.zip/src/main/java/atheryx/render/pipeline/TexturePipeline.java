package atheryx.render.pipeline;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_12137;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;
import atheryx.internal.RuntimeCipher;


public class TexturePipeline {
   private static RenderPipeline obf_u045c_u2201;
   private static GpuBuffer obf_u00cc_u2201;
   private static final int obf_u0449_u2201 = (int)(float)256.0F;

   public static void init() {

      if (obf_u045c_u2201 == null) {
         obf_u045c_u2201 = RenderPipeline.builder(new Snippet[0])
            .withLocation(
               class_2960.method_60655(
                  "atheryx",
                  "texture"
               )
            )
            .withVertexShader(
               class_2960.method_60655(
                  "atheryx",
                  "texture_vertex"
               )
            )
            .withFragmentShader(
               class_2960.method_60655(
                  "atheryx",
                  "texture_fragment"
               )
            )
            .withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379)
            .withUniform(
               "Uniforms",
               class_10789.field_60031
            )
            .withSampler(
               "Sampler0"
            )
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withCull(false)
            .build();
         obf_u00cc_u2201 = RenderSystem.getDevice()
            .createBuffer(
               () -> {

                  return "TexturePipeline Uniforms";
               },
               136,
               (long)256L
            );
      }
   }

   public static void drawTexture(
      Matrix4f matrix, float x, float y, float width, float height, GpuTextureView textureView, int color, float radius, float z
   ) {

      drawTextureRegion(matrix, x, y, width, height, textureView, color, radius, z, 0.0F, 0.0F, 1.0F, 1.0F);
   }

   public static void drawSquareTexture(Matrix4f matrix, float x, float y, float size, GpuTextureView textureView, int color, float radius, float z) {

      drawTextureRegion(matrix, x, y, size, size, textureView, color, radius, z, 0.0F, 0.0F, 1.0F, 1.0F);
   }

   public static void drawSquareTextureRegion(
      Matrix4f matrix,
      float x,
      float y,
      float size,
      GpuTextureView textureView,
      int color,
      float radius,
      float z,
      float u,
      float v,
      float uvWidth,
      float uvHeight
   ) {

      drawTextureRegionFiltered(matrix, x, y, size, size, textureView, color, radius, z, u, v, uvWidth, uvHeight, true);
   }

   public static void drawSquareTextureRegionFiltered(
      Matrix4f matrix,
      float x,
      float y,
      float size,
      GpuTextureView textureView,
      int color,
      float radius,
      float z,
      float u,
      float v,
      float uvWidth,
      float uvHeight,
      boolean linearFilter
   ) {

      drawTextureRegionFiltered(matrix, x, y, size, size, textureView, color, radius, z, u, v, uvWidth, uvHeight, linearFilter);
   }

   public static void drawTextureRegion(
      Matrix4f matrix,
      float x,
      float y,
      float width,
      float height,
      GpuTextureView textureView,
      int color,
      float radius,
      float z,
      float u,
      float v,
      float uvWidth,
      float uvHeight
   ) {

      drawTextureRegionFiltered(matrix, x, y, width, height, textureView, color, radius, z, u, v, uvWidth, uvHeight, true);
   }

   public static void drawTextureRegionFiltered(
      Matrix4f matrix,
      float x,
      float y,
      float width,
      float height,
      GpuTextureView textureView,
      int color,
      float radius,
      float z,
      float u,
      float v,
      float uvWidth,
      float uvHeight,
      boolean linearFilter
   ) {

      if (obf_u045c_u2201 == null) {
         init();
      }

      if (obf_u045c_u2201 != null && obf_u00cc_u2201 != null && textureView != null) {
         float r = (color >> 16 & 0xFF) / (float)255.0F;
         float g = (color >> 8 & 0xFF) / (float)255.0F;
         float b = (color & 0xFF) / (float)255.0F;
         float a = (color >> 24 & 0xFF) / (float)255.0F;
         ByteBuffer buffer = MemoryUtil.memAlloc(256);
         buffer.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
         buffer.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
         buffer.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
         buffer.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
         buffer.position(64);
         buffer.putFloat(x).putFloat(y).putFloat(width).putFloat(height);
         buffer.putFloat(r).putFloat(g).putFloat(b).putFloat(a);
         buffer.putFloat(radius).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
         buffer.putFloat(z).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
         buffer.putFloat(u).putFloat(v).putFloat(uvWidth).putFloat(uvHeight);
         buffer.flip();
         CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
         encoder.writeToBuffer(obf_u00cc_u2201.slice(), buffer);
         MemoryUtil.memFree(buffer);
         class_12137 sampler = RenderSystem.getSamplerCache().method_75294(linearFilter ? FilterMode.LINEAR : FilterMode.NEAREST);
         class_276 framebuffer = class_310.method_1551().method_1522();
         RenderPass pass = encoder.createRenderPass(
            () -> {

               return "TexturePipeline";
            },
            framebuffer.method_71639(),
            OptionalInt.empty(),
            framebuffer.method_71640(),
            OptionalDouble.of(1.0)
         );

         try {
            pass.setPipeline(obf_u045c_u2201);
            pass.setUniform(
               "Uniforms",
               obf_u00cc_u2201
            );
            pass.bindTexture(
               "Sampler0",
               textureView,
               sampler
            );
            pass.draw(0, 6);
         } catch (Throwable var26) {
            if (pass != null) {
               try {
                  pass.close();
               } catch (Throwable var25) {
                  var26.addSuppressed(var25);
               }
            }

            throw var26;
         }

         if (pass != null) {
            pass.close();
         }
      }
   }

   public static void close() {

      if (obf_u00cc_u2201 != null) {
         obf_u00cc_u2201.close();
         obf_u00cc_u2201 = null;
      }
   }

}
