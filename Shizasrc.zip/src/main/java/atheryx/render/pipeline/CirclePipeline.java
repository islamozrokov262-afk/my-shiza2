package atheryx.render.pipeline;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

public class CirclePipeline {
   private static RenderPipeline obf_u03ab_u2201;
   private static GpuBuffer obf_u00d0_u2201;
   private static final int obf_u00e2_u2201 = 128;

   public static void init() {
      if (obf_u03ab_u2201 == null) {
         try {
            obf_u03ab_u2201 = RenderPipeline.builder(new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655("atheryx", "circle")).withVertexShader(class_2960.method_60655("atheryx", "circle_vertex")).withFragmentShader(class_2960.method_60655("atheryx", "circle_fragment")).withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379).withUniform("Uniforms", class_10789.field_60031).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withCull(false).build();
            obf_u00d0_u2201 = RenderSystem.getDevice().createBuffer(() -> {
               return "CirclePipeline Uniforms";
            }, 136, 128L);
         } catch (Exception var1) {
         }

      }
   }

   public static void drawCircle(Matrix4f matrix, float cx, float cy, float radius, float thickness, float z, Color color) {
      drawArc(matrix, cx, cy, radius, thickness, 0.0F, 1.0F, z, color);
   }

   public static void drawArc(Matrix4f matrix, float cx, float cy, float radius, float thickness, float startAngle, float progress, float z, Color color) {
      if (obf_u03ab_u2201 == null) {
         init();
      }

      if (obf_u03ab_u2201 != null && obf_u00d0_u2201 != null) {
         float r = (float)color.getRed() / 255.0F;
         float g = (float)color.getGreen() / 255.0F;
         float b = (float)color.getBlue() / 255.0F;
         float a = (float)color.getAlpha() / 255.0F;
         ByteBuffer buffer = MemoryUtil.memAlloc(128);
         buffer.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
         buffer.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
         buffer.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
         buffer.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
         buffer.position(64);
         buffer.putFloat(cx).putFloat(cy).putFloat(radius).putFloat(z);
         buffer.putFloat(thickness);
         buffer.putFloat(startAngle);
         buffer.putFloat(Math.max(0.0F, Math.min(1.0F, progress)));
         buffer.putFloat(0.0F);
         buffer.position(96);
         buffer.putFloat(r).putFloat(g).putFloat(b).putFloat(a);
         buffer.flip();
         CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
         encoder.writeToBuffer(obf_u00d0_u2201.slice(), buffer);
         MemoryUtil.memFree(buffer);
         class_276 var15 = class_310.method_1551().method_1522();
         RenderPass pass = encoder.createRenderPass(() -> {
            return "CirclePipeline";
         }, var15.method_71639(), OptionalInt.empty(), var15.method_71640(), OptionalDouble.of((double)1.0F));

         try {
            pass.setPipeline(obf_u03ab_u2201);
            pass.setUniform("Uniforms", obf_u00d0_u2201);
            pass.draw(0, 6);
         } catch (Throwable var20) {
            if (pass != null) {
               try {
                  pass.close();
               } catch (Throwable var19) {
                  var20.addSuppressed(var19);
               }
            }

            throw var20;
         }

         if (pass != null) {
            pass.close();
         }

      }
   }

   public static void close() {
      if (obf_u00d0_u2201 != null) {
         obf_u00d0_u2201.close();
         obf_u00d0_u2201 = null;
      }

   }

}
