package atheryx.render.pipeline;

import atheryx.render.RenderUtil;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_10799;
import net.minecraft.class_12137;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

public class BlurPipeline {
   private static final int obf_u00db_u2201 = 5;
   private static final int obf_u03c7_u2201 = 2;
   private static final int obf_u044f_u2201 = 256;
   private static final RenderPipeline obf_u222e_u2201;
   private static final RenderPipeline obf_u0398_u2201;
   private static final Vector4f obf_u2226_u2201;
   private static final Vector3f obf_u2221_u2201;
   private static final Matrix4f obf_u040e_u2201;
   private static GpuBuffer obf_u043d_u2201;
   private static GpuBuffer obf_u03b5_u2201;
   private static ByteBuffer obf_u03aa_u2201;
   private static GpuTexture obf_u00dc_u2201;
   private static GpuTextureView obf_u222d_u2201;
   private static GpuTexture[] obf_u03a5_u2201;
   private static GpuTextureView[] obf_u00c3_u2201;
   private static int obf_u0412_u2201;
   private static int obf_u0453_u2201;
   private static boolean obf_u03a4_u2201;
   private static long obf_u00ee_u2201;
   private static int obf_u221f_u2201;
   private static float obf_u040d_u2201;

   public static void init() {
      if (!obf_u03a4_u2201) {
         obf_u03aa_u2201 = MemoryUtil.memAlloc(256);
         ByteBuffer dummyData = MemoryUtil.memAlloc(4);
         dummyData.putInt(0);
         dummyData.flip();
         obf_u03b5_u2201 = RenderSystem.getDevice().createBuffer(() -> {
            return "atheryx:blur_dummy_vertex";
         }, 32, dummyData);
         MemoryUtil.memFree(dummyData);
         obf_u03a4_u2201 = true;
      }
   }

   private static void ensureFramebuffers(int fbWidth, int fbHeight) {
      int blurWidth = fbWidth / 2;
      int blurHeight = fbHeight / 2;
      if (obf_u00dc_u2201 == null || fbWidth != obf_u0412_u2201 || fbHeight != obf_u0453_u2201) {
         if (obf_u222d_u2201 != null) {
            obf_u222d_u2201.close();
            obf_u222d_u2201 = null;
         }

         if (obf_u00dc_u2201 != null) {
            obf_u00dc_u2201.close();
            obf_u00dc_u2201 = null;
         }

         obf_u00dc_u2201 = RenderSystem.getDevice().createTexture(() -> {
            return "atheryx:blur_copy";
         }, 5, TextureFormat.RGBA8, fbWidth, fbHeight, 1, 1);
         obf_u222d_u2201 = RenderSystem.getDevice().createTextureView(obf_u00dc_u2201);

         for(int i = 0; i < 2; ++i) {
            if (obf_u00c3_u2201[i] != null) {
               obf_u00c3_u2201[i].close();
               obf_u00c3_u2201[i] = null;
            }

            if (obf_u03a5_u2201[i] != null) {
               obf_u03a5_u2201[i].close();
               obf_u03a5_u2201[i] = null;
            }

            final int textureIndex = i;
            obf_u03a5_u2201[i] = RenderSystem.getDevice().createTexture(() -> {
               return "atheryx:blur_" + String.valueOf(textureIndex);
            }, 13, TextureFormat.RGBA8, blurWidth, blurHeight, 1, 1);
            obf_u00c3_u2201[i] = RenderSystem.getDevice().createTextureView(obf_u03a5_u2201[i]);
         }

         obf_u0412_u2201 = fbWidth;
         obf_u0453_u2201 = fbHeight;
         obf_u00ee_u2201 = -1L;
      }
   }

   public static void renderBlur(Matrix4f matrix, float x, float y, float width, float height, float radius, float strength, float z) {
      class_310 client = class_310.method_1551();
      if (client.method_1522() != null) {
         if (client.method_1522().method_30277() != null) {
            init();
            int fbWidth = client.method_1522().field_1482;
            int fbHeight = client.method_1522().field_1481;
            int blurWidth = fbWidth / 2;
            int blurHeight = fbHeight / 2;
            ensureFramebuffers(fbWidth, fbHeight);
            long currentTime = System.nanoTime() / 16666666L;
            boolean needsBlur = currentTime != obf_u00ee_u2201 || Math.abs(strength - obf_u040d_u2201) > 0.01F;
            class_12137 sampler = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
            GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms().method_71106(RenderSystem.getModelViewMatrix(), obf_u2226_u2201, obf_u2221_u2201, obf_u040e_u2201);
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            if (needsBlur) {
               encoder.copyTextureToTexture(client.method_1522().method_30277(), obf_u00dc_u2201, 0, 0, 0, 0, 0, fbWidth, fbHeight);
               uploadBlurUniforms(fbWidth, fbHeight, blurWidth, blurHeight, 1.0F, strength);
               encoder.writeToBuffer(obf_u043d_u2201.slice(), obf_u03aa_u2201);
               RenderPass downsample = encoder.createRenderPass(() -> {
                  return "atheryx:blur_downsample";
               }, obf_u00c3_u2201[0], OptionalInt.empty(), (GpuTextureView)null, OptionalDouble.empty());

               try {
                  downsample.setPipeline(obf_u222e_u2201);
                  downsample.setVertexBuffer(0, obf_u03b5_u2201);
                  downsample.bindTexture("Sampler0", obf_u222d_u2201, sampler);
                  RenderSystem.bindDefaultUniforms(downsample);
                  downsample.setUniform("DynamicTransforms", dynamicTransforms);
                  downsample.setUniform("BlurData", obf_u043d_u2201);
                  downsample.draw(0, 6);
               } catch (Throwable var34) {
                  if (downsample != null) {
                     try {
                        downsample.close();
                     } catch (Throwable var31) {
                        var34.addSuppressed(var31);
                     }
                  }

                  throw var34;
               }

               if (downsample != null) {
                  downsample.close();
               }

               int iterations = Math.max(2, (int)(5.0F * strength));
               float[] offsets = new float[]{1.0F, 2.0F, 2.0F, 3.0F};

               for(int i = 0; i < iterations; ++i) {
                  int src = i % 2;
                  int dst = (i + 1) % 2;
                  float offset = i < offsets.length ? offsets[i] : 3.0F;
                  uploadBlurUniforms(blurWidth, blurHeight, blurWidth, blurHeight, offset, 1.0F);
                  encoder.writeToBuffer(obf_u043d_u2201.slice(), obf_u03aa_u2201);
                  final int passIndex = i;
                  RenderPass pass = encoder.createRenderPass(() -> {
                     return "atheryx:blur_pp_" + String.valueOf(passIndex);
                  }, obf_u00c3_u2201[dst], OptionalInt.empty(), (GpuTextureView)null, OptionalDouble.empty());

                  try {
                     pass.setPipeline(obf_u222e_u2201);
                     pass.setVertexBuffer(0, obf_u03b5_u2201);
                     pass.bindTexture("Sampler0", obf_u00c3_u2201[src], sampler);
                     RenderSystem.bindDefaultUniforms(pass);
                     pass.setUniform("DynamicTransforms", dynamicTransforms);
                     pass.setUniform("BlurData", obf_u043d_u2201);
                     pass.draw(0, 6);
                  } catch (Throwable var33) {
                     if (pass != null) {
                        try {
                           pass.close();
                        } catch (Throwable var30) {
                           var33.addSuppressed(var30);
                        }
                     }

                     throw var33;
                  }

                  if (pass != null) {
                     pass.close();
                  }
               }

               obf_u221f_u2201 = iterations % 2;
               obf_u00ee_u2201 = currentTime;
               obf_u040d_u2201 = strength;
            }

            float[] radii = new float[]{radius, radius, radius, radius};
            int scaledW = RenderUtil.getScaledWidth();
            int var38 = RenderUtil.getScaledHeight();
            uploadCompositeUniforms(matrix, x, y, width, height, scaledW, var38, radii, z);
            encoder.writeToBuffer(obf_u043d_u2201.slice(), obf_u03aa_u2201);
            RenderPass finalPass = encoder.createRenderPass(() -> {
               return "atheryx:blur_final";
            }, client.method_1522().method_71639(), OptionalInt.empty(), client.method_1522().method_71640(), OptionalDouble.of((double)1.0F));

            try {
               finalPass.setPipeline(obf_u0398_u2201);
               finalPass.setVertexBuffer(0, obf_u03b5_u2201);
               finalPass.bindTexture("Sampler0", obf_u00c3_u2201[obf_u221f_u2201], sampler);
               RenderSystem.bindDefaultUniforms(finalPass);
               finalPass.setUniform("DynamicTransforms", dynamicTransforms);
               finalPass.setUniform("BlurData", obf_u043d_u2201);
               finalPass.draw(0, 6);
            } catch (Throwable var32) {
               if (finalPass != null) {
                  try {
                     finalPass.close();
                  } catch (Throwable var29) {
                     var32.addSuppressed(var29);
                  }
               }

               throw var32;
            }

            if (finalPass != null) {
               finalPass.close();
            }

         }
      }
   }

   private static void uploadBlurUniforms(int screenW, int screenH, int texW, int texH, float offset, float strength) {
      obf_u03aa_u2201.clear();

      for(int i = 0; i < 16; ++i) {
         obf_u03aa_u2201.putFloat(0.0F);
      }

      obf_u03aa_u2201.putFloat(0.0F).putFloat(0.0F).putFloat((float)screenW).putFloat((float)screenH);
      obf_u03aa_u2201.putFloat((float)screenW).putFloat((float)screenH).putFloat(1.0F).putFloat(offset);
      obf_u03aa_u2201.putFloat((float)texW).putFloat((float)texH).putFloat(1.0F).putFloat(strength);
      obf_u03aa_u2201.putFloat(0.0F).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
      obf_u03aa_u2201.putFloat(0.0F).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
      obf_u03aa_u2201.flip();
      uploadUniformBuffer();
   }

   private static void uploadCompositeUniforms(Matrix4f matrix, float x, float y, float w, float h, int fbW, int fbH, float[] r, float z) {
      obf_u03aa_u2201.clear();
      obf_u03aa_u2201.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
      obf_u03aa_u2201.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
      obf_u03aa_u2201.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
      obf_u03aa_u2201.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
      obf_u03aa_u2201.putFloat(x).putFloat(y).putFloat(w).putFloat(h);
      obf_u03aa_u2201.putFloat((float)fbW).putFloat((float)fbH).putFloat(0.0F).putFloat(0.0F);
      obf_u03aa_u2201.putFloat((float)fbW).putFloat((float)fbH).putFloat(1.0F).putFloat(0.0F);
      obf_u03aa_u2201.putFloat(r[0]).putFloat(r[1]).putFloat(r[2]).putFloat(r[3]);
      obf_u03aa_u2201.putFloat(z).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
      obf_u03aa_u2201.flip();
      uploadUniformBuffer();
   }

   private static void uploadUniformBuffer() {
      int size = obf_u03aa_u2201.remaining();
      if (obf_u043d_u2201 == null || obf_u043d_u2201.size() < (long)size) {
         if (obf_u043d_u2201 != null) {
            obf_u043d_u2201.close();
         }

         obf_u043d_u2201 = RenderSystem.getDevice().createBuffer(() -> {
            return "atheryx:blur_uniform";
         }, 136, (long)size);
      }

   }

   public static GpuTextureView getBlurTexture() {
      return obf_u03a4_u2201 && obf_u00c3_u2201[obf_u221f_u2201] != null ? obf_u00c3_u2201[obf_u221f_u2201] : null;
   }

   public static void close() {
      if (obf_u043d_u2201 != null) {
         obf_u043d_u2201.close();
         obf_u043d_u2201 = null;
      }

      if (obf_u03b5_u2201 != null) {
         obf_u03b5_u2201.close();
         obf_u03b5_u2201 = null;
      }

      if (obf_u03aa_u2201 != null) {
         MemoryUtil.memFree(obf_u03aa_u2201);
         obf_u03aa_u2201 = null;
      }

      if (obf_u222d_u2201 != null) {
         obf_u222d_u2201.close();
         obf_u222d_u2201 = null;
      }

      if (obf_u00dc_u2201 != null) {
         obf_u00dc_u2201.close();
         obf_u00dc_u2201 = null;
      }

      for(int i = 0; i < 2; ++i) {
         if (obf_u00c3_u2201[i] != null) {
            obf_u00c3_u2201[i].close();
            obf_u00c3_u2201[i] = null;
         }

         if (obf_u03a5_u2201[i] != null) {
            obf_u03a5_u2201[i].close();
            obf_u03a5_u2201[i] = null;
         }
      }

      obf_u0412_u2201 = 0;
      obf_u0453_u2201 = 0;
      obf_u03a4_u2201 = false;
      obf_u00ee_u2201 = -1L;
   }

   static {
      obf_u222e_u2201 = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_60125}).withLocation(class_2960.method_60655("atheryx", "blur_pass")).withVertexShader(class_2960.method_60655("atheryx", "blur_pass_vertex")).withFragmentShader(class_2960.method_60655("atheryx", "blur_pass_fragment")).withVertexFormat(class_290.field_60033, class_5596.field_27379).withUniform("BlurData", class_10789.field_60031).withSampler("Sampler0").withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build());
      obf_u0398_u2201 = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_60125}).withLocation(class_2960.method_60655("atheryx", "blur_final")).withVertexShader(class_2960.method_60655("atheryx", "blur_final_vertex")).withFragmentShader(class_2960.method_60655("atheryx", "blur_final_fragment")).withVertexFormat(class_290.field_60033, class_5596.field_27379).withUniform("BlurData", class_10789.field_60031).withSampler("Sampler0").withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).build());
      obf_u2226_u2201 = new Vector4f(1.0F, 1.0F, 1.0F, 1.0F);
      obf_u2221_u2201 = new Vector3f(0.0F, 0.0F, 0.0F);
      obf_u040e_u2201 = new Matrix4f();
      obf_u03a5_u2201 = new GpuTexture[2];
      obf_u00c3_u2201 = new GpuTextureView[2];
      obf_u0412_u2201 = 0;
      obf_u0453_u2201 = 0;
      obf_u03a4_u2201 = false;
      obf_u00ee_u2201 = -1L;
      obf_u221f_u2201 = 0;
      obf_u040d_u2201 = 0.0F;
   }

}
