package atheryx.render.pipeline;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_12137;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;
import atheryx.internal.RuntimeCipher;


public class HudBlurPipeline {
   private static final int obf_u0402_u2201 = (int)(float)256.0F;
   private static RenderPipeline obf_u00cb_u2201;
   private static GpuBuffer obf_u03ba_u2201;
   private static GpuTexture obf_u00c4_u2201;
   private static GpuTextureView obf_u00cd_u2201;
   private static int obf_u00f0_u2201;
   private static int obf_u00e0_u2201;
   private static boolean obf_u2209_u2201 = true;

   public static void markSceneDirty() {

      obf_u2209_u2201 = true;
   }

   public static void init() {

      if (obf_u00cb_u2201 == null) {
         obf_u00cb_u2201 = RenderPipeline.builder(new Snippet[0])
            .withLocation(
               class_2960.method_60655(
                  "atheryx",
                  "hud_blur"
               )
            )
            .withVertexShader(
               class_2960.method_60655(
                  "atheryx",
                  "hud_blur_vertex"
               )
            )
            .withFragmentShader(
               class_2960.method_60655(
                  "atheryx",
                  "hud_blur_fragment"
               )
            )
            .withVertexFormat(VertexFormat.builder().build(), class_5596.field_27379)
            .withUniform(
               "Uniforms",
               class_10789.field_60031
            )
            .withSampler(
               "Sampler0"
            )
            .withBlend(BlendFunction.TRANSLUCENT)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withDepthWrite(false)
            .withCull(false)
            .build();
         obf_u03ba_u2201 = RenderSystem.getDevice()
            .createBuffer(
               () -> {

                  return "HudBlurPipeline Uniforms";
               },
               136,
               (long)256L
            );
      }
   }

   public static void drawBlurredRect(
      Matrix4f matrix, float x, float y, float width, float height, float tl, float tr, float br, float bl, float blurRadius, float alpha, Color tint, float z
   ) {

      if (!(alpha <= 0.0F) && !(width <= 0.0F) && !(height <= 0.0F)) {
         class_310 client = class_310.method_1551();
         class_276 framebuffer = client.method_1522();
         if (framebuffer != null && framebuffer.method_30277() != null) {
            if (obf_u00cb_u2201 == null) {
               init();
            }

            if (obf_u00cb_u2201 != null && obf_u03ba_u2201 != null) {
               int fbWidth = framebuffer.field_1482;
               int fbHeight = framebuffer.field_1481;
               int screenWidth = atheryx.render.RenderUtil.getScaledWidth();
               int screenHeight = atheryx.render.RenderUtil.getScaledHeight();
               ensureCaptureTexture(fbWidth, fbHeight);
               if (obf_u00c4_u2201 != null && obf_u00cd_u2201 != null) {
                  float red = tint.getRed() / (float)255.0F;
                  float green = tint.getGreen() / (float)255.0F;
                  float blue = tint.getBlue() / (float)255.0F;
                  float tintAlpha = tint.getAlpha() / (float)255.0F;
                  float smoothness = 1.0F;
                  ByteBuffer buffer = MemoryUtil.memAlloc(256);
                  buffer.putFloat(matrix.m00()).putFloat(matrix.m01()).putFloat(matrix.m02()).putFloat(matrix.m03());
                  buffer.putFloat(matrix.m10()).putFloat(matrix.m11()).putFloat(matrix.m12()).putFloat(matrix.m13());
                  buffer.putFloat(matrix.m20()).putFloat(matrix.m21()).putFloat(matrix.m22()).putFloat(matrix.m23());
                  buffer.putFloat(matrix.m30()).putFloat(matrix.m31()).putFloat(matrix.m32()).putFloat(matrix.m33());
                  buffer.position(64);
                  buffer.putFloat(x).putFloat(y).putFloat(width).putFloat(height);
                  buffer.putFloat(screenWidth).putFloat(screenHeight).putFloat(0.0F).putFloat(0.0F);
                  buffer.putFloat(tr).putFloat(br).putFloat(tl).putFloat(bl);
                  buffer.putFloat(blurRadius).putFloat(smoothness).putFloat(Math.clamp(alpha, 0.0F, 1.0F)).putFloat(tintAlpha);
                  buffer.putFloat(red).putFloat(green).putFloat(blue).putFloat(0.0F);
                  buffer.putFloat(z).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
                  buffer.flip();
                  CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
                  if (obf_u2209_u2201) {
                     encoder.copyTextureToTexture(framebuffer.method_30277(), obf_u00c4_u2201, 0, 0, 0, 0, 0, fbWidth, fbHeight);
                     obf_u2209_u2201 = false;
                  }

                  encoder.writeToBuffer(obf_u03ba_u2201.slice(), buffer);
                  MemoryUtil.memFree(buffer);
                  class_12137 sampler = RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
                  RenderPass pass = encoder.createRenderPass(
                     () -> {

                        return "HudBlurPipeline";
                     },
                     framebuffer.method_71639(),
                     OptionalInt.empty(),
                     framebuffer.method_71640(),
                     OptionalDouble.of(1.0)
                  );

                  try {
                     pass.setPipeline(obf_u00cb_u2201);
                     pass.setUniform(
                        "Uniforms",
                        obf_u03ba_u2201
                     );
                     pass.bindTexture(
                        "Sampler0",
                        obf_u00cd_u2201,
                        sampler
                     );
                     pass.draw(0, 6);
                  } catch (Throwable var31) {
                     if (pass != null) {
                        try {
                           pass.close();
                        } catch (Throwable var30) {
                           var31.addSuppressed(var30);
                        }
                     }

                     throw var31;
                  }

                  if (pass != null) {
                     pass.close();
                  }
               }
            }
         }
      }
   }

   private static void ensureCaptureTexture(int width, int height) {

      if (obf_u00c4_u2201 == null || width != obf_u00f0_u2201 || height != obf_u00e0_u2201) {
         if (obf_u00cd_u2201 != null) {
            obf_u00cd_u2201.close();
            obf_u00cd_u2201 = null;
         }

         if (obf_u00c4_u2201 != null) {
            obf_u00c4_u2201.close();
            obf_u00c4_u2201 = null;
         }

         obf_u00c4_u2201 = RenderSystem.getDevice()
            .createTexture(
               () -> {

                  return "atheryx:hud_blur_copy";
               },
               5,
               TextureFormat.RGBA8,
               width,
               height,
               1,
               1
            );
         obf_u00cd_u2201 = RenderSystem.getDevice().createTextureView(obf_u00c4_u2201);
         obf_u00f0_u2201 = width;
         obf_u00e0_u2201 = height;
         obf_u2209_u2201 = true;
      }
   }

   public static void close() {

      if (obf_u03ba_u2201 != null) {
         obf_u03ba_u2201.close();
         obf_u03ba_u2201 = null;
      }

      if (obf_u00cd_u2201 != null) {
         obf_u00cd_u2201.close();
         obf_u00cd_u2201 = null;
      }

      if (obf_u00c4_u2201 != null) {
         obf_u00c4_u2201.close();
         obf_u00c4_u2201 = null;
      }

      obf_u00f0_u2201 = 0;
      obf_u00e0_u2201 = 0;
   }

}
