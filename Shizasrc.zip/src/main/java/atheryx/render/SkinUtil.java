package atheryx.render;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class SkinUtil {
   private static final Map<String, class_2960> obf_u00cc_u220e = new ConcurrentHashMap<String, class_2960>();
   private static final Set<String> obf_u0449_u220e = ConcurrentHashMap.newKeySet();
   private static final ExecutorService obf_u042b_u220e = Executors.newFixedThreadPool(2);

   public static class_2960 getOrLoadAvatar(String name) {
      if (obf_u00cc_u220e.containsKey(name)) {
         return obf_u00cc_u220e.get(name);
      } else {
         if (obf_u0449_u220e.add(name)) {
            obf_u042b_u220e.submit((Runnable)(() -> {
               try {
                  URL url = new URL("https://mc-heads.net/avatar/" + String.valueOf(name) + "/64");
                  HttpURLConnection connection = (HttpURLConnection)url.openConnection();
                  connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)");
                  connection.setConnectTimeout(5000);
                  connection.setReadTimeout(5000);
                  if (connection.getResponseCode() == 200) {
                     try (InputStream is = connection.getInputStream()) {
                        class_1011 image = class_1011.method_4309(is);
                        class_310.method_1551().execute(() -> {
                           class_1043 texture = new class_1043(() -> {
                              return "avatar_" + String.valueOf(name.toLowerCase());
                           }, image);
                           texture.method_4524();
                           class_2960 id = class_2960.method_60655("minar", "avatar_" + String.valueOf(name.toLowerCase()));
                           class_310.method_1551().method_1531().method_4616(id, texture);
                           obf_u00cc_u220e.put(name, id);
                        });
                     }
                  } else {
                       obf_u00cc_u220e.put(name, null);
                  }
               } catch (Exception var8) {
                    obf_u00cc_u220e.put(name, null);
               }

            }));
         }

         return null;
      }
   }

}
