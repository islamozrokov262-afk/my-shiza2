package atheryx.render;

import java.util.List;
import net.minecraft.class_10017;
import net.minecraft.class_10444;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_11785;
import net.minecraft.class_11791;
import net.minecraft.class_12075;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_327;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5481;
import net.minecraft.class_630;
import net.minecraft.class_777;
import net.minecraft.class_811;
import org.joml.Quaternionf;

public record ImmediateMaskQueue(class_4597.class_4598 consumers) implements class_11659, class_11785 {
   public class_11785 method_73529(int layer) {
      return this;
   }

   public <T> void method_73490(class_3879<? super T> model, T state, class_4587 matrices, class_1921 layer, int light, int overlay, int color, class_1058 sprite, int outlineColor, class_11683.class_11792 crumblingOverlay) {
      model.method_2819(state);
      model.method_62100(matrices, this.getConsumersInternal().method_73477(layer), light, overlay, color);
   }

   public void method_73494(class_630 part, class_4587 matrices, class_1921 layer, int light, int overlay, class_1058 sprite, boolean applyTransform, boolean renderCuboids, int color, class_11683.class_11792 crumblingOverlay, int outlineColor) {
      part.method_22699(matrices, this.getConsumersInternal().method_73477(layer), light, overlay, color);
   }

   public void method_73479(class_4587 matrices, float opacity, List<class_10017.class_11680> pieces) {
   }

   public void method_73482(class_4587 matrices, class_243 pos, int yOffset, class_2561 text, boolean seeThrough, int light, double distance, class_12075 cameraRenderState) {
   }

   public void method_73478(class_4587 matrices, float x, float y, class_5481 text, boolean shadow, class_327.class_6415 layerType, int color, int backgroundColor, int light, int seed) {
   }

   public void method_73488(class_4587 matrices, class_10017 state, Quaternionf rotation) {
   }

   public void method_73486(class_4587 matrices, class_10017.class_10018 leashData) {
   }

   public void method_73481(class_4587 matrices, class_2680 state, int light, int overlay, int color) {
   }

   public void method_73485(class_4587 matrices, class_11791 state) {
   }

   public void method_73484(class_4587 matrices, class_1921 layer, class_1087 model, float red, float green, float blue, int light, int overlay, int color) {
   }

   public void method_73480(class_4587 matrices, class_811 displayContext, int light, int overlay, int seed, int[] tints, List<class_777> quads, class_1921 layer, class_10444.class_10445 glint) {
   }

   public void method_73483(class_4587 matrices, class_1921 layer, class_11659.class_11660 command) {
   }

   public void method_74315(class_11659.class_11947 command) {
   }

   public class_4597.class_4598 consumers() {
      return this.getConsumersInternal();
   }

   private class_4597.class_4598 getConsumersInternal() {
      return this.consumers;
   }

}
