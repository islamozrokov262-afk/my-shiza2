package atheryx.render.font;

import atheryx.render.RenderUtil;
import atheryx.render.pipeline.MsdfGlowPipeline;
import atheryx.render.pipeline.MsdfPipeline;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.joml.Matrix4f;

public class Msdf {
   public static MsdfFont SF_REGULAR;
   public static MsdfFont SF_BOLD;
   public static MsdfFont WTMICO;
   public static MsdfFont WOQUED_ICONS;
   private static boolean obf_u2237_u2201 = false;

   public static void setVanillaFontForced(boolean enabled) {
      obf_u2237_u2201 = enabled;
   }

   public static boolean isReady() {
      MsdfManager.init();
      MsdfPipeline.init();
      return MsdfManager.getDefaultFont() != null && MsdfManager.getDefaultFont().isLoaded();
   }

   public static void drawText(class_332 context, String text, float x, float y, float size, int color) {
      drawText(context, text, x, y, size, color, false);
   }

   public static void drawText(class_332 context, String text, float x, float y, float size, int color, boolean overrideContext) {
      if (!obf_u2237_u2201 && isReady()) {
         drawText(context, MsdfManager.getDefaultFont(), text, x, y, size, color, overrideContext);
      } else {
         drawVanillaText(context, text, x, y, size, color);
      }
   }

   public static void drawText(class_332 context, String fontName, String text, float x, float y, float size, int color, boolean overrideContext) {
      MsdfFont font = MsdfManager.getFont(fontName);
      if (!obf_u2237_u2201 && font != null && font.isLoaded()) {
         drawText(context, font, text, x, y, size, color, overrideContext);
      } else {
         drawVanillaText(context, text, x, y, size, color);
      }
   }

   public static void drawText(class_332 context, MsdfFont font, String text, float x, float y, float size, int color, boolean overrideContext) {
      drawRotatedText(context, font, text, x, y, size, color, 0.0F, overrideContext);
   }

   public static void drawRotatedText(class_332 context, MsdfFont font, String text, float x, float y, float size, int color, float rotation, boolean overrideContext) {
      if (isReady()) {
         if (font == null) {
            font = MsdfManager.getDefaultFont();
         }

         if (overrideContext) {
            final MsdfFont renderFont = font;
            RenderUtil.enqueueRenderCall(() -> {
               MsdfPipeline.drawText(RenderUtil.createGuiProjection(), renderFont, text, x, y, size, color, rotation, 500.0F);
            });
         } else if (font != null && font.isLoaded()) {
            MsdfPipeline.drawText(RenderUtil.createGuiProjection(), font, text, x, y, size, color, rotation, 0.0F);
         } else {
            drawVanillaText(context, text, x, y, size, color);
         }
      }
   }

   public static void drawText(Matrix4f matrix, String text, float x, float y, float size, int color) {
      MsdfPipeline.drawText(matrix, MsdfManager.getDefaultFont(), text, x, y, size, color, 0.0F, 0.0F);
   }

   public static void drawText(Matrix4f matrix, String fontName, String text, float x, float y, float size, int color) {
      MsdfPipeline.drawText(matrix, MsdfManager.getFont(fontName), text, x, y, size, color, 0.0F, 0.0F);
   }

   public static void drawText(Matrix4f matrix, MsdfFont font, String text, float x, float y, float size, int color) {
      MsdfPipeline.drawText(matrix, font, text, x, y, size, color, 0.0F, 0.0F);
   }

   private static void drawVanillaText(class_332 context, String text, float x, float y, float size, int color) {
      class_310 client = class_310.method_1551();
      context.method_51433(client.field_1772, text, (int)x, (int)y, color, false);
   }

   public static float getTextWidth(String text, float size) {
      return getTextWidth(MsdfManager.getDefaultFont(), text, size);
   }

   public static float getTextWidth(String fontName, String text, float size) {
      return getTextWidth(MsdfManager.getFont(fontName), text, size);
   }

   public static float getTextWidth(MsdfFont font, String text, float size) {
      return font == null ? 0.0F : font.getTextWidth(text, size);
   }

   public static float getTextHeight(float size) {
      return getTextHeight(MsdfManager.getDefaultFont(), size);
   }

   public static float getTextHeight(String fontName, float size) {
      return getTextHeight(MsdfManager.getFont(fontName), size);
   }

   public static float getTextHeight(MsdfFont font, float size) {
      return font == null ? size : font.getLineHeight() * size;
   }

   public static void drawCenteredText(class_332 context, String text, float x, float y, float size, int color) {
      drawText(context, text, x - getTextWidth(text, size) / 2.0F, y, size, color, false);
   }

   public static void drawCenteredText(class_332 context, String fontName, String text, float x, float y, float size, int color) {
      drawText(context, fontName, text, x - getTextWidth(fontName, text, size) / 2.0F, y, size, color, false);
   }

   public static void drawRightAlignedText(class_332 context, String text, float x, float y, float size, int color) {
      drawText(context, text, x - getTextWidth(text, size), y, size, color, false);
   }

   public static void drawCenteredGradientText(class_332 context, String text, float x, float y, float size, int startColor, int endColor) {
      float xOffset = x - getTextWidth(text, size) / 2.0F;
      drawGradientText(context, MsdfManager.getDefaultFont(), text, xOffset, y, size, startColor, endColor, false);
   }

   public static void drawCenteredGradientText(class_332 context, String fontName, String text, float x, float y, float size, int startColor, int endColor) {
      float xOffset = x - getTextWidth(fontName, text, size) / 2.0F;
      drawGradientText(context, MsdfManager.getFont(fontName), text, xOffset, y, size, startColor, endColor, false);
   }

   public static void drawRightAlignedGradientText(class_332 context, String text, float x, float y, float size, int startColor, int endColor) {
      float xOffset = x - getTextWidth(text, size);
      drawGradientText(context, MsdfManager.getDefaultFont(), text, xOffset, y, size, startColor, endColor, false);
   }

   public static void drawRightAlignedGradientText(class_332 context, String fontName, String text, float x, float y, float size, int startColor, int endColor) {
      float xOffset = x - getTextWidth(fontName, text, size);
      drawGradientText(context, MsdfManager.getFont(fontName), text, xOffset, y, size, startColor, endColor, false);
   }

   public static void drawRightAlignedText(class_332 context, String fontName, String text, float x, float y, float size, int color) {
      drawText(context, fontName, text, x - getTextWidth(fontName, text, size), y, size, color, false);
   }

   public static void drawShadowedText(class_332 context, String text, float x, float y, float size, int color) {
      drawText(context, text, x + 1.0F, y + 1.0F, size, 1140850688, false);
      drawText(context, text, x, y, size, color, false);
   }

   public static void drawShadowedText(class_332 context, String fontName, String text, float x, float y, float size, int color) {
      drawText(context, fontName, text, x + 1.0F, y + 1.0F, size, 1140850688, false);
      drawText(context, fontName, text, x, y, size, color, false);
   }

   public static void drawGlowingText(class_332 context, String text, float x, float y, float size, int textColor, int glowColor, float glowIntensity, boolean overrideContext) {
      drawGlowingText(context, MsdfManager.getDefaultFont(), text, x, y, size, textColor, glowColor, glowIntensity, overrideContext);
   }

   public static void drawGlowingText(class_332 context, MsdfFont font, String text, float x, float y, float size, int textColor, int glowColor, float glowIntensity, boolean overrideContext) {
      if (isReady()) {
         if (font == null) {
            font = MsdfManager.getDefaultFont();
         }

         if (overrideContext) {
            final MsdfFont renderFont = font;
            RenderUtil.enqueueRenderCall(() -> {
               MsdfGlowPipeline.drawGlowingText(RenderUtil.createGuiProjection(), renderFont, text, x, y, size, textColor, glowColor, glowIntensity, 500.0F);
            });
         } else if (font != null && font.isLoaded()) {
            MsdfGlowPipeline.drawGlowingText(RenderUtil.createGuiProjection(), font, text, x, y, size, textColor, glowColor, glowIntensity, 0.0F);
         }
      }
   }

   public static void drawGlowingText(class_332 context, String fontName, String text, float x, float y, float size, int textColor, int glowColor, float glowIntensity, boolean overrideContext) {
      MsdfFont font = MsdfManager.getFont(fontName);
      drawGlowingText(context, font, text, x, y, size, textColor, glowColor, glowIntensity, overrideContext);
   }

   public static void drawRainbowText(class_332 context, String text, float x, float y, float size, float speed) {
      drawRainbowText(context, MsdfManager.getDefaultFont(), text, x, y, size, speed, false);
   }

   public static void drawRainbowText(class_332 context, MsdfFont font, String text, float x, float y, float size, float speed, boolean overrideContext) {
      if (overrideContext) {
         RenderUtil.enqueueRenderCall(() -> {
            drawRainbowText(context, font, text, x, y, size, speed, false);
         });
      } else if (font != null && !text.isEmpty()) {
         int[] colors = new int[text.length()];
         long time = System.currentTimeMillis();

         for(int i = 0; i < text.length(); ++i) {
            float hue = ((float)time * speed / 1000.0F + (float)i * 0.1F) % 1.0F;
            colors[i] = hsbToRgb(hue, 1.0F, 1.0F);
         }

         MsdfPipeline.drawMulticolorText(RenderUtil.createGuiProjection(), font, text, x, y, size, colors, 500.0F);
      }
   }

   public static void drawGradientText(class_332 context, String text, float x, float y, float size, int startColor, int endColor) {
      drawGradientText(context, MsdfManager.getDefaultFont(), text, x, y, size, startColor, endColor, false);
   }

   public static void drawGradientText(class_332 context, MsdfFont font, String text, float x, float y, float size, int startColor, int endColor, boolean overrideContext) {
      if (overrideContext) {
         RenderUtil.enqueueRenderCall(() -> {
            drawGradientText(context, font, text, x, y, size, startColor, endColor, false);
         });
      } else if (font != null && !text.isEmpty()) {
         int[] colors = new int[text.length()];

         for(int i = 0; i < text.length(); ++i) {
            float t = text.length() > 1 ? (float)i / (float)(text.length() - 1) : 0.0F;
            colors[i] = lerpArgb(startColor, endColor, t);
         }

         MsdfPipeline.drawMulticolorText(RenderUtil.createGuiProjection(), font, text, x, y, size, colors, 500.0F);
      }
   }

   public static void drawMulticolorText(class_332 context, String text, float x, float y, float size, int... colors) {
      drawMulticolorText(context, MsdfManager.getDefaultFont(), text, x, y, size, false, colors);
   }

   public static void drawMulticolorText(class_332 context, MsdfFont font, String text, float x, float y, float size, boolean overrideContext, int... colors) {
      if (overrideContext) {
         RenderUtil.enqueueRenderCall(() -> {
            drawMulticolorText(context, font, text, x, y, size, false, colors);
         });
      } else if (font != null && !text.isEmpty() && colors.length != 0) {
         float z = RenderUtil.isGuiRenderContext() ? 500.0F : 0.0F;
         MsdfPipeline.drawMulticolorText(RenderUtil.createGuiProjection(), font, text, x, y, size, colors, z);
      }
   }

   private static int hsbToRgb(float hue, float saturation, float brightness) {
      int r = 0;
      int g = 0;
      int b = 0;
      if (saturation == 0.0F) {
         r = g = b = (int)(brightness * 255.0F + 0.5F);
      } else {
         float h = (hue - (float)Math.floor((double)hue)) * 6.0F;
         float f = h - (float)Math.floor((double)h);
         float p = brightness * (1.0F - saturation);
         float q = brightness * (1.0F - saturation * f);
         float t = brightness * (1.0F - saturation * (1.0F - f));
         switch ((int)h) {
            case 0:
               r = (int)(brightness * 255.0F + 0.5F);
               g = (int)(t * 255.0F + 0.5F);
               b = (int)(p * 255.0F + 0.5F);
               break;
            case 1:
               r = (int)(q * 255.0F + 0.5F);
               g = (int)(brightness * 255.0F + 0.5F);
               b = (int)(p * 255.0F + 0.5F);
               break;
            case 2:
               r = (int)(p * 255.0F + 0.5F);
               g = (int)(brightness * 255.0F + 0.5F);
               b = (int)(t * 255.0F + 0.5F);
               break;
            case 3:
               r = (int)(p * 255.0F + 0.5F);
               g = (int)(q * 255.0F + 0.5F);
               b = (int)(brightness * 255.0F + 0.5F);
               break;
            case 4:
               r = (int)(t * 255.0F + 0.5F);
               g = (int)(p * 255.0F + 0.5F);
               b = (int)(brightness * 255.0F + 0.5F);
               break;
            case 5:
               r = (int)(brightness * 255.0F + 0.5F);
               g = (int)(p * 255.0F + 0.5F);
               b = (int)(q * 255.0F + 0.5F);
         }
      }

      return -16777216 | r << 16 | g << 8 | b;
   }

   private static int lerpArgb(int c1, int c2, float t) {
      int a1 = c1 >> 24 & 255;
      int r1 = c1 >> 16 & 255;
      int g1 = c1 >> 8 & 255;
      int b1 = c1 & 255;
      int a2 = c2 >> 24 & 255;
      int r2 = c2 >> 16 & 255;
      int g2 = c2 >> 8 & 255;
      int b2 = c2 & 255;
      int a = (int)((float)a1 + (float)(a2 - a1) * t);
      int r = (int)((float)r1 + (float)(r2 - r1) * t);
      int g = (int)((float)g1 + (float)(g2 - g1) * t);
      int b = (int)((float)b1 + (float)(b2 - b1) * t);
      return a << 24 | r << 16 | g << 8 | b;
   }

}
