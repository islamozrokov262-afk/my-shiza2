package atheryx.render.font;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;

public class MsdfFont {
   private final String field_6d2b79f5;
   private final Map<Integer, MsdfGlyph> field_da56f3ea = new HashMap<Integer, MsdfGlyph>();
   private GpuTexture field_47826ddf;
   private GpuTextureView field_b4ade7d4;
   private float field_21d961c9;
   private float field_8f04dbbe;
   private float field_fc3055b3;
   private float field_695bcfa8;
   private int field_d687499d;
   private int field_43b2c392;
   private float field_b0de3d87;
   private boolean field_1e09b77c;

   public MsdfFont(String name) {
      this.setLoadedInternal(false);
      this.field_6d2b79f5 = name;
   }

   public void load(class_2960 atlasId, class_2960 jsonId) {
      if (!this.getLoadedInternal()) {
         try {
            this.loadAtlas(atlasId);
            this.loadMetrics(jsonId);
            this.setLoadedInternal(true);
            System.out.println("[MSDF] Successfully loaded font: " + String.valueOf(this.getNameInternal()));
         } catch (Exception e) {
            System.err.println("[MSDF] Failed to load font '" + String.valueOf(this.getNameInternal()) + "':");
            e.printStackTrace();
         }

      }
   }

   private void loadAtlas(class_2960 id) throws Exception {
      class_2960 resourceId = class_2960.method_60655(id.method_12836(), "font/" + String.valueOf(id.method_12832()));

      try (InputStream is = ((class_3298)class_310.method_1551().method_1478().method_14486(resourceId).get()).method_14482()) {
         class_1011 image = class_1011.method_4309(is);
         this.setAtlasWidthInternal(image.method_4307());
         this.setAtlasHeightInternal(image.method_4323());
         this.setTextureInternal(RenderSystem.getDevice().createTexture(() -> {
            return "font/" + String.valueOf(this.getNameInternal());
         }, 5, TextureFormat.RGBA8, this.getAtlasWidthInternal(), this.getAtlasHeightInternal(), 1, 1));
         RenderSystem.getDevice().createCommandEncoder().writeToTexture(this.getTextureInternal(), image);
         this.setTextureViewInternal(RenderSystem.getDevice().createTextureView(this.getTextureInternal()));
         image.close();
      }

   }

   private void loadMetrics(class_2960 id) throws Exception {
      class_2960 resourceId = class_2960.method_60655(id.method_12836(), "font/" + String.valueOf(id.method_12832()));

      try (InputStream is = ((class_3298)class_310.method_1551().method_1478().method_14486(resourceId).get()).method_14482()) {
         String json = new String(is.readAllBytes());
         JsonObject root = JsonParser.parseString(json).getAsJsonObject();
         JsonObject atlas = root.getAsJsonObject("atlas");
         this.setDistanceRangeInternal(atlas.get("distanceRange").getAsFloat());
         boolean yOriginBottom = atlas.has("yOrigin") && "bottom".equals(atlas.get("yOrigin").getAsString());
         JsonObject metrics = root.getAsJsonObject("metrics");
         this.setEmSizeInternal(metrics.get("emSize").getAsFloat());
         this.setLineHeightInternal(metrics.get("lineHeight").getAsFloat());
         this.setAscenderInternal(metrics.get("ascender").getAsFloat());
         this.setDescenderInternal(metrics.get("descender").getAsFloat());

         for(JsonElement el : root.getAsJsonArray("glyphs")) {
            JsonObject g = el.getAsJsonObject();
            int unicode = g.get("unicode").getAsInt();
            float advance = g.has("advance") ? g.get("advance").getAsFloat() : 0.0F;
            float pw = 0.0F;
            float ph = 0.0F;
            float u0 = 0.0F;
            float v0 = 0.0F;
            float u1 = 0.0F;
            float v1 = 0.0F;
            float bx = 0.0F;
            float by = 0.0F;
            if (g.has("atlasBounds")) {
               JsonObject ab = g.getAsJsonObject("atlasBounds");
               float left = ab.get("left").getAsFloat();
               float bottom = ab.get("bottom").getAsFloat();
               float right = ab.get("right").getAsFloat();
               float top = ab.get("top").getAsFloat();
               u0 = left / (float)this.getAtlasWidthInternal();
               u1 = right / (float)this.getAtlasWidthInternal();
               if (yOriginBottom) {
                  v0 = 1.0F - top / (float)this.getAtlasHeightInternal();
                  v1 = 1.0F - bottom / (float)this.getAtlasHeightInternal();
               } else {
                  v0 = top / (float)this.getAtlasHeightInternal();
                  v1 = bottom / (float)this.getAtlasHeightInternal();
               }
            }

            if (g.has("planeBounds")) {
               JsonObject pb = g.getAsJsonObject("planeBounds");
               float left = pb.get("left").getAsFloat();
               float bottom = pb.get("bottom").getAsFloat();
               float right = pb.get("right").getAsFloat();
               float top = pb.get("top").getAsFloat();
               bx = left;
               by = top;
               pw = right - left;
               ph = top - bottom;
            }

            this.getGlyphsInternal().put(unicode, new MsdfGlyph(unicode, advance, 0.0F, 0.0F, pw, ph, u0, v0, u1, v1, bx, by));
         }

         PrintStream var34 = System.out;
         String var10001 = this.getNameInternal();
         var34.println(var10001 + this.getGlyphsInternal().size());
      }

   }

   public MsdfGlyph getGlyph(int codepoint) {
      return (MsdfGlyph)this.getGlyphsInternal().get(codepoint);
   }

   public GpuTextureView getTextureView() {
      return this.getTextureViewInternal();
   }

   public float getLineHeight() {
      return this.getLineHeightInternal();
   }

   public float getAscender() {
      return this.getAscenderInternal();
   }

   public float getDescender() {
      return this.getDescenderInternal();
   }

   public float getDistanceRange() {
      return this.getDistanceRangeInternal();
   }

   public float getEmSize() {
      return this.getEmSizeInternal();
   }

   public String getName() {
      return this.getNameInternal();
   }

   public boolean isLoaded() {
      return this.getLoadedInternal();
   }

   public float getTextWidth(String text, float size) {
      float scale = size / this.getEmSizeInternal();
      float width = 0.0F;

      for(int i = 0; i < text.length(); ++i) {
         MsdfGlyph glyph = (MsdfGlyph)this.getGlyphsInternal().get(Integer.valueOf(text.charAt(i)));
         if (glyph != null) {
            width += glyph.advance * scale;
         }
      }

      return width;
   }

   public void close() {
      if (this.getTextureViewInternal() != null) {
         this.getTextureViewInternal().close();
         this.setTextureViewInternal((GpuTextureView)null);
      }

      if (this.getTextureInternal() != null) {
         this.getTextureInternal().close();
         this.setTextureInternal((GpuTexture)null);
      }

      this.getGlyphsInternal().clear();
      this.setLoadedInternal(false);
   }

   private String getNameInternal() {
      return this.field_6d2b79f5;
   }

   private Map getGlyphsInternal() {
      return this.field_da56f3ea;
   }

   private GpuTexture getTextureInternal() {
      return this.field_47826ddf;
   }

   private void setTextureInternal(GpuTexture var1) {
      this.field_47826ddf = var1;
   }

   private GpuTextureView getTextureViewInternal() {
      return this.field_b4ade7d4;
   }

   private void setTextureViewInternal(GpuTextureView var1) {
      this.field_b4ade7d4 = var1;
   }

   private float getLineHeightInternal() {
      return this.field_21d961c9;
   }

   private void setLineHeightInternal(float var1) {
      this.field_21d961c9 = var1;
   }

   private float getAscenderInternal() {
      return this.field_8f04dbbe;
   }

   private void setAscenderInternal(float var1) {
      this.field_8f04dbbe = var1;
   }

   private float getDescenderInternal() {
      return this.field_fc3055b3;
   }

   private void setDescenderInternal(float var1) {
      this.field_fc3055b3 = var1;
   }

   private float getDistanceRangeInternal() {
      return this.field_695bcfa8;
   }

   private void setDistanceRangeInternal(float var1) {
      this.field_695bcfa8 = var1;
   }

   private int getAtlasWidthInternal() {
      return this.field_d687499d;
   }

   private void setAtlasWidthInternal(int var1) {
      this.field_d687499d = var1;
   }

   private int getAtlasHeightInternal() {
      return this.field_43b2c392;
   }

   private void setAtlasHeightInternal(int var1) {
      this.field_43b2c392 = var1;
   }

   private float getEmSizeInternal() {
      return this.field_b0de3d87;
   }

   private void setEmSizeInternal(float var1) {
      this.field_b0de3d87 = var1;
   }

   private boolean getLoadedInternal() {
      return this.field_1e09b77c;
   }

   private void setLoadedInternal(boolean var1) {
      this.field_1e09b77c = var1;
   }

}
