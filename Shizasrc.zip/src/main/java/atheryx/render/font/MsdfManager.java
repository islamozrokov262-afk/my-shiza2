package atheryx.render.font;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2960;

public class MsdfManager {
   private static final Map<String, MsdfFont> obf_u00c7_u2201 = new HashMap<String, MsdfFont>();
   private static MsdfFont obf_u2228_u2201;
   private static boolean obf_u00f7_u2201 = false;
   public static MsdfFont SF_REGULAR;
   public static MsdfFont SF_BOLD;
   public static MsdfFont WTMICO;
   public static MsdfFont WOQUED_ICONS;

   public static void init() {
      if (!obf_u00f7_u2201) {
         System.out.println("[MSDF] Initializing MsdfManager...");
         Msdf.SF_REGULAR = SF_REGULAR = registerFont("sf_regular", "sf_regular.png", "sf_regular.json");
         Msdf.SF_BOLD = SF_BOLD = registerFont("sf_bold", "sf_bold.png", "sf_bold.json");
         Msdf.WTMICO = WTMICO = registerFont("wtmico", "wtmico.png", "wtmico.json");
         Msdf.WOQUED_ICONS = WOQUED_ICONS = registerFont("iconswoqued", "iconswoqued.png", "iconswoqued.json");
         setDefaultFont("sf_regular");
         obf_u00f7_u2201 = true;
      }
   }

   public static MsdfFont registerFont(String name, String atlasPath, String jsonPath) {
      MsdfFont font = new MsdfFont(name);
      font.load(class_2960.method_60655("atheryx", atlasPath), class_2960.method_60655("atheryx", jsonPath));
      obf_u00c7_u2201.put(name, font);
      if (obf_u2228_u2201 == null) {
         obf_u2228_u2201 = font;
      }

      return font;
   }

   public static MsdfFont getFont(String name) {
      return obf_u00c7_u2201.get(name);
   }

   public static MsdfFont getDefaultFont() {
      return obf_u2228_u2201;
   }

   public static void setDefaultFont(String name) {
      MsdfFont font = obf_u00c7_u2201.get(name);
      if (font != null) {
         obf_u2228_u2201 = font;
      }

   }

   public static void close() {
      obf_u00c7_u2201.values().forEach(MsdfFont::close);
      obf_u00c7_u2201.clear();
      obf_u2228_u2201 = null;
      obf_u00f7_u2201 = false;
   }

}
