package atheryx.render;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class WorldToScreen {
   private static final class_310 obf_u2202_u220e = class_310.method_1551();

   private WorldToScreen() {
   }

   public static float[] project(class_243 worldPos) {
      class_4184 camera = obf_u2202_u220e.field_1773.method_19418();
      if (camera != null && obf_u2202_u220e.field_1724 != null) {
         class_243 camPos = camera.method_71156();
         Vector3f pos = new Vector3f((float)(worldPos.field_1352 - camPos.field_1352), (float)(worldPos.field_1351 - camPos.field_1351), (float)(worldPos.field_1350 - camPos.field_1350));
         Quaternionf rotation = (new Quaternionf(camera.method_23767())).conjugate();
         pos.rotate(rotation);
         if (pos.z >= 0.0F) {
            return null;
         } else {
            double fov = (double)(Integer)obf_u2202_u220e.field_1690.method_41808().method_41753();
            int fixedW = RenderUtil.getScaledWidth();
            int fixedH = RenderUtil.getScaledHeight();
            float halfW = (float)fixedW * 0.5F;
            float halfH = (float)fixedH * 0.5F;
            float factor = (float)((double)halfH / Math.tan(Math.toRadians(fov) * (double)0.5F)) / -pos.z;
            float screenX = halfW + pos.x * factor;
            float screenY = halfH - pos.y * factor;
            return new float[]{screenX, screenY, factor};
         }
      } else {
         return null;
      }
   }

   public static class_243 interpolateEntityPosition(class_1297 entity, float tickDelta) {
      return entity.method_30950(tickDelta);
   }

}
