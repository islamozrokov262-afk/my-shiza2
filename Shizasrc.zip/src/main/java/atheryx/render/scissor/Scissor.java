package atheryx.render.scissor;

import atheryx.render.RenderUtil;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.class_310;
import org.lwjgl.opengl.GL11;

public class Scissor {
   private static final Deque<ScissorRect> obf_u221c_u0426 = new ArrayDeque<ScissorRect>();

   public static void pushBounds(int x1, int y1, int x2, int y2) {
      push((double)x1, (double)y1, (double)Math.max(0, x2 - x1), (double)Math.max(0, y2 - y1));
   }

   public static void pushBounds(double x1, double y1, double x2, double y2) {
      push(x1, y1, Math.max((double)0.0F, x2 - x1), Math.max((double)0.0F, y2 - y1));
   }

   public static void pop() {
      popTertiary();
   }

   public static void push(double x, double y, double w, double h) {
      push(x, y, w, h, false);
   }

   public static void push(double x, double y, double w, double h, boolean overrideContext) {
      if (overrideContext) {
         RenderUtil.enqueueRenderCall(() -> {
            push(x, y, w, h, false);
         });
      } else {
         ScissorRect current = new ScissorRect(x, y, Math.max((double)0.0F, w), Math.max((double)0.0F, h));
         if (!obf_u221c_u0426.isEmpty()) {
            current = intersect(current, obf_u221c_u0426.peek());
         }

         obf_u221c_u0426.push(current);
         apply(current);
      }
   }

   public static void pushHorizontalBand(double y, double h) {
      pushHorizontalBand(y, h, false);
   }

   public static void pushHorizontalBand(double y, double h, boolean overrideContext) {
      double width = (double)RenderUtil.getScaledWidth();
      push((double)0.0F, y, width, h, overrideContext);
   }

   public static void popSecondary() {
      popSecondary(false);
   }

   public static void pop(boolean overrideContext) {
      popSecondary(overrideContext);
   }

   public static void popTertiary() {
      popSecondary(false);
   }

   public static void popSecondary(boolean overrideContext) {
      if (overrideContext) {
         RenderUtil.enqueueRenderCall(() -> {
            popSecondary(false);
         });
      } else {
         if (!obf_u221c_u0426.isEmpty()) {
            obf_u221c_u0426.pop();
         }

         if (obf_u221c_u0426.isEmpty()) {
            GL11.glDisable(3089);
         } else {
            apply(obf_u221c_u0426.peek());
         }

      }
   }

   public static void drawEdgeShadow(float size, Color shadow) {
      if (!obf_u221c_u0426.isEmpty() && !(size <= 0.0F)) {
         ScissorRect r = obf_u221c_u0426.peek();
         if (!(r.w <= (double)0.0F) && !(r.h <= (double)0.0F)) {
            Color transparent = new Color(shadow.getRed(), shadow.getGreen(), shadow.getBlue(), 0);
            float x = (float)r.x;
            float y = (float)r.y;
            float w = (float)r.w;
            float h = (float)r.h;
            float s = Math.min(size, Math.min(w, h) * 0.5F);
            RenderUtil.drawRoundedRect(x, y, w, s, 0.0F, 0.0F, 0.0F, 0.0F, shadow, shadow, transparent, shadow, shadow, transparent, transparent, transparent, transparent);
            RenderUtil.drawRoundedRect(x, y + h - s, w, s, 0.0F, 0.0F, 0.0F, 0.0F, transparent, transparent, transparent, shadow, shadow, transparent, shadow, shadow, transparent);
            RenderUtil.drawRoundedRect(x, y + s, s, Math.max(0.0F, h - s * 2.0F), 0.0F, 0.0F, 0.0F, 0.0F, shadow, transparent, transparent, shadow, transparent, transparent, shadow, transparent, transparent);
            RenderUtil.drawRoundedRect(x + w - s, y + s, s, Math.max(0.0F, h - s * 2.0F), 0.0F, 0.0F, 0.0F, 0.0F, transparent, transparent, shadow, transparent, transparent, shadow, transparent, transparent, shadow);
         }
      }
   }

   private static ScissorRect intersect(ScissorRect a, ScissorRect b) {
      double nx = Math.max(a.x, b.x);
      double ny = Math.max(a.y, b.y);
      double nw = Math.min(a.x + a.w, b.x + b.w) - nx;
      double nh = Math.min(a.y + a.h, b.y + b.h) - ny;
      return new ScissorRect(nx, ny, Math.max((double)0.0F, nw), Math.max((double)0.0F, nh));
   }

   private static void apply(ScissorRect rect) {
      class_310 mc = class_310.method_1551();
      float scale = (float)mc.method_22683().method_4495();
      float framebufferHeight = (float)RenderUtil.getScaledHeight() * scale;
      int scissorX = (int)Math.floor(rect.x * (double)scale);
      int scissorY = (int)Math.floor((double)framebufferHeight - (rect.y + rect.h) * (double)scale);
      int scissorW = (int)Math.ceil(rect.w * (double)scale);
      int scissorH = (int)Math.ceil(rect.h * (double)scale);
      GL11.glEnable(3089);
      GL11.glScissor(Math.max(0, scissorX), Math.max(0, scissorY), Math.max(0, scissorW), Math.max(0, scissorH));
   }


   private static record ScissorRect(double x, double y, double w, double h) {
      public double x() {
         return this.getXInternal();
      }

      public double y() {
         return this.getYInternal();
      }

      public double w() {
         return this.getWidthInternal();
      }

      public double h() {
         return this.getHeightInternal();
      }

      private double getXInternal() {
         return this.x;
      }

      private double getYInternal() {
         return this.y;
      }

      private double getWidthInternal() {
         return this.w;
      }

      private double getHeightInternal() {
         return this.h;
      }

   }
}
