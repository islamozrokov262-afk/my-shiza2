package atheryx.render.scissor;

import atheryx.render.RenderUtil;
import atheryx.render.font.Msdf;
import atheryx.render.font.MsdfFont;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_332;

public class TextScissor {
   private static final Map<String, Float> obf_u03b2_u0426 = new HashMap<String, Float>();
   private static final Map<String, Long> obf_u220e_u0426 = new HashMap<String, Long>();

   public static void drawScrollingText(class_332 context, MsdfFont font, String text, float x, float y, float fontSize, float maxWidth, float fadeWidth, int textColor, int bgColor, boolean scaled, String key, float mouseX, float mouseY, float areaHeight) {
      if (font != null && text != null && !text.isEmpty()) {
         float textWidth = Msdf.getTextWidth(font, text, fontSize);
         if (textWidth <= maxWidth) {
            Msdf.drawText(context, font, text, x, y, fontSize, textColor, scaled);
         } else {
            long now = System.currentTimeMillis();
            long lastTime = (Long)obf_u220e_u0426.getOrDefault(key, now);
            float dt = Math.min((float)(now - lastTime) / 1000.0F, 0.05F);
            obf_u220e_u0426.put(key, now);
            float currentOffset = (Float)obf_u03b2_u0426.getOrDefault(key, 0.0F);
            boolean hovered = mouseX >= x && mouseX <= x + maxWidth && mouseY >= y - 2.0F && mouseY <= y + areaHeight + 2.0F;
            float overflow = textWidth - maxWidth;
            float targetOffset = 0.0F;
            if (hovered) {
               targetOffset = -(overflow + 4.0F);
            }

            float hoverSpeed = Math.max(0.8F, 3.0F - overflow / 60.0F);
            float returnSpeed = Math.max(1.5F, 5.0F - overflow / 80.0F);
            float speed = hovered ? hoverSpeed : returnSpeed;
            currentOffset += (targetOffset - currentOffset) * Math.min(dt * speed, 1.0F);
            if (Math.abs(currentOffset - targetOffset) < 0.05F) {
               currentOffset = targetOffset;
            }

            obf_u03b2_u0426.put(key, currentOffset);
            float renderX = x + currentOffset;
            Scissor.push((double)x, (double)(y - 2.0F), (double)maxWidth, (double)(fontSize + 6.0F), scaled);
            Msdf.drawText(context, font, text, renderX, y, fontSize, textColor, scaled);
            Scissor.popSecondary(scaled);
            int bgR = bgColor >> 16 & 255;
            int bgG = bgColor >> 8 & 255;
            int bgB = bgColor & 255;
            int bgA = bgColor >> 24 & 255;
            Color transparent = new Color(bgR, bgG, bgB, 0);
            Color opaque = new Color(bgR, bgG, bgB, bgA);
            float fadeX = x + maxWidth - fadeWidth;
            float fadeY = y - 2.0F;
            float fadeH = fontSize + 6.0F;
            RenderUtil.drawRoundedRect(fadeX, fadeY, fadeWidth, fadeH, 0.0F, 0.0F, 0.0F, 0.0F, transparent, opaque, opaque, transparent);
         }
      }
   }

   public static void drawScrollingText(class_332 context, MsdfFont font, String text, float x, float y, float fontSize, float maxWidth, int textColor, int bgColor, boolean scaled, String key, float mouseX, float mouseY, float areaHeight) {
      drawScrollingText(context, font, text, x, y, fontSize, maxWidth, 14.0F, textColor, bgColor, scaled, key, mouseX, mouseY, areaHeight);
   }

   public static void drawClippedText(class_332 context, MsdfFont font, String text, float x, float y, float fontSize, float maxWidth, float fadeWidth, int textColor, int bgColor, boolean scaled) {
      if (font != null && text != null && !text.isEmpty()) {
         float textWidth = Msdf.getTextWidth(font, text, fontSize);
         if (textWidth <= maxWidth) {
            Msdf.drawText(context, font, text, x, y, fontSize, textColor, scaled);
         } else {
            Scissor.push((double)x, (double)(y - 2.0F), (double)maxWidth, (double)(fontSize + 6.0F), scaled);
            Msdf.drawText(context, font, text, x, y, fontSize, textColor, scaled);
            Scissor.popSecondary(scaled);
            int bgR = bgColor >> 16 & 255;
            int bgG = bgColor >> 8 & 255;
            int bgB = bgColor & 255;
            int bgA = bgColor >> 24 & 255;
            Color transparent = new Color(bgR, bgG, bgB, 0);
            Color opaque = new Color(bgR, bgG, bgB, bgA);
            float fadeX = x + maxWidth - fadeWidth;
            float fadeY = y - 2.0F;
            float fadeH = fontSize + 6.0F;
            RenderUtil.drawRoundedRect(fadeX, fadeY, fadeWidth, fadeH, 0.0F, 0.0F, 0.0F, 0.0F, transparent, opaque, opaque, transparent);
         }
      }
   }

   public static void resetScrollState(String key) {
      obf_u03b2_u0426.remove(key);
      obf_u220e_u0426.remove(key);
   }

}
