package atheryx.render;

import atheryx.render.font.Msdf;
import atheryx.render.font.MsdfFont;
import atheryx.render.font.MsdfManager;
import atheryx.render.pipeline.BlurPipeline;
import atheryx.render.pipeline.CirclePipeline;
import atheryx.render.pipeline.FluidGlassPipeline;
import atheryx.render.pipeline.GlowOutlinePipeline;
import atheryx.render.pipeline.GlowPipeline;
import atheryx.render.pipeline.HudBlurPipeline;
import atheryx.render.pipeline.LiquidGlassPipeline;
import atheryx.render.pipeline.OutlinePipeline;
import atheryx.render.pipeline.RectPipeline;
import atheryx.render.pipeline.TexturePipeline;
import atheryx.util.color.ColorHelper;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1041;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_408;
import org.joml.Matrix4f;

public class RenderUtil {
   private static final List<Runnable> obf_u2234_u220e = new ArrayList<Runnable>();
   private static final float obf_u03b1_u220e = 0.0F;
   private static final int obf_u0433_u220e = 2;

   public static void enqueueRenderCall(Runnable runnable) {
      obf_u2234_u220e.add(runnable);
   }

   public static int getScaledWidth() {
      class_1041 window = class_310.method_1551().method_22683();
        return window.method_4486();
   }

   public static int getScaledHeight() {
      class_1041 window = class_310.method_1551().method_22683();
        return window.method_4502();
   }

   public static Matrix4f createGuiProjection() {
      return (new Matrix4f()).ortho(0.0F, (float)getScaledWidth(), (float)getScaledHeight(), 0.0F, -1000.0F, 1000.0F);
   }

   public static float getCoordinateScale() {
      // Screen callbacks and Window#getScaledWidth/Height already use GUI-scaled coordinates.
      return 1.0F;
   }

   public static float toScaledX(float x) {
      return x * getCoordinateScale();
   }

   public static float toScaledY(float y) {
      return y * getCoordinateScale();
   }

   public static void drawRoundedRect(Matrix4f matrix, float x, float y, float width, float height, float tl, float tr, float br, float bl, boolean overrideContext, Color... colors) {
      if (overrideContext) {
         obf_u2234_u220e.add((Runnable)() -> {
            RectPipeline.drawRoundedRect(matrix, x, y, width, height, tl, tr, br, bl, 0.0F, ColorHelper.toArgbArray(colors));
         });
      } else {
         RectPipeline.drawRoundedRect(matrix, x, y, width, height, tl, tr, br, bl, 0.0F, ColorHelper.toArgbArray(colors));
      }
   }

   public static void drawRoundedRect(float x, float y, float width, float height, float tl, float tr, float br, float bl, Color... colors) {
      drawRoundedRect(createGuiProjection(), x, y, width, height, tl, tr, br, bl, false, colors);
   }

   public static void drawRoundedRect(float x, float y, float width, float height, float radius, Color... colors) {
      drawRoundedRect(createGuiProjection(), x, y, width, height, radius, radius, radius, radius, false, colors);
   }

   public static void drawBlurredRect(float x, float y, float width, float height, float radius, float strength) {
      BlurPipeline.renderBlur(createGuiProjection(), x, y, width, height, radius, strength, 0.0F);
   }

   public static void drawHudBlur(float x, float y, float width, float height, float tl, float tr, float br, float bl, float blurRadius, float alpha, Color tint) {
      HudBlurPipeline.drawBlurredRect(createGuiProjection(), x, y, width, height, tl, tr, br, bl, blurRadius, alpha, tint, 0.0F);
   }

   public static void drawHudBlur(float x, float y, float width, float height, float radius, float blurRadius, float alpha, Color tint) {
      drawHudBlur(x, y, width, height, radius, radius, radius, radius, blurRadius, alpha, tint);
   }

   public static void drawLiquidGlass(float x, float y, float width, float height, float radius, float strength, float alpha, Color tint) {
      LiquidGlassPipeline.render(createGuiProjection(), x, y, width, height, radius, strength, alpha, ColorHelper.toArgb(tint), 0.0F);
   }

   public static void drawFluidGlass(float x, float y, float width, float height, float radius, float strength, float alpha, Color tint) {
      FluidGlassPipeline.render(createGuiProjection(), x, y, width, height, radius, strength, alpha, ColorHelper.toArgb(tint), 0.0F);
   }

   public static void drawRoundedOutline(float x, float y, float width, float height, float tl, float tr, float br, float bl, float thickness, Color... colors) {
      OutlinePipeline.drawRoundedOutline(createGuiProjection(), x, y, width, height, tl, tr, br, bl, thickness, 0.0F, ColorHelper.toArgbArray(colors));
   }

   public static void drawRoundedOutline(float x, float y, float width, float height, float radius, float thickness, Color... colors) {
      OutlinePipeline.drawRoundedOutline(createGuiProjection(), x, y, width, height, radius, radius, radius, radius, thickness, 0.0F, ColorHelper.toArgbArray(colors));
   }

   public static void drawGlowingText(class_332 context, float x, float y, String text, float size, Color textColor, Color glowColor, float intensity) {
      Msdf.drawGlowingText(context, text, x, y, size, ColorHelper.toArgb(textColor), ColorHelper.toArgb(glowColor), intensity, false);
   }

   public static void drawGlowingText(class_332 context, MsdfFont font, float x, float y, String text, float size, Color textColor, Color glowColor, float intensity) {
      Msdf.drawGlowingText(context, font, text, x, y, size, ColorHelper.toArgb(textColor), ColorHelper.toArgb(glowColor), intensity, false);
   }

   public static void drawText(class_332 context, float x, float y, String text, float size, Color color) {
      Msdf.drawText(context, text, x, y, size, ColorHelper.toArgb(color), false);
   }

   public static void drawAlignedText(class_332 context, float x, float y, String text, float size, Color color, String align) {
      if (align.equals("center")) {
         Msdf.drawCenteredText(context, text, x, y, size, ColorHelper.toArgb(color));
      } else if (align.equals("right")) {
         Msdf.drawRightAlignedText(context, text, x, y, size, ColorHelper.toArgb(color));
      } else {
         Msdf.drawText(context, text, x, y, size, ColorHelper.toArgb(color));
      }

   }

   public static void drawAlignedGradientText(class_332 context, float x, float y, String text, float size, Color startColor, Color endColor, String align) {
      if (align.equals("center")) {
         Msdf.drawCenteredGradientText(context, text, x, y, size, ColorHelper.toArgb(startColor), ColorHelper.toArgb(endColor));
      } else if (align.equals("right")) {
         Msdf.drawRightAlignedGradientText(context, text, x, y, size, ColorHelper.toArgb(startColor), ColorHelper.toArgb(endColor));
      } else {
         Msdf.drawGradientText(context, text, x, y, size, ColorHelper.toArgb(startColor), ColorHelper.toArgb(endColor));
      }

   }

   public static void drawText(class_332 context, MsdfFont font, float x, float y, String text, float size, Color color) {
      Msdf.drawText(context, font, text, x, y, size, ColorHelper.toArgb(color), false);
   }

   public static void drawMulticolorText(class_332 context, float x, float y, String text, float size, Color... color) {
      Msdf.drawMulticolorText(context, MsdfManager.getDefaultFont(), text, x, y, size, false, ColorHelper.toArgbArray(color));
   }

   public static void drawTexture(float x, float y, float size, class_2960 texture, float radius, Color color) {
      class_310 client = class_310.method_1551();
      class_1044 tex = client.method_1531().method_4619(texture);
      TexturePipeline.drawSquareTexture(createGuiProjection(), x, y, size, tex.method_71659(), ColorHelper.toArgb(color), radius, 0.0F);
   }

   public static void drawGlowDot(float x, float y, float size, Color color) {
      GlowPipeline.drawGlow(createGuiProjection(), x, y, size, ColorHelper.toArgb(color), 0.0F);
   }

   public static void drawCircle(float cx, float cy, float radius, float thickness, Color color) {
      CirclePipeline.drawCircle(createGuiProjection(), cx, cy, radius, thickness, 0.0F, color);
   }

   public static void drawArc(float cx, float cy, float radius, float thickness, float startAngle, float progress, Color color) {
      CirclePipeline.drawArc(createGuiProjection(), cx, cy, radius, thickness, startAngle, progress, 0.0F, color);
   }

   public static void drawGlowOutline(float x, float y, float width, float height, float thickness, float radius, Color color) {
      drawGlowOutline(x, y, width, height, thickness, radius, 0.0F, 1.0F, 0.0F, color);
   }

   public static void drawProgressGlowOutline(float x, float y, float width, float height, float thickness, float radius, float progress, Color color) {
      drawGlowOutline(x, y, width, height, thickness, radius, 0.0F, 1.0F, Math.clamp(progress, 0.0F, 1.0F), color);
   }

   public static void drawGlowOutline(float x, float y, float width, float height, float thickness, float radius, float glowSize, float glowIntensity, float glowSoftness, Color color) {
      GlowOutlinePipeline.render(createGuiProjection(), x, y, width, height, thickness, ColorHelper.toArgb(color), radius, glowSize, Math.clamp(glowIntensity, 0.0F, 1.0F), glowSoftness, 1.0F, 0.0F);
   }

   public static void drawShadow(float x, float y, float width, float height, float radius, float size, float intensity, float softness, Color color) {
      if (!(size <= 0.0F) && !(intensity <= 0.0F)) {
         GlowOutlinePipeline.render(createGuiProjection(), x, y, width, height, 0.0F, ColorHelper.toArgb(color), radius, size, Math.clamp(intensity, 0.0F, 1.0F), Math.max(0.1F, softness), 1.0F, 0.0F);
      }
   }

   public static void drawDefaultShadow(float x, float y, float width, float height, float radius, Color color) {
      drawShadow(x, y, width, height, radius, 12.0F, 0.55F, 2.20000005F, color);
   }

   public static boolean isGuiRenderContext() {
      class_310 client = class_310.method_1551();
      return client.field_1755 == null || client.field_1755 instanceof class_408;
   }

   public static void drawAlignedText(class_332 context, MsdfFont font, float x, float y, String text, float size, Color color, String align) {
      float drawX = x;
      if (align.equals("center")) {
         drawX = x - Msdf.getTextWidth(font, text, size) / 2.0F;
      } else if (align.equals("right")) {
         drawX = x - Msdf.getTextWidth(font, text, size);
      }

      Msdf.drawText(context, font, text, drawX, y, size, ColorHelper.toArgb(color), false);
   }

}
