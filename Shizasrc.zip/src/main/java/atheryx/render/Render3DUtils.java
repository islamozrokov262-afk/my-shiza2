package atheryx.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import java.util.function.Function;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_10799;
import net.minecraft.class_12247;
import net.minecraft.class_12249;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class Render3DUtils {
   private static final RenderPipeline obf_u00ef_u220e;
   public static final Function<class_2960, class_1921> ADDITIVE_TEXTURE_LAYER;
   private static final RenderPipeline obf_u0454_u220e;
   public static final Function<class_2960, class_1921> ADDITIVE_TEXTURE_NO_DEPTH_LAYER;
   private static final RenderPipeline obf_u0396_u220e;
   private static final Function<class_2960, class_1921> obf_u2235_u220e;

   private Render3DUtils() {
   }

   public static BillboardBatch beginTexturedBillboards(WorldRenderContext context, class_2960 texture) {
      return createBillboardBatch(context, class_12249.method_75984(texture, false));
   }

   public static BillboardBatch beginAdditiveBillboards(WorldRenderContext context, class_2960 texture) {
      return createBillboardBatch(context, ADDITIVE_TEXTURE_LAYER.apply(texture));
   }

   public static BillboardBatch beginAdditiveBillboardsNoDepth(WorldRenderContext context, class_2960 texture) {
      return createBillboardBatch(context, ADDITIVE_TEXTURE_NO_DEPTH_LAYER.apply(texture));
   }

   public static BillboardBatch beginOverlayBillboards(WorldRenderContext context, class_2960 texture) {
      return createBillboardBatch(context, obf_u2235_u220e.apply(texture));
   }

   public static BillboardBatch createBillboardBatch(WorldRenderContext context, class_1921 layer) {
      class_243 camera = context.worldState().field_63082.field_63078;
      Quaternionf orientation = context.worldState().field_63082.field_63081;
      Vector3f cameraRight = orientation.transform(new Vector3f(1.0F, 0.0F, 0.0F));
      Vector3f cameraUp = orientation.transform(new Vector3f(0.0F, 1.0F, 0.0F));
      class_4588 buffer = context.consumers().method_73477(layer);
      return new BillboardBatch(buffer, camera, cameraRight, cameraUp);
   }

   public static GroundQuadBatch beginGroundQuads(WorldRenderContext context, class_2960 texture) {
      class_243 camera = context.worldState().field_63082.field_63078;
      class_4588 buffer = context.consumers().method_73477(class_12249.method_75984(texture, false));
      return new GroundQuadBatch(buffer, camera);
   }

   public static GroundQuadBatch beginAdditiveGroundQuads(WorldRenderContext context, class_2960 texture) {
      class_243 camera = context.worldState().field_63082.field_63078;
      class_4588 buffer = context.consumers().method_73477(ADDITIVE_TEXTURE_LAYER.apply(texture));
      return new GroundQuadBatch(buffer, camera);
   }

   public static void drawBillboard(WorldRenderContext context, class_2960 texture, class_243 position, float size, float rotationDegrees, float alpha) {
      beginTexturedBillboards(context, texture).drawBillboard(position, size, rotationDegrees, alpha);
   }

   public static void drawAdditiveBillboard(WorldRenderContext context, class_2960 texture, class_243 position, float size, float rotationDegrees, float alpha) {
      beginAdditiveBillboards(context, texture).drawBillboard(position, size, rotationDegrees, alpha);
   }

   public static void drawGlowingBillboard(WorldRenderContext context, class_2960 texture, class_243 position, float size, float rotationDegrees, float alpha, float glowScale, float glowAlpha) {
      beginAdditiveBillboards(context, texture).drawGlowingBillboard(position, size, rotationDegrees, alpha, glowScale, glowAlpha);
   }

   public static void drawBillboardWithGlowTexture(WorldRenderContext context, class_2960 texture, class_2960 glowTexture, class_243 position, float size, float rotationDegrees, float alpha, float glowScale, float glowAlpha) {
      beginAdditiveBillboards(context, glowTexture).drawBillboard(position, size * glowScale, rotationDegrees, alpha * glowAlpha);
      beginAdditiveBillboards(context, texture).drawBillboard(position, size, rotationDegrees, alpha);
   }

   public static TexturedCubeBatch beginRotatedQuads(WorldRenderContext context, class_2960 texture) {
      class_243 camera = context.worldState().field_63082.field_63078;
      class_4588 buffer = context.consumers().method_73477(ADDITIVE_TEXTURE_NO_DEPTH_LAYER.apply(texture));
      return new TexturedCubeBatch(buffer, camera);
   }

   public static ColoredGeometryBatch beginLineBatch(WorldRenderContext context, class_2960 texture) {
      class_243 camera = context.worldState().field_63082.field_63078;
      class_4588 buffer = context.consumers().method_73477(ADDITIVE_TEXTURE_NO_DEPTH_LAYER.apply(texture));
      return new ColoredGeometryBatch(buffer, camera);
   }

   static {
      obf_u00ef_u220e = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_60794}).withLocation(class_2960.method_60655("atheryx", "additive_textured_billboard")).withShaderDefine("PER_FACE_LIGHTING").withSampler("Sampler1").withBlend(BlendFunction.LIGHTNING).withCull(false).withDepthWrite(false).build());
      ADDITIVE_TEXTURE_LAYER = class_156.method_34866((texture) -> {
         return class_1921.method_75940("atheryx_additive_textured_billboard", class_12247.method_75927(obf_u00ef_u220e).method_75934("Sampler0", texture).method_75935().method_75937().method_75929(1536).method_75938());
      });
      obf_u0454_u220e = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_60794}).withLocation(class_2960.method_60655("atheryx", "additive_textured_billboard_no_depth")).withShaderDefine("PER_FACE_LIGHTING").withSampler("Sampler1").withBlend(BlendFunction.LIGHTNING).withCull(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).build());
      ADDITIVE_TEXTURE_NO_DEPTH_LAYER = class_156.method_34866((texture) -> {
         return class_1921.method_75940("atheryx_additive_textured_billboard_no_depth", class_12247.method_75927(obf_u0454_u220e).method_75934("Sampler0", texture).method_75935().method_75937().method_75929(1536).method_75938());
      });
      obf_u0396_u220e = class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_60794}).withLocation(class_2960.method_60655("atheryx", "textured_billboard_no_depth")).withShaderDefine("PER_FACE_LIGHTING").withSampler("Sampler1").withBlend(BlendFunction.TRANSLUCENT).withCull(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).build());
      obf_u2235_u220e = class_156.method_34866((texture) -> {
         return class_1921.method_75940("atheryx_textured_billboard_no_depth", class_12247.method_75927(obf_u0396_u220e).method_75934("Sampler0", texture).method_75935().method_75937().method_75929(1536).method_75938());
      });
   }


   public static class TexturedCubeBatch {
      private final class_4588 field_6d2b79f5;
      private final class_243 field_da56f3ea;

      private TexturedCubeBatch(class_4588 buffer, class_243 camera) {
         this.field_6d2b79f5 = buffer;
         this.field_da56f3ea = camera;
      }

      public void drawRotatedQuad(class_243 position, float size, float rotX, float rotY, float rotZ, int red, int green, int blue, float alpha) {
         if (!(alpha <= 0.0F) && !(size <= 0.0F)) {
            float half = size * 0.5F;
            Quaternionf rotation = (new Quaternionf()).rotateX(rotX * ((float)Math.PI / 180F)).rotateY(rotY * ((float)Math.PI / 180F)).rotateZ(rotZ * ((float)Math.PI / 180F));
            Vector3f[] v = new Vector3f[]{this.transformVertex(-half, -half, -half, rotation, position), this.transformVertex(half, -half, -half, rotation, position), this.transformVertex(half, half, -half, rotation, position), this.transformVertex(-half, half, -half, rotation, position), this.transformVertex(-half, -half, half, rotation, position), this.transformVertex(half, -half, half, rotation, position), this.transformVertex(half, half, half, rotation, position), this.transformVertex(-half, half, half, rotation, position)};
            this.emitQuad(v[0], v[1], v[2], v[3], red, green, blue, alpha);
            this.emitQuad(v[5], v[4], v[7], v[6], red, green, blue, alpha);
            this.emitQuad(v[4], v[0], v[3], v[7], red, green, blue, alpha);
            this.emitQuad(v[1], v[5], v[6], v[2], red, green, blue, alpha);
            this.emitQuad(v[3], v[2], v[6], v[7], red, green, blue, alpha);
            this.emitQuad(v[4], v[5], v[1], v[0], red, green, blue, alpha);
         }
      }

      private Vector3f transformVertex(float x, float y, float z, Quaternionf rotation, class_243 position) {
         Vector3f out = (new Vector3f(x, y, z)).rotate(rotation);
         out.add((float)(position.field_1352 - this.getCameraPositionInternal().field_1352), (float)(position.field_1351 - this.getCameraPositionInternal().field_1351), (float)(position.field_1350 - this.getCameraPositionInternal().field_1350));
         return out;
      }

      private void emitQuad(Vector3f a, Vector3f b, Vector3f c, Vector3f d, int red, int green, int blue, float alpha) {
         this.emitVertex(a, 0.0F, 1.0F, red, green, blue, alpha);
         this.emitVertex(b, 1.0F, 1.0F, red, green, blue, alpha);
         this.emitVertex(c, 1.0F, 0.0F, red, green, blue, alpha);
         this.emitVertex(d, 0.0F, 0.0F, red, green, blue, alpha);
      }

      private void emitVertex(Vector3f pos, float u, float v, int red, int green, int blue, float alpha) {
         this.getBufferInternal().method_22912(pos.x, pos.y, pos.z).method_1336(red, green, blue, (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F)).method_22913(u, v).method_22922(class_4608.field_21444).method_60803(15728880).method_22914(0.0F, 1.0F, 0.0F);
      }

      private class_4588 getBufferInternal() {
         return this.field_6d2b79f5;
      }

      private class_243 getCameraPositionInternal() {
         return this.field_da56f3ea;
      }

   }

   public static class BillboardBatch {
      private final class_4588 field_6d2b79f5;
      private final class_243 field_da56f3ea;
      private final Vector3f field_47826ddf;
      private final Vector3f field_b4ade7d4;

      private BillboardBatch(class_4588 buffer, class_243 camera, Vector3f cameraRight, Vector3f cameraUp) {
         this.field_6d2b79f5 = buffer;
         this.field_da56f3ea = camera;
         this.field_47826ddf = cameraRight;
         this.field_b4ade7d4 = cameraUp;
      }

      public void drawBillboard(class_243 position, float size, float rotationDegrees, float alpha) {
         this.drawColoredBillboard(position, size, rotationDegrees, 255, 255, 255, alpha);
      }

      public void drawColoredBillboard(class_243 position, float size, float rotationDegrees, int red, int green, int blue, float alpha) {
         this.emitBillboardQuad(position, size, rotationDegrees, red, green, blue, alpha);
      }

      public void drawGlowingBillboard(class_243 position, float size, float rotationDegrees, float alpha, float glowScale, float glowAlpha) {
         this.drawColoredGlowingBillboard(position, size, rotationDegrees, 255, 255, 255, alpha, glowScale, glowAlpha);
      }

      public void drawColoredGlowingBillboard(class_243 position, float size, float rotationDegrees, int red, int green, int blue, float alpha, float glowScale, float glowAlpha) {
         if (!(alpha <= 0.0F)) {
            this.emitBillboardQuad(position, size * glowScale, rotationDegrees, red, green, blue, alpha * glowAlpha);
            this.emitBillboardQuad(position, size, rotationDegrees, red, green, blue, alpha);
         }
      }

      private void emitBillboardQuad(class_243 position, float size, float rotationDegrees, int red, int green, int blue, float alpha) {
         float spin = rotationDegrees * ((float)Math.PI / 180F);
         Vector3f right = (new Vector3f(this.getCameraRightInternal())).mul((float)Math.cos((double)spin)).add((new Vector3f(this.getCameraUpInternal())).mul((float)Math.sin((double)spin))).mul(size);
         Vector3f up = (new Vector3f(this.getCameraUpInternal())).mul((float)Math.cos((double)spin)).sub((new Vector3f(this.getCameraRightInternal())).mul((float)Math.sin((double)spin))).mul(size);
         float x = (float)(position.field_1352 - this.getCameraPositionInternal().field_1352);
         float y = (float)(position.field_1351 - this.getCameraPositionInternal().field_1351);
         float z = (float)(position.field_1350 - this.getCameraPositionInternal().field_1350);
         this.emitVertex(x - right.x - up.x, y - right.y - up.y, z - right.z - up.z, 0.0F, 1.0F, red, green, blue, alpha);
         this.emitVertex(x - right.x + up.x, y - right.y + up.y, z - right.z + up.z, 0.0F, 0.0F, red, green, blue, alpha);
         this.emitVertex(x + right.x + up.x, y + right.y + up.y, z + right.z + up.z, 1.0F, 0.0F, red, green, blue, alpha);
         this.emitVertex(x + right.x - up.x, y + right.y - up.y, z + right.z - up.z, 1.0F, 1.0F, red, green, blue, alpha);
      }

      private void emitVertex(float x, float y, float z, float u, float v, int red, int green, int blue, float alpha) {
         this.getBufferInternal().method_22912(x, y, z).method_1336(red, green, blue, (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F)).method_22913(u, v).method_22922(class_4608.field_21444).method_60803(15728880).method_22914(0.0F, 1.0F, 0.0F);
      }

      private class_4588 getBufferInternal() {
         return this.field_6d2b79f5;
      }

      private class_243 getCameraPositionInternal() {
         return this.field_da56f3ea;
      }

      private Vector3f getCameraRightInternal() {
         return this.field_47826ddf;
      }

      private Vector3f getCameraUpInternal() {
         return this.field_b4ade7d4;
      }

   }

   public static class GroundQuadBatch {
      private final class_4588 field_6d2b79f5;
      private final class_243 field_da56f3ea;

      private GroundQuadBatch(class_4588 buffer, class_243 camera) {
         this.field_6d2b79f5 = buffer;
         this.field_da56f3ea = camera;
      }

      public void drawColoredBillboard(class_243 position, float size, float rotationDegrees, int red, int green, int blue, float alpha) {
         if (!(alpha <= 0.0F) && !(size <= 0.0F)) {
            float half = size * 0.5F;
            float spin = rotationDegrees * ((float)Math.PI / 180F);
            float cos = (float)Math.cos((double)spin);
            float sin = (float)Math.sin((double)spin);
            this.emitGroundVertex(position, -half, -half, cos, sin, 0.0F, 1.0F, red, green, blue, alpha);
            this.emitGroundVertex(position, -half, half, cos, sin, 0.0F, 0.0F, red, green, blue, alpha);
            this.emitGroundVertex(position, half, half, cos, sin, 1.0F, 0.0F, red, green, blue, alpha);
            this.emitGroundVertex(position, half, -half, cos, sin, 1.0F, 1.0F, red, green, blue, alpha);
         }
      }

      private void emitGroundVertex(class_243 position, float localX, float localZ, float cos, float sin, float u, float v, int red, int green, int blue, float alpha) {
         float rotatedX = localX * cos - localZ * sin;
         float rotatedZ = localX * sin + localZ * cos;
         this.getBufferInternal().method_22912((float)(position.field_1352 - this.getCameraPositionInternal().field_1352) + rotatedX, (float)(position.field_1351 - this.getCameraPositionInternal().field_1351), (float)(position.field_1350 - this.getCameraPositionInternal().field_1350) + rotatedZ).method_1336(red, green, blue, (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F)).method_22913(u, v).method_22922(class_4608.field_21444).method_60803(15728880).method_22914(0.0F, 1.0F, 0.0F);
      }

      private class_4588 getBufferInternal() {
         return this.field_6d2b79f5;
      }

      private class_243 getCameraPositionInternal() {
         return this.field_da56f3ea;
      }

   }

   public static class ColoredGeometryBatch {
      private final class_4588 field_6d2b79f5;
      private final class_243 field_da56f3ea;

      private ColoredGeometryBatch(class_4588 buffer, class_243 camera) {
         this.field_6d2b79f5 = buffer;
         this.field_da56f3ea = camera;
      }

      public void drawQuad(class_243 a, class_243 b, class_243 c, class_243 d, int red, int green, int blue, float alpha) {
         this.emitVertex(a, red, green, blue, alpha);
         this.emitVertex(b, red, green, blue, alpha);
         this.emitVertex(c, red, green, blue, alpha);
         this.emitVertex(d, red, green, blue, alpha);
      }

      private void emitVertex(class_243 pos, int red, int green, int blue, float alpha) {
         this.getBufferInternal().method_22912((float)(pos.field_1352 - this.getCameraPositionInternal().field_1352), (float)(pos.field_1351 - this.getCameraPositionInternal().field_1351), (float)(pos.field_1350 - this.getCameraPositionInternal().field_1350)).method_1336(red, green, blue, (int)(Math.clamp(alpha, 0.0F, 1.0F) * 255.0F));
      }

      public void drawLine(class_243 from, class_243 to, int red, int green, int blue, float alphaFrom, float alphaTo) {
         this.emitVertex(from, red, green, blue, alphaFrom);
         this.emitVertex(to, red, green, blue, alphaTo);
      }

      private class_4588 getBufferInternal() {
         return this.field_6d2b79f5;
      }

      private class_243 getCameraPositionInternal() {
         return this.field_da56f3ea;
      }

   }
}
