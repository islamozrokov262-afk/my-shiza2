package atheryx.internal;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.invoke.MethodHandles;
import java.nio.charset.StandardCharsets;
import java.security.CodeSource;
import java.security.Key;
import java.security.MessageDigest;
import java.security.PermissionCollection;
import java.security.ProtectionDomain;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import shiza.protect.jvm.Arga;

public final class RuntimeCipher {
   private static final int[] f_1_ddcb = new int[]{1059723719, 189697313, 2085697898, 513492944, 1721944127, 762443192, 1489299770};
   private static volatile int[] f_2_5537;
   private static final int[] f_3_3407 = new int[]{765407652, 1992839602, 165992335, 1519630272};
   private static final byte[] f_4_66d3 = new byte[]{83, 72, 90, 71};
   private static final int f_5_1900 = 1;
   public static final int f_6_975e = 4096;
   private static final char[] f_7_f094 = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
   private static final int f_8_bf3f = 5350851;

   private RuntimeCipher() {
   }

   public static String bootstrapString(MethodHandles.Lookup lookup, String name, Class<?> type, String data) {
      int classKey = computeLookupClassKey(lookup);

      try {
         byte[] payload = decodeBitString(data);
         if (payload.length < 17) {
            return "";
         } else {
            byte[] iv = Arrays.copyOfRange(payload, 0, 16);
            byte[] cipher = Arrays.copyOfRange(payload, 16, payload.length);
            byte[] aesKey = deriveStringAesKey(classKey, name);
            byte[] plain = decryptAesCtr(aesKey, iv, cipher);
            return new String(plain, StandardCharsets.UTF_8);
         }
      } catch (Throwable var10) {
         return "";
      }
   }

   public static byte[] decodeBitString(String data) {
      if (data != null && data.length() % 8 == 0) {
         byte[] out = new byte[data.length() / 8];

         for(int i = 0; i < out.length; ++i) {
            int v = 0;

            for(int j = 0; j < 8; ++j) {
               v = v << 1 | (data.charAt(i * 8 + j) == 'l' ? 1 : 0);
            }

            out[i] = (byte)v;
         }

         return out;
      } else {
         return new byte[0];
      }
   }

   public static String encodeBitString(byte[] in) {
      if (in == null) {
         return "";
      } else {
         StringBuilder sb = new StringBuilder(in.length * 8);

         for(byte b : in) {
            for(int i = 7; i >= 0; --i) {
               sb.append((char)((b >> i & 1) == 0 ? '0' : 'l'));
            }
         }

         return sb.toString();
      }
   }

   public static int bootstrapInt(MethodHandles.Lookup lookup, String name, Class<?> type, long raw) {
      return (int)(raw ^ deriveConstantXorKey(computeLookupClassKey(lookup), name));
   }

   public static long bootstrapLong(MethodHandles.Lookup lookup, String name, Class<?> type, long raw) {
      return raw ^ deriveConstantXorKey(computeLookupClassKey(lookup), name);
   }

   public static float bootstrapFloat(MethodHandles.Lookup lookup, String name, Class<?> type, long raw) {
      return Float.intBitsToFloat((int)(raw ^ deriveConstantXorKey(computeLookupClassKey(lookup), name)));
   }

   public static double bootstrapDouble(MethodHandles.Lookup lookup, String name, Class<?> type, long raw) {
      return Double.longBitsToDouble(raw ^ deriveConstantXorKey(computeLookupClassKey(lookup), name));
   }

   public static int computeClassKey(String internalName) {
      return internalName.hashCode() * -1640531535 ^ 5350851;
   }

   public static int computeLookupClassKey(MethodHandles.Lookup lookup) {
      return computeClassKey(lookup.lookupClass().getName().replace('.', '/'));
   }

   public static byte[] intToBigEndianBytes(int v) {
      return new byte[]{(byte)(v >>> 24), (byte)(v >>> 16), (byte)(v >>> 8), (byte)v};
   }

   public static byte[] utf8Bytes(String name) {
      return name.getBytes(StandardCharsets.UTF_8);
   }

   private static int computeKeySeed() {
      int m = 5350851;

      for(int p : f_1_ddcb) {
         m ^= p;
      }

      return m;
   }

   private static int computeKeyDerivationRounds(int classKey, String name) {
      return 3 + ((classKey * 4577779 ^ name.hashCode() * 521288629) & 15);
   }

   public static byte[] deriveClassResourceKey(int classKey, String name) {
      try {
         MessageDigest sha = MessageDigest.getInstance("SHA-256");
         sha.update(intToBigEndianBytes(classKey));
         sha.update(utf8Bytes(name));
         sha.update(intToBigEndianBytes(computeKeySeed()));
         byte[] key = sha.digest();
         int rounds = computeKeyDerivationRounds(classKey, name);

         for(int i = 0; i < rounds; ++i) {
            sha = MessageDigest.getInstance("SHA-256");
            sha.update(key);
            sha.update(intToBigEndianBytes(i));
            sha.update(intToBigEndianBytes(computeKeySeed() ^ 58));
            key = sha.digest();
         }

         return Arrays.copyOf(key, 16);
      } catch (Throwable var6) {
         return new byte[16];
      }
   }

   public static long deriveLegacyNumericKey(int classKey, String name) {
      try {
         byte[] key = deriveLegacyNumericKeyMaterial(classKey, name);
         long result = 0L;

         for(int i = 0; i < 8; ++i) {
            result = result << 8 | (long)(key[i] & 255);
         }

         return result;
      } catch (Throwable var6) {
         return 0L;
      }
   }

   private static byte[] deriveLegacyNumericKeyMaterial(int classKey, String name) {
      try {
         MessageDigest sha = MessageDigest.getInstance("SHA-256");
         sha.update(intToBigEndianBytes(classKey));
         sha.update(utf8Bytes(name));
         sha.update(intToBigEndianBytes(computeKeySeed() ^ 90));
         byte[] key = sha.digest();
         int rounds = computeKeyDerivationRounds(classKey, name) + 4;

         for(int i = 0; i < rounds; ++i) {
            sha = MessageDigest.getInstance("SHA-256");
            sha.update(key);
            sha.update(intToBigEndianBytes(i));
            sha.update(intToBigEndianBytes(computeKeySeed() ^ 199));
            key = sha.digest();
         }

         return key;
      } catch (Throwable var6) {
         return new byte[32];
      }
   }

   public static void setRuntimeSalt(int[] salt) {
      f_2_5537 = salt;
   }

   private static int[] getRuntimeSalt() {
      int[] s = f_2_5537;
      if (s == null) {
         s = f_3_3407;

         try {
            int[] reported = Arga.nativeSalt();
            if (reported != null && reported.length > 0) {
               s = reported;
            }
         } catch (Throwable var2) {
         }

         f_2_5537 = s;
      }

      return s;
   }

   private static byte[] deriveRuntimeKeyMaterial(int classKey, String name) throws Exception {
      MessageDigest sha = MessageDigest.getInstance("SHA-256");
      sha.update(intToBigEndianBytes(classKey));
      sha.update(utf8Bytes(name));
      sha.update(intToBigEndianBytes(computeKeySeed() ^ 125));
      int[] salt = getRuntimeSalt();

      for(int v : salt) {
         sha.update(intToBigEndianBytes(v));
      }

      byte[] key = sha.digest();
      int rounds = computeKeyDerivationRounds(classKey, name) + 2;

      for(int i = 0; i < rounds; ++i) {
         sha = MessageDigest.getInstance("SHA-256");
         sha.update(key);
         sha.update(intToBigEndianBytes(i));

         for(int v : salt) {
            sha.update(intToBigEndianBytes(v ^ i));
         }

         sha.update(intToBigEndianBytes(computeKeySeed() ^ 199));
         key = sha.digest();
      }

      return key;
   }

   public static byte[] deriveStringAesKey(int classKey, String name) {
      try {
         return Arrays.copyOf(deriveRuntimeKeyMaterial(classKey, name), 16);
      } catch (Throwable var3) {
         return new byte[16];
      }
   }

   public static long deriveConstantXorKey(int classKey, String name) {
      try {
         byte[] key = deriveRuntimeKeyMaterial(classKey, name);
         long result = 0L;

         for(int i = 0; i < 8; ++i) {
            result = result << 8 | (long)(key[i] & 255);
         }

         return result;
      } catch (Throwable var6) {
         return 0L;
      }
   }

   public static byte[] encryptClassBytes(byte[] baseKey, byte[] classBytes) {
      if (classBytes != null && classBytes.length != 0) {
         try {
            byte[] salt = new byte[16];
            (new SecureRandom()).nextBytes(salt);
            int nChunks = (classBytes.length + 4096 - 1) / 4096;
            ByteArrayOutputStream out = new ByteArrayOutputStream(classBytes.length + 128);
            out.write(f_4_66d3);
            writeLittleEndianShort(out, 1);
            writeLittleEndianInt(out, 4096);
            writeLittleEndianInt(out, classBytes.length);
            writeLittleEndianInt(out, nChunks);
            out.write(salt);
            byte[] prevCipher = new byte[0];

            for(int i = 0; i < nChunks; ++i) {
               int from = i * 4096;
               int to = Math.min(classBytes.length, from + 4096);
               byte[] piece = Arrays.copyOfRange(classBytes, from, to);
               byte[] key = deriveChunkAesKey(baseKey, salt, i, prevCipher);
               byte[] enc = cryptChunkAesCtr(key, piece, true);
               writeLittleEndianInt(out, enc.length);
               out.write(enc);
               prevCipher = enc;
            }

            return out.toByteArray();
         } catch (Throwable var12) {
            return new byte[0];
         }
      } else {
         return new byte[0];
      }
   }

   public static byte[] decryptClassStream(byte[] baseKey, InputStream in) throws IOException {
      byte[] header = readUpToLength(in, 34);
      if (header.length >= 34 && Arrays.equals((byte[])header, 0, 4, (byte[])f_4_66d3, 0, 4) && readUnsignedLittleEndianShort(header, 4) == 1) {
         int chunkSize = (int)readUnsignedLittleEndianInt(header, 6);
         int plainLen = (int)readUnsignedLittleEndianInt(header, 10);
         int nChunks = (int)readUnsignedLittleEndianInt(header, 14);
         if (chunkSize > 0 && plainLen >= 0 && nChunks > 0 && nChunks <= 1000000) {
            byte[] salt = Arrays.copyOfRange(header, 18, 34);
            ByteArrayOutputStream plain = new ByteArrayOutputStream(plainLen);
            byte[] prevCipher = new byte[0];

            try {
               for(int i = 0; i < nChunks; ++i) {
                  byte[] lenBuf = readUpToLength(in, 4);
                  if (lenBuf.length < 4) {
                     return null;
                  }

                  int encLen = (int)readUnsignedLittleEndianInt(lenBuf, 0);
                  if (encLen < 0 || encLen > chunkSize) {
                     return null;
                  }

                  byte[] enc = readUpToLength(in, encLen);
                  if (enc.length != encLen) {
                     return null;
                  }

                  byte[] key = deriveChunkAesKey(baseKey, salt, i, prevCipher);
                  byte[] piece = cryptChunkAesCtr(key, enc, false);
                  if (i == nChunks - 1 && plain.size() + piece.length != plainLen) {
                     return null;
                  }

                  plain.write(piece);
                  prevCipher = enc;
               }
            } catch (Throwable var15) {
               return null;
            }

            return plain.size() == plainLen ? plain.toByteArray() : null;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private static byte[] deriveChunkAesKey(byte[] baseKey, byte[] salt, int index, byte[] prevCipher) {
      try {
         MessageDigest sha = MessageDigest.getInstance("SHA-256");
         sha.update(salt);
         sha.update(intToBigEndianBytes(index));
         sha.update(baseKey);
         if (index > 0 && prevCipher != null) {
            sha.update(prevCipher);
         }

         sha.update(new byte[]{-34, -83});
         return Arrays.copyOf(sha.digest(), 16);
      } catch (Throwable var5) {
         return new byte[16];
      }
   }

   private static void writeLittleEndianShort(ByteArrayOutputStream out, int v) {
      out.write(v & 255);
      out.write(v >>> 8 & 255);
   }

   private static void writeLittleEndianInt(ByteArrayOutputStream out, int v) {
      out.write(v & 255);
      out.write(v >>> 8 & 255);
      out.write(v >>> 16 & 255);
      out.write(v >>> 24 & 255);
   }

   private static int readUnsignedLittleEndianShort(byte[] b, int off) {
      return b[off] & 255 | (b[off + 1] & 255) << 8;
   }

   private static long readUnsignedLittleEndianInt(byte[] b, int off) {
      return (long)b[off] & 255L | ((long)b[off + 1] & 255L) << 8 | ((long)b[off + 2] & 255L) << 16 | ((long)b[off + 3] & 255L) << 24;
   }

   private static byte[] readUpToLength(InputStream in, int len) throws IOException {
      byte[] buf = new byte[len];

      int n;
      for(int read = 0; read < len; read += n) {
         n = in.read(buf, read, len - read);
         if (n < 0) {
            return Arrays.copyOf(buf, read);
         }
      }

      return buf;
   }

   public static byte[] decryptAesCtr(byte[] aesKey, byte[] iv, byte[] input) {
      try {
         Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
         cipher.init(2, (Key)(new SecretKeySpec(aesKey, "AES")), (AlgorithmParameterSpec)(new IvParameterSpec(iv)));
         return cipher.doFinal(input);
      } catch (Throwable var4) {
         return new byte[0];
      }
   }

   public static byte[] cryptChunkAesCtr(byte[] aesKey, byte[] input, boolean encrypt) {
      try {
         byte[] iv = Arrays.copyOf(aesKey, 16);
         iv[0] = (byte)(iv[0] ^ 90);
         Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
         cipher.init(encrypt ? 1 : 2, (Key)(new SecretKeySpec(aesKey, "AES")), (AlgorithmParameterSpec)(new IvParameterSpec(iv)));
         return cipher.doFinal(input);
      } catch (Throwable var5) {
         return new byte[0];
      }
   }

   public static ClassLoader loader() {
      return RuntimeCipher.ProtectLoader.f_2_eea7;
   }

   public static String buildHashedClassResourcePath(String internalName) {
      try {
         MessageDigest sha = MessageDigest.getInstance("SHA-256");
         byte[] d = sha.digest((internalName + ".blob").getBytes(StandardCharsets.UTF_8));
         StringBuilder sb = new StringBuilder("shiza/zz/");

         for(int i = 0; i < 6; ++i) {
            int b = d[i] & 255;
            sb.append(f_7_f094[b >>> 4 & 15]).append(f_7_f094[b & 15]);
         }

         return sb.append(".shizaguard").toString();
      } catch (Throwable var6) {
         return internalName + ".shizaguard";
      }
   }

   public static String buildClassResourcePath(String internalName) {
      return internalName + ".shizaguard";
   }

   private static final class ProtectLoader extends ClassLoader {
      private static final String f_1_7b4a = "shiza/protect/jvm/Arga";
      private static final ProtectLoader f_2_eea7 = new ProtectLoader();
      private final ProtectionDomain f_3_653b;

      private ProtectLoader() {
         super(RuntimeCipher.class.getClassLoader());
         CodeSource cs = RuntimeCipher.class.getProtectionDomain().getCodeSource();
         this.f_3_653b = new ProtectionDomain(cs, (PermissionCollection)null);
      }

      protected Class<?> findClass(String name) throws ClassNotFoundException {
         String internal = name.replace('.', '/');
         if (!internal.startsWith("shiza/") && !internal.startsWith("wtf/anoxis/")) {
            throw new ClassNotFoundException(name);
         } else {
            byte[] classBytes = this.loadEncryptedClassResource(internal, RuntimeCipher.buildClassResourcePath(internal));
            if (classBytes == null && internal.startsWith("shiza/protect/")) {
               classBytes = this.loadEncryptedClassResource(internal, RuntimeCipher.buildHashedClassResourcePath(internal));
            }

            if (classBytes == null) {
               return null;
            } else if (internal.equals("shiza/protect/jvm/Arga")) {
               return this.defineClass(name, classBytes, 0, classBytes.length, this.f_3_653b);
            } else {
               Class<?> defined = Arga.defineClassSafely(this, internal, classBytes);
               return defined != null ? defined : this.defineClass(name, classBytes, 0, classBytes.length, this.f_3_653b);
            }
         }
      }

      private byte[] loadEncryptedClassResource(String internal, String path) {
         try (InputStream in = RuntimeCipher.class.getResourceAsStream("/" + path)) {
            if (in == null) {
               return null;
            } else {
               byte[] key = RuntimeCipher.deriveClassResourceKey(RuntimeCipher.computeClassKey(internal), internal);
               return RuntimeCipher.decryptClassStream(key, in);
            }
         } catch (Throwable var8) {
            return null;
         }
      }
   }
}
