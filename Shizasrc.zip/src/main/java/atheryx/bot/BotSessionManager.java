package atheryx.bot;

import atheryx.mixin.interfaces.IMinecraftClient;
import io.netty.channel.Channel;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.util.ReferenceCountUtil;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.class_1268;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2661;
import net.minecraft.class_2670;
import net.minecraft.class_2708;
import net.minecraft.class_2709;
import net.minecraft.class_2749;
import net.minecraft.class_2793;
import net.minecraft.class_2827;
import net.minecraft.class_2879;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_320;
import net.minecraft.class_412;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_634;
import net.minecraft.class_636;
import net.minecraft.class_6373;
import net.minecraft.class_6374;
import net.minecraft.class_638;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_746;
import net.minecraft.class_2828.class_2830;
import net.minecraft.class_2828.class_5911;
import net.minecraft.class_642.class_8678;
import atheryx.internal.RuntimeCipher;
import atheryx.event.EventHandler;
import atheryx.event.EventBus;
import atheryx.event.impl.UpdateEvent;


public final class BotSessionManager {
   public static final List<BotSessionManager.BotSession> connections = new ArrayList<>();
   private static final Map<BotSessionManager.BotSession, Integer> obf_u2209_u220e = new WeakHashMap<>();

   public static List<BotSessionManager.BotSession> getConnections() {

      return new ArrayList<>(connections);
   }

   public static void connectBot(String name, String address) {

      class_310 mc = class_310.method_1551();
      captureCurrentSession();
      ((IMinecraftClient)mc).setSession(createSessionWithName(mc.method_1548(), name));
      mc.execute(
         () -> {

            class_412.method_36877(
               new class_500(new class_442()), mc, class_639.method_2950(address), new class_642(address, address, class_8678.field_45611), false, null
            );
         }
      );
      connections.removeIf(
         b -> {

            return b.name().equalsIgnoreCase(name);
         }
      );
   }

   public static void interactAll(boolean rightClick) {

      for (BotSessionManager.BotSession bot : connections) {
         if (bot.handler() != null && bot.player() != null) {
            if (rightClick) {
               bot.handler().method_52787(new class_2886(class_1268.field_5808, 0, bot.player().method_36454(), bot.player().method_36455()));
            } else {
               bot.handler().method_52787(new class_2879(class_1268.field_5808));
            }
         }
      }
   }

   public static void sendMessageToAll(String message) {

      for (BotSessionManager.BotSession bot : connections) {
         if (bot.handler() != null) {
            if (message.startsWith(
               "/"
            )) {
               bot.handler().method_45730(message.substring(1));
            } else {
               bot.handler().method_45729(message);
            }
         }
      }
   }

   public static boolean controlBot(String name) {

      class_310 mc = class_310.method_1551();
      return connections.stream()
         .filter(
            b -> {

               return b.name().equalsIgnoreCase(name);
            }
         )
         .findFirst()
         .map(
            bot -> {

               captureCurrentSession();
               connections.remove(bot);
               Channel ch = findNetworkChannel(bot.connection());
               if (ch != null
                  && ch.pipeline()
                        .get(
                           "bot_filter"
                        )
                     != null) {
                  ch.pipeline()
                     .remove(
                        "bot_filter"
                     );
               }

               mc.field_1687 = bot.world();
               mc.field_1724 = bot.player();
               mc.method_1504(bot.player());
               mc.field_1761 = bot.interactionManager();

               try {
                  for (Field f : class_310.class.getDeclaredFields()) {
                     if ((class_634.class.isAssignableFrom(f.getType()) || f.getType().isAssignableFrom(class_634.class)) && f.getType() != Object.class) {
                        f.setAccessible(true);
                        f.set(mc, bot.handler());
                        break;
                     }
                  }
               } catch (Exception var7) {
               }

               if (mc.field_1769 != null) {
                  mc.field_1769.method_3244(bot.world());
                  mc.field_1769.method_3279();
               }

               ((IMinecraftClient)mc).setSession(createSessionWithName(mc.method_1548(), bot.name()));
               mc.method_1507(null);
               return true;
            }
         )
         .orElse(false);
   }

   private static void captureCurrentSession() {

      class_310 mc = class_310.method_1551();
      if (mc.method_1562() != null && mc.field_1687 != null) {
         class_634 h = mc.method_1562();
         installPacketFilter(h, mc.method_1548().method_1676(), mc.field_1724);
         connections.add(
            new BotSessionManager.BotSession(
               mc.method_1548().method_1676(),
               mc.method_1558() != null
                  ? mc.method_1558().field_3761
                  : "",
               h.method_48296(),
               h,
               mc.field_1687,
               mc.field_1724,
               mc.field_1761
            )
         );
         mc.field_1687 = null;
         mc.field_1724 = null;

         try {
            for (Field f : class_310.class.getDeclaredFields()) {
               if ((class_634.class.isAssignableFrom(f.getType()) || f.getType().isAssignableFrom(class_634.class)) && f.getType() != Object.class) {
                  f.setAccessible(true);
                  f.set(mc, null);
                  break;
               }
            }
         } catch (Exception var6) {
         }
      }
   }

   private static void installPacketFilter(class_634 handler, String name, class_746 botPlayer) {

      Channel channel = findNetworkChannel(handler.method_48296());
      if (channel != null) {
         channel.pipeline()
            .addBefore(
               "packet_handler",
               "bot_filter",
               new ChannelDuplexHandler()
       {
                  public void handleBotPacket(ChannelHandlerContext ctx, Object msg) throws Exception {

                     if (msg instanceof class_2708 p) {
                        class_310.method_1551()
                           .execute(
                              () -> {

                                 handler.method_48296().method_10743(new class_2793(p.comp_3133()));
                                 if (botPlayer != null) {
                                    double d = p.comp_3228().comp_3148().field_1352;
                                    double e = p.comp_3228().comp_3148().field_1351;
                                    double f = p.comp_3228().comp_3148().field_1350;
                                    float g = p.comp_3228().comp_3150();
                                    float h = p.comp_3228().comp_3151();
                                    if (p.comp_3229().contains(class_2709.field_12400)) {
                                       d += botPlayer.method_23317();
                                    }

                                    if (p.comp_3229().contains(class_2709.field_12398)) {
                                       e += botPlayer.method_23318();
                                    }

                                    if (p.comp_3229().contains(class_2709.field_12403)) {
                                       f += botPlayer.method_23321();
                                    }

                                    if (p.comp_3229().contains(class_2709.field_12401)) {
                                       g += botPlayer.method_36454();
                                    }

                                    if (p.comp_3229().contains(class_2709.field_12397)) {
                                       h += botPlayer.method_36455();
                                    }

                                    botPlayer.method_5814(d, e, f);
                                    botPlayer.method_36456(g);
                                    botPlayer.method_36457(h);
                                    handler.method_48296()
                                       .method_10743(
                                          new class_2830(
                                             botPlayer.method_23317(),
                                             botPlayer.method_23318(),
                                             botPlayer.method_23321(),
                                             botPlayer.method_36454(),
                                             botPlayer.method_36455(),
                                             botPlayer.method_24828(),
                                             botPlayer.field_5976
                                          )
                                       );

                                    for (BotSessionManager.BotSession b : BotSessionManager.connections) {
                                       if (b.player() == botPlayer) {
                                          BotSessionManager.obf_u2209_u220e.put(b, 0);
                                       }
                                    }
                                 }
                              }
                           );
                        ReferenceCountUtil.release(msg);
                     } else if (msg instanceof class_2749 p) {
                        class_310.method_1551()
                           .execute(
                              () -> {

                                 if (botPlayer != null) {
                                    botPlayer.method_6033(p.method_11833());
                                 }
                              }
                           );
                        ReferenceCountUtil.release(msg);
                     } else if (msg instanceof class_2661) {
                        BotSessionManager.connections
                           .removeIf(
                              b -> {

                                 return b.name().equalsIgnoreCase(name);
                              }
                           );
                        ctx.close();
                        ReferenceCountUtil.release(msg);
                     } else if (msg instanceof class_2670 p) {
                        this.getHandlerInternal().method_48296().method_10743(new class_2827(p.method_11517()));
                        ReferenceCountUtil.release(msg);
                     } else if (msg instanceof class_6373 p) {
                        this.getHandlerInternal().method_48296().method_10743(new class_6374(p.method_36950()));
                        ReferenceCountUtil.release(msg);
                     } else {
                        ReferenceCountUtil.release(msg);
                     }
                  }

                  private class_634 getHandlerInternal() {

                     return handler;
                  }

                  private class_746 getBotPlayerInternal() {

                     return botPlayer;
                  }

                  private String getNameInternal() {

                     return name;
                  }

               }
            );
      }
   }

   public static boolean sendMessageToBot(String n, String m) {

      return connections.stream()
         .filter(
            b -> {

               return b.name().equalsIgnoreCase(n);
            }
         )
         .findFirst()
         .map(
            b -> {

               if (m.startsWith(
                  "/"
               )) {
                  b.handler().method_45730(m.substring(1));
               } else {
                  b.handler().method_45729(m);
               }

               return true;
            }
         )
         .orElse(false);
   }

   public static boolean removeBot(String n) {

      return connections.removeIf(
         b -> {

            if (b.name().equalsIgnoreCase(n)) {
               b.connection()
                  .method_10747(
                     class_2561.method_43470(
                        "Removed"
                     )
                  );
               return true;
            } else {
               return false;
            }
         }
      );
   }

   public static boolean returnToPreviousSession() {

      return !connections.isEmpty() && controlBot(connections.get(connections.size() - 1).name());
   }

   private static Channel findNetworkChannel(class_2535 c) {

      try {
         for (Field f : class_2535.class.getDeclaredFields()) {
            if (Channel.class.isAssignableFrom(f.getType())) {
               f.setAccessible(true);
               return (Channel)f.get(c);
            }
         }
      } catch (Exception var5) {
      }

      return null;
   }

   private static class_320 createSessionWithName(class_320 current, String name) {

      try {
         Constructor<class_320> c = class_320.class.getDeclaredConstructor(String.class, UUID.class, String.class, Optional.class, Optional.class);
         c.setAccessible(true);
         return c.newInstance(name, UUID.randomUUID(), current.method_1674(), Optional.empty(), Optional.empty());
      } catch (Exception var3) {
         throw new RuntimeException(var3);
      }
   }

   static {
      EventBus.register(
         new Object()
    {
            @EventHandler
            public void onUpdate(UpdateEvent event) {

               for (BotSessionManager.BotSession bot : BotSessionManager.connections) {
                  if (bot.player() != null && bot.handler() != null && bot.connection() != null && bot.connection().method_10758()) {
                     int ticks = BotSessionManager.obf_u2209_u220e.getOrDefault(bot, 0) + 1;
                     if (ticks >= 20) {
                        bot.handler().method_48296().method_10743(new class_5911(bot.player().method_24828(), bot.player().field_5976));
                        ticks = 0;
                     }

                     BotSessionManager.obf_u2209_u220e.put(bot, ticks);
                  }
               }
            }

         }
      );
   }



   public record BotSession(String name, String address, class_2535 connection, class_634 handler, class_638 world, class_746 player, class_636 interactionManager) {

public String name() {

         return this.getNameInternal();
      }

      public String address() {

         return this.getAddressInternal();
      }

      public class_2535 connection() {

         return this.getConnectionInternal();
      }

      public class_634 handler() {

         return this.getHandlerInternal();
      }

      public class_638 world() {

         return this.getWorldInternal();
      }

      public class_746 player() {

         return this.getPlayerInternal();
      }

      public class_636 interactionManager() {

         return this.getInteractionManagerInternal();
      }

      private String getNameInternal() {

         return this.name;
      }

      private String getAddressInternal() {

         return this.address;
      }

      private class_2535 getConnectionInternal() {

         return this.connection;
      }

      private class_634 getHandlerInternal() {

         return this.handler;
      }

      private class_638 getWorldInternal() {

         return this.world;
      }

      private class_746 getPlayerInternal() {

         return this.player;
      }

      private class_636 getInteractionManagerInternal() {

         return this.interactionManager;
      }

   }
}
